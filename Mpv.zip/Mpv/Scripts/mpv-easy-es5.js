// ==UserScript==
// @name         mpv-easy-es5
// @version      0.1.9
// @description  An easy-to-use UI implemented with js
// @author       mpv-easy
// @downloadURL  https://github.com/mpv-easy/mpv-easy/releases/latest/download/mpv-easy-es5.js
// ==/UserScript==


"use strict";

var _excluded = ["prefix", "postfix", "text"],
  _excluded2 = ["tooltipThrottle"],
  _excluded3 = ["width", "height"],
  _excluded4 = ["items"];
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == _typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator.return && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, catch: function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function _objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = _objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var s = Object.getOwnPropertySymbols(e); for (r = 0; r < s.length; r++) o = s[r], t.includes(o) || {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function _objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (e.includes(n)) continue; t[n] = r[n]; } return t; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
function _toConsumableArray(r) { return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _iterableToArray(r) { if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r); }
function _arrayWithoutHoles(r) { if (Array.isArray(r)) return _arrayLikeToArray(r); }
function _slicedToArray(r, e) { return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(r) { if (Array.isArray(r)) return r; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function _defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o); } }
function _createClass(e, r, t) { return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _possibleConstructorReturn(t, e) { if (e && ("object" == _typeof(e) || "function" == typeof e)) return e; if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined"); return _assertThisInitialized(t); }
function _assertThisInitialized(e) { if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); return e; }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
function _getPrototypeOf(t) { return _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) { return t.__proto__ || Object.getPrototypeOf(t); }, _getPrototypeOf(t); }
function _inherits(t, e) { if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function"); t.prototype = Object.create(e && e.prototype, { constructor: { value: t, writable: !0, configurable: !0 } }), Object.defineProperty(t, "prototype", { writable: !1 }), e && _setPrototypeOf(t, e); }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (!t) { if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n2 = 0, F = function F() {}; return { s: F, n: function n() { return _n2 >= r.length ? { done: !0 } : { done: !1, value: r[_n2++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
(function (_Cr$console) {
  var $6 = Object.create;
  var Dv = Object.defineProperty;
  var V6 = Object.getOwnPropertyDescriptor;
  var W6 = Object.getOwnPropertyNames;
  var G6 = Object.getPrototypeOf,
    K6 = Object.prototype.hasOwnProperty;
  var h = function h(e, r) {
      return function () {
        return r || e((r = {
          exports: {}
        }).exports, r), r.exports;
      };
    },
    Ju = function Ju(e, r) {
      for (var t in r) Dv(e, t, {
        get: r[t],
        enumerable: !0
      });
    },
    Y6 = function Y6(e, r, t, i) {
      if (r && _typeof(r) == "object" || typeof r == "function") {
        var _iterator = _createForOfIteratorHelper(W6(r)),
          _step;
        try {
          var _loop = function _loop() {
            var a = _step.value;
            !K6.call(e, a) && a !== t && Dv(e, a, {
              get: function get() {
                return r[a];
              },
              enumerable: !(i = V6(r, a)) || i.enumerable
            });
          };
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            _loop();
          }
        } catch (err) {
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
      }
      return e;
    };
  var j = function j(e, r, t) {
    return t = e != null ? $6(G6(e)) : {}, Y6(r || !e || !e.__esModule ? Dv(t, "default", {
      value: e,
      enumerable: !0
    }) : t, e);
  };
  var ae = h(function (Bv, NE) {
    "use strict";

    var Zu = function Zu(e) {
      return e && e.Math === Math && e;
    };
    NE.exports = Zu((typeof globalThis === "undefined" ? "undefined" : _typeof(globalThis)) == "object" && globalThis) || Zu((typeof window === "undefined" ? "undefined" : _typeof(window)) == "object" && window) || Zu((typeof self === "undefined" ? "undefined" : _typeof(self)) == "object" && self) || Zu((typeof global === "undefined" ? "undefined" : _typeof(global)) == "object" && global) || Zu(_typeof(Bv) == "object" && Bv) || function () {
      return this;
    }() || Function("return this")();
  });
  var J = h(function (HSe, RE) {
    "use strict";

    RE.exports = function (e) {
      try {
        return !!e();
      } catch (_unused) {
        return !0;
      }
    };
  });
  var Xe = h(function ($Se, ME) {
    "use strict";

    var X6 = J();
    ME.exports = !X6(function () {
      return Object.defineProperty({}, 1, {
        get: function get() {
          return 7;
        }
      })[1] !== 7;
    });
  });
  var el = h(function (VSe, kE) {
    "use strict";

    var Q6 = J();
    kE.exports = !Q6(function () {
      var e = function () {}.bind();
      return typeof e != "function" || e.hasOwnProperty("prototype");
    });
  });
  var Oe = h(function (WSe, DE) {
    "use strict";

    var J6 = el(),
      Ff = Function.prototype.call;
    DE.exports = J6 ? Ff.bind(Ff) : function () {
      return Ff.apply(Ff, arguments);
    };
  });
  var Lf = h(function (LE) {
    "use strict";

    var BE = {}.propertyIsEnumerable,
      FE = Object.getOwnPropertyDescriptor,
      Z6 = FE && !BE.call({
        1: 2
      }, 1);
    LE.f = Z6 ? function (r) {
      var t = FE(this, r);
      return !!t && t.enumerable;
    } : BE;
  });
  var Vn = h(function (KSe, zE) {
    "use strict";

    zE.exports = function (e, r) {
      return {
        enumerable: !(e & 1),
        configurable: !(e & 2),
        writable: !(e & 4),
        value: r
      };
    };
  });
  var Q = h(function (YSe, HE) {
    "use strict";

    var jE = el(),
      UE = Function.prototype,
      Fv = UE.call,
      e$ = jE && UE.bind.bind(Fv, Fv);
    HE.exports = jE ? e$ : function (e) {
      return function () {
        return Fv.apply(e, arguments);
      };
    };
  });
  var Zt = h(function (XSe, VE) {
    "use strict";

    var $E = Q(),
      r$ = $E({}.toString),
      t$ = $E("".slice);
    VE.exports = function (e) {
      return t$(r$(e), 8, -1);
    };
  });
  var ts = h(function (QSe, WE) {
    "use strict";

    var n$ = Q(),
      o$ = J(),
      i$ = Zt(),
      Lv = Object,
      a$ = n$("".split);
    WE.exports = o$(function () {
      return !Lv("z").propertyIsEnumerable(0);
    }) ? function (e) {
      return i$(e) === "String" ? a$(e, "") : Lv(e);
    } : Lv;
  });
  var xt = h(function (JSe, GE) {
    "use strict";

    GE.exports = function (e) {
      return e == null;
    };
  });
  var er = h(function (ZSe, KE) {
    "use strict";

    var s$ = xt(),
      u$ = TypeError;
    KE.exports = function (e) {
      if (s$(e)) throw new u$("Can't call method on " + e);
      return e;
    };
  });
  var Wn = h(function (ebe, YE) {
    "use strict";

    var l$ = ts(),
      c$ = er();
    YE.exports = function (e) {
      return l$(c$(e));
    };
  });
  var Re = h(function (rbe, XE) {
    "use strict";

    var zv = (typeof document === "undefined" ? "undefined" : _typeof(document)) == "object" && document.all;
    XE.exports = _typeof(zv) > "u" && zv !== void 0 ? function (e) {
      return typeof e == "function" || e === zv;
    } : function (e) {
      return typeof e == "function";
    };
  });
  var nr = h(function (tbe, QE) {
    "use strict";

    var f$ = Re();
    QE.exports = function (e) {
      return _typeof(e) == "object" ? e !== null : f$(e);
    };
  });
  var ot = h(function (nbe, JE) {
    "use strict";

    var jv = ae(),
      p$ = Re(),
      d$ = function d$(e) {
        return p$(e) ? e : void 0;
      };
    JE.exports = function (e, r) {
      return arguments.length < 2 ? d$(jv[e]) : jv[e] && jv[e][r];
    };
  });
  var vo = h(function (obe, ZE) {
    "use strict";

    var m$ = Q();
    ZE.exports = m$({}.isPrototypeOf);
  });
  var go = h(function (ibe, eC) {
    "use strict";

    eC.exports = (typeof navigator === "undefined" ? "undefined" : _typeof(navigator)) < "u" && String(navigator.userAgent) || "";
  });
  var rl = h(function (abe, aC) {
    "use strict";

    var iC = ae(),
      Uv = go(),
      rC = iC.process,
      tC = iC.Deno,
      nC = rC && rC.versions || tC && tC.version,
      oC = nC && nC.v8,
      En,
      zf;
    oC && (En = oC.split("."), zf = En[0] > 0 && En[0] < 4 ? 1 : +(En[0] + En[1]));
    !zf && Uv && (En = Uv.match(/Edge\/(\d+)/), (!En || En[1] >= 74) && (En = Uv.match(/Chrome\/(\d+)/), En && (zf = +En[1])));
    aC.exports = zf;
  });
  var Hv = h(function (sbe, uC) {
    "use strict";

    var sC = rl(),
      h$ = J(),
      v$ = ae(),
      g$ = v$.String;
    uC.exports = !!Object.getOwnPropertySymbols && !h$(function () {
      var e = Symbol("symbol detection");
      return !g$(e) || !(Object(e) instanceof Symbol) || !Symbol.sham && sC && sC < 41;
    });
  });
  var $v = h(function (ube, lC) {
    "use strict";

    var y$ = Hv();
    lC.exports = y$ && !Symbol.sham && _typeof(Symbol.iterator) == "symbol";
  });
  var ns = h(function (lbe, cC) {
    "use strict";

    var x$ = ot(),
      S$ = Re(),
      b$ = vo(),
      w$ = $v(),
      E$ = Object;
    cC.exports = w$ ? function (e) {
      return _typeof(e) == "symbol";
    } : function (e) {
      var r = x$("Symbol");
      return S$(r) && b$(r.prototype, E$(e));
    };
  });
  var Ji = h(function (cbe, fC) {
    "use strict";

    var C$ = String;
    fC.exports = function (e) {
      try {
        return C$(e);
      } catch (_unused2) {
        return "Object";
      }
    };
  });
  var Xr = h(function (fbe, pC) {
    "use strict";

    var I$ = Re(),
      P$ = Ji(),
      q$ = TypeError;
    pC.exports = function (e) {
      if (I$(e)) return e;
      throw new q$(P$(e) + " is not a function");
    };
  });
  var Gn = h(function (pbe, dC) {
    "use strict";

    var T$ = Xr(),
      O$ = xt();
    dC.exports = function (e, r) {
      var t = e[r];
      return O$(t) ? void 0 : T$(t);
    };
  });
  var hC = h(function (dbe, mC) {
    "use strict";

    var Vv = Oe(),
      Wv = Re(),
      Gv = nr(),
      A$ = TypeError;
    mC.exports = function (e, r) {
      var t, i;
      if (r === "string" && Wv(t = e.toString) && !Gv(i = Vv(t, e)) || Wv(t = e.valueOf) && !Gv(i = Vv(t, e)) || r !== "string" && Wv(t = e.toString) && !Gv(i = Vv(t, e))) return i;
      throw new A$("Can't convert object to primitive value");
    };
  });
  var xr = h(function (mbe, vC) {
    "use strict";

    vC.exports = !1;
  });
  var jf = h(function (hbe, yC) {
    "use strict";

    var gC = ae(),
      _$ = Object.defineProperty;
    yC.exports = function (e, r) {
      try {
        _$(gC, e, {
          value: r,
          configurable: !0,
          writable: !0
        });
      } catch (_unused3) {
        gC[e] = r;
      }
      return r;
    };
  });
  var Uf = h(function (vbe, bC) {
    "use strict";

    var N$ = xr(),
      R$ = ae(),
      M$ = jf(),
      xC = "__core-js_shared__",
      SC = bC.exports = R$[xC] || M$(xC, {});
    (SC.versions || (SC.versions = [])).push({
      version: "3.37.1",
      mode: N$ ? "pure" : "global",
      copyright: "© 2014-2024 Denis Pushkarev (zloirock.ru)",
      license: "https://github.com/zloirock/core-js/blob/v3.37.1/LICENSE",
      source: "https://github.com/zloirock/core-js"
    });
  });
  var Hf = h(function (gbe, EC) {
    "use strict";

    var wC = Uf();
    EC.exports = function (e, r) {
      return wC[e] || (wC[e] = r || {});
    };
  });
  var Qr = h(function (ybe, CC) {
    "use strict";

    var k$ = er(),
      D$ = Object;
    CC.exports = function (e) {
      return D$(k$(e));
    };
  });
  var Sr = h(function (xbe, IC) {
    "use strict";

    var B$ = Q(),
      F$ = Qr(),
      L$ = B$({}.hasOwnProperty);
    IC.exports = Object.hasOwn || function (r, t) {
      return L$(F$(r), t);
    };
  });
  var os = h(function (Sbe, PC) {
    "use strict";

    var z$ = Q(),
      j$ = 0,
      U$ = Math.random(),
      H$ = z$(1 .toString);
    PC.exports = function (e) {
      return "Symbol(" + (e === void 0 ? "" : e) + ")_" + H$(++j$ + U$, 36);
    };
  });
  var Ue = h(function (bbe, TC) {
    "use strict";

    var $$ = ae(),
      V$ = Hf(),
      qC = Sr(),
      W$ = os(),
      G$ = Hv(),
      K$ = $v(),
      is = $$.Symbol,
      Kv = V$("wks"),
      Y$ = K$ ? is.for || is : is && is.withoutSetter || W$;
    TC.exports = function (e) {
      return qC(Kv, e) || (Kv[e] = G$ && qC(is, e) ? is[e] : Y$("Symbol." + e)), Kv[e];
    };
  });
  var $f = h(function (wbe, _C) {
    "use strict";

    var X$ = Oe(),
      OC = nr(),
      AC = ns(),
      Q$ = Gn(),
      J$ = hC(),
      Z$ = Ue(),
      e5 = TypeError,
      r5 = Z$("toPrimitive");
    _C.exports = function (e, r) {
      if (!OC(e) || AC(e)) return e;
      var t = Q$(e, r5),
        i;
      if (t) {
        if (r === void 0 && (r = "default"), i = X$(t, e, r), !OC(i) || AC(i)) return i;
        throw new e5("Can't convert object to primitive value");
      }
      return r === void 0 && (r = "number"), J$(e, r);
    };
  });
  var Vf = h(function (Ebe, NC) {
    "use strict";

    var t5 = $f(),
      n5 = ns();
    NC.exports = function (e) {
      var r = t5(e, "string");
      return n5(r) ? r : r + "";
    };
  });
  var tl = h(function (Cbe, MC) {
    "use strict";

    var o5 = ae(),
      RC = nr(),
      Yv = o5.document,
      i5 = RC(Yv) && RC(Yv.createElement);
    MC.exports = function (e) {
      return i5 ? Yv.createElement(e) : {};
    };
  });
  var Xv = h(function (Ibe, kC) {
    "use strict";

    var a5 = Xe(),
      s5 = J(),
      u5 = tl();
    kC.exports = !a5 && !s5(function () {
      return Object.defineProperty(u5("div"), "a", {
        get: function get() {
          return 7;
        }
      }).a !== 7;
    });
  });
  var Zi = h(function (BC) {
    "use strict";

    var l5 = Xe(),
      c5 = Oe(),
      f5 = Lf(),
      p5 = Vn(),
      d5 = Wn(),
      m5 = Vf(),
      h5 = Sr(),
      v5 = Xv(),
      DC = Object.getOwnPropertyDescriptor;
    BC.f = l5 ? DC : function (r, t) {
      if (r = d5(r), t = m5(t), v5) try {
        return DC(r, t);
      } catch (_unused4) {}
      if (h5(r, t)) return p5(!c5(f5.f, r, t), r[t]);
    };
  });
  var Qv = h(function (qbe, FC) {
    "use strict";

    var g5 = Xe(),
      y5 = J();
    FC.exports = g5 && y5(function () {
      return Object.defineProperty(function () {}, "prototype", {
        value: 42,
        writable: !1
      }).prototype !== 42;
    });
  });
  var rr = h(function (Tbe, LC) {
    "use strict";

    var x5 = nr(),
      S5 = String,
      b5 = TypeError;
    LC.exports = function (e) {
      if (x5(e)) return e;
      throw new b5(S5(e) + " is not an object");
    };
  });
  var it = h(function (jC) {
    "use strict";

    var w5 = Xe(),
      E5 = Xv(),
      C5 = Qv(),
      Wf = rr(),
      zC = Vf(),
      I5 = TypeError,
      Jv = Object.defineProperty,
      P5 = Object.getOwnPropertyDescriptor,
      Zv = "enumerable",
      eg = "configurable",
      rg = "writable";
    jC.f = w5 ? C5 ? function (r, t, i) {
      if (Wf(r), t = zC(t), Wf(i), typeof r == "function" && t === "prototype" && "value" in i && rg in i && !i[rg]) {
        var a = P5(r, t);
        a && a[rg] && (r[t] = i.value, i = {
          configurable: eg in i ? i[eg] : a[eg],
          enumerable: Zv in i ? i[Zv] : a[Zv],
          writable: !1
        });
      }
      return Jv(r, t, i);
    } : Jv : function (r, t, i) {
      if (Wf(r), t = zC(t), Wf(i), E5) try {
        return Jv(r, t, i);
      } catch (_unused5) {}
      if ("get" in i || "set" in i) throw new I5("Accessors not supported");
      return "value" in i && (r[t] = i.value), r;
    };
  });
  var Dt = h(function (Abe, UC) {
    "use strict";

    var q5 = Xe(),
      T5 = it(),
      O5 = Vn();
    UC.exports = q5 ? function (e, r, t) {
      return T5.f(e, r, O5(1, t));
    } : function (e, r, t) {
      return e[r] = t, e;
    };
  });
  var nl = h(function (_be, $C) {
    "use strict";

    var tg = Xe(),
      A5 = Sr(),
      HC = Function.prototype,
      _5 = tg && Object.getOwnPropertyDescriptor,
      ng = A5(HC, "name"),
      N5 = ng && function () {}.name === "something",
      R5 = ng && (!tg || tg && _5(HC, "name").configurable);
    $C.exports = {
      EXISTS: ng,
      PROPER: N5,
      CONFIGURABLE: R5
    };
  });
  var Gf = h(function (Nbe, VC) {
    "use strict";

    var M5 = Q(),
      k5 = Re(),
      og = Uf(),
      D5 = M5(Function.toString);
    k5(og.inspectSource) || (og.inspectSource = function (e) {
      return D5(e);
    });
    VC.exports = og.inspectSource;
  });
  var KC = h(function (Rbe, GC) {
    "use strict";

    var B5 = ae(),
      F5 = Re(),
      WC = B5.WeakMap;
    GC.exports = F5(WC) && /native code/.test(String(WC));
  });
  var Kf = h(function (Mbe, XC) {
    "use strict";

    var L5 = Hf(),
      z5 = os(),
      YC = L5("keys");
    XC.exports = function (e) {
      return YC[e] || (YC[e] = z5(e));
    };
  });
  var ol = h(function (kbe, QC) {
    "use strict";

    QC.exports = {};
  });
  var en = h(function (Dbe, e1) {
    "use strict";

    var j5 = KC(),
      ZC = ae(),
      U5 = nr(),
      H5 = Dt(),
      ig = Sr(),
      ag = Uf(),
      $5 = Kf(),
      V5 = ol(),
      JC = "Object already initialized",
      sg = ZC.TypeError,
      W5 = ZC.WeakMap,
      Yf,
      il,
      Xf,
      G5 = function G5(e) {
        return Xf(e) ? il(e) : Yf(e, {});
      },
      K5 = function K5(e) {
        return function (r) {
          var t;
          if (!U5(r) || (t = il(r)).type !== e) throw new sg("Incompatible receiver, " + e + " required");
          return t;
        };
      };
    j5 || ag.state ? (Cn = ag.state || (ag.state = new W5()), Cn.get = Cn.get, Cn.has = Cn.has, Cn.set = Cn.set, Yf = function Yf(e, r) {
      if (Cn.has(e)) throw new sg(JC);
      return r.facade = e, Cn.set(e, r), r;
    }, il = function il(e) {
      return Cn.get(e) || {};
    }, Xf = function Xf(e) {
      return Cn.has(e);
    }) : (ea = $5("state"), V5[ea] = !0, Yf = function Yf(e, r) {
      if (ig(e, ea)) throw new sg(JC);
      return r.facade = e, H5(e, ea, r), r;
    }, il = function il(e) {
      return ig(e, ea) ? e[ea] : {};
    }, Xf = function Xf(e) {
      return ig(e, ea);
    });
    var Cn, ea;
    e1.exports = {
      set: Yf,
      get: il,
      has: Xf,
      enforce: G5,
      getterFor: K5
    };
  });
  var cg = h(function (Bbe, n1) {
    "use strict";

    var lg = Q(),
      Y5 = J(),
      X5 = Re(),
      Qf = Sr(),
      ug = Xe(),
      Q5 = nl().CONFIGURABLE,
      J5 = Gf(),
      t1 = en(),
      Z5 = t1.enforce,
      eV = t1.get,
      r1 = String,
      Jf = Object.defineProperty,
      rV = lg("".slice),
      tV = lg("".replace),
      nV = lg([].join),
      oV = ug && !Y5(function () {
        return Jf(function () {}, "length", {
          value: 8
        }).length !== 8;
      }),
      iV = String(String).split("String"),
      aV = n1.exports = function (e, r, t) {
        rV(r1(r), 0, 7) === "Symbol(" && (r = "[" + tV(r1(r), /^Symbol\(([^)]*)\).*$/, "$1") + "]"), t && t.getter && (r = "get " + r), t && t.setter && (r = "set " + r), (!Qf(e, "name") || Q5 && e.name !== r) && (ug ? Jf(e, "name", {
          value: r,
          configurable: !0
        }) : e.name = r), oV && t && Qf(t, "arity") && e.length !== t.arity && Jf(e, "length", {
          value: t.arity
        });
        try {
          t && Qf(t, "constructor") && t.constructor ? ug && Jf(e, "prototype", {
            writable: !1
          }) : e.prototype && (e.prototype = void 0);
        } catch (_unused6) {}
        var i = Z5(e);
        return Qf(i, "source") || (i.source = nV(iV, typeof r == "string" ? r : "")), e;
      };
    Function.prototype.toString = aV(function () {
      return X5(this) && eV(this).source || J5(this);
    }, "toString");
  });
  var at = h(function (Fbe, o1) {
    "use strict";

    var sV = Re(),
      uV = it(),
      lV = cg(),
      cV = jf();
    o1.exports = function (e, r, t, i) {
      i || (i = {});
      var a = i.enumerable,
        s = i.name !== void 0 ? i.name : r;
      if (sV(t) && lV(t, s, i), i.global) a ? e[r] = t : cV(r, t);else {
        try {
          i.unsafe ? e[r] && (a = !0) : delete e[r];
        } catch (_unused7) {}
        a ? e[r] = t : uV.f(e, r, {
          value: t,
          enumerable: !1,
          configurable: !i.nonConfigurable,
          writable: !i.nonWritable
        });
      }
      return e;
    };
  });
  var a1 = h(function (Lbe, i1) {
    "use strict";

    var fV = Math.ceil,
      pV = Math.floor;
    i1.exports = Math.trunc || function (r) {
      var t = +r;
      return (t > 0 ? pV : fV)(t);
    };
  });
  var br = h(function (zbe, s1) {
    "use strict";

    var dV = a1();
    s1.exports = function (e) {
      var r = +e;
      return r !== r || r === 0 ? 0 : dV(r);
    };
  });
  var ra = h(function (jbe, u1) {
    "use strict";

    var mV = br(),
      hV = Math.max,
      vV = Math.min;
    u1.exports = function (e, r) {
      var t = mV(e);
      return t < 0 ? hV(t + r, 0) : vV(t, r);
    };
  });
  var St = h(function (Ube, l1) {
    "use strict";

    var gV = br(),
      yV = Math.min;
    l1.exports = function (e) {
      var r = gV(e);
      return r > 0 ? yV(r, 9007199254740991) : 0;
    };
  });
  var wr = h(function (Hbe, c1) {
    "use strict";

    var xV = St();
    c1.exports = function (e) {
      return xV(e.length);
    };
  });
  var al = h(function ($be, p1) {
    "use strict";

    var SV = Wn(),
      bV = ra(),
      wV = wr(),
      f1 = function f1(e) {
        return function (r, t, i) {
          var a = SV(r),
            s = wV(a);
          if (s === 0) return !e && -1;
          var l = bV(i, s),
            p;
          if (e && t !== t) {
            for (; s > l;) if (p = a[l++], p !== p) return !0;
          } else for (; s > l; l++) if ((e || l in a) && a[l] === t) return e || l || 0;
          return !e && -1;
        };
      };
    p1.exports = {
      includes: f1(!0),
      indexOf: f1(!1)
    };
  });
  var pg = h(function (Vbe, m1) {
    "use strict";

    var EV = Q(),
      fg = Sr(),
      CV = Wn(),
      IV = al().indexOf,
      PV = ol(),
      d1 = EV([].push);
    m1.exports = function (e, r) {
      var t = CV(e),
        i = 0,
        a = [],
        s;
      for (s in t) !fg(PV, s) && fg(t, s) && d1(a, s);
      for (; r.length > i;) fg(t, s = r[i++]) && (~IV(a, s) || d1(a, s));
      return a;
    };
  });
  var Zf = h(function (Wbe, h1) {
    "use strict";

    h1.exports = ["constructor", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "toLocaleString", "toString", "valueOf"];
  });
  var as = h(function (v1) {
    "use strict";

    var qV = pg(),
      TV = Zf(),
      OV = TV.concat("length", "prototype");
    v1.f = Object.getOwnPropertyNames || function (r) {
      return qV(r, OV);
    };
  });
  var dg = h(function (g1) {
    "use strict";

    g1.f = Object.getOwnPropertySymbols;
  });
  var x1 = h(function (Ybe, y1) {
    "use strict";

    var AV = ot(),
      _V = Q(),
      NV = as(),
      RV = dg(),
      MV = rr(),
      kV = _V([].concat);
    y1.exports = AV("Reflect", "ownKeys") || function (r) {
      var t = NV.f(MV(r)),
        i = RV.f;
      return i ? kV(t, i(r)) : t;
    };
  });
  var ep = h(function (Xbe, b1) {
    "use strict";

    var S1 = Sr(),
      DV = x1(),
      BV = Zi(),
      FV = it();
    b1.exports = function (e, r, t) {
      for (var i = DV(r), a = FV.f, s = BV.f, l = 0; l < i.length; l++) {
        var p = i[l];
        !S1(e, p) && !(t && S1(t, p)) && a(e, p, s(r, p));
      }
    };
  });
  var ul = h(function (Qbe, w1) {
    "use strict";

    var LV = J(),
      zV = Re(),
      jV = /#|\.prototype\./,
      sl = function sl(e, r) {
        var t = HV[UV(e)];
        return t === VV ? !0 : t === $V ? !1 : zV(r) ? LV(r) : !!r;
      },
      UV = sl.normalize = function (e) {
        return String(e).replace(jV, ".").toLowerCase();
      },
      HV = sl.data = {},
      $V = sl.NATIVE = "N",
      VV = sl.POLYFILL = "P";
    w1.exports = sl;
  });
  var F = h(function (Jbe, E1) {
    "use strict";

    var rp = ae(),
      WV = Zi().f,
      GV = Dt(),
      KV = at(),
      YV = jf(),
      XV = ep(),
      QV = ul();
    E1.exports = function (e, r) {
      var t = e.target,
        i = e.global,
        a = e.stat,
        s,
        l,
        p,
        d,
        v,
        g;
      if (i ? l = rp : a ? l = rp[t] || YV(t, {}) : l = rp[t] && rp[t].prototype, l) for (p in r) {
        if (v = r[p], e.dontCallGetSet ? (g = WV(l, p), d = g && g.value) : d = l[p], s = QV(i ? p : t + (a ? "." : "#") + p, e.forced), !s && d !== void 0) {
          if (_typeof(v) == _typeof(d)) continue;
          XV(v, d);
        }
        (e.sham || d && d.sham) && GV(v, "sham", !0), KV(l, p, v, e);
      }
    };
  });
  var ta = h(function (Zbe, C1) {
    "use strict";

    var JV = Zt(),
      ZV = Q();
    C1.exports = function (e) {
      if (JV(e) === "Function") return ZV(e);
    };
  });
  var yo = h(function (ewe, P1) {
    "use strict";

    var I1 = ta(),
      eW = Xr(),
      rW = el(),
      tW = I1(I1.bind);
    P1.exports = function (e, r) {
      return eW(e), r === void 0 ? e : rW ? tW(e, r) : function () {
        return e.apply(r, arguments);
      };
    };
  });
  var T1 = h(function (rwe, q1) {
    "use strict";

    var nW = Zt();
    q1.exports = Array.isArray || function (r) {
      return nW(r) === "Array";
    };
  });
  var tp = h(function (twe, A1) {
    "use strict";

    var oW = Ue(),
      iW = oW("toStringTag"),
      O1 = {};
    O1[iW] = "z";
    A1.exports = String(O1) === "[object z]";
  });
  var Kn = h(function (nwe, _1) {
    "use strict";

    var aW = tp(),
      sW = Re(),
      np = Zt(),
      uW = Ue(),
      lW = uW("toStringTag"),
      cW = Object,
      fW = np(function () {
        return arguments;
      }()) === "Arguments",
      pW = function pW(e, r) {
        try {
          return e[r];
        } catch (_unused8) {}
      };
    _1.exports = aW ? np : function (e) {
      var r, t, i;
      return e === void 0 ? "Undefined" : e === null ? "Null" : typeof (t = pW(r = cW(e), lW)) == "string" ? t : fW ? np(r) : (i = np(r)) === "Object" && sW(r.callee) ? "Arguments" : i;
    };
  });
  var cl = h(function (owe, D1) {
    "use strict";

    var dW = Q(),
      mW = J(),
      N1 = Re(),
      hW = Kn(),
      vW = ot(),
      gW = Gf(),
      R1 = function R1() {},
      M1 = vW("Reflect", "construct"),
      mg = /^\s*(?:class|function)\b/,
      yW = dW(mg.exec),
      xW = !mg.test(R1),
      ll = function ll(r) {
        if (!N1(r)) return !1;
        try {
          return M1(R1, [], r), !0;
        } catch (_unused9) {
          return !1;
        }
      },
      k1 = function k1(r) {
        if (!N1(r)) return !1;
        switch (hW(r)) {
          case "AsyncFunction":
          case "GeneratorFunction":
          case "AsyncGeneratorFunction":
            return !1;
        }
        try {
          return xW || !!yW(mg, gW(r));
        } catch (_unused10) {
          return !0;
        }
      };
    k1.sham = !0;
    D1.exports = !M1 || mW(function () {
      var e;
      return ll(ll.call) || !ll(Object) || !ll(function () {
        e = !0;
      }) || e;
    }) ? k1 : ll;
  });
  var z1 = h(function (iwe, L1) {
    "use strict";

    var B1 = T1(),
      SW = cl(),
      bW = nr(),
      wW = Ue(),
      EW = wW("species"),
      F1 = Array;
    L1.exports = function (e) {
      var r;
      return B1(e) && (r = e.constructor, SW(r) && (r === F1 || B1(r.prototype)) ? r = void 0 : bW(r) && (r = r[EW], r === null && (r = void 0))), r === void 0 ? F1 : r;
    };
  });
  var U1 = h(function (awe, j1) {
    "use strict";

    var CW = z1();
    j1.exports = function (e, r) {
      return new (CW(e))(r === 0 ? 0 : r);
    };
  });
  var bt = h(function (swe, $1) {
    "use strict";

    var IW = yo(),
      PW = Q(),
      qW = ts(),
      TW = Qr(),
      OW = wr(),
      AW = U1(),
      H1 = PW([].push),
      Ko = function Ko(e) {
        var r = e === 1,
          t = e === 2,
          i = e === 3,
          a = e === 4,
          s = e === 6,
          l = e === 7,
          p = e === 5 || s;
        return function (d, v, g, x) {
          for (var S = TW(d), b = qW(S), q = OW(b), E = IW(v, g), C = 0, T = x || AW, D = r ? T(d, q) : t || l ? T(d, 0) : void 0, M, k; q > C; C++) if ((p || C in b) && (M = b[C], k = E(M, C, S), e)) if (r) D[C] = k;else if (k) switch (e) {
            case 3:
              return !0;
            case 5:
              return M;
            case 6:
              return C;
            case 2:
              H1(D, M);
          } else switch (e) {
            case 4:
              return !1;
            case 7:
              H1(D, M);
          }
          return s ? -1 : i || a ? a : D;
        };
      };
    $1.exports = {
      forEach: Ko(0),
      map: Ko(1),
      filter: Ko(2),
      some: Ko(3),
      every: Ko(4),
      find: Ko(5),
      findIndex: Ko(6),
      filterReject: Ko(7)
    };
  });
  var fl = h(function (uwe, V1) {
    "use strict";

    var _W = J();
    V1.exports = function (e, r) {
      var t = [][e];
      return !!t && _W(function () {
        t.call(null, r || function () {
          return 1;
        }, 1);
      });
    };
  });
  var W1 = h(function () {
    "use strict";

    var NW = F(),
      RW = bt().every,
      MW = fl(),
      kW = MW("every");
    NW({
      target: "Array",
      proto: !0,
      forced: !kW
    }, {
      every: function every(r) {
        return RW(this, r, arguments.length > 1 ? arguments[1] : void 0);
      }
    });
  });
  var wt = h(function (fwe, G1) {
    "use strict";

    var DW = ae(),
      BW = Q();
    G1.exports = function (e, r) {
      return BW(DW[e].prototype[r]);
    };
  });
  var Y1 = h(function (pwe, K1) {
    "use strict";

    W1();
    var FW = wt();
    K1.exports = FW("Array", "every");
  });
  var Q1 = h(function (dwe, X1) {
    "use strict";

    var LW = Y1();
    X1.exports = LW;
  });
  var op = h(function (mwe, Z1) {
    "use strict";

    var zW = Qr(),
      J1 = ra(),
      jW = wr();
    Z1.exports = function (r) {
      for (var t = zW(this), i = jW(t), a = arguments.length, s = J1(a > 1 ? arguments[1] : void 0, i), l = a > 2 ? arguments[2] : void 0, p = l === void 0 ? i : J1(l, i); p > s;) t[s++] = r;
      return t;
    };
  });
  var pl = h(function (hwe, eI) {
    "use strict";

    var UW = pg(),
      HW = Zf();
    eI.exports = Object.keys || function (r) {
      return UW(r, HW);
    };
  });
  var tI = h(function (rI) {
    "use strict";

    var $W = Xe(),
      VW = Qv(),
      WW = it(),
      GW = rr(),
      KW = Wn(),
      YW = pl();
    rI.f = $W && !VW ? Object.defineProperties : function (r, t) {
      GW(r);
      for (var i = KW(t), a = YW(t), s = a.length, l = 0, p; s > l;) WW.f(r, p = a[l++], i[p]);
      return r;
    };
  });
  var hg = h(function (gwe, nI) {
    "use strict";

    var XW = ot();
    nI.exports = XW("document", "documentElement");
  });
  var xo = h(function (ywe, cI) {
    "use strict";

    var QW = rr(),
      JW = tI(),
      oI = Zf(),
      ZW = ol(),
      e7 = hg(),
      r7 = tl(),
      t7 = Kf(),
      iI = ">",
      aI = "<",
      gg = "prototype",
      yg = "script",
      uI = t7("IE_PROTO"),
      vg = function vg() {},
      lI = function lI(e) {
        return aI + yg + iI + e + aI + "/" + yg + iI;
      },
      sI = function sI(e) {
        e.write(lI("")), e.close();
        var r = e.parentWindow.Object;
        return e = null, r;
      },
      n7 = function n7() {
        var e = r7("iframe"),
          r = "java" + yg + ":",
          t;
        return e.style.display = "none", e7.appendChild(e), e.src = String(r), t = e.contentWindow.document, t.open(), t.write(lI("document.F=Object")), t.close(), t.F;
      },
      ip,
      _ap = function ap() {
        try {
          ip = new ActiveXObject("htmlfile");
        } catch (_unused11) {}
        _ap = (typeof document === "undefined" ? "undefined" : _typeof(document)) < "u" ? document.domain && ip ? sI(ip) : n7() : sI(ip);
        for (var e = oI.length; e--;) delete _ap[gg][oI[e]];
        return _ap();
      };
    ZW[uI] = !0;
    cI.exports = Object.create || function (r, t) {
      var i;
      return r !== null ? (vg[gg] = QW(r), i = new vg(), vg[gg] = null, i[uI] = r) : i = _ap(), t === void 0 ? i : JW.f(i, t);
    };
  });
  var So = h(function (xwe, fI) {
    "use strict";

    var o7 = Ue(),
      i7 = xo(),
      a7 = it().f,
      xg = o7("unscopables"),
      Sg = Array.prototype;
    Sg[xg] === void 0 && a7(Sg, xg, {
      configurable: !0,
      value: i7(null)
    });
    fI.exports = function (e) {
      Sg[xg][e] = !0;
    };
  });
  var pI = h(function () {
    "use strict";

    var s7 = F(),
      u7 = op(),
      l7 = So();
    s7({
      target: "Array",
      proto: !0
    }, {
      fill: u7
    });
    l7("fill");
  });
  var mI = h(function (wwe, dI) {
    "use strict";

    pI();
    var c7 = wt();
    dI.exports = c7("Array", "fill");
  });
  var vI = h(function (Ewe, hI) {
    "use strict";

    var f7 = mI();
    hI.exports = f7;
  });
  var yI = h(function () {
    "use strict";

    var p7 = F(),
      d7 = bt().findIndex,
      m7 = So(),
      bg = "findIndex",
      gI = !0;
    bg in [] && Array(1)[bg](function () {
      gI = !1;
    });
    p7({
      target: "Array",
      proto: !0,
      forced: gI
    }, {
      findIndex: function findIndex(r) {
        return d7(this, r, arguments.length > 1 ? arguments[1] : void 0);
      }
    });
    m7(bg);
  });
  var SI = h(function (Pwe, xI) {
    "use strict";

    yI();
    var h7 = wt();
    xI.exports = h7("Array", "findIndex");
  });
  var wI = h(function (qwe, bI) {
    "use strict";

    var v7 = SI();
    bI.exports = v7;
  });
  var CI = h(function () {
    "use strict";

    var g7 = F(),
      y7 = bt().find,
      x7 = So(),
      wg = "find",
      EI = !0;
    wg in [] && Array(1)[wg](function () {
      EI = !1;
    });
    g7({
      target: "Array",
      proto: !0,
      forced: EI
    }, {
      find: function find(r) {
        return y7(this, r, arguments.length > 1 ? arguments[1] : void 0);
      }
    });
    x7(wg);
  });
  var PI = h(function (Awe, II) {
    "use strict";

    CI();
    var S7 = wt();
    II.exports = S7("Array", "find");
  });
  var TI = h(function (_we, qI) {
    "use strict";

    var b7 = PI();
    qI.exports = b7;
  });
  var dl = h(function (Nwe, AI) {
    "use strict";

    var w7 = yo(),
      E7 = ts(),
      C7 = Qr(),
      I7 = wr(),
      OI = function OI(e) {
        var r = e === 1;
        return function (t, i, a) {
          for (var s = C7(t), l = E7(s), p = I7(l), d = w7(i, a), v, g; p-- > 0;) if (v = l[p], g = d(v, p, s), g) switch (e) {
            case 0:
              return v;
            case 1:
              return p;
          }
          return r ? -1 : void 0;
        };
      };
    AI.exports = {
      findLast: OI(0),
      findLastIndex: OI(1)
    };
  });
  var _I = h(function () {
    "use strict";

    var P7 = F(),
      q7 = dl().findLast,
      T7 = So();
    P7({
      target: "Array",
      proto: !0
    }, {
      findLast: function findLast(r) {
        return q7(this, r, arguments.length > 1 ? arguments[1] : void 0);
      }
    });
    T7("findLast");
  });
  var RI = h(function (kwe, NI) {
    "use strict";

    _I();
    var O7 = wt();
    NI.exports = O7("Array", "findLast");
  });
  var kI = h(function (Dwe, MI) {
    "use strict";

    MI.exports = RI();
  });
  var sp = h(function (Bwe, DI) {
    "use strict";

    DI.exports = (typeof ArrayBuffer === "undefined" ? "undefined" : _typeof(ArrayBuffer)) < "u" && (typeof DataView === "undefined" ? "undefined" : _typeof(DataView)) < "u";
  });
  var Yo = h(function (Fwe, FI) {
    "use strict";

    var BI = cg(),
      A7 = it();
    FI.exports = function (e, r, t) {
      return t.get && BI(t.get, r, {
        getter: !0
      }), t.set && BI(t.set, r, {
        setter: !0
      }), A7.f(e, r, t);
    };
  });
  var Eg = h(function (Lwe, LI) {
    "use strict";

    var _7 = at();
    LI.exports = function (e, r, t) {
      for (var i in r) _7(e, i, r[i], t);
      return e;
    };
  });
  var Xo = h(function (zwe, zI) {
    "use strict";

    var N7 = vo(),
      R7 = TypeError;
    zI.exports = function (e, r) {
      if (N7(r, e)) return e;
      throw new R7("Incorrect invocation");
    };
  });
  var up = h(function (jwe, jI) {
    "use strict";

    var M7 = br(),
      k7 = St(),
      D7 = RangeError;
    jI.exports = function (e) {
      if (e === void 0) return 0;
      var r = M7(e),
        t = k7(r);
      if (r !== t) throw new D7("Wrong length or index");
      return t;
    };
  });
  var HI = h(function (Uwe, UI) {
    "use strict";

    UI.exports = Math.sign || function (r) {
      var t = +r;
      return t === 0 || t !== t ? t : t < 0 ? -1 : 1;
    };
  });
  var GI = h(function (Hwe, WI) {
    "use strict";

    var B7 = HI(),
      F7 = Math.abs,
      VI = 2220446049250313e-31,
      $I = 1 / VI,
      L7 = function L7(e) {
        return e + $I - $I;
      };
    WI.exports = function (e, r, t, i) {
      var a = +e,
        s = F7(a),
        l = B7(a);
      if (s < i) return l * L7(s / i / r) * i * r;
      var p = (1 + r / VI) * s,
        d = p - (p - s);
      return d > t || d !== d ? l * (1 / 0) : l * d;
    };
  });
  var YI = h(function ($we, KI) {
    "use strict";

    var z7 = GI(),
      j7 = 11920928955078125e-23,
      U7 = 34028234663852886e22,
      H7 = 11754943508222875e-54;
    KI.exports = Math.fround || function (r) {
      return z7(r, j7, U7, H7);
    };
  });
  var QI = h(function (Vwe, XI) {
    "use strict";

    var $7 = Array,
      V7 = Math.abs,
      bo = Math.pow,
      W7 = Math.floor,
      G7 = Math.log,
      K7 = Math.LN2,
      Y7 = function Y7(e, r, t) {
        var i = $7(t),
          a = t * 8 - r - 1,
          s = (1 << a) - 1,
          l = s >> 1,
          p = r === 23 ? bo(2, -24) - bo(2, -77) : 0,
          d = e < 0 || e === 0 && 1 / e < 0 ? 1 : 0,
          v = 0,
          g,
          x,
          S;
        for (e = V7(e), e !== e || e === 1 / 0 ? (x = e !== e ? 1 : 0, g = s) : (g = W7(G7(e) / K7), S = bo(2, -g), e * S < 1 && (g--, S *= 2), g + l >= 1 ? e += p / S : e += p * bo(2, 1 - l), e * S >= 2 && (g++, S /= 2), g + l >= s ? (x = 0, g = s) : g + l >= 1 ? (x = (e * S - 1) * bo(2, r), g += l) : (x = e * bo(2, l - 1) * bo(2, r), g = 0)); r >= 8;) i[v++] = x & 255, x /= 256, r -= 8;
        for (g = g << r | x, a += r; a > 0;) i[v++] = g & 255, g /= 256, a -= 8;
        return i[--v] |= d * 128, i;
      },
      X7 = function X7(e, r) {
        var t = e.length,
          i = t * 8 - r - 1,
          a = (1 << i) - 1,
          s = a >> 1,
          l = i - 7,
          p = t - 1,
          d = e[p--],
          v = d & 127,
          g;
        for (d >>= 7; l > 0;) v = v * 256 + e[p--], l -= 8;
        for (g = v & (1 << -l) - 1, v >>= -l, l += r; l > 0;) g = g * 256 + e[p--], l -= 8;
        if (v === 0) v = 1 - s;else {
          if (v === a) return g ? NaN : d ? -1 / 0 : 1 / 0;
          g += bo(2, r), v -= s;
        }
        return (d ? -1 : 1) * g * bo(2, v - r);
      };
    XI.exports = {
      pack: Y7,
      unpack: X7
    };
  });
  var ZI = h(function (Wwe, JI) {
    "use strict";

    var Q7 = J();
    JI.exports = !Q7(function () {
      function e() {}
      return e.prototype.constructor = null, Object.getPrototypeOf(new e()) !== e.prototype;
    });
  });
  var na = h(function (Gwe, rP) {
    "use strict";

    var J7 = Sr(),
      Z7 = Re(),
      eG = Qr(),
      rG = Kf(),
      tG = ZI(),
      eP = rG("IE_PROTO"),
      Cg = Object,
      nG = Cg.prototype;
    rP.exports = tG ? Cg.getPrototypeOf : function (e) {
      var r = eG(e);
      if (J7(r, eP)) return r[eP];
      var t = r.constructor;
      return Z7(t) && r instanceof t ? t.prototype : r instanceof Cg ? nG : null;
    };
  });
  var ml = h(function (Kwe, tP) {
    "use strict";

    var oG = Q(),
      iG = Xr();
    tP.exports = function (e, r, t) {
      try {
        return oG(iG(Object.getOwnPropertyDescriptor(e, r)[t]));
      } catch (_unused12) {}
    };
  });
  var oP = h(function (Ywe, nP) {
    "use strict";

    var aG = nr();
    nP.exports = function (e) {
      return aG(e) || e === null;
    };
  });
  var aP = h(function (Xwe, iP) {
    "use strict";

    var sG = oP(),
      uG = String,
      lG = TypeError;
    iP.exports = function (e) {
      if (sG(e)) return e;
      throw new lG("Can't set " + uG(e) + " as a prototype");
    };
  });
  var Qo = h(function (Qwe, sP) {
    "use strict";

    var cG = ml(),
      fG = nr(),
      pG = er(),
      dG = aP();
    sP.exports = Object.setPrototypeOf || ("__proto__" in {} ? function () {
      var e = !1,
        r = {},
        t;
      try {
        t = cG(Object.prototype, "__proto__", "set"), t(r, []), e = r instanceof Array;
      } catch (_unused13) {}
      return function (a, s) {
        return pG(a), dG(s), fG(a) && (e ? t(a, s) : a.__proto__ = s), a;
      };
    }() : void 0);
  });
  var oa = h(function (Jwe, uP) {
    "use strict";

    var mG = Q();
    uP.exports = mG([].slice);
  });
  var ss = h(function (Zwe, cP) {
    "use strict";

    var hG = Re(),
      vG = nr(),
      lP = Qo();
    cP.exports = function (e, r, t) {
      var i, a;
      return lP && hG(i = r.constructor) && i !== t && vG(a = i.prototype) && a !== t.prototype && lP(e, a), e;
    };
  });
  var Jo = h(function (eEe, pP) {
    "use strict";

    var gG = it().f,
      yG = Sr(),
      xG = Ue(),
      fP = xG("toStringTag");
    pP.exports = function (e, r, t) {
      e && !t && (e = e.prototype), e && !yG(e, fP) && gG(e, fP, {
        configurable: !0,
        value: r
      });
    };
  });
  var gl = h(function (rEe, OP) {
    "use strict";

    var dp = ae(),
      Og = Q(),
      Ig = Xe(),
      SG = sp(),
      CP = nl(),
      bG = Dt(),
      wG = Yo(),
      dP = Eg(),
      Pg = J(),
      lp = Xo(),
      EG = br(),
      CG = St(),
      fp = up(),
      IG = YI(),
      IP = QI(),
      PG = na(),
      mP = Qo(),
      qG = op(),
      TG = oa(),
      OG = ss(),
      AG = ep(),
      PP = Jo(),
      Ag = en(),
      _G = CP.PROPER,
      hP = CP.CONFIGURABLE,
      ls = "ArrayBuffer",
      mp = "DataView",
      cs = "prototype",
      NG = "Wrong length",
      qP = "Wrong index",
      vP = Ag.getterFor(ls),
      vl = Ag.getterFor(mp),
      gP = Ag.set,
      In = dp[ls],
      _Bt = In,
      us = _Bt && _Bt[cs],
      Yn = dp[mp],
      ia = Yn && Yn[cs],
      yP = Object.prototype,
      RG = dp.Array,
      pp = dp.RangeError,
      MG = Og(qG),
      kG = Og([].reverse),
      TP = IP.pack,
      xP = IP.unpack,
      SP = function SP(e) {
        return [e & 255];
      },
      bP = function bP(e) {
        return [e & 255, e >> 8 & 255];
      },
      wP = function wP(e) {
        return [e & 255, e >> 8 & 255, e >> 16 & 255, e >> 24 & 255];
      },
      EP = function EP(e) {
        return e[3] << 24 | e[2] << 16 | e[1] << 8 | e[0];
      },
      DG = function DG(e) {
        return TP(IG(e), 23, 4);
      },
      BG = function BG(e) {
        return TP(e, 52, 8);
      },
      cp = function cp(e, r, t) {
        wG(e[cs], r, {
          configurable: !0,
          get: function get() {
            return t(this)[r];
          }
        });
      },
      Zo = function Zo(e, r, t, i) {
        var a = vl(e),
          s = fp(t),
          l = !!i;
        if (s + r > a.byteLength) throw new pp(qP);
        var p = a.bytes,
          d = s + a.byteOffset,
          v = TG(p, d, d + r);
        return l ? v : kG(v);
      },
      ei = function ei(e, r, t, i, a, s) {
        var l = vl(e),
          p = fp(t),
          d = i(+a),
          v = !!s;
        if (p + r > l.byteLength) throw new pp(qP);
        for (var g = l.bytes, x = p + l.byteOffset, S = 0; S < r; S++) g[x + S] = d[v ? S : r - S - 1];
      };
    SG ? (qg = _G && In.name !== ls, !Pg(function () {
      In(1);
    }) || !Pg(function () {
      new In(-1);
    }) || Pg(function () {
      return new In(), new In(1.5), new In(NaN), In.length !== 1 || qg && !hP;
    }) ? (_Bt = function Bt(r) {
      return lp(this, us), OG(new In(fp(r)), this, _Bt);
    }, _Bt[cs] = us, us.constructor = _Bt, AG(_Bt, In)) : qg && hP && bG(In, "name", ls), mP && PG(ia) !== yP && mP(ia, yP), hl = new Yn(new _Bt(2)), Tg = Og(ia.setInt8), hl.setInt8(0, 2147483648), hl.setInt8(1, 2147483649), (hl.getInt8(0) || !hl.getInt8(1)) && dP(ia, {
      setInt8: function setInt8(r, t) {
        Tg(this, r, t << 24 >> 24);
      },
      setUint8: function setUint8(r, t) {
        Tg(this, r, t << 24 >> 24);
      }
    }, {
      unsafe: !0
    })) : (_Bt = function _Bt(r) {
      lp(this, us);
      var t = fp(r);
      gP(this, {
        type: ls,
        bytes: MG(RG(t), 0),
        byteLength: t
      }), Ig || (this.byteLength = t, this.detached = !1);
    }, us = _Bt[cs], Yn = function Yn(r, t, i) {
      lp(this, ia), lp(r, us);
      var a = vP(r),
        s = a.byteLength,
        l = EG(t);
      if (l < 0 || l > s) throw new pp("Wrong offset");
      if (i = i === void 0 ? s - l : CG(i), l + i > s) throw new pp(NG);
      gP(this, {
        type: mp,
        buffer: r,
        byteLength: i,
        byteOffset: l,
        bytes: a.bytes
      }), Ig || (this.buffer = r, this.byteLength = i, this.byteOffset = l);
    }, ia = Yn[cs], Ig && (cp(_Bt, "byteLength", vP), cp(Yn, "buffer", vl), cp(Yn, "byteLength", vl), cp(Yn, "byteOffset", vl)), dP(ia, {
      getInt8: function getInt8(r) {
        return Zo(this, 1, r)[0] << 24 >> 24;
      },
      getUint8: function getUint8(r) {
        return Zo(this, 1, r)[0];
      },
      getInt16: function getInt16(r) {
        var t = Zo(this, 2, r, arguments.length > 1 ? arguments[1] : !1);
        return (t[1] << 8 | t[0]) << 16 >> 16;
      },
      getUint16: function getUint16(r) {
        var t = Zo(this, 2, r, arguments.length > 1 ? arguments[1] : !1);
        return t[1] << 8 | t[0];
      },
      getInt32: function getInt32(r) {
        return EP(Zo(this, 4, r, arguments.length > 1 ? arguments[1] : !1));
      },
      getUint32: function getUint32(r) {
        return EP(Zo(this, 4, r, arguments.length > 1 ? arguments[1] : !1)) >>> 0;
      },
      getFloat32: function getFloat32(r) {
        return xP(Zo(this, 4, r, arguments.length > 1 ? arguments[1] : !1), 23);
      },
      getFloat64: function getFloat64(r) {
        return xP(Zo(this, 8, r, arguments.length > 1 ? arguments[1] : !1), 52);
      },
      setInt8: function setInt8(r, t) {
        ei(this, 1, r, SP, t);
      },
      setUint8: function setUint8(r, t) {
        ei(this, 1, r, SP, t);
      },
      setInt16: function setInt16(r, t) {
        ei(this, 2, r, bP, t, arguments.length > 2 ? arguments[2] : !1);
      },
      setUint16: function setUint16(r, t) {
        ei(this, 2, r, bP, t, arguments.length > 2 ? arguments[2] : !1);
      },
      setInt32: function setInt32(r, t) {
        ei(this, 4, r, wP, t, arguments.length > 2 ? arguments[2] : !1);
      },
      setUint32: function setUint32(r, t) {
        ei(this, 4, r, wP, t, arguments.length > 2 ? arguments[2] : !1);
      },
      setFloat32: function setFloat32(r, t) {
        ei(this, 4, r, DG, t, arguments.length > 2 ? arguments[2] : !1);
      },
      setFloat64: function setFloat64(r, t) {
        ei(this, 8, r, BG, t, arguments.length > 2 ? arguments[2] : !1);
      }
    }));
    var qg, hl, Tg;
    PP(_Bt, ls);
    PP(Yn, mp);
    OP.exports = {
      ArrayBuffer: _Bt,
      DataView: Yn
    };
  });
  var yl = h(function (tEe, _P) {
    "use strict";

    var FG = ot(),
      LG = Yo(),
      zG = Ue(),
      jG = Xe(),
      AP = zG("species");
    _P.exports = function (e) {
      var r = FG(e);
      jG && r && !r[AP] && LG(r, AP, {
        configurable: !0,
        get: function get() {
          return this;
        }
      });
    };
  });
  var RP = h(function () {
    "use strict";

    var UG = F(),
      HG = ae(),
      $G = gl(),
      VG = yl(),
      _g = "ArrayBuffer",
      NP = $G[_g],
      WG = HG[_g];
    UG({
      global: !0,
      constructor: !0,
      forced: WG !== NP
    }, {
      ArrayBuffer: NP
    });
    VG(_g);
  });
  var xe = h(function (iEe, HP) {
    "use strict";

    var GG = sp(),
      kg = Xe(),
      st = ae(),
      BP = Re(),
      gp = nr(),
      ti = Sr(),
      Dg = Kn(),
      KG = Ji(),
      YG = Dt(),
      Ng = at(),
      XG = Yo(),
      QG = vo(),
      yp = na(),
      ps = Qo(),
      JG = Ue(),
      ZG = os(),
      FP = en(),
      LP = FP.enforce,
      eK = FP.get,
      hp = st.Int8Array,
      Rg = hp && hp.prototype,
      MP = st.Uint8ClampedArray,
      kP = MP && MP.prototype,
      Xn = hp && yp(hp),
      Pn = Rg && yp(Rg),
      rK = Object.prototype,
      Bg = st.TypeError,
      DP = JG("toStringTag"),
      Mg = ZG("TYPED_ARRAY_TAG"),
      vp = "TypedArrayConstructor",
      wo = GG && !!ps && Dg(st.opera) !== "Opera",
      zP = !1,
      Et,
      ri,
      fs,
      Eo = {
        Int8Array: 1,
        Uint8Array: 1,
        Uint8ClampedArray: 1,
        Int16Array: 2,
        Uint16Array: 2,
        Int32Array: 4,
        Uint32Array: 4,
        Float32Array: 4,
        Float64Array: 8
      },
      Fg = {
        BigInt64Array: 8,
        BigUint64Array: 8
      },
      tK = function tK(r) {
        if (!gp(r)) return !1;
        var t = Dg(r);
        return t === "DataView" || ti(Eo, t) || ti(Fg, t);
      },
      _jP = function jP(e) {
        var r = yp(e);
        if (gp(r)) {
          var t = eK(r);
          return t && ti(t, vp) ? t[vp] : _jP(r);
        }
      },
      UP = function UP(e) {
        if (!gp(e)) return !1;
        var r = Dg(e);
        return ti(Eo, r) || ti(Fg, r);
      },
      nK = function nK(e) {
        if (UP(e)) return e;
        throw new Bg("Target is not a typed array");
      },
      oK = function oK(e) {
        if (BP(e) && (!ps || QG(Xn, e))) return e;
        throw new Bg(KG(e) + " is not a typed array constructor");
      },
      iK = function iK(e, r, t, i) {
        if (kg) {
          if (t) for (var a in Eo) {
            var s = st[a];
            if (s && ti(s.prototype, e)) try {
              delete s.prototype[e];
            } catch (_unused14) {
              try {
                s.prototype[e] = r;
              } catch (_unused15) {}
            }
          }
          (!Pn[e] || t) && Ng(Pn, e, t ? r : wo && Rg[e] || r, i);
        }
      },
      aK = function aK(e, r, t) {
        var i, a;
        if (kg) {
          if (ps) {
            if (t) {
              for (i in Eo) if (a = st[i], a && ti(a, e)) try {
                delete a[e];
              } catch (_unused16) {}
            }
            if (!Xn[e] || t) try {
              return Ng(Xn, e, t ? r : wo && Xn[e] || r);
            } catch (_unused17) {} else return;
          }
          for (i in Eo) a = st[i], a && (!a[e] || t) && Ng(a, e, r);
        }
      };
    for (Et in Eo) ri = st[Et], fs = ri && ri.prototype, fs ? LP(fs)[vp] = ri : wo = !1;
    for (Et in Fg) ri = st[Et], fs = ri && ri.prototype, fs && (LP(fs)[vp] = ri);
    if ((!wo || !BP(Xn) || Xn === Function.prototype) && (Xn = function Xn() {
      throw new Bg("Incorrect invocation");
    }, wo)) for (Et in Eo) st[Et] && ps(st[Et], Xn);
    if ((!wo || !Pn || Pn === rK) && (Pn = Xn.prototype, wo)) for (Et in Eo) st[Et] && ps(st[Et].prototype, Pn);
    wo && yp(kP) !== Pn && ps(kP, Pn);
    if (kg && !ti(Pn, DP)) {
      zP = !0, XG(Pn, DP, {
        configurable: !0,
        get: function get() {
          return gp(this) ? this[Mg] : void 0;
        }
      });
      for (Et in Eo) st[Et] && YG(st[Et], Mg, Et);
    }
    HP.exports = {
      NATIVE_ARRAY_BUFFER_VIEWS: wo,
      TYPED_ARRAY_TAG: zP && Mg,
      aTypedArray: nK,
      aTypedArrayConstructor: oK,
      exportTypedArrayMethod: iK,
      exportTypedArrayStaticMethod: aK,
      getTypedArrayConstructor: _jP,
      isView: tK,
      isTypedArray: UP,
      TypedArray: Xn,
      TypedArrayPrototype: Pn
    };
  });
  var VP = h(function () {
    "use strict";

    var sK = F(),
      $P = xe(),
      uK = $P.NATIVE_ARRAY_BUFFER_VIEWS;
    sK({
      target: "ArrayBuffer",
      stat: !0,
      forced: !uK
    }, {
      isView: $P.isView
    });
  });
  var Lg = h(function (uEe, WP) {
    "use strict";

    var lK = cl(),
      cK = Ji(),
      fK = TypeError;
    WP.exports = function (e) {
      if (lK(e)) return e;
      throw new fK(cK(e) + " is not a constructor");
    };
  });
  var aa = h(function (lEe, KP) {
    "use strict";

    var GP = rr(),
      pK = Lg(),
      dK = xt(),
      mK = Ue(),
      hK = mK("species");
    KP.exports = function (e, r) {
      var t = GP(e).constructor,
        i;
      return t === void 0 || dK(i = GP(t)[hK]) ? r : pK(i);
    };
  });
  var eq = h(function () {
    "use strict";

    var vK = F(),
      jg = ta(),
      gK = J(),
      JP = gl(),
      YP = rr(),
      XP = ra(),
      yK = St(),
      xK = aa(),
      Ug = JP.ArrayBuffer,
      zg = JP.DataView,
      ZP = zg.prototype,
      QP = jg(Ug.prototype.slice),
      SK = jg(ZP.getUint8),
      bK = jg(ZP.setUint8),
      wK = gK(function () {
        return !new Ug(2).slice(1, void 0).byteLength;
      });
    vK({
      target: "ArrayBuffer",
      proto: !0,
      unsafe: !0,
      forced: wK
    }, {
      slice: function slice(r, t) {
        if (QP && t === void 0) return QP(YP(this), r);
        for (var i = YP(this).byteLength, a = XP(r, i), s = XP(t === void 0 ? i : t, i), l = new (xK(this, Ug))(yK(s - a)), p = new zg(this), d = new zg(l), v = 0; a < s;) bK(d, v++, SK(p, a++));
        return l;
      }
    });
  });
  var rq = h(function () {
    "use strict";

    var EK = F(),
      CK = gl(),
      IK = sp();
    EK({
      global: !0,
      constructor: !0,
      forced: !IK
    }, {
      DataView: CK.DataView
    });
  });
  var tq = h(function () {
    "use strict";

    rq();
  });
  var Hg = h(function (vEe, nq) {
    "use strict";

    var PK = ml(),
      qK = Zt(),
      TK = TypeError;
    nq.exports = PK(ArrayBuffer.prototype, "byteLength", "get") || function (e) {
      if (qK(e) !== "ArrayBuffer") throw new TK("ArrayBuffer expected");
      return e.byteLength;
    };
  });
  var $g = h(function (gEe, oq) {
    "use strict";

    var OK = Q(),
      AK = Hg(),
      _K = OK(ArrayBuffer.prototype.slice);
    oq.exports = function (e) {
      if (AK(e) !== 0) return !1;
      try {
        return _K(e, 0, 0), !1;
      } catch (_unused18) {
        return !0;
      }
    };
  });
  var aq = h(function () {
    "use strict";

    var NK = Xe(),
      RK = Yo(),
      MK = $g(),
      iq = ArrayBuffer.prototype;
    NK && !("detached" in iq) && RK(iq, "detached", {
      configurable: !0,
      get: function get() {
        return MK(this);
      }
    });
  });
  var sa = h(function (SEe, sq) {
    "use strict";

    var kK = ae(),
      DK = Zt();
    sq.exports = DK(kK.process) === "process";
  });
  var Vg = h(function (bEe, uq) {
    "use strict";

    var BK = sa();
    uq.exports = function (e) {
      try {
        if (BK) return Function('return require("' + e + '")')();
      } catch (_unused19) {}
    };
  });
  var xp = h(function (wEe, lq) {
    "use strict";

    lq.exports = (typeof Deno === "undefined" ? "undefined" : _typeof(Deno)) == "object" && Deno && _typeof(Deno.version) == "object";
  });
  var Wg = h(function (EEe, cq) {
    "use strict";

    var FK = xp(),
      LK = sa();
    cq.exports = !FK && !LK && (typeof window === "undefined" ? "undefined" : _typeof(window)) == "object" && (typeof document === "undefined" ? "undefined" : _typeof(document)) == "object";
  });
  var Sp = h(function (CEe, pq) {
    "use strict";

    var zK = ae(),
      jK = J(),
      Gg = rl(),
      UK = Wg(),
      HK = xp(),
      $K = sa(),
      fq = zK.structuredClone;
    pq.exports = !!fq && !jK(function () {
      if (HK && Gg > 92 || $K && Gg > 94 || UK && Gg > 97) return !1;
      var e = new ArrayBuffer(8),
        r = fq(e, {
          transfer: [e]
        });
      return e.byteLength !== 0 || r.byteLength !== 8;
    });
  });
  var Jg = h(function (IEe, hq) {
    "use strict";

    var Qg = ae(),
      VK = Vg(),
      WK = Sp(),
      GK = Qg.structuredClone,
      dq = Qg.ArrayBuffer,
      bp = Qg.MessageChannel,
      Xg = !1,
      Kg,
      mq,
      wp,
      Yg;
    if (WK) Xg = function Xg(e) {
      GK(e, {
        transfer: [e]
      });
    };else if (dq) try {
      bp || (Kg = VK("worker_threads"), Kg && (bp = Kg.MessageChannel)), bp && (mq = new bp(), wp = new dq(2), Yg = function Yg(e) {
        mq.port1.postMessage(null, [e]);
      }, wp.byteLength === 2 && (Yg(wp), wp.byteLength === 0 && (Xg = Yg)));
    } catch (_unused20) {}
    hq.exports = Xg;
  });
  var ny = h(function (PEe, wq) {
    "use strict";

    var Ep = ae(),
      ry = Q(),
      xq = ml(),
      KK = up(),
      YK = $g(),
      XK = Hg(),
      vq = Jg(),
      Zg = Sp(),
      QK = Ep.structuredClone,
      Sq = Ep.ArrayBuffer,
      ey = Ep.DataView,
      JK = Ep.TypeError,
      ZK = Math.min,
      ty = Sq.prototype,
      bq = ey.prototype,
      e9 = ry(ty.slice),
      gq = xq(ty, "resizable", "get"),
      yq = xq(ty, "maxByteLength", "get"),
      r9 = ry(bq.getInt8),
      t9 = ry(bq.setInt8);
    wq.exports = (Zg || vq) && function (e, r, t) {
      var i = XK(e),
        a = r === void 0 ? i : KK(r),
        s = !gq || !gq(e),
        l;
      if (YK(e)) throw new JK("ArrayBuffer is detached");
      if (Zg && (e = QK(e, {
        transfer: [e]
      }), i === a && (t || s))) return e;
      if (i >= a && (!t || s)) l = e9(e, 0, a);else {
        var p = t && !s && yq ? {
          maxByteLength: yq(e)
        } : void 0;
        l = new Sq(a, p);
        for (var d = new ey(e), v = new ey(l), g = ZK(a, i), x = 0; x < g; x++) t9(v, x, r9(d, x));
      }
      return Zg || vq(e), l;
    };
  });
  var Cq = h(function () {
    "use strict";

    var n9 = F(),
      Eq = ny();
    Eq && n9({
      target: "ArrayBuffer",
      proto: !0
    }, {
      transfer: function transfer() {
        return Eq(this, arguments.length ? arguments[0] : void 0, !0);
      }
    });
  });
  var Pq = h(function () {
    "use strict";

    var o9 = F(),
      Iq = ny();
    Iq && o9({
      target: "ArrayBuffer",
      proto: !0
    }, {
      transferToFixedLength: function transferToFixedLength() {
        return Iq(this, arguments.length ? arguments[0] : void 0, !1);
      }
    });
  });
  var Tq = h(function (_Ee, qq) {
    "use strict";

    var i9 = tp(),
      a9 = Kn();
    qq.exports = i9 ? {}.toString : function () {
      return "[object " + a9(this) + "]";
    };
  });
  var ni = h(function () {
    "use strict";

    var s9 = tp(),
      u9 = at(),
      l9 = Tq();
    s9 || u9(Object.prototype, "toString", l9, {
      unsafe: !0
    });
  });
  var Ct = h(function (MEe, Oq) {
    "use strict";

    var c9 = ae();
    Oq.exports = c9;
  });
  var _q = h(function (kEe, Aq) {
    "use strict";

    RP();
    VP();
    eq();
    tq();
    aq();
    Cq();
    Pq();
    ni();
    var f9 = Ct();
    Aq.exports = f9.ArrayBuffer;
  });
  var Rq = h(function (DEe, Nq) {
    "use strict";

    var p9 = _q();
    Nq.exports = p9;
  });
  var Mq = h(function () {
    "use strict";

    var d9 = F(),
      m9 = dl().findLastIndex,
      h9 = So();
    d9({
      target: "Array",
      proto: !0
    }, {
      findLastIndex: function findLastIndex(r) {
        return m9(this, r, arguments.length > 1 ? arguments[1] : void 0);
      }
    });
    h9("findLastIndex");
  });
  var Dq = h(function (LEe, kq) {
    "use strict";

    Mq();
    var v9 = wt();
    kq.exports = v9("Array", "findLastIndex");
  });
  var Fq = h(function (zEe, Bq) {
    "use strict";

    Bq.exports = Dq();
  });
  var zq = h(function (jEe, Lq) {
    "use strict";

    var g9 = bt().forEach,
      y9 = fl(),
      x9 = y9("forEach");
    Lq.exports = x9 ? [].forEach : function (r) {
      return g9(this, r, arguments.length > 1 ? arguments[1] : void 0);
    };
  });
  var Uq = h(function () {
    "use strict";

    var S9 = F(),
      jq = zq();
    S9({
      target: "Array",
      proto: !0,
      forced: [].forEach !== jq
    }, {
      forEach: jq
    });
  });
  var $q = h(function ($Ee, Hq) {
    "use strict";

    Uq();
    var b9 = wt();
    Hq.exports = b9("Array", "forEach");
  });
  var Wq = h(function (VEe, Vq) {
    "use strict";

    var w9 = $q();
    Vq.exports = w9;
  });
  var He = h(function (WEe, Gq) {
    "use strict";

    var E9 = Kn(),
      C9 = String;
    Gq.exports = function (e) {
      if (E9(e) === "Symbol") throw new TypeError("Cannot convert a Symbol value to a string");
      return C9(e);
    };
  });
  var Cp = h(function (GEe, Xq) {
    "use strict";

    var oy = Q(),
      I9 = br(),
      P9 = He(),
      q9 = er(),
      T9 = oy("".charAt),
      Kq = oy("".charCodeAt),
      O9 = oy("".slice),
      Yq = function Yq(e) {
        return function (r, t) {
          var i = P9(q9(r)),
            a = I9(t),
            s = i.length,
            l,
            p;
          return a < 0 || a >= s ? e ? "" : void 0 : (l = Kq(i, a), l < 55296 || l > 56319 || a + 1 === s || (p = Kq(i, a + 1)) < 56320 || p > 57343 ? e ? T9(i, a) : l : e ? O9(i, a, a + 2) : (l - 55296 << 10) + (p - 56320) + 65536);
        };
      };
    Xq.exports = {
      codeAt: Yq(!1),
      charAt: Yq(!0)
    };
  });
  var uy = h(function (KEe, Zq) {
    "use strict";

    var A9 = J(),
      _9 = Re(),
      N9 = nr(),
      R9 = xo(),
      Qq = na(),
      M9 = at(),
      k9 = Ue(),
      D9 = xr(),
      sy = k9("iterator"),
      Jq = !1,
      Co,
      iy,
      ay;
    [].keys && (ay = [].keys(), "next" in ay ? (iy = Qq(Qq(ay)), iy !== Object.prototype && (Co = iy)) : Jq = !0);
    var B9 = !N9(Co) || A9(function () {
      var e = {};
      return Co[sy].call(e) !== e;
    });
    B9 ? Co = {} : D9 && (Co = R9(Co));
    _9(Co[sy]) || M9(Co, sy, function () {
      return this;
    });
    Zq.exports = {
      IteratorPrototype: Co,
      BUGGY_SAFARI_ITERATORS: Jq
    };
  });
  var ds = h(function (YEe, eT) {
    "use strict";

    eT.exports = {};
  });
  var ly = h(function (XEe, rT) {
    "use strict";

    var F9 = uy().IteratorPrototype,
      L9 = xo(),
      z9 = Vn(),
      j9 = Jo(),
      U9 = ds(),
      H9 = function H9() {
        return this;
      };
    rT.exports = function (e, r, t, i) {
      var a = r + " Iterator";
      return e.prototype = L9(F9, {
        next: z9(+!i, t)
      }), j9(e, a, !1, !0), U9[a] = H9, e;
    };
  });
  var qp = h(function (QEe, fT) {
    "use strict";

    var $9 = F(),
      V9 = Oe(),
      Ip = xr(),
      lT = nl(),
      W9 = Re(),
      G9 = ly(),
      tT = na(),
      nT = Qo(),
      K9 = Jo(),
      Y9 = Dt(),
      cy = at(),
      X9 = Ue(),
      oT = ds(),
      cT = uy(),
      Q9 = lT.PROPER,
      J9 = lT.CONFIGURABLE,
      iT = cT.IteratorPrototype,
      Pp = cT.BUGGY_SAFARI_ITERATORS,
      xl = X9("iterator"),
      aT = "keys",
      Sl = "values",
      sT = "entries",
      uT = function uT() {
        return this;
      };
    fT.exports = function (e, r, t, i, a, s, l) {
      G9(t, r, i);
      var p = function p(T) {
          if (T === a && S) return S;
          if (!Pp && T && T in g) return g[T];
          switch (T) {
            case aT:
              return function () {
                return new t(this, T);
              };
            case Sl:
              return function () {
                return new t(this, T);
              };
            case sT:
              return function () {
                return new t(this, T);
              };
          }
          return function () {
            return new t(this);
          };
        },
        d = r + " Iterator",
        v = !1,
        g = e.prototype,
        x = g[xl] || g["@@iterator"] || a && g[a],
        S = !Pp && x || p(a),
        b = r === "Array" && g.entries || x,
        q,
        E,
        C;
      if (b && (q = tT(b.call(new e())), q !== Object.prototype && q.next && (!Ip && tT(q) !== iT && (nT ? nT(q, iT) : W9(q[xl]) || cy(q, xl, uT)), K9(q, d, !0, !0), Ip && (oT[d] = uT))), Q9 && a === Sl && x && x.name !== Sl && (!Ip && J9 ? Y9(g, "name", Sl) : (v = !0, S = function S() {
        return V9(x, this);
      })), a) if (E = {
        values: p(Sl),
        keys: s ? S : p(aT),
        entries: p(sT)
      }, l) for (C in E) (Pp || v || !(C in g)) && cy(g, C, E[C]);else $9({
        target: r,
        proto: !0,
        forced: Pp || v
      }, E);
      return (!Ip || l) && g[xl] !== S && cy(g, xl, S, {
        name: a
      }), oT[r] = S, E;
    };
  });
  var bl = h(function (JEe, pT) {
    "use strict";

    pT.exports = function (e, r) {
      return {
        value: e,
        done: r
      };
    };
  });
  var ua = h(function () {
    "use strict";

    var Z9 = Cp().charAt,
      eY = He(),
      mT = en(),
      rY = qp(),
      dT = bl(),
      hT = "String Iterator",
      tY = mT.set,
      nY = mT.getterFor(hT);
    rY(String, "String", function (e) {
      tY(this, {
        type: hT,
        string: eY(e),
        index: 0
      });
    }, function () {
      var r = nY(this),
        t = r.string,
        i = r.index,
        a;
      return i >= t.length ? dT(void 0, !0) : (a = Z9(t, i), r.index += a.length, dT(a, !1));
    });
  });
  var wl = h(function (rCe, gT) {
    "use strict";

    var oY = Oe(),
      vT = rr(),
      iY = Gn();
    gT.exports = function (e, r, t) {
      var i, a;
      vT(e);
      try {
        if (i = iY(e, "return"), !i) {
          if (r === "throw") throw t;
          return t;
        }
        i = oY(i, e);
      } catch (s) {
        a = !0, i = s;
      }
      if (r === "throw") throw t;
      if (a) throw i;
      return vT(i), t;
    };
  });
  var xT = h(function (tCe, yT) {
    "use strict";

    var aY = rr(),
      sY = wl();
    yT.exports = function (e, r, t, i) {
      try {
        return i ? r(aY(t)[0], t[1]) : r(t);
      } catch (a) {
        sY(e, "throw", a);
      }
    };
  });
  var Tp = h(function (nCe, ST) {
    "use strict";

    var uY = Ue(),
      lY = ds(),
      cY = uY("iterator"),
      fY = Array.prototype;
    ST.exports = function (e) {
      return e !== void 0 && (lY.Array === e || fY[cY] === e);
    };
  });
  var fy = h(function (oCe, bT) {
    "use strict";

    var pY = Xe(),
      dY = it(),
      mY = Vn();
    bT.exports = function (e, r, t) {
      pY ? dY.f(e, r, mY(0, t)) : e[r] = t;
    };
  });
  var El = h(function (iCe, ET) {
    "use strict";

    var hY = Kn(),
      wT = Gn(),
      vY = xt(),
      gY = ds(),
      yY = Ue(),
      xY = yY("iterator");
    ET.exports = function (e) {
      if (!vY(e)) return wT(e, xY) || wT(e, "@@iterator") || gY[hY(e)];
    };
  });
  var Op = h(function (aCe, CT) {
    "use strict";

    var SY = Oe(),
      bY = Xr(),
      wY = rr(),
      EY = Ji(),
      CY = El(),
      IY = TypeError;
    CT.exports = function (e, r) {
      var t = arguments.length < 2 ? CY(e) : r;
      if (bY(t)) return wY(SY(t, e));
      throw new IY(EY(e) + " is not iterable");
    };
  });
  var TT = h(function (sCe, qT) {
    "use strict";

    var PY = yo(),
      qY = Oe(),
      TY = Qr(),
      OY = xT(),
      AY = Tp(),
      _Y = cl(),
      NY = wr(),
      IT = fy(),
      RY = Op(),
      MY = El(),
      PT = Array;
    qT.exports = function (r) {
      var t = TY(r),
        i = _Y(this),
        a = arguments.length,
        s = a > 1 ? arguments[1] : void 0,
        l = s !== void 0;
      l && (s = PY(s, a > 2 ? arguments[2] : void 0));
      var p = MY(t),
        d = 0,
        v,
        g,
        x,
        S,
        b,
        q;
      if (p && !(this === PT && AY(p))) for (g = i ? new this() : [], S = RY(t, p), b = S.next; !(x = qY(b, S)).done; d++) q = l ? OY(S, s, [x.value, d], !0) : x.value, IT(g, d, q);else for (v = NY(t), g = i ? new this(v) : PT(v); v > d; d++) q = l ? s(t[d], d) : t[d], IT(g, d, q);
      return g.length = d, g;
    };
  });
  var Cl = h(function (uCe, NT) {
    "use strict";

    var kY = Ue(),
      AT = kY("iterator"),
      _T = !1;
    try {
      OT = 0, py = {
        next: function next() {
          return {
            done: !!OT++
          };
        },
        return: function _return() {
          _T = !0;
        }
      }, py[AT] = function () {
        return this;
      }, Array.from(py, function () {
        throw 2;
      });
    } catch (_unused21) {}
    var OT, py;
    NT.exports = function (e, r) {
      try {
        if (!r && !_T) return !1;
      } catch (_unused22) {
        return !1;
      }
      var t = !1;
      try {
        var i = {};
        i[AT] = function () {
          return {
            next: function next() {
              return {
                done: t = !0
              };
            }
          };
        }, e(i);
      } catch (_unused23) {}
      return t;
    };
  });
  var RT = h(function () {
    "use strict";

    var DY = F(),
      BY = TT(),
      FY = Cl(),
      LY = !FY(function (e) {
        Array.from(e);
      });
    DY({
      target: "Array",
      stat: !0,
      forced: LY
    }, {
      from: BY
    });
  });
  var kT = h(function (fCe, MT) {
    "use strict";

    ua();
    RT();
    var zY = Ct();
    MT.exports = zY.Array.from;
  });
  var BT = h(function (pCe, DT) {
    "use strict";

    var jY = kT();
    DT.exports = jY;
  });
  var FT = h(function () {
    "use strict";

    var UY = F(),
      HY = bt().some,
      $Y = fl(),
      VY = $Y("some");
    UY({
      target: "Array",
      proto: !0,
      forced: !VY
    }, {
      some: function some(r) {
        return HY(this, r, arguments.length > 1 ? arguments[1] : void 0);
      }
    });
  });
  var zT = h(function (hCe, LT) {
    "use strict";

    FT();
    var WY = wt();
    LT.exports = WY("Array", "some");
  });
  var UT = h(function (vCe, jT) {
    "use strict";

    var GY = zT();
    jT.exports = GY;
  });
  var HT = h(function () {
    "use strict";

    var KY = F(),
      YY = al().includes,
      XY = J(),
      QY = So(),
      JY = XY(function () {
        return !Array(1).includes();
      });
    KY({
      target: "Array",
      proto: !0,
      forced: JY
    }, {
      includes: function includes(r) {
        return YY(this, r, arguments.length > 1 ? arguments[1] : void 0);
      }
    });
    QY("includes");
  });
  var VT = h(function (xCe, $T) {
    "use strict";

    HT();
    var ZY = wt();
    $T.exports = ZY("Array", "includes");
  });
  var GT = h(function (SCe, WT) {
    "use strict";

    var eX = VT();
    WT.exports = eX;
  });
  var KT = h(function () {
    "use strict";

    var rX = F(),
      tX = Qr(),
      nX = wr(),
      oX = br(),
      iX = So();
    rX({
      target: "Array",
      proto: !0
    }, {
      at: function at(r) {
        var t = tX(this),
          i = nX(t),
          a = oX(r),
          s = a >= 0 ? a : i + a;
        return s < 0 || s >= i ? void 0 : t[s];
      }
    });
    iX("at");
  });
  var XT = h(function (ECe, YT) {
    "use strict";

    KT();
    var aX = wt();
    YT.exports = aX("Array", "at");
  });
  var JT = h(function (CCe, QT) {
    "use strict";

    var sX = XT();
    QT.exports = sX;
  });
  var Il = h(function (ICe, ZT) {
    "use strict";

    var uX = Q();
    ZT.exports = uX(1 .valueOf);
  });
  var Pl = h(function (PCe, eO) {
    "use strict";

    eO.exports = "\t\n\x0B\f\r \xA0\u1680\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028\u2029\uFEFF";
  });
  var la = h(function (qCe, tO) {
    "use strict";

    var lX = Q(),
      cX = er(),
      fX = He(),
      my = Pl(),
      rO = lX("".replace),
      pX = RegExp("^[" + my + "]+"),
      dX = RegExp("(^|[^" + my + "])[" + my + "]+$"),
      dy = function dy(e) {
        return function (r) {
          var t = fX(cX(r));
          return e & 1 && (t = rO(t, pX, "")), e & 2 && (t = rO(t, dX, "$1")), t;
        };
      };
    tO.exports = {
      start: dy(1),
      end: dy(2),
      trim: dy(3)
    };
  });
  var lO = h(function () {
    "use strict";

    var mX = F(),
      hy = xr(),
      hX = Xe(),
      iO = ae(),
      vy = Ct(),
      aO = Q(),
      vX = ul(),
      nO = Sr(),
      gX = ss(),
      yX = vo(),
      xX = ns(),
      sO = $f(),
      SX = J(),
      bX = as().f,
      wX = Zi().f,
      EX = it().f,
      CX = Il(),
      IX = la().trim,
      ql = "Number",
      ms = iO[ql],
      oO = vy[ql],
      gy = ms.prototype,
      PX = iO.TypeError,
      qX = aO("".slice),
      Ap = aO("".charCodeAt),
      TX = function TX(e) {
        var r = sO(e, "number");
        return typeof r == "bigint" ? r : OX(r);
      },
      OX = function OX(e) {
        var r = sO(e, "number"),
          t,
          i,
          a,
          s,
          l,
          p,
          d,
          v;
        if (xX(r)) throw new PX("Cannot convert a Symbol value to a number");
        if (typeof r == "string" && r.length > 2) {
          if (r = IX(r), t = Ap(r, 0), t === 43 || t === 45) {
            if (i = Ap(r, 2), i === 88 || i === 120) return NaN;
          } else if (t === 48) {
            switch (Ap(r, 1)) {
              case 66:
              case 98:
                a = 2, s = 49;
                break;
              case 79:
              case 111:
                a = 8, s = 55;
                break;
              default:
                return +r;
            }
            for (l = qX(r, 2), p = l.length, d = 0; d < p; d++) if (v = Ap(l, d), v < 48 || v > s) return NaN;
            return parseInt(l, a);
          }
        }
        return +r;
      },
      yy = vX(ql, !ms(" 0o1") || !ms("0b1") || ms("+0x1")),
      AX = function AX(e) {
        return yX(gy, e) && SX(function () {
          CX(e);
        });
      },
      _p2 = function _p(r) {
        var t = arguments.length < 1 ? 0 : ms(TX(r));
        return AX(this) ? gX(Object(t), this, _p2) : t;
      };
    _p2.prototype = gy;
    yy && !hy && (gy.constructor = _p2);
    mX({
      global: !0,
      constructor: !0,
      wrap: !0,
      forced: yy
    }, {
      Number: _p2
    });
    var uO = function uO(e, r) {
      for (var t = hX ? bX(r) : "MAX_VALUE,MIN_VALUE,NaN,NEGATIVE_INFINITY,POSITIVE_INFINITY,EPSILON,MAX_SAFE_INTEGER,MIN_SAFE_INTEGER,isFinite,isInteger,isNaN,isSafeInteger,parseFloat,parseInt,fromString,range".split(","), i = 0, a; t.length > i; i++) nO(r, a = t[i]) && !nO(e, a) && EX(e, a, wX(r, a));
    };
    hy && oO && uO(vy[ql], oO);
    (yy || hy) && uO(vy[ql], ms);
  });
  var cO = h(function () {
    "use strict";

    var _X = F();
    _X({
      target: "Number",
      stat: !0,
      nonConfigurable: !0,
      nonWritable: !0
    }, {
      EPSILON: Math.pow(2, -52)
    });
  });
  var pO = h(function (NCe, fO) {
    "use strict";

    var NX = ae(),
      RX = NX.isFinite;
    fO.exports = Number.isFinite || function (r) {
      return typeof r == "number" && RX(r);
    };
  });
  var dO = h(function () {
    "use strict";

    var MX = F(),
      kX = pO();
    MX({
      target: "Number",
      stat: !0
    }, {
      isFinite: kX
    });
  });
  var Np = h(function (kCe, mO) {
    "use strict";

    var DX = nr(),
      BX = Math.floor;
    mO.exports = Number.isInteger || function (r) {
      return !DX(r) && isFinite(r) && BX(r) === r;
    };
  });
  var hO = h(function () {
    "use strict";

    var FX = F(),
      LX = Np();
    FX({
      target: "Number",
      stat: !0
    }, {
      isInteger: LX
    });
  });
  var vO = h(function () {
    "use strict";

    var zX = F();
    zX({
      target: "Number",
      stat: !0
    }, {
      isNaN: function isNaN(r) {
        return r !== r;
      }
    });
  });
  var gO = h(function () {
    "use strict";

    var jX = F(),
      UX = Np(),
      HX = Math.abs;
    jX({
      target: "Number",
      stat: !0
    }, {
      isSafeInteger: function isSafeInteger(r) {
        return UX(r) && HX(r) <= 9007199254740991;
      }
    });
  });
  var yO = h(function () {
    "use strict";

    var $X = F();
    $X({
      target: "Number",
      stat: !0,
      nonConfigurable: !0,
      nonWritable: !0
    }, {
      MAX_SAFE_INTEGER: 9007199254740991
    });
  });
  var xO = h(function () {
    "use strict";

    var VX = F();
    VX({
      target: "Number",
      stat: !0,
      nonConfigurable: !0,
      nonWritable: !0
    }, {
      MIN_SAFE_INTEGER: -9007199254740991
    });
  });
  var CO = h(function (WCe, EO) {
    "use strict";

    var wO = ae(),
      WX = J(),
      GX = Q(),
      KX = He(),
      YX = la().trim,
      XX = Pl(),
      QX = GX("".charAt),
      Rp = wO.parseFloat,
      SO = wO.Symbol,
      bO = SO && SO.iterator,
      JX = 1 / Rp(XX + "-0") !== -1 / 0 || bO && !WX(function () {
        Rp(Object(bO));
      });
    EO.exports = JX ? function (r) {
      var t = YX(KX(r)),
        i = Rp(t);
      return i === 0 && QX(t, 0) === "-" ? -0 : i;
    } : Rp;
  });
  var PO = h(function () {
    "use strict";

    var ZX = F(),
      IO = CO();
    ZX({
      target: "Number",
      stat: !0,
      forced: Number.parseFloat !== IO
    }, {
      parseFloat: IO
    });
  });
  var RO = h(function (YCe, NO) {
    "use strict";

    var AO = ae(),
      eQ = J(),
      rQ = Q(),
      tQ = He(),
      nQ = la().trim,
      qO = Pl(),
      Tl = AO.parseInt,
      TO = AO.Symbol,
      OO = TO && TO.iterator,
      _O = /^[+-]?0x/i,
      oQ = rQ(_O.exec),
      iQ = Tl(qO + "08") !== 8 || Tl(qO + "0x16") !== 22 || OO && !eQ(function () {
        Tl(Object(OO));
      });
    NO.exports = iQ ? function (r, t) {
      var i = nQ(tQ(r));
      return Tl(i, t >>> 0 || (oQ(_O, i) ? 16 : 10));
    } : Tl;
  });
  var kO = h(function () {
    "use strict";

    var aQ = F(),
      MO = RO();
    aQ({
      target: "Number",
      stat: !0,
      forced: Number.parseInt !== MO
    }, {
      parseInt: MO
    });
  });
  var Ol = h(function (JCe, DO) {
    "use strict";

    var sQ = br(),
      uQ = He(),
      lQ = er(),
      cQ = RangeError;
    DO.exports = function (r) {
      var t = uQ(lQ(this)),
        i = "",
        a = sQ(r);
      if (a < 0 || a === 1 / 0) throw new cQ("Wrong number of repetitions");
      for (; a > 0; (a >>>= 1) && (t += t)) a & 1 && (i += t);
      return i;
    };
  });
  var FO = h(function (ZCe, BO) {
    "use strict";

    var fQ = Math.log,
      pQ = Math.LOG10E;
    BO.exports = Math.log10 || function (r) {
      return fQ(r) * pQ;
    };
  });
  var HO = h(function () {
    "use strict";

    var dQ = F(),
      Sy = Q(),
      mQ = br(),
      hQ = Il(),
      vQ = Ol(),
      gQ = FO(),
      xy = J(),
      yQ = RangeError,
      LO = String,
      xQ = isFinite,
      SQ = Math.abs,
      bQ = Math.floor,
      zO = Math.pow,
      wQ = Math.round,
      Qn = Sy(1 .toExponential),
      EQ = Sy(vQ),
      jO = Sy("".slice),
      UO = Qn(-69e-12, 4) === "-6.9000e-11" && Qn(1.255, 2) === "1.25e+0" && Qn(12345, 3) === "1.235e+4" && Qn(25, 0) === "3e+1",
      CQ = function CQ() {
        return xy(function () {
          Qn(1, 1 / 0);
        }) && xy(function () {
          Qn(1, -1 / 0);
        });
      },
      IQ = function IQ() {
        return !xy(function () {
          Qn(1 / 0, 1 / 0), Qn(NaN, 1 / 0);
        });
      },
      PQ = !UO || !CQ() || !IQ();
    dQ({
      target: "Number",
      proto: !0,
      forced: PQ
    }, {
      toExponential: function toExponential(r) {
        var t = hQ(this);
        if (r === void 0) return Qn(t);
        var i = mQ(r);
        if (!xQ(t)) return String(t);
        if (i < 0 || i > 20) throw new yQ("Incorrect fraction digits");
        if (UO) return Qn(t, i);
        var a = "",
          s = "",
          l = 0,
          p = "",
          d = "";
        if (t < 0 && (a = "-", t = -t), t === 0) l = 0, s = EQ("0", i + 1);else {
          var v = gQ(t);
          l = bQ(v);
          var g = 0,
            x = zO(10, l - i);
          g = wQ(t / x), 2 * t >= (2 * g + 1) * x && (g += 1), g >= zO(10, i + 1) && (g /= 10, l += 1), s = LO(g);
        }
        return i !== 0 && (s = jO(s, 0, 1) + "." + jO(s, 1)), l === 0 ? (p = "+", d = "0") : (p = l > 0 ? "+" : "-", d = LO(SQ(l))), s += "e" + p + d, a + s;
      }
    });
  });
  var YO = h(function () {
    "use strict";

    var qQ = F(),
      Ey = Q(),
      TQ = br(),
      OQ = Il(),
      AQ = Ol(),
      $O = J(),
      _Q = RangeError,
      GO = String,
      KO = Math.floor,
      wy = Ey(AQ),
      VO = Ey("".slice),
      Al = Ey(1 .toFixed),
      _vs = function vs(e, r, t) {
        return r === 0 ? t : r % 2 === 1 ? _vs(e, r - 1, t * e) : _vs(e * e, r / 2, t);
      },
      NQ = function NQ(e) {
        for (var r = 0, t = e; t >= 4096;) r += 12, t /= 4096;
        for (; t >= 2;) r += 1, t /= 2;
        return r;
      },
      hs = function hs(e, r, t) {
        for (var i = -1, a = t; ++i < 6;) a += r * e[i], e[i] = a % 1e7, a = KO(a / 1e7);
      },
      by = function by(e, r) {
        for (var t = 6, i = 0; --t >= 0;) i += e[t], e[t] = KO(i / r), i = i % r * 1e7;
      },
      WO = function WO(e) {
        for (var r = 6, t = ""; --r >= 0;) if (t !== "" || r === 0 || e[r] !== 0) {
          var i = GO(e[r]);
          t = t === "" ? i : t + wy("0", 7 - i.length) + i;
        }
        return t;
      },
      RQ = $O(function () {
        return Al(8e-5, 3) !== "0.000" || Al(.9, 0) !== "1" || Al(1.255, 2) !== "1.25" || Al(0xde0b6b3a7640080, 0) !== "1000000000000000128";
      }) || !$O(function () {
        Al({});
      });
    qQ({
      target: "Number",
      proto: !0,
      forced: RQ
    }, {
      toFixed: function toFixed(r) {
        var t = OQ(this),
          i = TQ(r),
          a = [0, 0, 0, 0, 0, 0],
          s = "",
          l = "0",
          p,
          d,
          v,
          g;
        if (i < 0 || i > 20) throw new _Q("Incorrect fraction digits");
        if (t !== t) return "NaN";
        if (t <= -1e21 || t >= 1e21) return GO(t);
        if (t < 0 && (s = "-", t = -t), t > 1e-21) if (p = NQ(t * _vs(2, 69, 1)) - 69, d = p < 0 ? t * _vs(2, -p, 1) : t / _vs(2, p, 1), d *= 4503599627370496, p = 52 - p, p > 0) {
          for (hs(a, 0, d), v = i; v >= 7;) hs(a, 1e7, 0), v -= 7;
          for (hs(a, _vs(10, v, 1), 0), v = p - 1; v >= 23;) by(a, 1 << 23), v -= 23;
          by(a, 1 << v), hs(a, 1, 1), by(a, 2), l = WO(a);
        } else hs(a, 0, d), hs(a, 1 << -p, 0), l = WO(a) + wy("0", i);
        return i > 0 ? (g = l.length, l = s + (g <= i ? "0." + wy("0", i - g) + l : VO(l, 0, g - i) + "." + VO(l, g - i))) : l = s + l, l;
      }
    });
  });
  var JO = h(function () {
    "use strict";

    var MQ = F(),
      kQ = Q(),
      XO = J(),
      QO = Il(),
      Mp = kQ(1 .toPrecision),
      DQ = XO(function () {
        return Mp(1, void 0) !== "1";
      }) || !XO(function () {
        Mp({});
      });
    MQ({
      target: "Number",
      proto: !0,
      forced: DQ
    }, {
      toPrecision: function toPrecision(r) {
        return r === void 0 ? Mp(QO(this)) : Mp(QO(this), r);
      }
    });
  });
  var eA = h(function (a1e, ZO) {
    "use strict";

    lO();
    cO();
    dO();
    hO();
    vO();
    gO();
    yO();
    xO();
    PO();
    kO();
    HO();
    YO();
    JO();
    var BQ = Ct();
    ZO.exports = BQ.Number;
  });
  var tA = h(function (s1e, rA) {
    "use strict";

    var FQ = eA();
    rA.exports = FQ;
  });
  var aA = h(function (u1e, iA) {
    "use strict";

    var nA = Xe(),
      LQ = Q(),
      zQ = Oe(),
      jQ = J(),
      Cy = pl(),
      UQ = dg(),
      HQ = Lf(),
      $Q = Qr(),
      VQ = ts(),
      gs = Object.assign,
      oA = Object.defineProperty,
      WQ = LQ([].concat);
    iA.exports = !gs || jQ(function () {
      if (nA && gs({
        b: 1
      }, gs(oA({}, "a", {
        enumerable: !0,
        get: function get() {
          oA(this, "b", {
            value: 3,
            enumerable: !1
          });
        }
      }), {
        b: 2
      })).b !== 1) return !0;
      var e = {},
        r = {},
        t = Symbol("assign detection"),
        i = "abcdefghijklmnopqrst";
      return e[t] = 7, i.split("").forEach(function (a) {
        r[a] = a;
      }), gs({}, e)[t] !== 7 || Cy(gs({}, r)).join("") !== i;
    }) ? function (r, t) {
      for (var i = $Q(r), a = arguments.length, s = 1, l = UQ.f, p = HQ.f; a > s;) for (var d = VQ(arguments[s++]), v = l ? WQ(Cy(d), l(d)) : Cy(d), g = v.length, x = 0, S; g > x;) S = v[x++], (!nA || zQ(p, d, S)) && (i[S] = d[S]);
      return i;
    } : gs;
  });
  var uA = h(function () {
    "use strict";

    var GQ = F(),
      sA = aA();
    GQ({
      target: "Object",
      stat: !0,
      arity: 2,
      forced: Object.assign !== sA
    }, {
      assign: sA
    });
  });
  var cA = h(function (f1e, lA) {
    "use strict";

    uA();
    var KQ = Ct();
    lA.exports = KQ.Object.assign;
  });
  var pA = h(function (p1e, fA) {
    "use strict";

    var YQ = cA();
    fA.exports = YQ;
  });
  var Iy = h(function (d1e, gA) {
    "use strict";

    var mA = Xe(),
      XQ = J(),
      hA = Q(),
      QQ = na(),
      JQ = pl(),
      ZQ = Wn(),
      eJ = Lf().f,
      vA = hA(eJ),
      rJ = hA([].push),
      tJ = mA && XQ(function () {
        var e = Object.create(null);
        return e[2] = 2, !vA(e, 2);
      }),
      dA = function dA(e) {
        return function (r) {
          for (var t = ZQ(r), i = JQ(t), a = tJ && QQ(t) === null, s = i.length, l = 0, p = [], d; s > l;) d = i[l++], (!mA || (a ? d in t : vA(t, d))) && rJ(p, e ? [d, t[d]] : t[d]);
          return p;
        };
      };
    gA.exports = {
      entries: dA(!0),
      values: dA(!1)
    };
  });
  var yA = h(function () {
    "use strict";

    var nJ = F(),
      oJ = Iy().entries;
    nJ({
      target: "Object",
      stat: !0
    }, {
      entries: function entries(r) {
        return oJ(r);
      }
    });
  });
  var SA = h(function (v1e, xA) {
    "use strict";

    yA();
    var iJ = Ct();
    xA.exports = iJ.Object.entries;
  });
  var Py = h(function (g1e, bA) {
    "use strict";

    var aJ = SA();
    bA.exports = aJ;
  });
  var qy = h(function (y1e, wA) {
    "use strict";

    wA.exports = Object.is || function (r, t) {
      return r === t ? r !== 0 || 1 / r === 1 / t : r !== r && t !== t;
    };
  });
  var EA = h(function () {
    "use strict";

    var sJ = F(),
      uJ = qy();
    sJ({
      target: "Object",
      stat: !0
    }, {
      is: uJ
    });
  });
  var IA = h(function (b1e, CA) {
    "use strict";

    EA();
    var lJ = Ct();
    CA.exports = lJ.Object.is;
  });
  var qA = h(function (w1e, PA) {
    "use strict";

    var cJ = IA();
    PA.exports = cJ;
  });
  var TA = h(function () {
    "use strict";

    var fJ = F(),
      pJ = Iy().values;
    fJ({
      target: "Object",
      stat: !0
    }, {
      values: function values(r) {
        return pJ(r);
      }
    });
  });
  var AA = h(function (I1e, OA) {
    "use strict";

    TA();
    var dJ = Ct();
    OA.exports = dJ.Object.values;
  });
  var NA = h(function (P1e, _A) {
    "use strict";

    var mJ = AA();
    _A.exports = mJ;
  });
  var Ty = h(function (q1e, DA) {
    "use strict";

    var kA = Q(),
      hJ = St(),
      RA = He(),
      vJ = Ol(),
      gJ = er(),
      yJ = kA(vJ),
      xJ = kA("".slice),
      SJ = Math.ceil,
      MA = function MA(e) {
        return function (r, t, i) {
          var a = RA(gJ(r)),
            s = hJ(t),
            l = a.length,
            p = i === void 0 ? " " : RA(i),
            d,
            v;
          return s <= l || p === "" ? a : (d = s - l, v = yJ(p, SJ(d / p.length)), v.length > d && (v = xJ(v, 0, d)), e ? a + v : v + a);
        };
      };
    DA.exports = {
      start: MA(!1),
      end: MA(!0)
    };
  });
  var Oy = h(function (T1e, BA) {
    "use strict";

    var bJ = go();
    BA.exports = /Version\/10(?:\.\d+){1,2}(?: [\w./]+)?(?: Mobile\/\w+)? Safari\//.test(bJ);
  });
  var Ay = h(function () {
    "use strict";

    var wJ = F(),
      EJ = Ty().end,
      CJ = Oy();
    wJ({
      target: "String",
      proto: !0,
      forced: CJ
    }, {
      padEnd: function padEnd(r) {
        return EJ(this, r, arguments.length > 1 ? arguments[1] : void 0);
      }
    });
  });
  var LA = h(function (_1e, FA) {
    "use strict";

    Ay();
    var IJ = wt();
    FA.exports = IJ("String", "padEnd");
  });
  var jA = h(function (N1e, zA) {
    "use strict";

    var PJ = LA();
    zA.exports = PJ;
  });
  var _y = h(function () {
    "use strict";

    var qJ = F(),
      TJ = Ty().start,
      OJ = Oy();
    qJ({
      target: "String",
      proto: !0,
      forced: OJ
    }, {
      padStart: function padStart(r) {
        return TJ(this, r, arguments.length > 1 ? arguments[1] : void 0);
      }
    });
  });
  var HA = h(function (k1e, UA) {
    "use strict";

    _y();
    var AJ = wt();
    UA.exports = AJ("String", "padStart");
  });
  var VA = h(function (D1e, $A) {
    "use strict";

    var _J = HA();
    $A.exports = _J;
  });
  var Ny = h(function () {
    "use strict";

    var NJ = F(),
      RJ = Q(),
      MJ = er(),
      kJ = br(),
      DJ = He(),
      BJ = J(),
      FJ = RJ("".charAt),
      LJ = BJ(function () {
        return "𠮷".at(-2) !== "\uD842";
      });
    NJ({
      target: "String",
      proto: !0,
      forced: LJ
    }, {
      at: function at(r) {
        var t = DJ(MJ(this)),
          i = t.length,
          a = kJ(r),
          s = a >= 0 ? a : i + a;
        return s < 0 || s >= i ? void 0 : FJ(t, s);
      }
    });
  });
  var GA = h(function (L1e, WA) {
    "use strict";

    Ny();
    var zJ = wt();
    WA.exports = zJ("String", "at");
  });
  var YA = h(function (z1e, KA) {
    "use strict";

    var jJ = GA();
    KA.exports = jJ;
  });
  var Ry = h(function (j1e, XA) {
    "use strict";

    var UJ = rr();
    XA.exports = function () {
      var e = UJ(this),
        r = "";
      return e.hasIndices && (r += "d"), e.global && (r += "g"), e.ignoreCase && (r += "i"), e.multiline && (r += "m"), e.dotAll && (r += "s"), e.unicode && (r += "u"), e.unicodeSets && (r += "v"), e.sticky && (r += "y"), r;
    };
  });
  var By = h(function (U1e, QA) {
    "use strict";

    var My = J(),
      HJ = ae(),
      ky = HJ.RegExp,
      Dy = My(function () {
        var e = ky("a", "y");
        return e.lastIndex = 2, e.exec("abcd") !== null;
      }),
      $J = Dy || My(function () {
        return !ky("a", "y").sticky;
      }),
      VJ = Dy || My(function () {
        var e = ky("^r", "gy");
        return e.lastIndex = 2, e.exec("str") !== null;
      });
    QA.exports = {
      BROKEN_CARET: VJ,
      MISSED_STICKY: $J,
      UNSUPPORTED_Y: Dy
    };
  });
  var ZA = h(function (H1e, JA) {
    "use strict";

    var WJ = J(),
      GJ = ae(),
      KJ = GJ.RegExp;
    JA.exports = WJ(function () {
      var e = KJ(".", "s");
      return !(e.dotAll && e.test("\n") && e.flags === "s");
    });
  });
  var r_ = h(function ($1e, e_) {
    "use strict";

    var YJ = J(),
      XJ = ae(),
      QJ = XJ.RegExp;
    e_.exports = YJ(function () {
      var e = QJ("(?<a>b)", "g");
      return e.exec("b").groups.a !== "b" || "b".replace(e, "$<a>c") !== "bc";
    });
  });
  var Bp = h(function (V1e, n_) {
    "use strict";

    var ys = Oe(),
      Dp = Q(),
      JJ = He(),
      ZJ = Ry(),
      eZ = By(),
      rZ = Hf(),
      tZ = xo(),
      nZ = en().get,
      oZ = ZA(),
      iZ = r_(),
      aZ = rZ("native-string-replace", String.prototype.replace),
      kp = RegExp.prototype.exec,
      _Ly = kp,
      sZ = Dp("".charAt),
      uZ = Dp("".indexOf),
      lZ = Dp("".replace),
      Fy = Dp("".slice),
      zy = function () {
        var e = /a/,
          r = /b*/g;
        return ys(kp, e, "a"), ys(kp, r, "a"), e.lastIndex !== 0 || r.lastIndex !== 0;
      }(),
      t_ = eZ.BROKEN_CARET,
      jy = /()??/.exec("")[1] !== void 0,
      cZ = zy || jy || t_ || oZ || iZ;
    cZ && (_Ly = function Ly(r) {
      var t = this,
        i = nZ(t),
        a = JJ(r),
        s = i.raw,
        l,
        p,
        d,
        v,
        g,
        x,
        S;
      if (s) return s.lastIndex = t.lastIndex, l = ys(_Ly, s, a), t.lastIndex = s.lastIndex, l;
      var b = i.groups,
        q = t_ && t.sticky,
        E = ys(ZJ, t),
        C = t.source,
        T = 0,
        D = a;
      if (q && (E = lZ(E, "y", ""), uZ(E, "g") === -1 && (E += "g"), D = Fy(a, t.lastIndex), t.lastIndex > 0 && (!t.multiline || t.multiline && sZ(a, t.lastIndex - 1) !== "\n") && (C = "(?: " + C + ")", D = " " + D, T++), p = new RegExp("^(?:" + C + ")", E)), jy && (p = new RegExp("^" + C + "$(?!\\s)", E)), zy && (d = t.lastIndex), v = ys(kp, q ? p : t, D), q ? v ? (v.input = Fy(v.input, T), v[0] = Fy(v[0], T), v.index = t.lastIndex, t.lastIndex += v[0].length) : t.lastIndex = 0 : zy && v && (t.lastIndex = t.global ? v.index + v[0].length : d), jy && v && v.length > 1 && ys(aZ, v[0], p, function () {
        for (g = 1; g < arguments.length - 2; g++) arguments[g] === void 0 && (v[g] = void 0);
      }), v && b) for (v.groups = x = tZ(null), g = 0; g < b.length; g++) S = b[g], x[S[0]] = v[S[1]];
      return v;
    });
    n_.exports = _Ly;
  });
  var Uy = h(function () {
    "use strict";

    var fZ = F(),
      o_ = Bp();
    fZ({
      target: "RegExp",
      proto: !0,
      forced: /./.exec !== o_
    }, {
      exec: o_
    });
  });
  var s_ = h(function () {
    "use strict";

    var pZ = F(),
      dZ = Q(),
      mZ = ra(),
      hZ = RangeError,
      i_ = String.fromCharCode,
      a_ = String.fromCodePoint,
      vZ = dZ([].join),
      gZ = !!a_ && a_.length !== 1;
    pZ({
      target: "String",
      stat: !0,
      arity: 1,
      forced: gZ
    }, {
      fromCodePoint: function fromCodePoint(r) {
        for (var t = [], i = arguments.length, a = 0, s; i > a;) {
          if (s = +arguments[a++], mZ(s, 1114111) !== s) throw new hZ(s + " is not a valid code point");
          t[a] = s < 65536 ? i_(s) : i_(((s -= 65536) >> 10) + 55296, s % 1024 + 56320);
        }
        return vZ(t, "");
      }
    });
  });
  var f_ = h(function () {
    "use strict";

    var yZ = F(),
      c_ = Q(),
      xZ = Wn(),
      SZ = Qr(),
      u_ = He(),
      bZ = wr(),
      l_ = c_([].push),
      wZ = c_([].join);
    yZ({
      target: "String",
      stat: !0
    }, {
      raw: function raw(r) {
        var t = xZ(SZ(r).raw),
          i = bZ(t);
        if (!i) return "";
        for (var a = arguments.length, s = [], l = 0;;) {
          if (l_(s, u_(t[l++])), l === i) return wZ(s, "");
          l < a && l_(s, u_(arguments[l]));
        }
      }
    });
  });
  var p_ = h(function () {
    "use strict";

    var EZ = F(),
      CZ = Cp().codeAt;
    EZ({
      target: "String",
      proto: !0
    }, {
      codePointAt: function codePointAt(r) {
        return CZ(this, r);
      }
    });
  });
  var Fp = h(function (eIe, d_) {
    "use strict";

    var IZ = nr(),
      PZ = Zt(),
      qZ = Ue(),
      TZ = qZ("match");
    d_.exports = function (e) {
      var r;
      return IZ(e) && ((r = e[TZ]) !== void 0 ? !!r : PZ(e) === "RegExp");
    };
  });
  var Lp = h(function (rIe, m_) {
    "use strict";

    var OZ = Fp(),
      AZ = TypeError;
    m_.exports = function (e) {
      if (OZ(e)) throw new AZ("The method doesn't accept regular expressions");
      return e;
    };
  });
  var zp = h(function (tIe, h_) {
    "use strict";

    var _Z = Ue(),
      NZ = _Z("match");
    h_.exports = function (e) {
      var r = /./;
      try {
        "/./"[e](r);
      } catch (_unused24) {
        try {
          return r[NZ] = !1, "/./"[e](r);
        } catch (_unused25) {}
      }
      return !1;
    };
  });
  var y_ = h(function () {
    "use strict";

    var RZ = F(),
      MZ = ta(),
      kZ = Zi().f,
      DZ = St(),
      v_ = He(),
      BZ = Lp(),
      FZ = er(),
      LZ = zp(),
      zZ = xr(),
      jZ = MZ("".slice),
      UZ = Math.min,
      g_ = LZ("endsWith"),
      HZ = !zZ && !g_ && !!function () {
        var e = kZ(String.prototype, "endsWith");
        return e && !e.writable;
      }();
    RZ({
      target: "String",
      proto: !0,
      forced: !HZ && !g_
    }, {
      endsWith: function endsWith(r) {
        var t = v_(FZ(this));
        BZ(r);
        var i = arguments.length > 1 ? arguments[1] : void 0,
          a = t.length,
          s = i === void 0 ? a : UZ(DZ(i), a),
          l = v_(r);
        return jZ(t, s - l.length, s) === l;
      }
    });
  });
  var S_ = h(function () {
    "use strict";

    var $Z = F(),
      VZ = Q(),
      WZ = Lp(),
      GZ = er(),
      x_ = He(),
      KZ = zp(),
      YZ = VZ("".indexOf);
    $Z({
      target: "String",
      proto: !0,
      forced: !KZ("includes")
    }, {
      includes: function includes(r) {
        return !!~YZ(x_(GZ(this)), x_(WZ(r)), arguments.length > 1 ? arguments[1] : void 0);
      }
    });
  });
  var w_ = h(function () {
    "use strict";

    var XZ = F(),
      QZ = Q(),
      JZ = er(),
      ZZ = He(),
      b_ = QZ("".charCodeAt);
    XZ({
      target: "String",
      proto: !0
    }, {
      isWellFormed: function isWellFormed() {
        for (var r = ZZ(JZ(this)), t = r.length, i = 0; i < t; i++) {
          var a = b_(r, i);
          if ((a & 63488) === 55296 && (a >= 56320 || ++i >= t || (b_(r, i) & 64512) !== 56320)) return !1;
        }
        return !0;
      }
    });
  });
  var _l = h(function (lIe, q_) {
    "use strict";

    Uy();
    var E_ = Oe(),
      C_ = at(),
      eee = Bp(),
      I_ = J(),
      P_ = Ue(),
      ree = Dt(),
      tee = P_("species"),
      Hy = RegExp.prototype;
    q_.exports = function (e, r, t, i) {
      var a = P_(e),
        s = !I_(function () {
          var v = {};
          return v[a] = function () {
            return 7;
          }, ""[e](v) !== 7;
        }),
        l = s && !I_(function () {
          var v = !1,
            g = /a/;
          return e === "split" && (g = {}, g.constructor = {}, g.constructor[tee] = function () {
            return g;
          }, g.flags = "", g[a] = /./[a]), g.exec = function () {
            return v = !0, null;
          }, g[a](""), !v;
        });
      if (!s || !l || t) {
        var p = /./[a],
          d = r(a, ""[e], function (v, g, x, S, b) {
            var q = g.exec;
            return q === eee || q === Hy.exec ? s && !b ? {
              done: !0,
              value: E_(p, g, x, S)
            } : {
              done: !0,
              value: E_(v, x, g, S)
            } : {
              done: !1
            };
          });
        C_(String.prototype, e, d[0]), C_(Hy, a, d[1]);
      }
      i && ree(Hy[a], "sham", !0);
    };
  });
  var Nl = h(function (cIe, T_) {
    "use strict";

    var nee = Cp().charAt;
    T_.exports = function (e, r, t) {
      return r + (t ? nee(e, r).length : 1);
    };
  });
  var xs = h(function (fIe, A_) {
    "use strict";

    var O_ = Oe(),
      oee = rr(),
      iee = Re(),
      aee = Zt(),
      see = Bp(),
      uee = TypeError;
    A_.exports = function (e, r) {
      var t = e.exec;
      if (iee(t)) {
        var i = O_(t, e, r);
        return i !== null && oee(i), i;
      }
      if (aee(e) === "RegExp") return O_(see, e, r);
      throw new uee("RegExp#exec called on incompatible receiver");
    };
  });
  var N_ = h(function () {
    "use strict";

    var lee = Oe(),
      cee = _l(),
      fee = rr(),
      pee = xt(),
      dee = St(),
      $y = He(),
      mee = er(),
      hee = Gn(),
      vee = Nl(),
      __ = xs();
    cee("match", function (e, r, t) {
      return [function (a) {
        var s = mee(this),
          l = pee(a) ? void 0 : hee(a, e);
        return l ? lee(l, a, s) : new RegExp(a)[e]($y(s));
      }, function (i) {
        var a = fee(this),
          s = $y(i),
          l = t(r, a, s);
        if (l.done) return l.value;
        if (!a.global) return __(a, s);
        var p = a.unicode;
        a.lastIndex = 0;
        for (var d = [], v = 0, g; (g = __(a, s)) !== null;) {
          var x = $y(g[0]);
          d[v] = x, x === "" && (a.lastIndex = vee(s, dee(a.lastIndex), p)), v++;
        }
        return v === 0 ? null : d;
      }];
    });
  });
  var jp = h(function (mIe, M_) {
    "use strict";

    var gee = Oe(),
      yee = Sr(),
      xee = vo(),
      See = Ry(),
      R_ = RegExp.prototype;
    M_.exports = function (e) {
      var r = e.flags;
      return r === void 0 && !("flags" in R_) && !yee(e, "flags") && xee(R_, e) ? gee(See, e) : r;
    };
  });
  var $_ = h(function () {
    "use strict";

    var bee = F(),
      k_ = Oe(),
      F_ = ta(),
      wee = ly(),
      Up = bl(),
      D_ = er(),
      L_ = St(),
      Rl = He(),
      Eee = rr(),
      Cee = xt(),
      Iee = Zt(),
      Pee = Fp(),
      z_ = jp(),
      qee = Gn(),
      Tee = at(),
      Oee = J(),
      Aee = Ue(),
      _ee = aa(),
      Nee = Nl(),
      Ree = xs(),
      j_ = en(),
      Wy = xr(),
      Hp = Aee("matchAll"),
      U_ = "RegExp String",
      H_ = U_ + " Iterator",
      Mee = j_.set,
      kee = j_.getterFor(H_),
      B_ = RegExp.prototype,
      Dee = TypeError,
      Gy = F_("".indexOf),
      $p = F_("".matchAll),
      Vy = !!$p && !Oee(function () {
        $p("a", /./);
      }),
      Bee = wee(function (r, t, i, a) {
        Mee(this, {
          type: H_,
          regexp: r,
          string: t,
          global: i,
          unicode: a,
          done: !1
        });
      }, U_, function () {
        var r = kee(this);
        if (r.done) return Up(void 0, !0);
        var t = r.regexp,
          i = r.string,
          a = Ree(t, i);
        return a === null ? (r.done = !0, Up(void 0, !0)) : r.global ? (Rl(a[0]) === "" && (t.lastIndex = Nee(i, L_(t.lastIndex), r.unicode)), Up(a, !1)) : (r.done = !0, Up(a, !1));
      }),
      Ky = function Ky(e) {
        var r = Eee(this),
          t = Rl(e),
          i = _ee(r, RegExp),
          a = Rl(z_(r)),
          s,
          l,
          p;
        return s = new i(i === RegExp ? r.source : r, a), l = !!~Gy(a, "g"), p = !!~Gy(a, "u"), s.lastIndex = L_(r.lastIndex), new Bee(s, t, l, p);
      };
    bee({
      target: "String",
      proto: !0,
      forced: Vy
    }, {
      matchAll: function matchAll(r) {
        var t = D_(this),
          i,
          a,
          s,
          l;
        if (Cee(r)) {
          if (Vy) return $p(t, r);
        } else {
          if (Pee(r) && (i = Rl(D_(z_(r))), !~Gy(i, "g"))) throw new Dee("`.matchAll` does not allow non-global regexes");
          if (Vy) return $p(t, r);
          if (s = qee(r, Hp), s === void 0 && Wy && Iee(r) === "RegExp" && (s = Ky), s) return k_(s, r, t);
        }
        return a = Rl(t), l = new RegExp(r, "g"), Wy ? k_(Ky, l, a) : l[Hp](a);
      }
    });
    Wy || Hp in B_ || Tee(B_, Hp, Ky);
  });
  var V_ = h(function () {
    "use strict";

    var Fee = F(),
      Lee = Ol();
    Fee({
      target: "String",
      proto: !0
    }, {
      repeat: Lee
    });
  });
  var Ss = h(function (xIe, Y_) {
    "use strict";

    var zee = el(),
      K_ = Function.prototype,
      W_ = K_.apply,
      G_ = K_.call;
    Y_.exports = (typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) == "object" && Reflect.apply || (zee ? G_.bind(W_) : function () {
      return G_.apply(W_, arguments);
    });
  });
  var Jy = h(function (SIe, X_) {
    "use strict";

    var Qy = Q(),
      jee = Qr(),
      Uee = Math.floor,
      Yy = Qy("".charAt),
      Hee = Qy("".replace),
      Xy = Qy("".slice),
      $ee = /\$([$&'`]|\d{1,2}|<[^>]*>)/g,
      Vee = /\$([$&'`]|\d{1,2})/g;
    X_.exports = function (e, r, t, i, a, s) {
      var l = t + e.length,
        p = i.length,
        d = Vee;
      return a !== void 0 && (a = jee(a), d = $ee), Hee(s, d, function (v, g) {
        var x;
        switch (Yy(g, 0)) {
          case "$":
            return "$";
          case "&":
            return e;
          case "`":
            return Xy(r, 0, t);
          case "'":
            return Xy(r, l);
          case "<":
            x = a[Xy(g, 1, -1)];
            break;
          default:
            var S = +g;
            if (S === 0) return v;
            if (S > p) {
              var b = Uee(S / 10);
              return b === 0 ? v : b <= p ? i[b - 1] === void 0 ? Yy(g, 1) : i[b - 1] + Yy(g, 1) : v;
            }
            x = i[S - 1];
        }
        return x === void 0 ? "" : x;
      });
    };
  });
  var rN = h(function () {
    "use strict";

    var Wee = Ss(),
      Q_ = Oe(),
      Vp = Q(),
      Gee = _l(),
      Kee = J(),
      Yee = rr(),
      Xee = Re(),
      Qee = xt(),
      Jee = br(),
      Zee = St(),
      bs = He(),
      ere = er(),
      rre = Nl(),
      tre = Gn(),
      nre = Jy(),
      ore = xs(),
      ire = Ue(),
      ex = ire("replace"),
      are = Math.max,
      sre = Math.min,
      ure = Vp([].concat),
      Zy = Vp([].push),
      J_ = Vp("".indexOf),
      Z_ = Vp("".slice),
      lre = function lre(e) {
        return e === void 0 ? e : String(e);
      },
      cre = function () {
        return "a".replace(/./, "$0") === "$0";
      }(),
      eN = function () {
        return /./[ex] ? /./[ex]("a", "$0") === "" : !1;
      }(),
      fre = !Kee(function () {
        var e = /./;
        return e.exec = function () {
          var r = [];
          return r.groups = {
            a: "7"
          }, r;
        }, "".replace(e, "$<a>") !== "7";
      });
    Gee("replace", function (e, r, t) {
      var i = eN ? "$" : "$0";
      return [function (s, l) {
        var p = ere(this),
          d = Qee(s) ? void 0 : tre(s, ex);
        return d ? Q_(d, s, p, l) : Q_(r, bs(p), s, l);
      }, function (a, s) {
        var l = Yee(this),
          p = bs(a);
        if (typeof s == "string" && J_(s, i) === -1 && J_(s, "$<") === -1) {
          var d = t(r, l, p, s);
          if (d.done) return d.value;
        }
        var v = Xee(s);
        v || (s = bs(s));
        var g = l.global,
          x;
        g && (x = l.unicode, l.lastIndex = 0);
        for (var S = [], b; b = ore(l, p), !(b === null || (Zy(S, b), !g));) {
          var q = bs(b[0]);
          q === "" && (l.lastIndex = rre(p, Zee(l.lastIndex), x));
        }
        for (var E = "", C = 0, T = 0; T < S.length; T++) {
          b = S[T];
          for (var D = bs(b[0]), M = are(sre(Jee(b.index), p.length), 0), k = [], W, ee = 1; ee < b.length; ee++) Zy(k, lre(b[ee]));
          var N = b.groups;
          if (v) {
            var B = ure([D], k, M, p);
            N !== void 0 && Zy(B, N), W = bs(Wee(s, void 0, B));
          } else W = nre(D, p, M, k, N, s);
          M >= C && (E += Z_(p, C, M) + W, C = M + D.length);
        }
        return E + Z_(p, C);
      }];
    }, !fre || !cre || eN);
  });
  var oN = h(function () {
    "use strict";

    var pre = F(),
      dre = Oe(),
      tx = Q(),
      tN = er(),
      mre = Re(),
      hre = xt(),
      vre = Fp(),
      ws = He(),
      gre = Gn(),
      yre = jp(),
      xre = Jy(),
      Sre = Ue(),
      bre = xr(),
      wre = Sre("replace"),
      Ere = TypeError,
      rx = tx("".indexOf),
      Cre = tx("".replace),
      nN = tx("".slice),
      Ire = Math.max;
    pre({
      target: "String",
      proto: !0
    }, {
      replaceAll: function replaceAll(r, t) {
        var i = tN(this),
          a,
          s,
          l,
          p,
          d,
          v,
          g,
          x,
          S,
          b = 0,
          q = 0,
          E = "";
        if (!hre(r)) {
          if (a = vre(r), a && (s = ws(tN(yre(r))), !~rx(s, "g"))) throw new Ere("`.replaceAll` does not allow non-global regexes");
          if (l = gre(r, wre), l) return dre(l, r, i, t);
          if (bre && a) return Cre(ws(i), r, t);
        }
        for (p = ws(i), d = ws(r), v = mre(t), v || (t = ws(t)), g = d.length, x = Ire(1, g), b = rx(p, d); b !== -1;) S = v ? ws(t(d, b, p)) : xre(d, p, b, [], void 0, t), E += nN(p, q, b) + S, q = b + g, b = b + x > p.length ? -1 : rx(p, d, b + x);
        return q < p.length && (E += nN(p, q)), E;
      }
    });
  });
  var sN = h(function () {
    "use strict";

    var Pre = Oe(),
      qre = _l(),
      Tre = rr(),
      Ore = xt(),
      Are = er(),
      iN = qy(),
      aN = He(),
      _re = Gn(),
      Nre = xs();
    qre("search", function (e, r, t) {
      return [function (a) {
        var s = Are(this),
          l = Ore(a) ? void 0 : _re(a, e);
        return l ? Pre(l, a, s) : new RegExp(a)[e](aN(s));
      }, function (i) {
        var a = Tre(this),
          s = aN(i),
          l = t(r, a, s);
        if (l.done) return l.value;
        var p = a.lastIndex;
        iN(p, 0) || (a.lastIndex = 0);
        var d = Nre(a, s);
        return iN(a.lastIndex, p) || (a.lastIndex = p), d === null ? -1 : d.index;
      }];
    });
  });
  var pN = h(function () {
    "use strict";

    var nx = Oe(),
      fN = Q(),
      Rre = _l(),
      Mre = rr(),
      kre = xt(),
      Dre = er(),
      Bre = aa(),
      Fre = Nl(),
      Lre = St(),
      uN = He(),
      zre = Gn(),
      lN = xs(),
      jre = By(),
      Ure = J(),
      Es = jre.UNSUPPORTED_Y,
      Hre = 4294967295,
      $re = Math.min,
      ox = fN([].push),
      ix = fN("".slice),
      Vre = !Ure(function () {
        var e = /(?:)/,
          r = e.exec;
        e.exec = function () {
          return r.apply(this, arguments);
        };
        var t = "ab".split(e);
        return t.length !== 2 || t[0] !== "a" || t[1] !== "b";
      }),
      cN = "abbc".split(/(b)*/)[1] === "c" || "test".split(/(?:)/, -1).length !== 4 || "ab".split(/(?:ab)*/).length !== 2 || ".".split(/(.?)(.?)/).length !== 4 || ".".split(/()()/).length > 1 || "".split(/.?/).length;
    Rre("split", function (e, r, t) {
      var i = "0".split(void 0, 0).length ? function (a, s) {
        return a === void 0 && s === 0 ? [] : nx(r, this, a, s);
      } : r;
      return [function (s, l) {
        var p = Dre(this),
          d = kre(s) ? void 0 : zre(s, e);
        return d ? nx(d, s, p, l) : nx(i, uN(p), s, l);
      }, function (a, s) {
        var l = Mre(this),
          p = uN(a);
        if (!cN) {
          var d = t(i, l, p, s, i !== r);
          if (d.done) return d.value;
        }
        var v = Bre(l, RegExp),
          g = l.unicode,
          x = (l.ignoreCase ? "i" : "") + (l.multiline ? "m" : "") + (l.unicode ? "u" : "") + (Es ? "g" : "y"),
          S = new v(Es ? "^(?:" + l.source + ")" : l, x),
          b = s === void 0 ? Hre : s >>> 0;
        if (b === 0) return [];
        if (p.length === 0) return lN(S, p) === null ? [p] : [];
        for (var q = 0, E = 0, C = []; E < p.length;) {
          S.lastIndex = Es ? 0 : E;
          var T = lN(S, Es ? ix(p, E) : p),
            D;
          if (T === null || (D = $re(Lre(S.lastIndex + (Es ? E : 0)), p.length)) === q) E = Fre(p, E, g);else {
            if (ox(C, ix(p, q, E)), C.length === b) return C;
            for (var M = 1; M <= T.length - 1; M++) if (ox(C, T[M]), C.length === b) return C;
            E = q = D;
          }
        }
        return ox(C, ix(p, q)), C;
      }];
    }, cN || !Vre, Es);
  });
  var hN = h(function () {
    "use strict";

    var Wre = F(),
      Gre = ta(),
      Kre = Zi().f,
      Yre = St(),
      dN = He(),
      Xre = Lp(),
      Qre = er(),
      Jre = zp(),
      Zre = xr(),
      ete = Gre("".slice),
      rte = Math.min,
      mN = Jre("startsWith"),
      tte = !Zre && !mN && !!function () {
        var e = Kre(String.prototype, "startsWith");
        return e && !e.writable;
      }();
    Wre({
      target: "String",
      proto: !0,
      forced: !tte && !mN
    }, {
      startsWith: function startsWith(r) {
        var t = dN(Qre(this));
        Xre(r);
        var i = Yre(rte(arguments.length > 1 ? arguments[1] : void 0, t.length)),
          a = dN(r);
        return ete(t, i, i + a.length) === a;
      }
    });
  });
  var gN = h(function () {
    "use strict";

    var nte = F(),
      ote = Q(),
      ite = er(),
      vN = br(),
      ate = He(),
      ste = ote("".slice),
      ute = Math.max,
      lte = Math.min,
      cte = !"".substr || "ab".substr(-1) !== "b";
    nte({
      target: "String",
      proto: !0,
      forced: cte
    }, {
      substr: function substr(r, t) {
        var i = ate(ite(this)),
          a = i.length,
          s = vN(r),
          l,
          p;
        return s === 1 / 0 && (s = 0), s < 0 && (s = ute(a + s, 0)), l = t === void 0 ? a : vN(t), l <= 0 || l === 1 / 0 ? "" : (p = lte(s + l, a), s >= p ? "" : ste(i, s, p));
      }
    });
  });
  var bN = h(function () {
    "use strict";

    var fte = F(),
      SN = Oe(),
      ux = Q(),
      pte = er(),
      dte = He(),
      mte = J(),
      hte = Array,
      ax = ux("".charAt),
      yN = ux("".charCodeAt),
      vte = ux([].join),
      sx = "".toWellFormed,
      gte = "�",
      xN = sx && mte(function () {
        return SN(sx, 1) !== "1";
      });
    fte({
      target: "String",
      proto: !0,
      forced: xN
    }, {
      toWellFormed: function toWellFormed() {
        var r = dte(pte(this));
        if (xN) return SN(sx, r);
        for (var t = r.length, i = hte(t), a = 0; a < t; a++) {
          var s = yN(r, a);
          (s & 63488) !== 55296 ? i[a] = ax(r, a) : s >= 56320 || a + 1 >= t || (yN(r, a + 1) & 64512) !== 56320 ? i[a] = gte : (i[a] = ax(r, a), i[++a] = ax(r, a));
        }
        return vte(i, "");
      }
    });
  });
  var Wp = h(function (kIe, CN) {
    "use strict";

    var yte = nl().PROPER,
      xte = J(),
      wN = Pl(),
      EN = "​᠎";
    CN.exports = function (e) {
      return xte(function () {
        return !!wN[e]() || EN[e]() !== EN || yte && wN[e].name !== e;
      });
    };
  });
  var IN = h(function () {
    "use strict";

    var Ste = F(),
      bte = la().trim,
      wte = Wp();
    Ste({
      target: "String",
      proto: !0,
      forced: wte("trim")
    }, {
      trim: function trim() {
        return bte(this);
      }
    });
  });
  var lx = h(function (FIe, PN) {
    "use strict";

    var Ete = la().start,
      Cte = Wp();
    PN.exports = Cte("trimStart") ? function () {
      return Ete(this);
    } : "".trimStart;
  });
  var TN = h(function () {
    "use strict";

    var Ite = F(),
      qN = lx();
    Ite({
      target: "String",
      proto: !0,
      name: "trimStart",
      forced: "".trimLeft !== qN
    }, {
      trimLeft: qN
    });
  });
  var AN = h(function () {
    "use strict";

    TN();
    var Pte = F(),
      ON = lx();
    Pte({
      target: "String",
      proto: !0,
      name: "trimStart",
      forced: "".trimStart !== ON
    }, {
      trimStart: ON
    });
  });
  var cx = h(function (HIe, _N) {
    "use strict";

    var qte = la().end,
      Tte = Wp();
    _N.exports = Tte("trimEnd") ? function () {
      return qte(this);
    } : "".trimEnd;
  });
  var RN = h(function () {
    "use strict";

    var Ote = F(),
      NN = cx();
    Ote({
      target: "String",
      proto: !0,
      name: "trimEnd",
      forced: "".trimRight !== NN
    }, {
      trimRight: NN
    });
  });
  var kN = h(function () {
    "use strict";

    RN();
    var Ate = F(),
      MN = cx();
    Ate({
      target: "String",
      proto: !0,
      name: "trimEnd",
      forced: "".trimEnd !== MN
    }, {
      trimEnd: MN
    });
  });
  var It = h(function (KIe, BN) {
    "use strict";

    var _te = Q(),
      Nte = er(),
      DN = He(),
      Rte = /"/g,
      Mte = _te("".replace);
    BN.exports = function (e, r, t, i) {
      var a = DN(Nte(e)),
        s = "<" + r;
      return t !== "" && (s += " " + t + '="' + Mte(DN(i), Rte, "&quot;") + '"'), s + ">" + a + "</" + r + ">";
    };
  });
  var Pt = h(function (YIe, FN) {
    "use strict";

    var kte = J();
    FN.exports = function (e) {
      return kte(function () {
        var r = ""[e]('"');
        return r !== r.toLowerCase() || r.split('"').length > 3;
      });
    };
  });
  var LN = h(function () {
    "use strict";

    var Dte = F(),
      Bte = It(),
      Fte = Pt();
    Dte({
      target: "String",
      proto: !0,
      forced: Fte("anchor")
    }, {
      anchor: function anchor(r) {
        return Bte(this, "a", "name", r);
      }
    });
  });
  var zN = h(function () {
    "use strict";

    var Lte = F(),
      zte = It(),
      jte = Pt();
    Lte({
      target: "String",
      proto: !0,
      forced: jte("big")
    }, {
      big: function big() {
        return zte(this, "big", "", "");
      }
    });
  });
  var jN = h(function () {
    "use strict";

    var Ute = F(),
      Hte = It(),
      $te = Pt();
    Ute({
      target: "String",
      proto: !0,
      forced: $te("blink")
    }, {
      blink: function blink() {
        return Hte(this, "blink", "", "");
      }
    });
  });
  var UN = h(function () {
    "use strict";

    var Vte = F(),
      Wte = It(),
      Gte = Pt();
    Vte({
      target: "String",
      proto: !0,
      forced: Gte("bold")
    }, {
      bold: function bold() {
        return Wte(this, "b", "", "");
      }
    });
  });
  var HN = h(function () {
    "use strict";

    var Kte = F(),
      Yte = It(),
      Xte = Pt();
    Kte({
      target: "String",
      proto: !0,
      forced: Xte("fixed")
    }, {
      fixed: function fixed() {
        return Yte(this, "tt", "", "");
      }
    });
  });
  var $N = h(function () {
    "use strict";

    var Qte = F(),
      Jte = It(),
      Zte = Pt();
    Qte({
      target: "String",
      proto: !0,
      forced: Zte("fontcolor")
    }, {
      fontcolor: function fontcolor(r) {
        return Jte(this, "font", "color", r);
      }
    });
  });
  var VN = h(function () {
    "use strict";

    var ene = F(),
      rne = It(),
      tne = Pt();
    ene({
      target: "String",
      proto: !0,
      forced: tne("fontsize")
    }, {
      fontsize: function fontsize(r) {
        return rne(this, "font", "size", r);
      }
    });
  });
  var WN = h(function () {
    "use strict";

    var nne = F(),
      one = It(),
      ine = Pt();
    nne({
      target: "String",
      proto: !0,
      forced: ine("italics")
    }, {
      italics: function italics() {
        return one(this, "i", "", "");
      }
    });
  });
  var GN = h(function () {
    "use strict";

    var ane = F(),
      sne = It(),
      une = Pt();
    ane({
      target: "String",
      proto: !0,
      forced: une("link")
    }, {
      link: function link(r) {
        return sne(this, "a", "href", r);
      }
    });
  });
  var KN = h(function () {
    "use strict";

    var lne = F(),
      cne = It(),
      fne = Pt();
    lne({
      target: "String",
      proto: !0,
      forced: fne("small")
    }, {
      small: function small() {
        return cne(this, "small", "", "");
      }
    });
  });
  var YN = h(function () {
    "use strict";

    var pne = F(),
      dne = It(),
      mne = Pt();
    pne({
      target: "String",
      proto: !0,
      forced: mne("strike")
    }, {
      strike: function strike() {
        return dne(this, "strike", "", "");
      }
    });
  });
  var XN = h(function () {
    "use strict";

    var hne = F(),
      vne = It(),
      gne = Pt();
    hne({
      target: "String",
      proto: !0,
      forced: gne("sub")
    }, {
      sub: function sub() {
        return vne(this, "sub", "", "");
      }
    });
  });
  var QN = h(function () {
    "use strict";

    var yne = F(),
      xne = It(),
      Sne = Pt();
    yne({
      target: "String",
      proto: !0,
      forced: Sne("sup")
    }, {
      sup: function sup() {
        return xne(this, "sup", "", "");
      }
    });
  });
  var ZN = h(function (wPe, JN) {
    "use strict";

    ni();
    Uy();
    s_();
    f_();
    p_();
    Ny();
    y_();
    S_();
    w_();
    N_();
    $_();
    Ay();
    _y();
    V_();
    rN();
    oN();
    sN();
    pN();
    hN();
    gN();
    bN();
    IN();
    AN();
    kN();
    ua();
    LN();
    zN();
    jN();
    UN();
    HN();
    $N();
    VN();
    WN();
    GN();
    KN();
    YN();
    XN();
    QN();
    var bne = Ct();
    JN.exports = bne.String;
  });
  var rR = h(function (EPe, eR) {
    "use strict";

    var wne = ZN();
    eR.exports = wne;
  });
  var Ml = h(function (CPe, tR) {
    "use strict";

    var Ene = He();
    tR.exports = function (e, r) {
      return e === void 0 ? arguments.length < 2 ? "" : r : Ene(e);
    };
  });
  var fx = h(function (IPe, oR) {
    "use strict";

    var Cne = Xe(),
      Ine = J(),
      Pne = rr(),
      nR = Ml(),
      Gp = Error.prototype.toString,
      qne = Ine(function () {
        if (Cne) {
          var e = Object.create(Object.defineProperty({}, "name", {
            get: function get() {
              return this === e;
            }
          }));
          if (Gp.call(e) !== "true") return !0;
        }
        return Gp.call({
          message: 1,
          name: 2
        }) !== "2: 1" || Gp.call({}) !== "Error";
      });
    oR.exports = qne ? function () {
      var r = Pne(this),
        t = nR(r.name, "Error"),
        i = nR(r.message);
      return t ? i ? t + ": " + i : t : i;
    } : Gp;
  });
  var sR = h(function () {
    "use strict";

    var Tne = at(),
      iR = fx(),
      aR = Error.prototype;
    aR.toString !== iR && Tne(aR, "toString", iR);
  });
  var ca = h(function (TPe, pR) {
    "use strict";

    var One = Wn(),
      px = So(),
      uR = ds(),
      cR = en(),
      Ane = it().f,
      _ne = qp(),
      Kp = bl(),
      Nne = xr(),
      Rne = Xe(),
      fR = "Array Iterator",
      Mne = cR.set,
      kne = cR.getterFor(fR);
    pR.exports = _ne(Array, "Array", function (e, r) {
      Mne(this, {
        type: fR,
        target: One(e),
        index: 0,
        kind: r
      });
    }, function () {
      var e = kne(this),
        r = e.target,
        t = e.index++;
      if (!r || t >= r.length) return e.target = void 0, Kp(void 0, !0);
      switch (e.kind) {
        case "keys":
          return Kp(t, !1);
        case "values":
          return Kp(r[t], !1);
      }
      return Kp([t, r[t]], !1);
    }, "values");
    var lR = uR.Arguments = uR.Array;
    px("keys");
    px("values");
    px("entries");
    if (!Nne && Rne && lR.name !== "values") try {
      Ane(lR, "name", {
        value: "values"
      });
    } catch (_unused26) {}
  });
  var mR = h(function () {
    "use strict";

    var Dne = F(),
      Bne = Qr(),
      dR = pl(),
      Fne = J(),
      Lne = Fne(function () {
        dR(1);
      });
    Dne({
      target: "Object",
      stat: !0,
      forced: Lne
    }, {
      keys: function keys(r) {
        return dR(Bne(r));
      }
    });
  });
  var yR = h(function (_Pe, gR) {
    "use strict";

    var zne = Zt(),
      jne = Wn(),
      hR = as().f,
      Une = oa(),
      vR = (typeof window === "undefined" ? "undefined" : _typeof(window)) == "object" && window && Object.getOwnPropertyNames ? Object.getOwnPropertyNames(window) : [],
      Hne = function Hne(e) {
        try {
          return hR(e);
        } catch (_unused27) {
          return Une(vR);
        }
      };
    gR.exports.f = function (r) {
      return vR && zne(r) === "Window" ? Hne(r) : hR(jne(r));
    };
  });
  var SR = h(function (NPe, xR) {
    "use strict";

    var $ne = J();
    xR.exports = $ne(function () {
      if (typeof ArrayBuffer == "function") {
        var e = new ArrayBuffer(8);
        Object.isExtensible(e) && Object.defineProperty(e, "a", {
          value: 8
        });
      }
    });
  });
  var ER = h(function (RPe, wR) {
    "use strict";

    var Vne = J(),
      Wne = nr(),
      Gne = Zt(),
      bR = SR(),
      Yp = Object.isExtensible,
      Kne = Vne(function () {
        Yp(1);
      });
    wR.exports = Kne || bR ? function (r) {
      return !Wne(r) || bR && Gne(r) === "ArrayBuffer" ? !1 : Yp ? Yp(r) : !0;
    } : Yp;
  });
  var IR = h(function (MPe, CR) {
    "use strict";

    var Yne = J();
    CR.exports = !Yne(function () {
      return Object.isExtensible(Object.preventExtensions({}));
    });
  });
  var vx = h(function (kPe, TR) {
    "use strict";

    var Xne = F(),
      Qne = Q(),
      Jne = ol(),
      Zne = nr(),
      dx = Sr(),
      eoe = it().f,
      PR = as(),
      roe = yR(),
      mx = ER(),
      toe = os(),
      noe = IR(),
      qR = !1,
      Io = toe("meta"),
      ooe = 0,
      hx = function hx(e) {
        eoe(e, Io, {
          value: {
            objectID: "O" + ooe++,
            weakData: {}
          }
        });
      },
      ioe = function ioe(e, r) {
        if (!Zne(e)) return _typeof(e) == "symbol" ? e : (typeof e == "string" ? "S" : "P") + e;
        if (!dx(e, Io)) {
          if (!mx(e)) return "F";
          if (!r) return "E";
          hx(e);
        }
        return e[Io].objectID;
      },
      aoe = function aoe(e, r) {
        if (!dx(e, Io)) {
          if (!mx(e)) return !0;
          if (!r) return !1;
          hx(e);
        }
        return e[Io].weakData;
      },
      soe = function soe(e) {
        return noe && qR && mx(e) && !dx(e, Io) && hx(e), e;
      },
      uoe = function uoe() {
        loe.enable = function () {}, qR = !0;
        var e = PR.f,
          r = Qne([].splice),
          t = {};
        t[Io] = 1, e(t).length && (PR.f = function (i) {
          for (var a = e(i), s = 0, l = a.length; s < l; s++) if (a[s] === Io) {
            r(a, s, 1);
            break;
          }
          return a;
        }, Xne({
          target: "Object",
          stat: !0,
          forced: !0
        }, {
          getOwnPropertyNames: roe.f
        }));
      },
      loe = TR.exports = {
        enable: uoe,
        fastKey: ioe,
        getWeakData: aoe,
        onFreeze: soe
      };
    Jne[Io] = !0;
  });
  var Jn = h(function (DPe, NR) {
    "use strict";

    var coe = yo(),
      foe = Oe(),
      poe = rr(),
      doe = Ji(),
      moe = Tp(),
      hoe = wr(),
      OR = vo(),
      voe = Op(),
      goe = El(),
      AR = wl(),
      yoe = TypeError,
      Xp = function Xp(e, r) {
        this.stopped = e, this.result = r;
      },
      _R = Xp.prototype;
    NR.exports = function (e, r, t) {
      var i = t && t.that,
        a = !!(t && t.AS_ENTRIES),
        s = !!(t && t.IS_RECORD),
        l = !!(t && t.IS_ITERATOR),
        p = !!(t && t.INTERRUPTED),
        d = coe(r, i),
        v,
        g,
        x,
        S,
        b,
        q,
        E,
        C = function C(D) {
          return v && AR(v, "normal", D), new Xp(!0, D);
        },
        T = function T(D) {
          return a ? (poe(D), p ? d(D[0], D[1], C) : d(D[0], D[1])) : p ? d(D, C) : d(D);
        };
      if (s) v = e.iterator;else if (l) v = e;else {
        if (g = goe(e), !g) throw new yoe(doe(e) + " is not iterable");
        if (moe(g)) {
          for (x = 0, S = hoe(e); S > x; x++) if (b = T(e[x]), b && OR(_R, b)) return b;
          return new Xp(!1);
        }
        v = voe(e, g);
      }
      for (q = s ? e.next : v.next; !(E = foe(q, v)).done;) {
        try {
          b = T(E.value);
        } catch (D) {
          AR(v, "throw", D);
        }
        if (_typeof(b) == "object" && b && OR(_R, b)) return b;
      }
      return new Xp(!1);
    };
  });
  var xx = h(function (BPe, MR) {
    "use strict";

    var xoe = F(),
      Soe = ae(),
      boe = Q(),
      RR = ul(),
      woe = at(),
      Eoe = vx(),
      Coe = Jn(),
      Ioe = Xo(),
      Poe = Re(),
      qoe = xt(),
      gx = nr(),
      yx = J(),
      Toe = Cl(),
      Ooe = Jo(),
      Aoe = ss();
    MR.exports = function (e, r, t) {
      var i = e.indexOf("Map") !== -1,
        a = e.indexOf("Weak") !== -1,
        s = i ? "set" : "add",
        l = Soe[e],
        p = l && l.prototype,
        d = l,
        v = {},
        g = function g(T) {
          var D = boe(p[T]);
          woe(p, T, T === "add" ? function (k) {
            return D(this, k === 0 ? 0 : k), this;
          } : T === "delete" ? function (M) {
            return a && !gx(M) ? !1 : D(this, M === 0 ? 0 : M);
          } : T === "get" ? function (k) {
            return a && !gx(k) ? void 0 : D(this, k === 0 ? 0 : k);
          } : T === "has" ? function (k) {
            return a && !gx(k) ? !1 : D(this, k === 0 ? 0 : k);
          } : function (k, W) {
            return D(this, k === 0 ? 0 : k, W), this;
          });
        },
        x = RR(e, !Poe(l) || !(a || p.forEach && !yx(function () {
          new l().entries().next();
        })));
      if (x) d = t.getConstructor(r, e, i, s), Eoe.enable();else if (RR(e, !0)) {
        var S = new d(),
          b = S[s](a ? {} : -0, 1) !== S,
          q = yx(function () {
            S.has(1);
          }),
          E = Toe(function (T) {
            new l(T);
          }),
          C = !a && yx(function () {
            for (var T = new l(), D = 5; D--;) T[s](D, D);
            return !T.has(-0);
          });
        E || (d = r(function (T, D) {
          Ioe(T, p);
          var M = Aoe(new l(), T, d);
          return qoe(D) || Coe(D, M[s], {
            that: M,
            AS_ENTRIES: i
          }), M;
        }), d.prototype = p, p.constructor = d), (q || C) && (g("delete"), g("has"), i && g("get")), (C || b) && g(s), a && p.clear && delete p.clear;
      }
      return v[e] = d, xoe({
        global: !0,
        constructor: !0,
        forced: d !== l
      }, v), Ooe(d, e), a || t.setStrong(d, e, i), d;
    };
  });
  var bx = h(function (FPe, zR) {
    "use strict";

    var kR = xo(),
      _oe = Yo(),
      DR = Eg(),
      Noe = yo(),
      Roe = Xo(),
      Moe = xt(),
      koe = Jn(),
      Doe = qp(),
      Qp = bl(),
      Boe = yl(),
      kl = Xe(),
      BR = vx().fastKey,
      LR = en(),
      FR = LR.set,
      Sx = LR.getterFor;
    zR.exports = {
      getConstructor: function getConstructor(e, r, t, i) {
        var a = e(function (v, g) {
            Roe(v, s), FR(v, {
              type: r,
              index: kR(null),
              first: void 0,
              last: void 0,
              size: 0
            }), kl || (v.size = 0), Moe(g) || koe(g, v[i], {
              that: v,
              AS_ENTRIES: t
            });
          }),
          s = a.prototype,
          l = Sx(r),
          p = function p(v, g, x) {
            var S = l(v),
              b = d(v, g),
              q,
              E;
            return b ? b.value = x : (S.last = b = {
              index: E = BR(g, !0),
              key: g,
              value: x,
              previous: q = S.last,
              next: void 0,
              removed: !1
            }, S.first || (S.first = b), q && (q.next = b), kl ? S.size++ : v.size++, E !== "F" && (S.index[E] = b)), v;
          },
          d = function d(v, g) {
            var x = l(v),
              S = BR(g),
              b;
            if (S !== "F") return x.index[S];
            for (b = x.first; b; b = b.next) if (b.key === g) return b;
          };
        return DR(s, {
          clear: function clear() {
            for (var g = this, x = l(g), S = x.first; S;) S.removed = !0, S.previous && (S.previous = S.previous.next = void 0), S = S.next;
            x.first = x.last = void 0, x.index = kR(null), kl ? x.size = 0 : g.size = 0;
          },
          delete: function _delete(v) {
            var g = this,
              x = l(g),
              S = d(g, v);
            if (S) {
              var b = S.next,
                q = S.previous;
              delete x.index[S.index], S.removed = !0, q && (q.next = b), b && (b.previous = q), x.first === S && (x.first = b), x.last === S && (x.last = q), kl ? x.size-- : g.size--;
            }
            return !!S;
          },
          forEach: function forEach(g) {
            for (var x = l(this), S = Noe(g, arguments.length > 1 ? arguments[1] : void 0), b; b = b ? b.next : x.first;) for (S(b.value, b.key, this); b && b.removed;) b = b.previous;
          },
          has: function has(g) {
            return !!d(this, g);
          }
        }), DR(s, t ? {
          get: function get(g) {
            var x = d(this, g);
            return x && x.value;
          },
          set: function set(g, x) {
            return p(this, g === 0 ? 0 : g, x);
          }
        } : {
          add: function add(g) {
            return p(this, g = g === 0 ? 0 : g, g);
          }
        }), kl && _oe(s, "size", {
          configurable: !0,
          get: function get() {
            return l(this).size;
          }
        }), a;
      },
      setStrong: function setStrong(e, r, t) {
        var i = r + " Iterator",
          a = Sx(r),
          s = Sx(i);
        Doe(e, r, function (l, p) {
          FR(this, {
            type: i,
            target: l,
            state: a(l),
            kind: p,
            last: void 0
          });
        }, function () {
          for (var l = s(this), p = l.kind, d = l.last; d && d.removed;) d = d.previous;
          return !l.target || !(l.last = d = d ? d.next : l.state.first) ? (l.target = void 0, Qp(void 0, !0)) : Qp(p === "keys" ? d.key : p === "values" ? d.value : [d.key, d.value], !1);
        }, t ? "entries" : "values", !t, !0), Boe(r);
      }
    };
  });
  var jR = h(function () {
    "use strict";

    var Foe = xx(),
      Loe = bx();
    Foe("Map", function (e) {
      return function () {
        return e(this, arguments.length ? arguments[0] : void 0);
      };
    }, Loe);
  });
  var wx = h(function () {
    "use strict";

    jR();
  });
  var UR = h(function () {
    "use strict";

    var zoe = xx(),
      joe = bx();
    zoe("Set", function (e) {
      return function () {
        return e(this, arguments.length ? arguments[0] : void 0);
      };
    }, joe);
  });
  var Ex = h(function () {
    "use strict";

    UR();
  });
  var Cx = h(function (GPe, HR) {
    "use strict";

    HR.exports = {
      IndexSizeError: {
        s: "INDEX_SIZE_ERR",
        c: 1,
        m: 1
      },
      DOMStringSizeError: {
        s: "DOMSTRING_SIZE_ERR",
        c: 2,
        m: 0
      },
      HierarchyRequestError: {
        s: "HIERARCHY_REQUEST_ERR",
        c: 3,
        m: 1
      },
      WrongDocumentError: {
        s: "WRONG_DOCUMENT_ERR",
        c: 4,
        m: 1
      },
      InvalidCharacterError: {
        s: "INVALID_CHARACTER_ERR",
        c: 5,
        m: 1
      },
      NoDataAllowedError: {
        s: "NO_DATA_ALLOWED_ERR",
        c: 6,
        m: 0
      },
      NoModificationAllowedError: {
        s: "NO_MODIFICATION_ALLOWED_ERR",
        c: 7,
        m: 1
      },
      NotFoundError: {
        s: "NOT_FOUND_ERR",
        c: 8,
        m: 1
      },
      NotSupportedError: {
        s: "NOT_SUPPORTED_ERR",
        c: 9,
        m: 1
      },
      InUseAttributeError: {
        s: "INUSE_ATTRIBUTE_ERR",
        c: 10,
        m: 1
      },
      InvalidStateError: {
        s: "INVALID_STATE_ERR",
        c: 11,
        m: 1
      },
      SyntaxError: {
        s: "SYNTAX_ERR",
        c: 12,
        m: 1
      },
      InvalidModificationError: {
        s: "INVALID_MODIFICATION_ERR",
        c: 13,
        m: 1
      },
      NamespaceError: {
        s: "NAMESPACE_ERR",
        c: 14,
        m: 1
      },
      InvalidAccessError: {
        s: "INVALID_ACCESS_ERR",
        c: 15,
        m: 1
      },
      ValidationError: {
        s: "VALIDATION_ERR",
        c: 16,
        m: 0
      },
      TypeMismatchError: {
        s: "TYPE_MISMATCH_ERR",
        c: 17,
        m: 1
      },
      SecurityError: {
        s: "SECURITY_ERR",
        c: 18,
        m: 1
      },
      NetworkError: {
        s: "NETWORK_ERR",
        c: 19,
        m: 1
      },
      AbortError: {
        s: "ABORT_ERR",
        c: 20,
        m: 1
      },
      URLMismatchError: {
        s: "URL_MISMATCH_ERR",
        c: 21,
        m: 1
      },
      QuotaExceededError: {
        s: "QUOTA_EXCEEDED_ERR",
        c: 22,
        m: 1
      },
      TimeoutError: {
        s: "TIMEOUT_ERR",
        c: 23,
        m: 1
      },
      InvalidNodeTypeError: {
        s: "INVALID_NODE_TYPE_ERR",
        c: 24,
        m: 1
      },
      DataCloneError: {
        s: "DATA_CLONE_ERR",
        c: 25,
        m: 1
      }
    };
  });
  var Jp = h(function (KPe, WR) {
    "use strict";

    var Uoe = Q(),
      $R = Error,
      Hoe = Uoe("".replace),
      $oe = function (e) {
        return String(new $R(e).stack);
      }("zxcasd"),
      VR = /\n\s*at [^:]*:[^\n]*/,
      Voe = VR.test($oe);
    WR.exports = function (e, r) {
      if (Voe && typeof e == "string" && !$R.prepareStackTrace) for (; r--;) e = Hoe(e, VR, "");
      return e;
    };
  });
  var nM = h(function () {
    "use strict";

    var Woe = F(),
      Goe = Vg(),
      rd = ot(),
      Ax = J(),
      Koe = xo(),
      _x = Vn(),
      td = it().f,
      Yoe = at(),
      Zp = Yo(),
      ed = Sr(),
      Xoe = Xo(),
      Qoe = rr(),
      YR = fx(),
      GR = Ml(),
      Cs = Cx(),
      Joe = Jp(),
      XR = en(),
      Nx = Xe(),
      QR = xr(),
      Is = "DOMException",
      Ox = "DATA_CLONE_ERR",
      od = rd("Error"),
      Po = rd(Is) || function () {
        try {
          var e = rd("MessageChannel") || Goe("worker_threads").MessageChannel;
          new e().port1.postMessage(new WeakMap());
        } catch (r) {
          if (r.name === Ox && r.code === 25) return r.constructor;
        }
      }(),
      Zoe = Po && Po.prototype,
      JR = od.prototype,
      eie = XR.set,
      rie = XR.getterFor(Is),
      tie = "stack" in new od(Is),
      ZR = function ZR(e) {
        return ed(Cs, e) && Cs[e].m ? Cs[e].c : 0;
      },
      Rx = function Rx() {
        Xoe(this, Bl);
        var r = arguments.length,
          t = GR(r < 1 ? void 0 : arguments[0]),
          i = GR(r < 2 ? void 0 : arguments[1], "Error"),
          a = ZR(i);
        if (eie(this, {
          type: Is,
          name: i,
          message: t,
          code: a
        }), Nx || (this.name = i, this.message = t, this.code = a), tie) {
          var s = new od(t);
          s.name = Is, td(this, "stack", _x(1, Joe(s.stack, 1)));
        }
      },
      Bl = Rx.prototype = Koe(JR),
      eM = function eM(e) {
        return {
          enumerable: !0,
          configurable: !0,
          get: e
        };
      },
      Ix = function Ix(e) {
        return eM(function () {
          return rie(this)[e];
        });
      };
    Nx && (Zp(Bl, "code", Ix("code")), Zp(Bl, "message", Ix("message")), Zp(Bl, "name", Ix("name")));
    td(Bl, "constructor", _x(1, Rx));
    var id = Ax(function () {
        return !(new Po() instanceof od);
      }),
      rM = id || Ax(function () {
        return JR.toString !== YR || String(new Po(1, 2)) !== "2: 1";
      }),
      tM = id || Ax(function () {
        return new Po(1, "DataCloneError").code !== 25;
      }),
      nie = id || Po[Ox] !== 25 || Zoe[Ox] !== 25,
      KR = QR ? rM || tM || nie : id;
    Woe({
      global: !0,
      constructor: !0,
      forced: KR
    }, {
      DOMException: KR ? Rx : Po
    });
    var Fl = rd(Is),
      nd = Fl.prototype;
    rM && (QR || Po === Fl) && Yoe(nd, "toString", YR);
    tM && Nx && Po === Fl && Zp(nd, "code", eM(function () {
      return ZR(Qoe(this).name);
    }));
    for (Px in Cs) ed(Cs, Px) && (qx = Cs[Px], Dl = qx.s, Tx = _x(6, qx.c), ed(Fl, Dl) || td(Fl, Dl, Tx), ed(nd, Dl) || td(nd, Dl, Tx));
    var qx, Dl, Tx, Px;
  });
  var cM = h(function () {
    "use strict";

    var oie = F(),
      iie = ae(),
      jx = ot(),
      Lx = Vn(),
      zx = it().f,
      oM = Sr(),
      aie = Xo(),
      sie = ss(),
      iM = Ml(),
      Mx = Cx(),
      uie = Jp(),
      lie = Xe(),
      uM = xr(),
      zl = "DOMException",
      lM = jx("Error"),
      jl = jx(zl),
      _Ux = function Ux() {
        aie(this, cie);
        var r = arguments.length,
          t = iM(r < 1 ? void 0 : arguments[0]),
          i = iM(r < 2 ? void 0 : arguments[1], "Error"),
          a = new jl(t, i),
          s = new lM(t);
        return s.name = zl, zx(a, "stack", Lx(1, uie(s.stack, 1))), sie(a, this, _Ux), a;
      },
      cie = _Ux.prototype = jl.prototype,
      fie = "stack" in new lM(zl),
      pie = "stack" in new jl(1, 2),
      kx = jl && lie && Object.getOwnPropertyDescriptor(iie, zl),
      die = !!kx && !(kx.writable && kx.configurable),
      aM = fie && !die && !pie;
    oie({
      global: !0,
      constructor: !0,
      forced: uM || aM
    }, {
      DOMException: aM ? _Ux : jl
    });
    var Ll = jx(zl),
      sM = Ll.prototype;
    if (sM.constructor !== Ll) {
      uM || zx(sM, "constructor", Lx(1, Ll));
      for (Dx in Mx) oM(Mx, Dx) && (Bx = Mx[Dx], Fx = Bx.s, oM(Ll, Fx) || zx(Ll, Fx, Lx(6, Bx.c)));
    }
    var Bx, Fx, Dx;
  });
  var pM = h(function () {
    "use strict";

    var mie = ot(),
      hie = Jo(),
      fM = "DOMException";
    hie(mie(fM), fM);
  });
  var Hx = h(function (rqe, dM) {
    "use strict";

    var vie = TypeError;
    dM.exports = function (e, r) {
      if (e < r) throw new vie("Not enough arguments");
      return e;
    };
  });
  var $x = h(function (tqe, mM) {
    "use strict";

    var ad = Q(),
      Ul = Map.prototype;
    mM.exports = {
      Map: Map,
      set: ad(Ul.set),
      get: ad(Ul.get),
      has: ad(Ul.has),
      remove: ad(Ul.delete),
      proto: Ul
    };
  });
  var rn = h(function (nqe, hM) {
    "use strict";

    var Vx = Q(),
      sd = Set.prototype;
    hM.exports = {
      Set: Set,
      add: Vx(sd.add),
      has: Vx(sd.has),
      remove: Vx(sd.delete),
      proto: sd
    };
  });
  var oi = h(function (oqe, vM) {
    "use strict";

    var gie = Oe();
    vM.exports = function (e, r, t) {
      for (var i = t ? e : e.iterator, a = e.next, s, l; !(s = gie(a, i)).done;) if (l = r(s.value), l !== void 0) return l;
    };
  });
  var fa = h(function (iqe, bM) {
    "use strict";

    var gM = Q(),
      yie = oi(),
      yM = rn(),
      xie = yM.Set,
      xM = yM.proto,
      Sie = gM(xM.forEach),
      SM = gM(xM.keys),
      bie = SM(new xie()).next;
    bM.exports = function (e, r, t) {
      return t ? yie({
        iterator: SM(e),
        next: bie
      }, r) : Sie(e, r);
    };
  });
  var Wx = h(function (aqe, wM) {
    "use strict";

    var wie = J(),
      Eie = Vn();
    wM.exports = !wie(function () {
      var e = new Error("a");
      return "stack" in e ? (Object.defineProperty(e, "stack", Eie(1, 7)), e.stack !== 7) : !0;
    });
  });
  var RM = h(function () {
    "use strict";

    var Cie = xr(),
      Iie = F(),
      jr = ae(),
      $l = ot(),
      Wl = Q(),
      Jx = J(),
      Pie = os(),
      qs = Re(),
      qie = cl(),
      Tie = xt(),
      pd = nr(),
      Oie = ns(),
      Aie = Jn(),
      IM = rr(),
      cd = Kn(),
      _ie = Sr(),
      Nie = fy(),
      Gx = Dt(),
      ud = wr(),
      Rie = Hx(),
      Mie = jp(),
      dd = $x(),
      Zx = rn(),
      kie = fa(),
      EM = Jg(),
      Die = Wx(),
      e0 = Sp(),
      Hl = jr.Object,
      Bie = jr.Array,
      PM = jr.Date,
      qM = jr.Error,
      Fie = jr.TypeError,
      Lie = jr.PerformanceMark,
      pa = $l("DOMException"),
      Xx = dd.Map,
      r0 = dd.has,
      TM = dd.get,
      fd = dd.set,
      OM = Zx.Set,
      AM = Zx.add,
      zie = Zx.has,
      jie = $l("Object", "keys"),
      Uie = Wl([].push),
      Hie = Wl((!0).valueOf),
      $ie = Wl(1 .valueOf),
      Vie = Wl("".valueOf),
      Wie = Wl(PM.prototype.getTime),
      Qx = Pie("structuredClone"),
      Vl = "DataCloneError",
      ld = "Transferring",
      _M = function _M(e) {
        return !Jx(function () {
          var r = new jr.Set([7]),
            t = e(r),
            i = e(Hl(7));
          return t === r || !t.has(7) || !pd(i) || +i != 7;
        }) && e;
      },
      CM = function CM(e, r) {
        return !Jx(function () {
          var t = new r(),
            i = e({
              a: t,
              b: t
            });
          return !(i && i.a === i.b && i.a instanceof r && i.a.stack === t.stack);
        });
      },
      Gie = function Gie(e) {
        return !Jx(function () {
          var r = e(new jr.AggregateError([1], Qx, {
            cause: 3
          }));
          return r.name !== "AggregateError" || r.errors[0] !== 1 || r.message !== Qx || r.cause !== 3;
        });
      },
      Ps = jr.structuredClone,
      Kie = Cie || !CM(Ps, qM) || !CM(Ps, pa) || !Gie(Ps),
      Yie = !Ps && _M(function (e) {
        return new Lie(Qx, {
          detail: e
        }).detail;
      }),
      qo = _M(Ps) || Yie,
      Kx = function Kx(e) {
        throw new pa("Uncloneable type: " + e, Vl);
      },
      qt = function qt(e, r) {
        throw new pa((r || "Cloning") + " of " + e + " cannot be properly polyfilled in this engine", Vl);
      },
      Yx = function Yx(e, r) {
        return qo || qt(r), qo(e);
      },
      Xie = function Xie() {
        var e;
        try {
          e = new jr.DataTransfer();
        } catch (_unused28) {
          try {
            e = new jr.ClipboardEvent("").clipboardData;
          } catch (_unused29) {}
        }
        return e && e.items && e.files ? e : null;
      },
      NM = function NM(e, r, t) {
        if (r0(r, e)) return TM(r, e);
        var i = t || cd(e),
          a,
          s,
          l,
          p,
          d,
          v;
        if (i === "SharedArrayBuffer") qo ? a = qo(e) : a = e;else {
          var g = jr.DataView;
          !g && !qs(e.slice) && qt("ArrayBuffer");
          try {
            if (qs(e.slice) && !e.resizable) a = e.slice(0);else for (s = e.byteLength, l = ("maxByteLength" in e) ? {
              maxByteLength: e.maxByteLength
            } : void 0, a = new ArrayBuffer(s, l), p = new g(e), d = new g(a), v = 0; v < s; v++) d.setUint8(v, p.getUint8(v));
          } catch (_unused30) {
            throw new pa("ArrayBuffer is detached", Vl);
          }
        }
        return fd(r, e, a), a;
      },
      Qie = function Qie(e, r, t, i, a) {
        var s = jr[r];
        return pd(s) || qt(r), new s(NM(e.buffer, a), t, i);
      },
      _zr = function zr(e, r) {
        if (Oie(e) && Kx("Symbol"), !pd(e)) return e;
        if (r) {
          if (r0(r, e)) return TM(r, e);
        } else r = new Xx();
        var t = cd(e),
          i,
          a,
          s,
          l,
          p,
          d,
          v,
          g;
        switch (t) {
          case "Array":
            s = Bie(ud(e));
            break;
          case "Object":
            s = {};
            break;
          case "Map":
            s = new Xx();
            break;
          case "Set":
            s = new OM();
            break;
          case "RegExp":
            s = new RegExp(e.source, Mie(e));
            break;
          case "Error":
            switch (a = e.name, a) {
              case "AggregateError":
                s = new ($l(a))([]);
                break;
              case "EvalError":
              case "RangeError":
              case "ReferenceError":
              case "SuppressedError":
              case "SyntaxError":
              case "TypeError":
              case "URIError":
                s = new ($l(a))();
                break;
              case "CompileError":
              case "LinkError":
              case "RuntimeError":
                s = new ($l("WebAssembly", a))();
                break;
              default:
                s = new qM();
            }
            break;
          case "DOMException":
            s = new pa(e.message, e.name);
            break;
          case "ArrayBuffer":
          case "SharedArrayBuffer":
            s = NM(e, r, t);
            break;
          case "DataView":
          case "Int8Array":
          case "Uint8Array":
          case "Uint8ClampedArray":
          case "Int16Array":
          case "Uint16Array":
          case "Int32Array":
          case "Uint32Array":
          case "Float16Array":
          case "Float32Array":
          case "Float64Array":
          case "BigInt64Array":
          case "BigUint64Array":
            d = t === "DataView" ? e.byteLength : e.length, s = Qie(e, t, e.byteOffset, d, r);
            break;
          case "DOMQuad":
            try {
              s = new DOMQuad(_zr(e.p1, r), _zr(e.p2, r), _zr(e.p3, r), _zr(e.p4, r));
            } catch (_unused31) {
              s = Yx(e, t);
            }
            break;
          case "File":
            if (qo) try {
              s = qo(e), cd(s) !== t && (s = void 0);
            } catch (_unused32) {}
            if (!s) try {
              s = new File([e], e.name, e);
            } catch (_unused33) {}
            s || qt(t);
            break;
          case "FileList":
            if (l = Xie(), l) {
              for (p = 0, d = ud(e); p < d; p++) l.items.add(_zr(e[p], r));
              s = l.files;
            } else s = Yx(e, t);
            break;
          case "ImageData":
            try {
              s = new ImageData(_zr(e.data, r), e.width, e.height, {
                colorSpace: e.colorSpace
              });
            } catch (_unused34) {
              s = Yx(e, t);
            }
            break;
          default:
            if (qo) s = qo(e);else switch (t) {
              case "BigInt":
                s = Hl(e.valueOf());
                break;
              case "Boolean":
                s = Hl(Hie(e));
                break;
              case "Number":
                s = Hl($ie(e));
                break;
              case "String":
                s = Hl(Vie(e));
                break;
              case "Date":
                s = new PM(Wie(e));
                break;
              case "Blob":
                try {
                  s = e.slice(0, e.size, e.type);
                } catch (_unused35) {
                  qt(t);
                }
                break;
              case "DOMPoint":
              case "DOMPointReadOnly":
                i = jr[t];
                try {
                  s = i.fromPoint ? i.fromPoint(e) : new i(e.x, e.y, e.z, e.w);
                } catch (_unused36) {
                  qt(t);
                }
                break;
              case "DOMRect":
              case "DOMRectReadOnly":
                i = jr[t];
                try {
                  s = i.fromRect ? i.fromRect(e) : new i(e.x, e.y, e.width, e.height);
                } catch (_unused37) {
                  qt(t);
                }
                break;
              case "DOMMatrix":
              case "DOMMatrixReadOnly":
                i = jr[t];
                try {
                  s = i.fromMatrix ? i.fromMatrix(e) : new i(e);
                } catch (_unused38) {
                  qt(t);
                }
                break;
              case "AudioData":
              case "VideoFrame":
                qs(e.clone) || qt(t);
                try {
                  s = e.clone();
                } catch (_unused39) {
                  Kx(t);
                }
                break;
              case "CropTarget":
              case "CryptoKey":
              case "FileSystemDirectoryHandle":
              case "FileSystemFileHandle":
              case "FileSystemHandle":
              case "GPUCompilationInfo":
              case "GPUCompilationMessage":
              case "ImageBitmap":
              case "RTCCertificate":
              case "WebAssembly.Module":
                qt(t);
              default:
                Kx(t);
            }
        }
        switch (fd(r, e, s), t) {
          case "Array":
          case "Object":
            for (v = jie(e), p = 0, d = ud(v); p < d; p++) g = v[p], Nie(s, g, _zr(e[g], r));
            break;
          case "Map":
            e.forEach(function (x, S) {
              fd(s, _zr(S, r), _zr(x, r));
            });
            break;
          case "Set":
            e.forEach(function (x) {
              AM(s, _zr(x, r));
            });
            break;
          case "Error":
            Gx(s, "message", _zr(e.message, r)), _ie(e, "cause") && Gx(s, "cause", _zr(e.cause, r)), a === "AggregateError" ? s.errors = _zr(e.errors, r) : a === "SuppressedError" && (s.error = _zr(e.error, r), s.suppressed = _zr(e.suppressed, r));
          case "DOMException":
            Die && Gx(s, "stack", _zr(e.stack, r));
        }
        return s;
      },
      Jie = function Jie(e, r) {
        if (!pd(e)) throw new Fie("Transfer option cannot be converted to a sequence");
        var t = [];
        Aie(e, function (S) {
          Uie(t, IM(S));
        });
        for (var i = 0, a = ud(t), s = new OM(), l, p, d, v, g, x; i < a;) {
          if (l = t[i++], p = cd(l), p === "ArrayBuffer" ? zie(s, l) : r0(r, l)) throw new pa("Duplicate transferable", Vl);
          if (p === "ArrayBuffer") {
            AM(s, l);
            continue;
          }
          if (e0) v = Ps(l, {
            transfer: [l]
          });else switch (p) {
            case "ImageBitmap":
              d = jr.OffscreenCanvas, qie(d) || qt(p, ld);
              try {
                g = new d(l.width, l.height), x = g.getContext("bitmaprenderer"), x.transferFromImageBitmap(l), v = g.transferToImageBitmap();
              } catch (_unused40) {}
              break;
            case "AudioData":
            case "VideoFrame":
              (!qs(l.clone) || !qs(l.close)) && qt(p, ld);
              try {
                v = l.clone(), l.close();
              } catch (_unused41) {}
              break;
            case "MediaSourceHandle":
            case "MessagePort":
            case "OffscreenCanvas":
            case "ReadableStream":
            case "TransformStream":
            case "WritableStream":
              qt(p, ld);
          }
          if (v === void 0) throw new pa("This object cannot be transferred: " + p, Vl);
          fd(r, l, v);
        }
        return s;
      },
      Zie = function Zie(e) {
        kie(e, function (r) {
          e0 ? qo(r, {
            transfer: [r]
          }) : qs(r.transfer) ? r.transfer() : EM ? EM(r) : qt("ArrayBuffer", ld);
        });
      };
    Iie({
      global: !0,
      enumerable: !0,
      sham: !e0,
      forced: Kie
    }, {
      structuredClone: function structuredClone(r) {
        var t = Rie(arguments.length, 1) > 1 && !Tie(arguments[1]) ? IM(arguments[1]) : void 0,
          i = t ? t.transfer : void 0,
          a,
          s;
        i !== void 0 && (a = new Xx(), s = Jie(i, a));
        var l = _zr(r, a);
        return s && Zie(s), l;
      }
    });
  });
  var kM = h(function (lqe, MM) {
    "use strict";

    sR();
    ca();
    mR();
    ni();
    wx();
    Ex();
    nM();
    cM();
    pM();
    RM();
    var eae = Ct();
    MM.exports = eae.structuredClone;
  });
  var md = h(function (cqe, BM) {
    "use strict";

    var DM = ae(),
      t0 = J(),
      rae = Cl(),
      tae = xe().NATIVE_ARRAY_BUFFER_VIEWS,
      nae = DM.ArrayBuffer,
      da = DM.Int8Array;
    BM.exports = !tae || !t0(function () {
      da(1);
    }) || !t0(function () {
      new da(-1);
    }) || !rae(function (e) {
      new da(), new da(null), new da(1.5), new da(e);
    }, !0) || t0(function () {
      return new da(new nae(2), 1, void 0).length !== 1;
    });
  });
  var LM = h(function (fqe, FM) {
    "use strict";

    var oae = br(),
      iae = RangeError;
    FM.exports = function (e) {
      var r = oae(e);
      if (r < 0) throw new iae("The argument can't be less than 0");
      return r;
    };
  });
  var n0 = h(function (pqe, zM) {
    "use strict";

    var aae = LM(),
      sae = RangeError;
    zM.exports = function (e, r) {
      var t = aae(e);
      if (t % r) throw new sae("Wrong offset");
      return t;
    };
  });
  var UM = h(function (dqe, jM) {
    "use strict";

    var uae = Math.round;
    jM.exports = function (e) {
      var r = uae(e);
      return r < 0 ? 0 : r > 255 ? 255 : r & 255;
    };
  });
  var o0 = h(function (mqe, HM) {
    "use strict";

    var lae = Kn();
    HM.exports = function (e) {
      var r = lae(e);
      return r === "BigInt64Array" || r === "BigUint64Array";
    };
  });
  var hd = h(function (hqe, $M) {
    "use strict";

    var cae = $f(),
      fae = TypeError;
    $M.exports = function (e) {
      var r = cae(e, "number");
      if (typeof r == "number") throw new fae("Can't convert number to bigint");
      return BigInt(r);
    };
  });
  var i0 = h(function (vqe, VM) {
    "use strict";

    var pae = yo(),
      dae = Oe(),
      mae = Lg(),
      hae = Qr(),
      vae = wr(),
      gae = Op(),
      yae = El(),
      xae = Tp(),
      Sae = o0(),
      bae = xe().aTypedArrayConstructor,
      wae = hd();
    VM.exports = function (r) {
      var t = mae(this),
        i = hae(r),
        a = arguments.length,
        s = a > 1 ? arguments[1] : void 0,
        l = s !== void 0,
        p = yae(i),
        d,
        v,
        g,
        x,
        S,
        b,
        q,
        E;
      if (p && !xae(p)) for (q = gae(i, p), E = q.next, i = []; !(b = dae(E, q)).done;) i.push(b.value);
      for (l && a > 2 && (s = pae(s, arguments[2])), v = vae(i), g = new (bae(t))(v), x = Sae(g), d = 0; v > d; d++) S = l ? s(i[d], d) : i[d], g[d] = x ? wae(S) : +S;
      return g;
    };
  });
  var vd = h(function (gqe, WM) {
    "use strict";

    var Eae = wr();
    WM.exports = function (e, r, t) {
      for (var i = 0, a = arguments.length > 2 ? t : Eae(r), s = new e(a); a > i;) s[i] = r[i++];
      return s;
    };
  });
  var Zn = h(function (yqe, p0) {
    "use strict";

    var GM = F(),
      ok = ae(),
      KM = Oe(),
      Cae = Xe(),
      Iae = md(),
      Xl = xe(),
      ik = gl(),
      YM = Xo(),
      Pae = Vn(),
      Gl = Dt(),
      qae = Np(),
      Tae = St(),
      XM = up(),
      a0 = n0(),
      Oae = UM(),
      ak = Vf(),
      Kl = Sr(),
      Aae = Kn(),
      l0 = nr(),
      _ae = ns(),
      Nae = xo(),
      Rae = vo(),
      gd = Qo(),
      Mae = as().f,
      QM = i0(),
      kae = bt().forEach,
      Dae = yl(),
      Bae = Yo(),
      sk = it(),
      uk = Zi(),
      JM = vd(),
      d0 = en(),
      Fae = ss(),
      c0 = d0.get,
      Lae = d0.set,
      zae = d0.enforce,
      lk = sk.f,
      jae = uk.f,
      s0 = ok.RangeError,
      ck = ik.ArrayBuffer,
      Uae = ck.prototype,
      Hae = ik.DataView,
      yd = Xl.NATIVE_ARRAY_BUFFER_VIEWS,
      ZM = Xl.TYPED_ARRAY_TAG,
      ek = Xl.TypedArray,
      Yl = Xl.TypedArrayPrototype,
      f0 = Xl.isTypedArray,
      xd = "BYTES_PER_ELEMENT",
      u0 = "Wrong length",
      Sd = function Sd(e, r) {
        Bae(e, r, {
          configurable: !0,
          get: function get() {
            return c0(this)[r];
          }
        });
      },
      rk = function rk(e) {
        var r;
        return Rae(Uae, e) || (r = Aae(e)) === "ArrayBuffer" || r === "SharedArrayBuffer";
      },
      fk = function fk(e, r) {
        return f0(e) && !_ae(r) && r in e && qae(+r) && r >= 0;
      },
      tk = function tk(r, t) {
        return t = ak(t), fk(r, t) ? Pae(2, r[t]) : jae(r, t);
      },
      nk = function nk(r, t, i) {
        return t = ak(t), fk(r, t) && l0(i) && Kl(i, "value") && !Kl(i, "get") && !Kl(i, "set") && !i.configurable && (!Kl(i, "writable") || i.writable) && (!Kl(i, "enumerable") || i.enumerable) ? (r[t] = i.value, r) : lk(r, t, i);
      };
    Cae ? (yd || (uk.f = tk, sk.f = nk, Sd(Yl, "buffer"), Sd(Yl, "byteOffset"), Sd(Yl, "byteLength"), Sd(Yl, "length")), GM({
      target: "Object",
      stat: !0,
      forced: !yd
    }, {
      getOwnPropertyDescriptor: tk,
      defineProperty: nk
    }), p0.exports = function (e, r, t) {
      var i = e.match(/\d+/)[0] / 8,
        a = e + (t ? "Clamped" : "") + "Array",
        s = "get" + e,
        l = "set" + e,
        p = ok[a],
        d = p,
        v = d && d.prototype,
        g = {},
        x = function x(E, C) {
          var T = c0(E);
          return T.view[s](C * i + T.byteOffset, !0);
        },
        S = function S(E, C, T) {
          var D = c0(E);
          D.view[l](C * i + D.byteOffset, t ? Oae(T) : T, !0);
        },
        b = function b(E, C) {
          lk(E, C, {
            get: function get() {
              return x(this, C);
            },
            set: function set(T) {
              return S(this, C, T);
            },
            enumerable: !0
          });
        };
      yd ? Iae && (d = r(function (E, C, T, D) {
        return YM(E, v), Fae(function () {
          return l0(C) ? rk(C) ? D !== void 0 ? new p(C, a0(T, i), D) : T !== void 0 ? new p(C, a0(T, i)) : new p(C) : f0(C) ? JM(d, C) : KM(QM, d, C) : new p(XM(C));
        }(), E, d);
      }), gd && gd(d, ek), kae(Mae(p), function (E) {
        E in d || Gl(d, E, p[E]);
      }), d.prototype = v) : (d = r(function (E, C, T, D) {
        YM(E, v);
        var M = 0,
          k = 0,
          W,
          ee,
          N;
        if (!l0(C)) N = XM(C), ee = N * i, W = new ck(ee);else if (rk(C)) {
          W = C, k = a0(T, i);
          var B = C.byteLength;
          if (D === void 0) {
            if (B % i) throw new s0(u0);
            if (ee = B - k, ee < 0) throw new s0(u0);
          } else if (ee = Tae(D) * i, ee + k > B) throw new s0(u0);
          N = ee / i;
        } else return f0(C) ? JM(d, C) : KM(QM, d, C);
        for (Lae(E, {
          buffer: W,
          byteOffset: k,
          byteLength: ee,
          length: N,
          view: new Hae(W)
        }); M < N;) b(E, M++);
      }), gd && gd(d, ek), v = d.prototype = Nae(Yl)), v.constructor !== d && Gl(v, "constructor", d), zae(v).TypedArrayConstructor = d, ZM && Gl(v, ZM, a);
      var q = d !== p;
      g[a] = d, GM({
        global: !0,
        constructor: !0,
        forced: q,
        sham: !yd
      }, g), xd in d || Gl(d, xd, i), xd in v || Gl(v, xd, i), Dae(a);
    }) : p0.exports = function () {};
  });
  var pk = h(function () {
    "use strict";

    var $ae = Zn();
    $ae("Int8", function (e) {
      return function (t, i, a) {
        return e(this, t, i, a);
      };
    });
  });
  var dk = h(function () {
    "use strict";

    var Vae = Zn();
    Vae("Uint8", function (e) {
      return function (t, i, a) {
        return e(this, t, i, a);
      };
    });
  });
  var mk = h(function () {
    "use strict";

    var Wae = Zn();
    Wae("Uint8", function (e) {
      return function (t, i, a) {
        return e(this, t, i, a);
      };
    }, !0);
  });
  var hk = h(function () {
    "use strict";

    var Gae = Zn();
    Gae("Int16", function (e) {
      return function (t, i, a) {
        return e(this, t, i, a);
      };
    });
  });
  var vk = h(function () {
    "use strict";

    var Kae = Zn();
    Kae("Uint16", function (e) {
      return function (t, i, a) {
        return e(this, t, i, a);
      };
    });
  });
  var gk = h(function () {
    "use strict";

    var Yae = Zn();
    Yae("Int32", function (e) {
      return function (t, i, a) {
        return e(this, t, i, a);
      };
    });
  });
  var yk = h(function () {
    "use strict";

    var Xae = Zn();
    Xae("Uint32", function (e) {
      return function (t, i, a) {
        return e(this, t, i, a);
      };
    });
  });
  var xk = h(function () {
    "use strict";

    var Qae = Zn();
    Qae("Float32", function (e) {
      return function (t, i, a) {
        return e(this, t, i, a);
      };
    });
  });
  var Sk = h(function () {
    "use strict";

    var Jae = Zn();
    Jae("Float64", function (e) {
      return function (t, i, a) {
        return e(this, t, i, a);
      };
    });
  });
  var bk = h(function () {
    "use strict";

    var Zae = md(),
      ese = xe().exportTypedArrayStaticMethod,
      rse = i0();
    ese("from", rse, Zae);
  });
  var Ek = h(function () {
    "use strict";

    var wk = xe(),
      tse = md(),
      nse = wk.aTypedArrayConstructor,
      ose = wk.exportTypedArrayStaticMethod;
    ose("of", function () {
      for (var r = 0, t = arguments.length, i = new (nse(this))(t); t > r;) i[r] = arguments[r++];
      return i;
    }, tse);
  });
  var Ik = h(function () {
    "use strict";

    var Ck = xe(),
      ise = wr(),
      ase = br(),
      sse = Ck.aTypedArray,
      use = Ck.exportTypedArrayMethod;
    use("at", function (r) {
      var t = sse(this),
        i = ise(t),
        a = ase(r),
        s = a >= 0 ? a : i + a;
      return s < 0 || s >= i ? void 0 : t[s];
    });
  });
  var Tk = h(function (Hqe, qk) {
    "use strict";

    var Pk = Ji(),
      lse = TypeError;
    qk.exports = function (e, r) {
      if (!delete e[r]) throw new lse("Cannot delete property " + Pk(r) + " of " + Pk(e));
    };
  });
  var Ak = h(function ($qe, Ok) {
    "use strict";

    var cse = Qr(),
      m0 = ra(),
      fse = wr(),
      pse = Tk(),
      dse = Math.min;
    Ok.exports = [].copyWithin || function (r, t) {
      var i = cse(this),
        a = fse(i),
        s = m0(r, a),
        l = m0(t, a),
        p = arguments.length > 2 ? arguments[2] : void 0,
        d = dse((p === void 0 ? a : m0(p, a)) - l, a - s),
        v = 1;
      for (l < s && s < l + d && (v = -1, l += d - 1, s += d - 1); d-- > 0;) l in i ? i[s] = i[l] : pse(i, s), s += v, l += v;
      return i;
    };
  });
  var Nk = h(function () {
    "use strict";

    var mse = Q(),
      _k = xe(),
      hse = Ak(),
      vse = mse(hse),
      gse = _k.aTypedArray,
      yse = _k.exportTypedArrayMethod;
    yse("copyWithin", function (r, t) {
      return vse(gse(this), r, t, arguments.length > 2 ? arguments[2] : void 0);
    });
  });
  var Mk = h(function () {
    "use strict";

    var Rk = xe(),
      xse = bt().every,
      Sse = Rk.aTypedArray,
      bse = Rk.exportTypedArrayMethod;
    bse("every", function (r) {
      return xse(Sse(this), r, arguments.length > 1 ? arguments[1] : void 0);
    });
  });
  var Dk = h(function () {
    "use strict";

    var kk = xe(),
      wse = op(),
      Ese = hd(),
      Cse = Kn(),
      Ise = Oe(),
      Pse = Q(),
      qse = J(),
      Tse = kk.aTypedArray,
      Ose = kk.exportTypedArrayMethod,
      Ase = Pse("".slice),
      _se = qse(function () {
        var e = 0;
        return new Int8Array(2).fill({
          valueOf: function valueOf() {
            return e++;
          }
        }), e !== 1;
      });
    Ose("fill", function (r) {
      var t = arguments.length;
      Tse(this);
      var i = Ase(Cse(this), 0, 3) === "Big" ? Ese(r) : +r;
      return Ise(wse, this, i, t > 1 ? arguments[1] : void 0, t > 2 ? arguments[2] : void 0);
    }, _se);
  });
  var Ql = h(function (Qqe, Fk) {
    "use strict";

    var Bk = xe(),
      Nse = aa(),
      Rse = Bk.aTypedArrayConstructor,
      Mse = Bk.getTypedArrayConstructor;
    Fk.exports = function (e) {
      return Rse(Nse(e, Mse(e)));
    };
  });
  var zk = h(function (Jqe, Lk) {
    "use strict";

    var kse = vd(),
      Dse = Ql();
    Lk.exports = function (e, r) {
      return kse(Dse(e), r);
    };
  });
  var Uk = h(function () {
    "use strict";

    var jk = xe(),
      Bse = bt().filter,
      Fse = zk(),
      Lse = jk.aTypedArray,
      zse = jk.exportTypedArrayMethod;
    zse("filter", function (r) {
      var t = Bse(Lse(this), r, arguments.length > 1 ? arguments[1] : void 0);
      return Fse(this, t);
    });
  });
  var $k = h(function () {
    "use strict";

    var Hk = xe(),
      jse = bt().find,
      Use = Hk.aTypedArray,
      Hse = Hk.exportTypedArrayMethod;
    Hse("find", function (r) {
      return jse(Use(this), r, arguments.length > 1 ? arguments[1] : void 0);
    });
  });
  var Wk = h(function () {
    "use strict";

    var Vk = xe(),
      $se = bt().findIndex,
      Vse = Vk.aTypedArray,
      Wse = Vk.exportTypedArrayMethod;
    Wse("findIndex", function (r) {
      return $se(Vse(this), r, arguments.length > 1 ? arguments[1] : void 0);
    });
  });
  var Kk = h(function () {
    "use strict";

    var Gk = xe(),
      Gse = dl().findLast,
      Kse = Gk.aTypedArray,
      Yse = Gk.exportTypedArrayMethod;
    Yse("findLast", function (r) {
      return Gse(Kse(this), r, arguments.length > 1 ? arguments[1] : void 0);
    });
  });
  var Xk = h(function () {
    "use strict";

    var Yk = xe(),
      Xse = dl().findLastIndex,
      Qse = Yk.aTypedArray,
      Jse = Yk.exportTypedArrayMethod;
    Jse("findLastIndex", function (r) {
      return Xse(Qse(this), r, arguments.length > 1 ? arguments[1] : void 0);
    });
  });
  var Jk = h(function () {
    "use strict";

    var Qk = xe(),
      Zse = bt().forEach,
      eue = Qk.aTypedArray,
      rue = Qk.exportTypedArrayMethod;
    rue("forEach", function (r) {
      Zse(eue(this), r, arguments.length > 1 ? arguments[1] : void 0);
    });
  });
  var e2 = h(function () {
    "use strict";

    var Zk = xe(),
      tue = al().includes,
      nue = Zk.aTypedArray,
      oue = Zk.exportTypedArrayMethod;
    oue("includes", function (r) {
      return tue(nue(this), r, arguments.length > 1 ? arguments[1] : void 0);
    });
  });
  var t2 = h(function () {
    "use strict";

    var r2 = xe(),
      iue = al().indexOf,
      aue = r2.aTypedArray,
      sue = r2.exportTypedArrayMethod;
    sue("indexOf", function (r) {
      return iue(aue(this), r, arguments.length > 1 ? arguments[1] : void 0);
    });
  });
  var o2 = h(function () {
    "use strict";

    var n2 = xe(),
      uue = Q(),
      lue = n2.aTypedArray,
      cue = n2.exportTypedArrayMethod,
      fue = uue([].join);
    cue("join", function (r) {
      return fue(lue(this), r);
    });
  });
  var s2 = h(function (gTe, a2) {
    "use strict";

    var pue = Ss(),
      due = Wn(),
      mue = br(),
      hue = wr(),
      vue = fl(),
      gue = Math.min,
      h0 = [].lastIndexOf,
      i2 = !!h0 && 1 / [1].lastIndexOf(1, -0) < 0,
      yue = vue("lastIndexOf"),
      xue = i2 || !yue;
    a2.exports = xue ? function (r) {
      if (i2) return pue(h0, this, arguments) || 0;
      var t = due(this),
        i = hue(t);
      if (i === 0) return -1;
      var a = i - 1;
      for (arguments.length > 1 && (a = gue(a, mue(arguments[1]))), a < 0 && (a = i + a); a >= 0; a--) if (a in t && t[a] === r) return a || 0;
      return -1;
    } : h0;
  });
  var l2 = h(function () {
    "use strict";

    var u2 = xe(),
      Sue = Ss(),
      bue = s2(),
      wue = u2.aTypedArray,
      Eue = u2.exportTypedArrayMethod;
    Eue("lastIndexOf", function (r) {
      var t = arguments.length;
      return Sue(bue, wue(this), t > 1 ? [r, arguments[1]] : [r]);
    });
  });
  var f2 = h(function () {
    "use strict";

    var c2 = xe(),
      Cue = bt().map,
      Iue = Ql(),
      Pue = c2.aTypedArray,
      que = c2.exportTypedArrayMethod;
    que("map", function (r) {
      return Cue(Pue(this), r, arguments.length > 1 ? arguments[1] : void 0, function (t, i) {
        return new (Iue(t))(i);
      });
    });
  });
  var v0 = h(function (wTe, h2) {
    "use strict";

    var Tue = Xr(),
      Oue = Qr(),
      Aue = ts(),
      _ue = wr(),
      p2 = TypeError,
      d2 = "Reduce of empty array with no initial value",
      m2 = function m2(e) {
        return function (r, t, i, a) {
          var s = Oue(r),
            l = Aue(s),
            p = _ue(s);
          if (Tue(t), p === 0 && i < 2) throw new p2(d2);
          var d = e ? p - 1 : 0,
            v = e ? -1 : 1;
          if (i < 2) for (;;) {
            if (d in l) {
              a = l[d], d += v;
              break;
            }
            if (d += v, e ? d < 0 : p <= d) throw new p2(d2);
          }
          for (; e ? d >= 0 : p > d; d += v) d in l && (a = t(a, l[d], d, s));
          return a;
        };
      };
    h2.exports = {
      left: m2(!1),
      right: m2(!0)
    };
  });
  var g2 = h(function () {
    "use strict";

    var v2 = xe(),
      Nue = v0().left,
      Rue = v2.aTypedArray,
      Mue = v2.exportTypedArrayMethod;
    Mue("reduce", function (r) {
      var t = arguments.length;
      return Nue(Rue(this), r, t, t > 1 ? arguments[1] : void 0);
    });
  });
  var x2 = h(function () {
    "use strict";

    var y2 = xe(),
      kue = v0().right,
      Due = y2.aTypedArray,
      Bue = y2.exportTypedArrayMethod;
    Bue("reduceRight", function (r) {
      var t = arguments.length;
      return kue(Due(this), r, t, t > 1 ? arguments[1] : void 0);
    });
  });
  var b2 = h(function () {
    "use strict";

    var S2 = xe(),
      Fue = S2.aTypedArray,
      Lue = S2.exportTypedArrayMethod,
      zue = Math.floor;
    Lue("reverse", function () {
      for (var r = this, t = Fue(r).length, i = zue(t / 2), a = 0, s; a < i;) s = r[a], r[a++] = r[--t], r[t] = s;
      return r;
    });
  });
  var q2 = h(function () {
    "use strict";

    var E2 = ae(),
      C2 = Oe(),
      x0 = xe(),
      jue = wr(),
      Uue = n0(),
      Hue = Qr(),
      I2 = J(),
      $ue = E2.RangeError,
      g0 = E2.Int8Array,
      w2 = g0 && g0.prototype,
      P2 = w2 && w2.set,
      Vue = x0.aTypedArray,
      Wue = x0.exportTypedArrayMethod,
      y0 = !I2(function () {
        var e = new Uint8ClampedArray(2);
        return C2(P2, e, {
          length: 1,
          0: 3
        }, 1), e[1] !== 3;
      }),
      Gue = y0 && x0.NATIVE_ARRAY_BUFFER_VIEWS && I2(function () {
        var e = new g0(2);
        return e.set(1), e.set("2", 1), e[0] !== 0 || e[1] !== 2;
      });
    Wue("set", function (r) {
      Vue(this);
      var t = Uue(arguments.length > 1 ? arguments[1] : void 0, 1),
        i = Hue(r);
      if (y0) return C2(P2, this, i, t);
      var a = this.length,
        s = jue(i),
        l = 0;
      if (s + t > a) throw new $ue("Wrong length");
      for (; l < s;) this[t + l] = i[l++];
    }, !y0 || Gue);
  });
  var O2 = h(function () {
    "use strict";

    var T2 = xe(),
      Kue = Ql(),
      Yue = J(),
      Xue = oa(),
      Que = T2.aTypedArray,
      Jue = T2.exportTypedArrayMethod,
      Zue = Yue(function () {
        new Int8Array(1).slice();
      });
    Jue("slice", function (r, t) {
      for (var i = Xue(Que(this), r, t), a = Kue(this), s = 0, l = i.length, p = new a(l); l > s;) p[s] = i[s++];
      return p;
    }, Zue);
  });
  var _2 = h(function () {
    "use strict";

    var A2 = xe(),
      ele = bt().some,
      rle = A2.aTypedArray,
      tle = A2.exportTypedArrayMethod;
    tle("some", function (r) {
      return ele(rle(this), r, arguments.length > 1 ? arguments[1] : void 0);
    });
  });
  var M2 = h(function (kTe, R2) {
    "use strict";

    var N2 = oa(),
      nle = Math.floor,
      _S2 = function S0(e, r) {
        var t = e.length;
        if (t < 8) for (var i = 1, a, s; i < t;) {
          for (s = i, a = e[i]; s && r(e[s - 1], a) > 0;) e[s] = e[--s];
          s !== i++ && (e[s] = a);
        } else for (var l = nle(t / 2), p = _S2(N2(e, 0, l), r), d = _S2(N2(e, l), r), v = p.length, g = d.length, x = 0, S = 0; x < v || S < g;) e[x + S] = x < v && S < g ? r(p[x], d[S]) <= 0 ? p[x++] : d[S++] : x < v ? p[x++] : d[S++];
        return e;
      };
    R2.exports = _S2;
  });
  var B2 = h(function (DTe, D2) {
    "use strict";

    var ole = go(),
      k2 = ole.match(/firefox\/(\d+)/i);
    D2.exports = !!k2 && +k2[1];
  });
  var L2 = h(function (BTe, F2) {
    "use strict";

    var ile = go();
    F2.exports = /MSIE|Trident/.test(ile);
  });
  var U2 = h(function (FTe, j2) {
    "use strict";

    var ale = go(),
      z2 = ale.match(/AppleWebKit\/(\d+)\./);
    j2.exports = !!z2 && +z2[1];
  });
  var K2 = h(function () {
    "use strict";

    var sle = ae(),
      ule = ta(),
      b0 = J(),
      lle = Xr(),
      cle = M2(),
      G2 = xe(),
      H2 = B2(),
      fle = L2(),
      $2 = rl(),
      V2 = U2(),
      ple = G2.aTypedArray,
      dle = G2.exportTypedArrayMethod,
      Jl = sle.Uint16Array,
      Ts = Jl && ule(Jl.prototype.sort),
      mle = !!Ts && !(b0(function () {
        Ts(new Jl(2), null);
      }) && b0(function () {
        Ts(new Jl(2), {});
      })),
      W2 = !!Ts && !b0(function () {
        if ($2) return $2 < 74;
        if (H2) return H2 < 67;
        if (fle) return !0;
        if (V2) return V2 < 602;
        var e = new Jl(516),
          r = Array(516),
          t,
          i;
        for (t = 0; t < 516; t++) i = t % 4, e[t] = 515 - t, r[t] = t - 2 * i + 3;
        for (Ts(e, function (a, s) {
          return (a / 4 | 0) - (s / 4 | 0);
        }), t = 0; t < 516; t++) if (e[t] !== r[t]) return !0;
      }),
      hle = function hle(e) {
        return function (r, t) {
          return e !== void 0 ? +e(r, t) || 0 : t !== t ? -1 : r !== r ? 1 : r === 0 && t === 0 ? 1 / r > 0 && 1 / t < 0 ? 1 : -1 : r > t;
        };
      };
    dle("sort", function (r) {
      return r !== void 0 && lle(r), W2 ? Ts(this, r) : cle(ple(this), hle(r));
    }, !W2 || mle);
  });
  var Q2 = h(function () {
    "use strict";

    var X2 = xe(),
      vle = St(),
      Y2 = ra(),
      gle = Ql(),
      yle = X2.aTypedArray,
      xle = X2.exportTypedArrayMethod;
    xle("subarray", function (r, t) {
      var i = yle(this),
        a = i.length,
        s = Y2(r, a),
        l = gle(i);
      return new l(i.buffer, i.byteOffset + s * i.BYTES_PER_ELEMENT, vle((t === void 0 ? a : Y2(t, a)) - s));
    });
  });
  var tD = h(function () {
    "use strict";

    var Sle = ae(),
      ble = Ss(),
      eD = xe(),
      w0 = J(),
      J2 = oa(),
      bd = Sle.Int8Array,
      Z2 = eD.aTypedArray,
      wle = eD.exportTypedArrayMethod,
      rD = [].toLocaleString,
      Ele = !!bd && w0(function () {
        rD.call(new bd(1));
      }),
      Cle = w0(function () {
        return [1, 2].toLocaleString() !== new bd([1, 2]).toLocaleString();
      }) || !w0(function () {
        bd.prototype.toLocaleString.call([1, 2]);
      });
    wle("toLocaleString", function () {
      return ble(rD, Ele ? J2(Z2(this)) : Z2(this), J2(arguments));
    }, Cle);
  });
  var oD = h(function () {
    "use strict";

    var Ile = xe().exportTypedArrayMethod,
      Ple = J(),
      qle = ae(),
      Tle = Q(),
      nD = qle.Uint8Array,
      Ole = nD && nD.prototype || {},
      wd = [].toString,
      Ale = Tle([].join);
    Ple(function () {
      wd.call({});
    }) && (wd = function wd() {
      return Ale(this);
    });
    var _le = Ole.toString !== wd;
    Ile("toString", wd, _le);
  });
  var aD = h(function (GTe, iD) {
    "use strict";

    var Nle = wr();
    iD.exports = function (e, r) {
      for (var t = Nle(e), i = new r(t), a = 0; a < t; a++) i[a] = e[t - a - 1];
      return i;
    };
  });
  var sD = h(function () {
    "use strict";

    var Rle = aD(),
      E0 = xe(),
      Mle = E0.aTypedArray,
      kle = E0.exportTypedArrayMethod,
      Dle = E0.getTypedArrayConstructor;
    kle("toReversed", function () {
      return Rle(Mle(this), Dle(this));
    });
  });
  var uD = h(function () {
    "use strict";

    var Ed = xe(),
      Ble = Q(),
      Fle = Xr(),
      Lle = vd(),
      zle = Ed.aTypedArray,
      jle = Ed.getTypedArrayConstructor,
      Ule = Ed.exportTypedArrayMethod,
      Hle = Ble(Ed.TypedArrayPrototype.sort);
    Ule("toSorted", function (r) {
      r !== void 0 && Fle(r);
      var t = zle(this),
        i = Lle(jle(t), t);
      return Hle(i, r);
    });
  });
  var cD = h(function (JTe, lD) {
    "use strict";

    var $le = wr(),
      Vle = br(),
      Wle = RangeError;
    lD.exports = function (e, r, t, i) {
      var a = $le(e),
        s = Vle(t),
        l = s < 0 ? a + s : s;
      if (l >= a || l < 0) throw new Wle("Incorrect index");
      for (var p = new r(a), d = 0; d < a; d++) p[d] = d === l ? i : e[d];
      return p;
    };
  });
  var fD = h(function () {
    "use strict";

    var Gle = cD(),
      C0 = xe(),
      Kle = o0(),
      Yle = br(),
      Xle = hd(),
      Qle = C0.aTypedArray,
      Jle = C0.getTypedArrayConstructor,
      Zle = C0.exportTypedArrayMethod,
      ece = !!function () {
        try {
          new Int8Array(1).with(2, {
            valueOf: function valueOf() {
              throw 8;
            }
          });
        } catch (e) {
          return e === 8;
        }
      }();
    Zle("with", function (e, r) {
      var t = Qle(this),
        i = Yle(e),
        a = Kle(t) ? Xle(r) : +r;
      return Gle(t, Jle(t), i, a);
    }, !ece);
  });
  var vD = h(function () {
    "use strict";

    var rce = ae(),
      tce = J(),
      I0 = Q(),
      dD = xe(),
      P0 = ca(),
      nce = Ue(),
      q0 = nce("iterator"),
      pD = rce.Uint8Array,
      oce = I0(P0.values),
      ice = I0(P0.keys),
      ace = I0(P0.entries),
      T0 = dD.aTypedArray,
      Cd = dD.exportTypedArrayMethod,
      Os = pD && pD.prototype,
      Id = !tce(function () {
        Os[q0].call([1]);
      }),
      mD = !!Os && Os.values && Os[q0] === Os.values && Os.values.name === "values",
      hD = function hD() {
        return oce(T0(this));
      };
    Cd("entries", function () {
      return ace(T0(this));
    }, Id);
    Cd("keys", function () {
      return ice(T0(this));
    }, Id);
    Cd("values", hD, Id || !mD, {
      name: "values"
    });
    Cd(q0, hD, Id || !mD, {
      name: "values"
    });
  });
  var gD = h(function () {
    "use strict";

    ni();
    ua();
    bk();
    Ek();
    Ik();
    Nk();
    Mk();
    Dk();
    Uk();
    $k();
    Wk();
    Kk();
    Xk();
    Jk();
    e2();
    t2();
    o2();
    l2();
    f2();
    g2();
    x2();
    b2();
    q2();
    O2();
    _2();
    K2();
    Q2();
    tD();
    oD();
    sD();
    uD();
    fD();
    vD();
  });
  var xD = h(function (iOe, yD) {
    "use strict";

    pk();
    dk();
    mk();
    hk();
    vk();
    gk();
    yk();
    xk();
    Sk();
    gD();
    yD.exports = ae();
  });
  var bD = h(function (aOe, SD) {
    "use strict";

    var sce = xD();
    SD.exports = sce;
  });
  var ED = h(function (sOe, wD) {
    "use strict";

    var uce = nr(),
      lce = Dt();
    wD.exports = function (e, r) {
      uce(r) && "cause" in r && lce(e, "cause", r.cause);
    };
  });
  var PD = h(function (uOe, ID) {
    "use strict";

    var cce = Dt(),
      fce = Jp(),
      pce = Wx(),
      CD = Error.captureStackTrace;
    ID.exports = function (e, r, t, i) {
      pce && (CD ? CD(e, r) : cce(e, "stack", fce(t, i)));
    };
  });
  var TD = h(function () {
    "use strict";

    var dce = F(),
      mce = vo(),
      hce = na(),
      Pd = Qo(),
      vce = ep(),
      qD = xo(),
      O0 = Dt(),
      A0 = Vn(),
      gce = ED(),
      yce = PD(),
      xce = Jn(),
      Sce = Ml(),
      bce = Ue(),
      wce = bce("toStringTag"),
      qd = Error,
      Ece = [].push,
      _As = function As(r, t) {
        var i = mce(_0, this),
          a;
        Pd ? a = Pd(new qd(), i ? hce(this) : _0) : (a = i ? this : qD(_0), O0(a, wce, "Error")), t !== void 0 && O0(a, "message", Sce(t)), yce(a, _As, a.stack, 1), arguments.length > 2 && gce(a, arguments[2]);
        var s = [];
        return xce(r, Ece, {
          that: s
        }), O0(a, "errors", s), a;
      };
    Pd ? Pd(_As, qd) : vce(_As, qd, {
      name: !0
    });
    var _0 = _As.prototype = qD(qd.prototype, {
      constructor: A0(1, _As),
      message: A0(1, ""),
      name: A0(1, "AggregateError")
    });
    dce({
      global: !0,
      constructor: !0,
      arity: 2
    }, {
      AggregateError: _As
    });
  });
  var OD = h(function () {
    "use strict";

    TD();
  });
  var N0 = h(function (dOe, AD) {
    "use strict";

    var Cce = go();
    AD.exports = /(?:ipad|iphone|ipod).*applewebkit/i.test(Cce);
  });
  var j0 = h(function (mOe, LD) {
    "use strict";

    var Ft = ae(),
      Ice = Ss(),
      Pce = yo(),
      _D = Re(),
      qce = Sr(),
      FD = J(),
      ND = hg(),
      Tce = oa(),
      RD = tl(),
      Oce = Hx(),
      Ace = N0(),
      _ce = sa(),
      F0 = Ft.setImmediate,
      L0 = Ft.clearImmediate,
      Nce = Ft.process,
      R0 = Ft.Dispatch,
      Rce = Ft.Function,
      MD = Ft.MessageChannel,
      Mce = Ft.String,
      M0 = 0,
      Zl = {},
      kD = "onreadystatechange",
      ec,
      ma,
      k0,
      D0;
    FD(function () {
      ec = Ft.location;
    });
    var z0 = function z0(e) {
        if (qce(Zl, e)) {
          var r = Zl[e];
          delete Zl[e], r();
        }
      },
      B0 = function B0(e) {
        return function () {
          z0(e);
        };
      },
      DD = function DD(e) {
        z0(e.data);
      },
      BD = function BD(e) {
        Ft.postMessage(Mce(e), ec.protocol + "//" + ec.host);
      };
    (!F0 || !L0) && (F0 = function F0(r) {
      Oce(arguments.length, 1);
      var t = _D(r) ? r : Rce(r),
        i = Tce(arguments, 1);
      return Zl[++M0] = function () {
        Ice(t, void 0, i);
      }, ma(M0), M0;
    }, L0 = function L0(r) {
      delete Zl[r];
    }, _ce ? ma = function ma(e) {
      Nce.nextTick(B0(e));
    } : R0 && R0.now ? ma = function ma(e) {
      R0.now(B0(e));
    } : MD && !Ace ? (k0 = new MD(), D0 = k0.port2, k0.port1.onmessage = DD, ma = Pce(D0.postMessage, D0)) : Ft.addEventListener && _D(Ft.postMessage) && !Ft.importScripts && ec && ec.protocol !== "file:" && !FD(BD) ? (ma = BD, Ft.addEventListener("message", DD, !1)) : kD in RD("script") ? ma = function ma(e) {
      ND.appendChild(RD("script"))[kD] = function () {
        ND.removeChild(this), z0(e);
      };
    } : ma = function ma(e) {
      setTimeout(B0(e), 0);
    });
    LD.exports = {
      set: F0,
      clear: L0
    };
  });
  var UD = h(function (hOe, jD) {
    "use strict";

    var zD = ae(),
      kce = Xe(),
      Dce = Object.getOwnPropertyDescriptor;
    jD.exports = function (e) {
      if (!kce) return zD[e];
      var r = Dce(zD, e);
      return r && r.value;
    };
  });
  var U0 = h(function (vOe, $D) {
    "use strict";

    var HD = function HD() {
      this.head = null, this.tail = null;
    };
    HD.prototype = {
      add: function add(e) {
        var r = {
            item: e,
            next: null
          },
          t = this.tail;
        t ? t.next = r : this.head = r, this.tail = r;
      },
      get: function get() {
        var e = this.head;
        if (e) {
          var r = this.head = e.next;
          return r === null && (this.tail = null), e.item;
        }
      }
    };
    $D.exports = HD;
  });
  var WD = h(function (gOe, VD) {
    "use strict";

    var Bce = go();
    VD.exports = /ipad|iphone|ipod/i.test(Bce) && (typeof Pebble === "undefined" ? "undefined" : _typeof(Pebble)) < "u";
  });
  var KD = h(function (yOe, GD) {
    "use strict";

    var Fce = go();
    GD.exports = /web0s(?!.*chrome)/i.test(Fce);
  });
  var rB = h(function (xOe, eB) {
    "use strict";

    var Ns = ae(),
      Lce = UD(),
      YD = yo(),
      H0 = j0().set,
      zce = U0(),
      jce = N0(),
      Uce = WD(),
      Hce = KD(),
      $0 = sa(),
      XD = Ns.MutationObserver || Ns.WebKitMutationObserver,
      QD = Ns.document,
      JD = Ns.process,
      Td = Ns.Promise,
      G0 = Lce("queueMicrotask"),
      _s,
      V0,
      W0,
      Od,
      ZD;
    G0 || (rc = new zce(), tc = function tc() {
      var e, r;
      for ($0 && (e = JD.domain) && e.exit(); r = rc.get();) try {
        r();
      } catch (t) {
        throw rc.head && _s(), t;
      }
      e && e.enter();
    }, !jce && !$0 && !Hce && XD && QD ? (V0 = !0, W0 = QD.createTextNode(""), new XD(tc).observe(W0, {
      characterData: !0
    }), _s = function _s() {
      W0.data = V0 = !V0;
    }) : !Uce && Td && Td.resolve ? (Od = Td.resolve(void 0), Od.constructor = Td, ZD = YD(Od.then, Od), _s = function _s() {
      ZD(tc);
    }) : $0 ? _s = function _s() {
      JD.nextTick(tc);
    } : (H0 = YD(H0, Ns), _s = function _s() {
      H0(tc);
    }), G0 = function G0(e) {
      rc.head || _s(), rc.add(e);
    });
    var rc, tc;
    eB.exports = G0;
  });
  var nB = h(function (SOe, tB) {
    "use strict";

    tB.exports = function (e, r) {
      try {
        arguments.length === 1 ? console.error(e) : console.error(e, r);
      } catch (_unused42) {}
    };
  });
  var Rs = h(function (bOe, oB) {
    "use strict";

    oB.exports = function (e) {
      try {
        return {
          error: !1,
          value: e()
        };
      } catch (r) {
        return {
          error: !0,
          value: r
        };
      }
    };
  });
  var ha = h(function (wOe, iB) {
    "use strict";

    var $ce = ae();
    iB.exports = $ce.Promise;
  });
  var Ms = h(function (EOe, uB) {
    "use strict";

    var Vce = ae(),
      nc = ha(),
      Wce = Re(),
      Gce = ul(),
      Kce = Gf(),
      Yce = Ue(),
      Xce = Wg(),
      Qce = xp(),
      Jce = xr(),
      K0 = rl(),
      aB = nc && nc.prototype,
      Zce = Yce("species"),
      Y0 = !1,
      sB = Wce(Vce.PromiseRejectionEvent),
      efe = Gce("Promise", function () {
        var e = Kce(nc),
          r = e !== String(nc);
        if (!r && K0 === 66 || Jce && !(aB.catch && aB.finally)) return !0;
        if (!K0 || K0 < 51 || !/native code/.test(e)) {
          var t = new nc(function (s) {
              s(1);
            }),
            i = function i(s) {
              s(function () {}, function () {});
            },
            a = t.constructor = {};
          if (a[Zce] = i, Y0 = t.then(function () {}) instanceof i, !Y0) return !0;
        }
        return !r && (Xce || Qce) && !sB;
      });
    uB.exports = {
      CONSTRUCTOR: efe,
      REJECTION_EVENT: sB,
      SUBCLASSING: Y0
    };
  });
  var To = h(function (COe, cB) {
    "use strict";

    var lB = Xr(),
      rfe = TypeError,
      tfe = function tfe(e) {
        var r, t;
        this.promise = new e(function (i, a) {
          if (r !== void 0 || t !== void 0) throw new rfe("Bad Promise constructor");
          r = i, t = a;
        }), this.resolve = lB(r), this.reject = lB(t);
      };
    cB.exports.f = function (e) {
      return new tfe(e);
    };
  });
  var OB = h(function () {
    "use strict";

    var nfe = F(),
      ofe = xr(),
      Rd = sa(),
      ii = ae(),
      Fs = Oe(),
      fB = at(),
      pB = Qo(),
      ife = Jo(),
      afe = yl(),
      sfe = Xr(),
      Nd = Re(),
      ufe = nr(),
      lfe = Xo(),
      cfe = aa(),
      gB = j0().set,
      eS = rB(),
      ffe = nB(),
      pfe = Rs(),
      dfe = U0(),
      yB = en(),
      Md = ha(),
      rS = Ms(),
      xB = To(),
      kd = "Promise",
      SB = rS.CONSTRUCTOR,
      mfe = rS.REJECTION_EVENT,
      hfe = rS.SUBCLASSING,
      X0 = yB.getterFor(kd),
      vfe = yB.set,
      ks = Md && Md.prototype,
      va = Md,
      Ad = ks,
      bB = ii.TypeError,
      Q0 = ii.document,
      tS = ii.process,
      J0 = xB.f,
      gfe = J0,
      yfe = !!(Q0 && Q0.createEvent && ii.dispatchEvent),
      wB = "unhandledrejection",
      xfe = "rejectionhandled",
      dB = 0,
      EB = 1,
      Sfe = 2,
      nS = 1,
      CB = 2,
      _d,
      mB,
      bfe,
      hB,
      IB = function IB(e) {
        var r;
        return ufe(e) && Nd(r = e.then) ? r : !1;
      },
      PB = function PB(e, r) {
        var t = r.value,
          i = r.state === EB,
          a = i ? e.ok : e.fail,
          s = e.resolve,
          l = e.reject,
          p = e.domain,
          d,
          v,
          g;
        try {
          a ? (i || (r.rejection === CB && Efe(r), r.rejection = nS), a === !0 ? d = t : (p && p.enter(), d = a(t), p && (p.exit(), g = !0)), d === e.promise ? l(new bB("Promise-chain cycle")) : (v = IB(d)) ? Fs(v, d, s, l) : s(d)) : l(t);
        } catch (x) {
          p && !g && p.exit(), l(x);
        }
      },
      qB = function qB(e, r) {
        e.notified || (e.notified = !0, eS(function () {
          for (var t = e.reactions, i; i = t.get();) PB(i, e);
          e.notified = !1, r && !e.rejection && wfe(e);
        }));
      },
      TB = function TB(e, r, t) {
        var i, a;
        yfe ? (i = Q0.createEvent("Event"), i.promise = r, i.reason = t, i.initEvent(e, !1, !0), ii.dispatchEvent(i)) : i = {
          promise: r,
          reason: t
        }, !mfe && (a = ii["on" + e]) ? a(i) : e === wB && ffe("Unhandled promise rejection", t);
      },
      wfe = function wfe(e) {
        Fs(gB, ii, function () {
          var r = e.facade,
            t = e.value,
            i = vB(e),
            a;
          if (i && (a = pfe(function () {
            Rd ? tS.emit("unhandledRejection", t, r) : TB(wB, r, t);
          }), e.rejection = Rd || vB(e) ? CB : nS, a.error)) throw a.value;
        });
      },
      vB = function vB(e) {
        return e.rejection !== nS && !e.parent;
      },
      Efe = function Efe(e) {
        Fs(gB, ii, function () {
          var r = e.facade;
          Rd ? tS.emit("rejectionHandled", r) : TB(xfe, r, e.value);
        });
      },
      Ds = function Ds(e, r, t) {
        return function (i) {
          e(r, i, t);
        };
      },
      Bs = function Bs(e, r, t) {
        e.done || (e.done = !0, t && (e = t), e.value = r, e.state = Sfe, qB(e, !0));
      },
      _Z2 = function Z0(e, r, t) {
        if (!e.done) {
          e.done = !0, t && (e = t);
          try {
            if (e.facade === r) throw new bB("Promise can't be resolved itself");
            var i = IB(r);
            i ? eS(function () {
              var a = {
                done: !1
              };
              try {
                Fs(i, r, Ds(_Z2, a, e), Ds(Bs, a, e));
              } catch (s) {
                Bs(a, s, e);
              }
            }) : (e.value = r, e.state = EB, qB(e, !1));
          } catch (a) {
            Bs({
              done: !1
            }, a, e);
          }
        }
      };
    if (SB && (va = function va(r) {
      lfe(this, Ad), sfe(r), Fs(_d, this);
      var t = X0(this);
      try {
        r(Ds(_Z2, t), Ds(Bs, t));
      } catch (i) {
        Bs(t, i);
      }
    }, Ad = va.prototype, _d = function _d(r) {
      vfe(this, {
        type: kd,
        done: !1,
        notified: !1,
        parent: !1,
        reactions: new dfe(),
        rejection: !1,
        state: dB,
        value: void 0
      });
    }, _d.prototype = fB(Ad, "then", function (r, t) {
      var i = X0(this),
        a = J0(cfe(this, va));
      return i.parent = !0, a.ok = Nd(r) ? r : !0, a.fail = Nd(t) && t, a.domain = Rd ? tS.domain : void 0, i.state === dB ? i.reactions.add(a) : eS(function () {
        PB(a, i);
      }), a.promise;
    }), mB = function mB() {
      var e = new _d(),
        r = X0(e);
      this.promise = e, this.resolve = Ds(_Z2, r), this.reject = Ds(Bs, r);
    }, xB.f = J0 = function J0(e) {
      return e === va || e === bfe ? new mB(e) : gfe(e);
    }, !ofe && Nd(Md) && ks !== Object.prototype)) {
      hB = ks.then, hfe || fB(ks, "then", function (r, t) {
        var i = this;
        return new va(function (a, s) {
          Fs(hB, i, a, s);
        }).then(r, t);
      }, {
        unsafe: !0
      });
      try {
        delete ks.constructor;
      } catch (_unused43) {}
      pB && pB(ks, Ad);
    }
    nfe({
      global: !0,
      constructor: !0,
      wrap: !0,
      forced: SB
    }, {
      Promise: va
    });
    ife(va, kd, !1, !0);
    afe(kd);
  });
  var oc = h(function (qOe, AB) {
    "use strict";

    var Cfe = ha(),
      Ife = Cl(),
      Pfe = Ms().CONSTRUCTOR;
    AB.exports = Pfe || !Ife(function (e) {
      Cfe.all(e).then(void 0, function () {});
    });
  });
  var _B = h(function () {
    "use strict";

    var qfe = F(),
      Tfe = Oe(),
      Ofe = Xr(),
      Afe = To(),
      _fe = Rs(),
      Nfe = Jn(),
      Rfe = oc();
    qfe({
      target: "Promise",
      stat: !0,
      forced: Rfe
    }, {
      all: function all(r) {
        var t = this,
          i = Afe.f(t),
          a = i.resolve,
          s = i.reject,
          l = _fe(function () {
            var p = Ofe(t.resolve),
              d = [],
              v = 0,
              g = 1;
            Nfe(r, function (x) {
              var S = v++,
                b = !1;
              g++, Tfe(p, t, x).then(function (q) {
                b || (b = !0, d[S] = q, --g || a(d));
              }, s);
            }), --g || a(d);
          });
        return l.error && s(l.value), i.promise;
      }
    });
  });
  var RB = h(function () {
    "use strict";

    var Mfe = F(),
      kfe = xr(),
      Dfe = Ms().CONSTRUCTOR,
      iS = ha(),
      Bfe = ot(),
      Ffe = Re(),
      Lfe = at(),
      NB = iS && iS.prototype;
    Mfe({
      target: "Promise",
      proto: !0,
      forced: Dfe,
      real: !0
    }, {
      catch: function _catch(e) {
        return this.then(void 0, e);
      }
    });
    !kfe && Ffe(iS) && (oS = Bfe("Promise").prototype.catch, NB.catch !== oS && Lfe(NB, "catch", oS, {
      unsafe: !0
    }));
    var oS;
  });
  var MB = h(function () {
    "use strict";

    var zfe = F(),
      jfe = Oe(),
      Ufe = Xr(),
      Hfe = To(),
      $fe = Rs(),
      Vfe = Jn(),
      Wfe = oc();
    zfe({
      target: "Promise",
      stat: !0,
      forced: Wfe
    }, {
      race: function race(r) {
        var t = this,
          i = Hfe.f(t),
          a = i.reject,
          s = $fe(function () {
            var l = Ufe(t.resolve);
            Vfe(r, function (p) {
              jfe(l, t, p).then(i.resolve, a);
            });
          });
        return s.error && a(s.value), i.promise;
      }
    });
  });
  var kB = h(function () {
    "use strict";

    var Gfe = F(),
      Kfe = To(),
      Yfe = Ms().CONSTRUCTOR;
    Gfe({
      target: "Promise",
      stat: !0,
      forced: Yfe
    }, {
      reject: function reject(r) {
        var t = Kfe.f(this),
          i = t.reject;
        return i(r), t.promise;
      }
    });
  });
  var aS = h(function (DOe, DB) {
    "use strict";

    var Xfe = rr(),
      Qfe = nr(),
      Jfe = To();
    DB.exports = function (e, r) {
      if (Xfe(e), Qfe(r) && r.constructor === e) return r;
      var t = Jfe.f(e),
        i = t.resolve;
      return i(r), t.promise;
    };
  });
  var LB = h(function () {
    "use strict";

    var Zfe = F(),
      epe = ot(),
      BB = xr(),
      rpe = ha(),
      FB = Ms().CONSTRUCTOR,
      tpe = aS(),
      npe = epe("Promise"),
      ope = BB && !FB;
    Zfe({
      target: "Promise",
      stat: !0,
      forced: BB || FB
    }, {
      resolve: function resolve(r) {
        return tpe(ope && this === npe ? rpe : this, r);
      }
    });
  });
  var zB = h(function () {
    "use strict";

    OB();
    _B();
    RB();
    MB();
    kB();
    LB();
  });
  var jB = h(function () {
    "use strict";

    var ipe = F(),
      ape = Oe(),
      spe = Xr(),
      upe = To(),
      lpe = Rs(),
      cpe = Jn(),
      fpe = oc();
    ipe({
      target: "Promise",
      stat: !0,
      forced: fpe
    }, {
      allSettled: function allSettled(r) {
        var t = this,
          i = upe.f(t),
          a = i.resolve,
          s = i.reject,
          l = lpe(function () {
            var p = spe(t.resolve),
              d = [],
              v = 0,
              g = 1;
            cpe(r, function (x) {
              var S = v++,
                b = !1;
              g++, ape(p, t, x).then(function (q) {
                b || (b = !0, d[S] = {
                  status: "fulfilled",
                  value: q
                }, --g || a(d));
              }, function (q) {
                b || (b = !0, d[S] = {
                  status: "rejected",
                  reason: q
                }, --g || a(d));
              });
            }), --g || a(d);
          });
        return l.error && s(l.value), i.promise;
      }
    });
  });
  var HB = h(function () {
    "use strict";

    var ppe = F(),
      dpe = Oe(),
      mpe = Xr(),
      hpe = ot(),
      vpe = To(),
      gpe = Rs(),
      ype = Jn(),
      xpe = oc(),
      UB = "No one promise resolved";
    ppe({
      target: "Promise",
      stat: !0,
      forced: xpe
    }, {
      any: function any(r) {
        var t = this,
          i = hpe("AggregateError"),
          a = vpe.f(t),
          s = a.resolve,
          l = a.reject,
          p = gpe(function () {
            var d = mpe(t.resolve),
              v = [],
              g = 0,
              x = 1,
              S = !1;
            ype(r, function (b) {
              var q = g++,
                E = !1;
              x++, dpe(d, t, b).then(function (C) {
                E || S || (S = !0, s(C));
              }, function (C) {
                E || S || (E = !0, v[q] = C, --x || l(new i(v, UB)));
              });
            }), --x || l(new i(v, UB));
          });
        return p.error && l(p.value), a.promise;
      }
    });
  });
  var $B = h(function () {
    "use strict";

    var Spe = F(),
      bpe = To();
    Spe({
      target: "Promise",
      stat: !0
    }, {
      withResolvers: function withResolvers() {
        var r = bpe.f(this);
        return {
          promise: r.promise,
          resolve: r.resolve,
          reject: r.reject
        };
      }
    });
  });
  var KB = h(function () {
    "use strict";

    var wpe = F(),
      Epe = xr(),
      Dd = ha(),
      Cpe = J(),
      WB = ot(),
      GB = Re(),
      Ipe = aa(),
      VB = aS(),
      Ppe = at(),
      uS = Dd && Dd.prototype,
      qpe = !!Dd && Cpe(function () {
        uS.finally.call({
          then: function then() {}
        }, function () {});
      });
    wpe({
      target: "Promise",
      proto: !0,
      real: !0,
      forced: qpe
    }, {
      finally: function _finally(e) {
        var r = Ipe(this, WB("Promise")),
          t = GB(e);
        return this.then(t ? function (i) {
          return VB(r, e()).then(function () {
            return i;
          });
        } : e, t ? function (i) {
          return VB(r, e()).then(function () {
            throw i;
          });
        } : e);
      }
    });
    !Epe && GB(Dd) && (sS = WB("Promise").prototype.finally, uS.finally !== sS && Ppe(uS, "finally", sS, {
      unsafe: !0
    }));
    var sS;
  });
  var XB = h(function (YOe, YB) {
    "use strict";

    OD();
    ca();
    ni();
    zB();
    jB();
    HB();
    $B();
    KB();
    ua();
    var Tpe = Ct();
    YB.exports = Tpe.Promise;
  });
  var JB = h(function (XOe, QB) {
    "use strict";

    QB.exports = {
      CSSRuleList: 0,
      CSSStyleDeclaration: 0,
      CSSValueList: 0,
      ClientRectList: 0,
      DOMRectList: 0,
      DOMStringList: 0,
      DOMTokenList: 1,
      DataTransferItemList: 0,
      FileList: 0,
      HTMLAllCollection: 0,
      HTMLCollection: 0,
      HTMLFormElement: 0,
      HTMLSelectElement: 0,
      MediaList: 0,
      MimeTypeArray: 0,
      NamedNodeMap: 0,
      NodeList: 1,
      PaintRequestList: 0,
      Plugin: 0,
      PluginArray: 0,
      SVGLengthList: 0,
      SVGNumberList: 0,
      SVGPathSegList: 0,
      SVGPointList: 0,
      SVGStringList: 0,
      SVGTransformList: 0,
      SourceBufferList: 0,
      StyleSheetList: 0,
      TextTrackCueList: 0,
      TextTrackList: 0,
      TouchList: 0
    };
  });
  var rF = h(function (QOe, eF) {
    "use strict";

    var Ope = tl(),
      lS = Ope("span").classList,
      ZB = lS && lS.constructor && lS.constructor.prototype;
    eF.exports = ZB === Object.prototype ? void 0 : ZB;
  });
  var Fd = h(function () {
    "use strict";

    var tF = ae(),
      oF = JB(),
      Ape = rF(),
      ic = ca(),
      nF = Dt(),
      _pe = Jo(),
      Npe = Ue(),
      cS = Npe("iterator"),
      fS = ic.values,
      iF = function iF(e, r) {
        if (e) {
          if (e[cS] !== fS) try {
            nF(e, cS, fS);
          } catch (_unused44) {
            e[cS] = fS;
          }
          if (_pe(e, r, !0), oF[r]) {
            for (var t in ic) if (e[t] !== ic[t]) try {
              nF(e, t, ic[t]);
            } catch (_unused45) {
              e[t] = ic[t];
            }
          }
        }
      };
    for (Bd in oF) iF(tF[Bd] && tF[Bd].prototype, Bd);
    var Bd;
    iF(Ape, "DOMTokenList");
  });
  var sF = h(function (eAe, aF) {
    "use strict";

    var Rpe = XB();
    Fd();
    aF.exports = Rpe;
  });
  var ai = h(function (rAe, uF) {
    "use strict";

    var Mpe = rn().has;
    uF.exports = function (e) {
      return Mpe(e), e;
    };
  });
  var Ld = h(function (tAe, cF) {
    "use strict";

    var lF = rn(),
      kpe = fa(),
      Dpe = lF.Set,
      Bpe = lF.add;
    cF.exports = function (e) {
      var r = new Dpe();
      return kpe(e, function (t) {
        Bpe(r, t);
      }), r;
    };
  });
  var Ls = h(function (nAe, fF) {
    "use strict";

    var Fpe = ml(),
      Lpe = rn();
    fF.exports = Fpe(Lpe.proto, "size", "get") || function (e) {
      return e.size;
    };
  });
  var dF = h(function (oAe, pF) {
    "use strict";

    pF.exports = function (e) {
      return {
        iterator: e,
        next: e.next,
        done: !1
      };
    };
  });
  var si = h(function (iAe, xF) {
    "use strict";

    var mF = Xr(),
      gF = rr(),
      hF = Oe(),
      zpe = br(),
      jpe = dF(),
      vF = "Invalid size",
      Upe = RangeError,
      Hpe = TypeError,
      $pe = Math.max,
      yF = function yF(e, r) {
        this.set = e, this.size = $pe(r, 0), this.has = mF(e.has), this.keys = mF(e.keys);
      };
    yF.prototype = {
      getIterator: function getIterator() {
        return jpe(gF(hF(this.keys, this.set)));
      },
      includes: function includes(e) {
        return hF(this.has, this.set, e);
      }
    };
    xF.exports = function (e) {
      gF(e);
      var r = +e.size;
      if (r !== r) throw new Hpe(vF);
      var t = zpe(r);
      if (t < 0) throw new Upe(vF);
      return new yF(e, t);
    };
  });
  var EF = h(function (aAe, wF) {
    "use strict";

    var Vpe = ai(),
      bF = rn(),
      Wpe = Ld(),
      Gpe = Ls(),
      Kpe = si(),
      Ype = fa(),
      Xpe = oi(),
      Qpe = bF.has,
      SF = bF.remove;
    wF.exports = function (r) {
      var t = Vpe(this),
        i = Kpe(r),
        a = Wpe(t);
      return Gpe(t) <= i.size ? Ype(t, function (s) {
        i.includes(s) && SF(a, s);
      }) : Xpe(i.getIterator(), function (s) {
        Qpe(t, s) && SF(a, s);
      }), a;
    };
  });
  var ui = h(function (sAe, IF) {
    "use strict";

    var Jpe = ot(),
      CF = function CF(e) {
        return {
          size: e,
          has: function has() {
            return !1;
          },
          keys: function keys() {
            return {
              next: function next() {
                return {
                  done: !0
                };
              }
            };
          }
        };
      };
    IF.exports = function (e) {
      var r = Jpe("Set");
      try {
        new r()[e](CF(0));
        try {
          return new r()[e](CF(-1)), !1;
        } catch (_unused46) {
          return !0;
        }
      } catch (_unused47) {
        return !1;
      }
    };
  });
  var PF = h(function () {
    "use strict";

    var Zpe = F(),
      ede = EF(),
      rde = ui();
    Zpe({
      target: "Set",
      proto: !0,
      real: !0,
      forced: !rde("difference")
    }, {
      difference: ede
    });
  });
  var OF = h(function (cAe, TF) {
    "use strict";

    var tde = ai(),
      pS = rn(),
      nde = Ls(),
      ode = si(),
      ide = fa(),
      ade = oi(),
      sde = pS.Set,
      qF = pS.add,
      ude = pS.has;
    TF.exports = function (r) {
      var t = tde(this),
        i = ode(r),
        a = new sde();
      return nde(t) > i.size ? ade(i.getIterator(), function (s) {
        ude(t, s) && qF(a, s);
      }) : ide(t, function (s) {
        i.includes(s) && qF(a, s);
      }), a;
    };
  });
  var AF = h(function () {
    "use strict";

    var lde = F(),
      cde = J(),
      fde = OF(),
      pde = ui(),
      dde = !pde("intersection") || cde(function () {
        return String(Array.from(new Set([1, 2, 3]).intersection(new Set([3, 2])))) !== "3,2";
      });
    lde({
      target: "Set",
      proto: !0,
      real: !0,
      forced: dde
    }, {
      intersection: fde
    });
  });
  var NF = h(function (dAe, _F) {
    "use strict";

    var mde = ai(),
      hde = rn().has,
      vde = Ls(),
      gde = si(),
      yde = fa(),
      xde = oi(),
      Sde = wl();
    _F.exports = function (r) {
      var t = mde(this),
        i = gde(r);
      if (vde(t) <= i.size) return yde(t, function (s) {
        if (i.includes(s)) return !1;
      }, !0) !== !1;
      var a = i.getIterator();
      return xde(a, function (s) {
        if (hde(t, s)) return Sde(a, "normal", !1);
      }) !== !1;
    };
  });
  var RF = h(function () {
    "use strict";

    var bde = F(),
      wde = NF(),
      Ede = ui();
    bde({
      target: "Set",
      proto: !0,
      real: !0,
      forced: !Ede("isDisjointFrom")
    }, {
      isDisjointFrom: wde
    });
  });
  var kF = h(function (vAe, MF) {
    "use strict";

    var Cde = ai(),
      Ide = Ls(),
      Pde = fa(),
      qde = si();
    MF.exports = function (r) {
      var t = Cde(this),
        i = qde(r);
      return Ide(t) > i.size ? !1 : Pde(t, function (a) {
        if (!i.includes(a)) return !1;
      }, !0) !== !1;
    };
  });
  var DF = h(function () {
    "use strict";

    var Tde = F(),
      Ode = kF(),
      Ade = ui();
    Tde({
      target: "Set",
      proto: !0,
      real: !0,
      forced: !Ade("isSubsetOf")
    }, {
      isSubsetOf: Ode
    });
  });
  var FF = h(function (xAe, BF) {
    "use strict";

    var _de = ai(),
      Nde = rn().has,
      Rde = Ls(),
      Mde = si(),
      kde = oi(),
      Dde = wl();
    BF.exports = function (r) {
      var t = _de(this),
        i = Mde(r);
      if (Rde(t) < i.size) return !1;
      var a = i.getIterator();
      return kde(a, function (s) {
        if (!Nde(t, s)) return Dde(a, "normal", !1);
      }) !== !1;
    };
  });
  var LF = h(function () {
    "use strict";

    var Bde = F(),
      Fde = FF(),
      Lde = ui();
    Bde({
      target: "Set",
      proto: !0,
      real: !0,
      forced: !Lde("isSupersetOf")
    }, {
      isSupersetOf: Fde
    });
  });
  var jF = h(function (wAe, zF) {
    "use strict";

    var zde = ai(),
      dS = rn(),
      jde = Ld(),
      Ude = si(),
      Hde = oi(),
      $de = dS.add,
      Vde = dS.has,
      Wde = dS.remove;
    zF.exports = function (r) {
      var t = zde(this),
        i = Ude(r).getIterator(),
        a = jde(t);
      return Hde(i, function (s) {
        Vde(t, s) ? Wde(a, s) : $de(a, s);
      }), a;
    };
  });
  var UF = h(function () {
    "use strict";

    var Gde = F(),
      Kde = jF(),
      Yde = ui();
    Gde({
      target: "Set",
      proto: !0,
      real: !0,
      forced: !Yde("symmetricDifference")
    }, {
      symmetricDifference: Kde
    });
  });
  var $F = h(function (IAe, HF) {
    "use strict";

    var Xde = ai(),
      Qde = rn().add,
      Jde = Ld(),
      Zde = si(),
      eme = oi();
    HF.exports = function (r) {
      var t = Xde(this),
        i = Zde(r).getIterator(),
        a = Jde(t);
      return eme(i, function (s) {
        Qde(a, s);
      }), a;
    };
  });
  var VF = h(function () {
    "use strict";

    var rme = F(),
      tme = $F(),
      nme = ui();
    rme({
      target: "Set",
      proto: !0,
      real: !0,
      forced: !nme("union")
    }, {
      union: tme
    });
  });
  var GF = h(function (TAe, WF) {
    "use strict";

    ca();
    ni();
    Ex();
    PF();
    AF();
    RF();
    DF();
    LF();
    UF();
    VF();
    ua();
    var ome = Ct();
    WF.exports = ome.Set;
  });
  var YF = h(function (OAe, KF) {
    "use strict";

    var ime = GF();
    Fd();
    KF.exports = ime;
  });
  var JF = h(function () {
    "use strict";

    var ame = F(),
      sme = Q(),
      ume = Xr(),
      lme = er(),
      cme = Jn(),
      zd = $x(),
      XF = xr(),
      fme = J(),
      QF = zd.Map,
      pme = zd.has,
      dme = zd.get,
      mme = zd.set,
      hme = sme([].push),
      vme = XF || fme(function () {
        return QF.groupBy("ab", function (e) {
          return e;
        }).get("a").length !== 1;
      });
    ame({
      target: "Map",
      stat: !0,
      forced: XF || vme
    }, {
      groupBy: function groupBy(r, t) {
        lme(r), ume(t);
        var i = new QF(),
          a = 0;
        return cme(r, function (s) {
          var l = t(s, a++);
          pme(i, l) ? hme(dme(i, l), s) : mme(i, l, [s]);
        }), i;
      }
    });
  });
  var eL = h(function (NAe, ZF) {
    "use strict";

    ca();
    wx();
    JF();
    ni();
    ua();
    var gme = Ct();
    ZF.exports = gme.Map;
  });
  var tL = h(function (RAe, rL) {
    "use strict";

    var yme = eL();
    Fd();
    rL.exports = yme;
  });
  var sL = h(function (MAe, aL) {
    "use strict";

    var li = {},
      iL = Object.create,
      mS = Object.defineProperties,
      jd = Object.defineProperty,
      pr = function pr(e) {
        var r = arguments[1] === void 0 ? {} : arguments[1];
        return {
          value: e,
          configurable: !!r.c,
          writable: !!r.w,
          enumerable: !!r.e
        };
      },
      xme = function xme(e) {
        return e && e[Er.toStringTag] === "Symbol";
      },
      ga = void 0;
    try {
      nL = jd({}, "y", {
        get: function get() {
          return 1;
        }
      }), ga = nL.y === 1;
    } catch (_unused48) {
      ga = !1;
    }
    var nL,
      oL = {},
      Sme = function Sme(e) {
        e = String(e);
        for (var r = "", t = 0; oL[e + r];) r = t += 1;
        oL[e + r] = 1;
        var i = "Symbol(" + e + r + ")";
        return ga && jd(Object.prototype, i, {
          get: void 0,
          set: function set(a) {
            jd(this, i, pr(a, {
              c: !0,
              w: !0
            }));
          },
          configurable: !0,
          enumerable: !1
        }), i;
      },
      hS = iL(null);
    function Er(e) {
      if (this instanceof Er) throw new TypeError("Symbol is not a constructor");
      e = e === void 0 ? "" : String(e);
      var r = Sme(e);
      return ga ? iL(hS, {
        __description__: pr(e),
        __tag__: pr(r)
      }) : r;
    }
    mS(Er, {
      for: pr(function (e) {
        var r = String(e);
        if (li[r]) return li[r];
        var t = Er(r);
        return li[r] = t, t;
      }),
      keyFor: pr(function (e) {
        if (ga && !xme(e)) throw new TypeError("" + e + " is not a symbol");
        for (var r in li) if (li[r] === e) return ga ? li[r].__description__ : li[r].substr(7, li[r].length - 8);
      })
    });
    mS(Er, {
      hasInstance: pr(Er("hasInstance")),
      isConcatSpreadable: pr(Er("isConcatSpreadable")),
      iterator: pr(Er("iterator")),
      match: pr(Er("match")),
      replace: pr(Er("replace")),
      search: pr(Er("search")),
      species: pr(Er("species")),
      split: pr(Er("split")),
      toPrimitive: pr(Er("toPrimitive")),
      toStringTag: pr(Er("toStringTag")),
      unscopables: pr(Er("unscopables"))
    });
    mS(hS, {
      constructor: pr(Er),
      toString: pr(function () {
        return this.__tag__;
      }),
      valueOf: pr(function () {
        return "Symbol(" + this.__description__ + ")";
      })
    });
    ga && jd(hS, Er.toStringTag, pr("Symbol", {
      c: !0
    }));
    aL.exports = typeof Symbol == "function" ? Symbol : Er;
  });
  var NL = h(function (D_e, _L) {
    _L.exports = vc;
    vc.default = vc;
    vc.stable = OL;
    vc.stableStringify = OL;
    var om = "[...]",
      qL = "[Circular]",
      Sa = [],
      xa = [];
    function TL() {
      return {
        depthLimit: Number.MAX_SAFE_INTEGER,
        edgesLimit: Number.MAX_SAFE_INTEGER
      };
    }
    function vc(e, r, t, i) {
      _typeof(i) > "u" && (i = TL()), IS(e, "", 0, [], void 0, 0, i);
      var a;
      try {
        xa.length === 0 ? a = JSON.stringify(e, r, t) : a = JSON.stringify(e, AL(r), t);
      } catch (_unused49) {
        return JSON.stringify("[unable to serialize, circular reference is too complex to analyze]");
      } finally {
        for (; Sa.length !== 0;) {
          var s = Sa.pop();
          s.length === 4 ? Object.defineProperty(s[0], s[1], s[3]) : s[0][s[1]] = s[2];
        }
      }
      return a;
    }
    function $s(e, r, t, i) {
      var a = Object.getOwnPropertyDescriptor(i, t);
      a.get !== void 0 ? a.configurable ? (Object.defineProperty(i, t, {
        value: e
      }), Sa.push([i, t, r, a])) : xa.push([r, t, e]) : (i[t] = e, Sa.push([i, t, r]));
    }
    function IS(e, r, t, i, a, s, l) {
      s += 1;
      var p;
      if (_typeof(e) == "object" && e !== null) {
        for (p = 0; p < i.length; p++) if (i[p] === e) {
          $s(qL, e, r, a);
          return;
        }
        if (_typeof(l.depthLimit) < "u" && s > l.depthLimit) {
          $s(om, e, r, a);
          return;
        }
        if (_typeof(l.edgesLimit) < "u" && t + 1 > l.edgesLimit) {
          $s(om, e, r, a);
          return;
        }
        if (i.push(e), Array.isArray(e)) for (p = 0; p < e.length; p++) IS(e[p], p, p, i, e, s, l);else {
          var d = Object.keys(e);
          for (p = 0; p < d.length; p++) {
            var v = d[p];
            IS(e[v], v, p, i, e, s, l);
          }
        }
        i.pop();
      }
    }
    function Tme(e, r) {
      return e < r ? -1 : e > r ? 1 : 0;
    }
    function OL(e, r, t, i) {
      _typeof(i) > "u" && (i = TL());
      var a = PS(e, "", 0, [], void 0, 0, i) || e,
        s;
      try {
        xa.length === 0 ? s = JSON.stringify(a, r, t) : s = JSON.stringify(a, AL(r), t);
      } catch (_unused50) {
        return JSON.stringify("[unable to serialize, circular reference is too complex to analyze]");
      } finally {
        for (; Sa.length !== 0;) {
          var l = Sa.pop();
          l.length === 4 ? Object.defineProperty(l[0], l[1], l[3]) : l[0][l[1]] = l[2];
        }
      }
      return s;
    }
    function PS(e, r, t, i, a, s, l) {
      s += 1;
      var p;
      if (_typeof(e) == "object" && e !== null) {
        for (p = 0; p < i.length; p++) if (i[p] === e) {
          $s(qL, e, r, a);
          return;
        }
        try {
          if (typeof e.toJSON == "function") return;
        } catch (_unused51) {
          return;
        }
        if (_typeof(l.depthLimit) < "u" && s > l.depthLimit) {
          $s(om, e, r, a);
          return;
        }
        if (_typeof(l.edgesLimit) < "u" && t + 1 > l.edgesLimit) {
          $s(om, e, r, a);
          return;
        }
        if (i.push(e), Array.isArray(e)) for (p = 0; p < e.length; p++) PS(e[p], p, p, i, e, s, l);else {
          var d = {},
            v = Object.keys(e).sort(Tme);
          for (p = 0; p < v.length; p++) {
            var g = v[p];
            PS(e[g], g, p, i, e, s, l), d[g] = e[g];
          }
          if (_typeof(a) < "u") Sa.push([a, r, e]), a[r] = d;else return d;
        }
        i.pop();
      }
    }
    function AL(e) {
      return e = _typeof(e) < "u" ? e : function (r, t) {
        return t;
      }, function (r, t) {
        if (xa.length > 0) for (var i = 0; i < xa.length; i++) {
          var a = xa[i];
          if (a[1] === r && a[0] === t) {
            t = a[2], xa.splice(i, 1);
            break;
          }
        }
        return e.call(this, r, t);
      };
    }
  });
  var WL = h(function (fm) {
    "use strict";

    fm.byteLength = Yme;
    fm.toByteArray = Qme;
    fm.fromByteArray = ehe;
    var no = [],
      un = [],
      Kme = (typeof Uint8Array === "undefined" ? "undefined" : _typeof(Uint8Array)) < "u" ? Uint8Array : Array,
      MS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    for (ba = 0, $L = MS.length; ba < $L; ++ba) no[ba] = MS[ba], un[MS.charCodeAt(ba)] = ba;
    var ba, $L;
    un[45] = 62;
    un[95] = 63;
    function VL(e) {
      var r = e.length;
      if (r % 4 > 0) throw new Error("Invalid string. Length must be a multiple of 4");
      var t = e.indexOf("=");
      t === -1 && (t = r);
      var i = t === r ? 0 : 4 - t % 4;
      return [t, i];
    }
    function Yme(e) {
      var r = VL(e),
        t = r[0],
        i = r[1];
      return (t + i) * 3 / 4 - i;
    }
    function Xme(e, r, t) {
      return (r + t) * 3 / 4 - t;
    }
    function Qme(e) {
      var r,
        t = VL(e),
        i = t[0],
        a = t[1],
        s = new Kme(Xme(e, i, a)),
        l = 0,
        p = a > 0 ? i - 4 : i,
        d;
      for (d = 0; d < p; d += 4) r = un[e.charCodeAt(d)] << 18 | un[e.charCodeAt(d + 1)] << 12 | un[e.charCodeAt(d + 2)] << 6 | un[e.charCodeAt(d + 3)], s[l++] = r >> 16 & 255, s[l++] = r >> 8 & 255, s[l++] = r & 255;
      return a === 2 && (r = un[e.charCodeAt(d)] << 2 | un[e.charCodeAt(d + 1)] >> 4, s[l++] = r & 255), a === 1 && (r = un[e.charCodeAt(d)] << 10 | un[e.charCodeAt(d + 1)] << 4 | un[e.charCodeAt(d + 2)] >> 2, s[l++] = r >> 8 & 255, s[l++] = r & 255), s;
    }
    function Jme(e) {
      return no[e >> 18 & 63] + no[e >> 12 & 63] + no[e >> 6 & 63] + no[e & 63];
    }
    function Zme(e, r, t) {
      for (var i, a = [], s = r; s < t; s += 3) i = (e[s] << 16 & 16711680) + (e[s + 1] << 8 & 65280) + (e[s + 2] & 255), a.push(Jme(i));
      return a.join("");
    }
    function ehe(e) {
      for (var r, t = e.length, i = t % 3, a = [], s = 16383, l = 0, p = t - i; l < p; l += s) a.push(Zme(e, l, l + s > p ? p : l + s));
      return i === 1 ? (r = e[t - 1], a.push(no[r >> 2] + no[r << 4 & 63] + "==")) : i === 2 && (r = (e[t - 2] << 8) + e[t - 1], a.push(no[r >> 10] + no[r >> 4 & 63] + no[r << 2 & 63] + "=")), a.join("");
    }
  });
  var GL = h(function (kS) {
    kS.read = function (e, r, t, i, a) {
      var s,
        l,
        p = a * 8 - i - 1,
        d = (1 << p) - 1,
        v = d >> 1,
        g = -7,
        x = t ? a - 1 : 0,
        S = t ? -1 : 1,
        b = e[r + x];
      for (x += S, s = b & (1 << -g) - 1, b >>= -g, g += p; g > 0; s = s * 256 + e[r + x], x += S, g -= 8);
      for (l = s & (1 << -g) - 1, s >>= -g, g += i; g > 0; l = l * 256 + e[r + x], x += S, g -= 8);
      if (s === 0) s = 1 - v;else {
        if (s === d) return l ? NaN : (b ? -1 : 1) * (1 / 0);
        l = l + Math.pow(2, i), s = s - v;
      }
      return (b ? -1 : 1) * l * Math.pow(2, s - i);
    };
    kS.write = function (e, r, t, i, a, s) {
      var l,
        p,
        d,
        v = s * 8 - a - 1,
        g = (1 << v) - 1,
        x = g >> 1,
        S = a === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0,
        b = i ? 0 : s - 1,
        q = i ? 1 : -1,
        E = r < 0 || r === 0 && 1 / r < 0 ? 1 : 0;
      for (r = Math.abs(r), isNaN(r) || r === 1 / 0 ? (p = isNaN(r) ? 1 : 0, l = g) : (l = Math.floor(Math.log(r) / Math.LN2), r * (d = Math.pow(2, -l)) < 1 && (l--, d *= 2), l + x >= 1 ? r += S / d : r += S * Math.pow(2, 1 - x), r * d >= 2 && (l++, d /= 2), l + x >= g ? (p = 0, l = g) : l + x >= 1 ? (p = (r * d - 1) * Math.pow(2, a), l = l + x) : (p = r * Math.pow(2, x - 1) * Math.pow(2, a), l = 0)); a >= 8; e[t + b] = p & 255, b += q, p /= 256, a -= 8);
      for (l = l << a | p, v += a; v > 0; e[t + b] = l & 255, b += q, l /= 256, v -= 8);
      e[t + b - q] |= E * 128;
    };
  });
  var cz = h(function (Xs) {
    "use strict";

    var DS = WL(),
      Ks = GL(),
      KL = typeof Symbol == "function" && typeof Symbol.for == "function" ? Symbol.for("nodejs.util.inspect.custom") : null;
    Xs.Buffer = R;
    Xs.SlowBuffer = ahe;
    Xs.INSPECT_MAX_BYTES = 50;
    var pm = 2147483647;
    Xs.kMaxLength = pm;
    R.TYPED_ARRAY_SUPPORT = rhe();
    !R.TYPED_ARRAY_SUPPORT && (typeof console === "undefined" ? "undefined" : _typeof(console)) < "u" && typeof console.error == "function" && console.error("This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support.");
    function rhe() {
      try {
        var e = new Uint8Array(1),
          r = {
            foo: function foo() {
              return 42;
            }
          };
        return Object.setPrototypeOf(r, Uint8Array.prototype), Object.setPrototypeOf(e, r), e.foo() === 42;
      } catch (_unused52) {
        return !1;
      }
    }
    Object.defineProperty(R.prototype, "parent", {
      enumerable: !0,
      get: function get() {
        if (R.isBuffer(this)) return this.buffer;
      }
    });
    Object.defineProperty(R.prototype, "offset", {
      enumerable: !0,
      get: function get() {
        if (R.isBuffer(this)) return this.byteOffset;
      }
    });
    function Ao(e) {
      if (e > pm) throw new RangeError('The value "' + e + '" is invalid for option "size"');
      var r = new Uint8Array(e);
      return Object.setPrototypeOf(r, R.prototype), r;
    }
    function R(e, r, t) {
      if (typeof e == "number") {
        if (typeof r == "string") throw new TypeError('The "string" argument must be of type string. Received type number');
        return zS(e);
      }
      return JL(e, r, t);
    }
    R.poolSize = 8192;
    function JL(e, r, t) {
      if (typeof e == "string") return nhe(e, r);
      if (ArrayBuffer.isView(e)) return ohe(e);
      if (e == null) throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + _typeof(e));
      if (oo(e, ArrayBuffer) || e && oo(e.buffer, ArrayBuffer) || (typeof SharedArrayBuffer === "undefined" ? "undefined" : _typeof(SharedArrayBuffer)) < "u" && (oo(e, SharedArrayBuffer) || e && oo(e.buffer, SharedArrayBuffer))) return FS(e, r, t);
      if (typeof e == "number") throw new TypeError('The "value" argument must not be of type number. Received type number');
      var i = e.valueOf && e.valueOf();
      if (i != null && i !== e) return R.from(i, r, t);
      var a = ihe(e);
      if (a) return a;
      if ((typeof Symbol === "undefined" ? "undefined" : _typeof(Symbol)) < "u" && Symbol.toPrimitive != null && typeof e[Symbol.toPrimitive] == "function") return R.from(e[Symbol.toPrimitive]("string"), r, t);
      throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + _typeof(e));
    }
    R.from = function (e, r, t) {
      return JL(e, r, t);
    };
    Object.setPrototypeOf(R.prototype, Uint8Array.prototype);
    Object.setPrototypeOf(R, Uint8Array);
    function ZL(e) {
      if (typeof e != "number") throw new TypeError('"size" argument must be of type number');
      if (e < 0) throw new RangeError('The value "' + e + '" is invalid for option "size"');
    }
    function the(e, r, t) {
      return ZL(e), e <= 0 ? Ao(e) : r !== void 0 ? typeof t == "string" ? Ao(e).fill(r, t) : Ao(e).fill(r) : Ao(e);
    }
    R.alloc = function (e, r, t) {
      return the(e, r, t);
    };
    function zS(e) {
      return ZL(e), Ao(e < 0 ? 0 : jS(e) | 0);
    }
    R.allocUnsafe = function (e) {
      return zS(e);
    };
    R.allocUnsafeSlow = function (e) {
      return zS(e);
    };
    function nhe(e, r) {
      if ((typeof r != "string" || r === "") && (r = "utf8"), !R.isEncoding(r)) throw new TypeError("Unknown encoding: " + r);
      var t = ez(e, r) | 0,
        i = Ao(t),
        a = i.write(e, r);
      return a !== t && (i = i.slice(0, a)), i;
    }
    function BS(e) {
      var r = e.length < 0 ? 0 : jS(e.length) | 0,
        t = Ao(r);
      for (var i = 0; i < r; i += 1) t[i] = e[i] & 255;
      return t;
    }
    function ohe(e) {
      if (oo(e, Uint8Array)) {
        var r = new Uint8Array(e);
        return FS(r.buffer, r.byteOffset, r.byteLength);
      }
      return BS(e);
    }
    function FS(e, r, t) {
      if (r < 0 || e.byteLength < r) throw new RangeError('"offset" is outside of buffer bounds');
      if (e.byteLength < r + (t || 0)) throw new RangeError('"length" is outside of buffer bounds');
      var i;
      return r === void 0 && t === void 0 ? i = new Uint8Array(e) : t === void 0 ? i = new Uint8Array(e, r) : i = new Uint8Array(e, r, t), Object.setPrototypeOf(i, R.prototype), i;
    }
    function ihe(e) {
      if (R.isBuffer(e)) {
        var r = jS(e.length) | 0,
          t = Ao(r);
        return t.length === 0 || e.copy(t, 0, 0, r), t;
      }
      if (e.length !== void 0) return typeof e.length != "number" || HS(e.length) ? Ao(0) : BS(e);
      if (e.type === "Buffer" && Array.isArray(e.data)) return BS(e.data);
    }
    function jS(e) {
      if (e >= pm) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + pm.toString(16) + " bytes");
      return e | 0;
    }
    function ahe(e) {
      return +e != e && (e = 0), R.alloc(+e);
    }
    R.isBuffer = function (r) {
      return r != null && r._isBuffer === !0 && r !== R.prototype;
    };
    R.compare = function (r, t) {
      if (oo(r, Uint8Array) && (r = R.from(r, r.offset, r.byteLength)), oo(t, Uint8Array) && (t = R.from(t, t.offset, t.byteLength)), !R.isBuffer(r) || !R.isBuffer(t)) throw new TypeError('The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array');
      if (r === t) return 0;
      var i = r.length,
        a = t.length;
      for (var s = 0, l = Math.min(i, a); s < l; ++s) if (r[s] !== t[s]) {
        i = r[s], a = t[s];
        break;
      }
      return i < a ? -1 : a < i ? 1 : 0;
    };
    R.isEncoding = function (r) {
      switch (String(r).toLowerCase()) {
        case "hex":
        case "utf8":
        case "utf-8":
        case "ascii":
        case "latin1":
        case "binary":
        case "base64":
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return !0;
        default:
          return !1;
      }
    };
    R.concat = function (r, t) {
      if (!Array.isArray(r)) throw new TypeError('"list" argument must be an Array of Buffers');
      if (r.length === 0) return R.alloc(0);
      var i;
      if (t === void 0) for (t = 0, i = 0; i < r.length; ++i) t += r[i].length;
      var a = R.allocUnsafe(t),
        s = 0;
      for (i = 0; i < r.length; ++i) {
        var l = r[i];
        if (oo(l, Uint8Array)) s + l.length > a.length ? (R.isBuffer(l) || (l = R.from(l)), l.copy(a, s)) : Uint8Array.prototype.set.call(a, l, s);else if (R.isBuffer(l)) l.copy(a, s);else throw new TypeError('"list" argument must be an Array of Buffers');
        s += l.length;
      }
      return a;
    };
    function ez(e, r) {
      if (R.isBuffer(e)) return e.length;
      if (ArrayBuffer.isView(e) || oo(e, ArrayBuffer)) return e.byteLength;
      if (typeof e != "string") throw new TypeError('The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + _typeof(e));
      var t = e.length,
        i = arguments.length > 2 && arguments[2] === !0;
      if (!i && t === 0) return 0;
      var a = !1;
      for (;;) switch (r) {
        case "ascii":
        case "latin1":
        case "binary":
          return t;
        case "utf8":
        case "utf-8":
          return LS(e).length;
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return t * 2;
        case "hex":
          return t >>> 1;
        case "base64":
          return lz(e).length;
        default:
          if (a) return i ? -1 : LS(e).length;
          r = ("" + r).toLowerCase(), a = !0;
      }
    }
    R.byteLength = ez;
    function she(e, r, t) {
      var i = !1;
      if ((r === void 0 || r < 0) && (r = 0), r > this.length || ((t === void 0 || t > this.length) && (t = this.length), t <= 0) || (t >>>= 0, r >>>= 0, t <= r)) return "";
      for (e || (e = "utf8");;) switch (e) {
        case "hex":
          return ghe(this, r, t);
        case "utf8":
        case "utf-8":
          return tz(this, r, t);
        case "ascii":
          return hhe(this, r, t);
        case "latin1":
        case "binary":
          return vhe(this, r, t);
        case "base64":
          return dhe(this, r, t);
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return yhe(this, r, t);
        default:
          if (i) throw new TypeError("Unknown encoding: " + e);
          e = (e + "").toLowerCase(), i = !0;
      }
    }
    R.prototype._isBuffer = !0;
    function wa(e, r, t) {
      var i = e[r];
      e[r] = e[t], e[t] = i;
    }
    R.prototype.swap16 = function () {
      var r = this.length;
      if (r % 2 !== 0) throw new RangeError("Buffer size must be a multiple of 16-bits");
      for (var t = 0; t < r; t += 2) wa(this, t, t + 1);
      return this;
    };
    R.prototype.swap32 = function () {
      var r = this.length;
      if (r % 4 !== 0) throw new RangeError("Buffer size must be a multiple of 32-bits");
      for (var t = 0; t < r; t += 4) wa(this, t, t + 3), wa(this, t + 1, t + 2);
      return this;
    };
    R.prototype.swap64 = function () {
      var r = this.length;
      if (r % 8 !== 0) throw new RangeError("Buffer size must be a multiple of 64-bits");
      for (var t = 0; t < r; t += 8) wa(this, t, t + 7), wa(this, t + 1, t + 6), wa(this, t + 2, t + 5), wa(this, t + 3, t + 4);
      return this;
    };
    R.prototype.toString = function () {
      var r = this.length;
      return r === 0 ? "" : arguments.length === 0 ? tz(this, 0, r) : she.apply(this, arguments);
    };
    R.prototype.toLocaleString = R.prototype.toString;
    R.prototype.equals = function (r) {
      if (!R.isBuffer(r)) throw new TypeError("Argument must be a Buffer");
      return this === r ? !0 : R.compare(this, r) === 0;
    };
    R.prototype.inspect = function () {
      var r = "",
        t = Xs.INSPECT_MAX_BYTES;
      return r = this.toString("hex", 0, t).replace(/(.{2})/g, "$1 ").trim(), this.length > t && (r += " ... "), "<Buffer " + r + ">";
    };
    KL && (R.prototype[KL] = R.prototype.inspect);
    R.prototype.compare = function (r, t, i, a, s) {
      if (oo(r, Uint8Array) && (r = R.from(r, r.offset, r.byteLength)), !R.isBuffer(r)) throw new TypeError('The "target" argument must be one of type Buffer or Uint8Array. Received type ' + _typeof(r));
      if (t === void 0 && (t = 0), i === void 0 && (i = r ? r.length : 0), a === void 0 && (a = 0), s === void 0 && (s = this.length), t < 0 || i > r.length || a < 0 || s > this.length) throw new RangeError("out of range index");
      if (a >= s && t >= i) return 0;
      if (a >= s) return -1;
      if (t >= i) return 1;
      if (t >>>= 0, i >>>= 0, a >>>= 0, s >>>= 0, this === r) return 0;
      var l = s - a,
        p = i - t,
        d = Math.min(l, p),
        v = this.slice(a, s),
        g = r.slice(t, i);
      for (var x = 0; x < d; ++x) if (v[x] !== g[x]) {
        l = v[x], p = g[x];
        break;
      }
      return l < p ? -1 : p < l ? 1 : 0;
    };
    function rz(e, r, t, i, a) {
      if (e.length === 0) return -1;
      if (typeof t == "string" ? (i = t, t = 0) : t > 2147483647 ? t = 2147483647 : t < -2147483648 && (t = -2147483648), t = +t, HS(t) && (t = a ? 0 : e.length - 1), t < 0 && (t = e.length + t), t >= e.length) {
        if (a) return -1;
        t = e.length - 1;
      } else if (t < 0) if (a) t = 0;else return -1;
      if (typeof r == "string" && (r = R.from(r, i)), R.isBuffer(r)) return r.length === 0 ? -1 : YL(e, r, t, i, a);
      if (typeof r == "number") return r = r & 255, typeof Uint8Array.prototype.indexOf == "function" ? a ? Uint8Array.prototype.indexOf.call(e, r, t) : Uint8Array.prototype.lastIndexOf.call(e, r, t) : YL(e, [r], t, i, a);
      throw new TypeError("val must be string, number or Buffer");
    }
    function YL(e, r, t, i, a) {
      var s = 1,
        l = e.length,
        p = r.length;
      if (i !== void 0 && (i = String(i).toLowerCase(), i === "ucs2" || i === "ucs-2" || i === "utf16le" || i === "utf-16le")) {
        if (e.length < 2 || r.length < 2) return -1;
        s = 2, l /= 2, p /= 2, t /= 2;
      }
      function d(g, x) {
        return s === 1 ? g[x] : g.readUInt16BE(x * s);
      }
      var v;
      if (a) {
        var g = -1;
        for (v = t; v < l; v++) if (d(e, v) === d(r, g === -1 ? 0 : v - g)) {
          if (g === -1 && (g = v), v - g + 1 === p) return g * s;
        } else g !== -1 && (v -= v - g), g = -1;
      } else for (t + p > l && (t = l - p), v = t; v >= 0; v--) {
        var _g2 = !0;
        for (var x = 0; x < p; x++) if (d(e, v + x) !== d(r, x)) {
          _g2 = !1;
          break;
        }
        if (_g2) return v;
      }
      return -1;
    }
    R.prototype.includes = function (r, t, i) {
      return this.indexOf(r, t, i) !== -1;
    };
    R.prototype.indexOf = function (r, t, i) {
      return rz(this, r, t, i, !0);
    };
    R.prototype.lastIndexOf = function (r, t, i) {
      return rz(this, r, t, i, !1);
    };
    function uhe(e, r, t, i) {
      t = Number(t) || 0;
      var a = e.length - t;
      i ? (i = Number(i), i > a && (i = a)) : i = a;
      var s = r.length;
      i > s / 2 && (i = s / 2);
      var l;
      for (l = 0; l < i; ++l) {
        var p = parseInt(r.substr(l * 2, 2), 16);
        if (HS(p)) return l;
        e[t + l] = p;
      }
      return l;
    }
    function lhe(e, r, t, i) {
      return dm(LS(r, e.length - t), e, t, i);
    }
    function che(e, r, t, i) {
      return dm(whe(r), e, t, i);
    }
    function fhe(e, r, t, i) {
      return dm(lz(r), e, t, i);
    }
    function phe(e, r, t, i) {
      return dm(Ehe(r, e.length - t), e, t, i);
    }
    R.prototype.write = function (r, t, i, a) {
      if (t === void 0) a = "utf8", i = this.length, t = 0;else if (i === void 0 && typeof t == "string") a = t, i = this.length, t = 0;else if (isFinite(t)) t = t >>> 0, isFinite(i) ? (i = i >>> 0, a === void 0 && (a = "utf8")) : (a = i, i = void 0);else throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
      var s = this.length - t;
      if ((i === void 0 || i > s) && (i = s), r.length > 0 && (i < 0 || t < 0) || t > this.length) throw new RangeError("Attempt to write outside buffer bounds");
      a || (a = "utf8");
      var l = !1;
      for (;;) switch (a) {
        case "hex":
          return uhe(this, r, t, i);
        case "utf8":
        case "utf-8":
          return lhe(this, r, t, i);
        case "ascii":
        case "latin1":
        case "binary":
          return che(this, r, t, i);
        case "base64":
          return fhe(this, r, t, i);
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return phe(this, r, t, i);
        default:
          if (l) throw new TypeError("Unknown encoding: " + a);
          a = ("" + a).toLowerCase(), l = !0;
      }
    };
    R.prototype.toJSON = function () {
      return {
        type: "Buffer",
        data: Array.prototype.slice.call(this._arr || this, 0)
      };
    };
    function dhe(e, r, t) {
      return r === 0 && t === e.length ? DS.fromByteArray(e) : DS.fromByteArray(e.slice(r, t));
    }
    function tz(e, r, t) {
      t = Math.min(e.length, t);
      var i = [],
        a = r;
      for (; a < t;) {
        var s = e[a],
          l = null,
          p = s > 239 ? 4 : s > 223 ? 3 : s > 191 ? 2 : 1;
        if (a + p <= t) {
          var d = void 0,
            v = void 0,
            g = void 0,
            x = void 0;
          switch (p) {
            case 1:
              s < 128 && (l = s);
              break;
            case 2:
              d = e[a + 1], (d & 192) === 128 && (x = (s & 31) << 6 | d & 63, x > 127 && (l = x));
              break;
            case 3:
              d = e[a + 1], v = e[a + 2], (d & 192) === 128 && (v & 192) === 128 && (x = (s & 15) << 12 | (d & 63) << 6 | v & 63, x > 2047 && (x < 55296 || x > 57343) && (l = x));
              break;
            case 4:
              d = e[a + 1], v = e[a + 2], g = e[a + 3], (d & 192) === 128 && (v & 192) === 128 && (g & 192) === 128 && (x = (s & 15) << 18 | (d & 63) << 12 | (v & 63) << 6 | g & 63, x > 65535 && x < 1114112 && (l = x));
          }
        }
        l === null ? (l = 65533, p = 1) : l > 65535 && (l -= 65536, i.push(l >>> 10 & 1023 | 55296), l = 56320 | l & 1023), i.push(l), a += p;
      }
      return mhe(i);
    }
    var XL = 4096;
    function mhe(e) {
      var r = e.length;
      if (r <= XL) return String.fromCharCode.apply(String, e);
      var t = "",
        i = 0;
      for (; i < r;) t += String.fromCharCode.apply(String, e.slice(i, i += XL));
      return t;
    }
    function hhe(e, r, t) {
      var i = "";
      t = Math.min(e.length, t);
      for (var a = r; a < t; ++a) i += String.fromCharCode(e[a] & 127);
      return i;
    }
    function vhe(e, r, t) {
      var i = "";
      t = Math.min(e.length, t);
      for (var a = r; a < t; ++a) i += String.fromCharCode(e[a]);
      return i;
    }
    function ghe(e, r, t) {
      var i = e.length;
      (!r || r < 0) && (r = 0), (!t || t < 0 || t > i) && (t = i);
      var a = "";
      for (var s = r; s < t; ++s) a += Che[e[s]];
      return a;
    }
    function yhe(e, r, t) {
      var i = e.slice(r, t),
        a = "";
      for (var s = 0; s < i.length - 1; s += 2) a += String.fromCharCode(i[s] + i[s + 1] * 256);
      return a;
    }
    R.prototype.slice = function (r, t) {
      var i = this.length;
      r = ~~r, t = t === void 0 ? i : ~~t, r < 0 ? (r += i, r < 0 && (r = 0)) : r > i && (r = i), t < 0 ? (t += i, t < 0 && (t = 0)) : t > i && (t = i), t < r && (t = r);
      var a = this.subarray(r, t);
      return Object.setPrototypeOf(a, R.prototype), a;
    };
    function Rr(e, r, t) {
      if (e % 1 !== 0 || e < 0) throw new RangeError("offset is not uint");
      if (e + r > t) throw new RangeError("Trying to access beyond buffer length");
    }
    R.prototype.readUintLE = R.prototype.readUIntLE = function (r, t, i) {
      r = r >>> 0, t = t >>> 0, i || Rr(r, t, this.length);
      var a = this[r],
        s = 1,
        l = 0;
      for (; ++l < t && (s *= 256);) a += this[r + l] * s;
      return a;
    };
    R.prototype.readUintBE = R.prototype.readUIntBE = function (r, t, i) {
      r = r >>> 0, t = t >>> 0, i || Rr(r, t, this.length);
      var a = this[r + --t],
        s = 1;
      for (; t > 0 && (s *= 256);) a += this[r + --t] * s;
      return a;
    };
    R.prototype.readUint8 = R.prototype.readUInt8 = function (r, t) {
      return r = r >>> 0, t || Rr(r, 1, this.length), this[r];
    };
    R.prototype.readUint16LE = R.prototype.readUInt16LE = function (r, t) {
      return r = r >>> 0, t || Rr(r, 2, this.length), this[r] | this[r + 1] << 8;
    };
    R.prototype.readUint16BE = R.prototype.readUInt16BE = function (r, t) {
      return r = r >>> 0, t || Rr(r, 2, this.length), this[r] << 8 | this[r + 1];
    };
    R.prototype.readUint32LE = R.prototype.readUInt32LE = function (r, t) {
      return r = r >>> 0, t || Rr(r, 4, this.length), (this[r] | this[r + 1] << 8 | this[r + 2] << 16) + this[r + 3] * 16777216;
    };
    R.prototype.readUint32BE = R.prototype.readUInt32BE = function (r, t) {
      return r = r >>> 0, t || Rr(r, 4, this.length), this[r] * 16777216 + (this[r + 1] << 16 | this[r + 2] << 8 | this[r + 3]);
    };
    R.prototype.readBigUInt64LE = yi(function (r) {
      r = r >>> 0, Ys(r, "offset");
      var t = this[r],
        i = this[r + 7];
      (t === void 0 || i === void 0) && yc(r, this.length - 8);
      var a = t + this[++r] * Math.pow(2, 8) + this[++r] * Math.pow(2, 16) + this[++r] * Math.pow(2, 24),
        s = this[++r] + this[++r] * Math.pow(2, 8) + this[++r] * Math.pow(2, 16) + i * Math.pow(2, 24);
      return BigInt(a) + (BigInt(s) << BigInt(32));
    });
    R.prototype.readBigUInt64BE = yi(function (r) {
      r = r >>> 0, Ys(r, "offset");
      var t = this[r],
        i = this[r + 7];
      (t === void 0 || i === void 0) && yc(r, this.length - 8);
      var a = t * Math.pow(2, 24) + this[++r] * Math.pow(2, 16) + this[++r] * Math.pow(2, 8) + this[++r],
        s = this[++r] * Math.pow(2, 24) + this[++r] * Math.pow(2, 16) + this[++r] * Math.pow(2, 8) + i;
      return (BigInt(a) << BigInt(32)) + BigInt(s);
    });
    R.prototype.readIntLE = function (r, t, i) {
      r = r >>> 0, t = t >>> 0, i || Rr(r, t, this.length);
      var a = this[r],
        s = 1,
        l = 0;
      for (; ++l < t && (s *= 256);) a += this[r + l] * s;
      return s *= 128, a >= s && (a -= Math.pow(2, 8 * t)), a;
    };
    R.prototype.readIntBE = function (r, t, i) {
      r = r >>> 0, t = t >>> 0, i || Rr(r, t, this.length);
      var a = t,
        s = 1,
        l = this[r + --a];
      for (; a > 0 && (s *= 256);) l += this[r + --a] * s;
      return s *= 128, l >= s && (l -= Math.pow(2, 8 * t)), l;
    };
    R.prototype.readInt8 = function (r, t) {
      return r = r >>> 0, t || Rr(r, 1, this.length), this[r] & 128 ? (255 - this[r] + 1) * -1 : this[r];
    };
    R.prototype.readInt16LE = function (r, t) {
      r = r >>> 0, t || Rr(r, 2, this.length);
      var i = this[r] | this[r + 1] << 8;
      return i & 32768 ? i | 4294901760 : i;
    };
    R.prototype.readInt16BE = function (r, t) {
      r = r >>> 0, t || Rr(r, 2, this.length);
      var i = this[r + 1] | this[r] << 8;
      return i & 32768 ? i | 4294901760 : i;
    };
    R.prototype.readInt32LE = function (r, t) {
      return r = r >>> 0, t || Rr(r, 4, this.length), this[r] | this[r + 1] << 8 | this[r + 2] << 16 | this[r + 3] << 24;
    };
    R.prototype.readInt32BE = function (r, t) {
      return r = r >>> 0, t || Rr(r, 4, this.length), this[r] << 24 | this[r + 1] << 16 | this[r + 2] << 8 | this[r + 3];
    };
    R.prototype.readBigInt64LE = yi(function (r) {
      r = r >>> 0, Ys(r, "offset");
      var t = this[r],
        i = this[r + 7];
      (t === void 0 || i === void 0) && yc(r, this.length - 8);
      var a = this[r + 4] + this[r + 5] * Math.pow(2, 8) + this[r + 6] * Math.pow(2, 16) + (i << 24);
      return (BigInt(a) << BigInt(32)) + BigInt(t + this[++r] * Math.pow(2, 8) + this[++r] * Math.pow(2, 16) + this[++r] * Math.pow(2, 24));
    });
    R.prototype.readBigInt64BE = yi(function (r) {
      r = r >>> 0, Ys(r, "offset");
      var t = this[r],
        i = this[r + 7];
      (t === void 0 || i === void 0) && yc(r, this.length - 8);
      var a = (t << 24) + this[++r] * Math.pow(2, 16) + this[++r] * Math.pow(2, 8) + this[++r];
      return (BigInt(a) << BigInt(32)) + BigInt(this[++r] * Math.pow(2, 24) + this[++r] * Math.pow(2, 16) + this[++r] * Math.pow(2, 8) + i);
    });
    R.prototype.readFloatLE = function (r, t) {
      return r = r >>> 0, t || Rr(r, 4, this.length), Ks.read(this, r, !0, 23, 4);
    };
    R.prototype.readFloatBE = function (r, t) {
      return r = r >>> 0, t || Rr(r, 4, this.length), Ks.read(this, r, !1, 23, 4);
    };
    R.prototype.readDoubleLE = function (r, t) {
      return r = r >>> 0, t || Rr(r, 8, this.length), Ks.read(this, r, !0, 52, 8);
    };
    R.prototype.readDoubleBE = function (r, t) {
      return r = r >>> 0, t || Rr(r, 8, this.length), Ks.read(this, r, !1, 52, 8);
    };
    function At(e, r, t, i, a, s) {
      if (!R.isBuffer(e)) throw new TypeError('"buffer" argument must be a Buffer instance');
      if (r > a || r < s) throw new RangeError('"value" argument is out of bounds');
      if (t + i > e.length) throw new RangeError("Index out of range");
    }
    R.prototype.writeUintLE = R.prototype.writeUIntLE = function (r, t, i, a) {
      if (r = +r, t = t >>> 0, i = i >>> 0, !a) {
        var p = Math.pow(2, 8 * i) - 1;
        At(this, r, t, i, p, 0);
      }
      var s = 1,
        l = 0;
      for (this[t] = r & 255; ++l < i && (s *= 256);) this[t + l] = r / s & 255;
      return t + i;
    };
    R.prototype.writeUintBE = R.prototype.writeUIntBE = function (r, t, i, a) {
      if (r = +r, t = t >>> 0, i = i >>> 0, !a) {
        var p = Math.pow(2, 8 * i) - 1;
        At(this, r, t, i, p, 0);
      }
      var s = i - 1,
        l = 1;
      for (this[t + s] = r & 255; --s >= 0 && (l *= 256);) this[t + s] = r / l & 255;
      return t + i;
    };
    R.prototype.writeUint8 = R.prototype.writeUInt8 = function (r, t, i) {
      return r = +r, t = t >>> 0, i || At(this, r, t, 1, 255, 0), this[t] = r & 255, t + 1;
    };
    R.prototype.writeUint16LE = R.prototype.writeUInt16LE = function (r, t, i) {
      return r = +r, t = t >>> 0, i || At(this, r, t, 2, 65535, 0), this[t] = r & 255, this[t + 1] = r >>> 8, t + 2;
    };
    R.prototype.writeUint16BE = R.prototype.writeUInt16BE = function (r, t, i) {
      return r = +r, t = t >>> 0, i || At(this, r, t, 2, 65535, 0), this[t] = r >>> 8, this[t + 1] = r & 255, t + 2;
    };
    R.prototype.writeUint32LE = R.prototype.writeUInt32LE = function (r, t, i) {
      return r = +r, t = t >>> 0, i || At(this, r, t, 4, 4294967295, 0), this[t + 3] = r >>> 24, this[t + 2] = r >>> 16, this[t + 1] = r >>> 8, this[t] = r & 255, t + 4;
    };
    R.prototype.writeUint32BE = R.prototype.writeUInt32BE = function (r, t, i) {
      return r = +r, t = t >>> 0, i || At(this, r, t, 4, 4294967295, 0), this[t] = r >>> 24, this[t + 1] = r >>> 16, this[t + 2] = r >>> 8, this[t + 3] = r & 255, t + 4;
    };
    function nz(e, r, t, i, a) {
      uz(r, i, a, e, t, 7);
      var s = Number(r & BigInt(4294967295));
      e[t++] = s, s = s >> 8, e[t++] = s, s = s >> 8, e[t++] = s, s = s >> 8, e[t++] = s;
      var l = Number(r >> BigInt(32) & BigInt(4294967295));
      return e[t++] = l, l = l >> 8, e[t++] = l, l = l >> 8, e[t++] = l, l = l >> 8, e[t++] = l, t;
    }
    function oz(e, r, t, i, a) {
      uz(r, i, a, e, t, 7);
      var s = Number(r & BigInt(4294967295));
      e[t + 7] = s, s = s >> 8, e[t + 6] = s, s = s >> 8, e[t + 5] = s, s = s >> 8, e[t + 4] = s;
      var l = Number(r >> BigInt(32) & BigInt(4294967295));
      return e[t + 3] = l, l = l >> 8, e[t + 2] = l, l = l >> 8, e[t + 1] = l, l = l >> 8, e[t] = l, t + 8;
    }
    R.prototype.writeBigUInt64LE = yi(function (r) {
      var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
      return nz(this, r, t, BigInt(0), BigInt("0xffffffffffffffff"));
    });
    R.prototype.writeBigUInt64BE = yi(function (r) {
      var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
      return oz(this, r, t, BigInt(0), BigInt("0xffffffffffffffff"));
    });
    R.prototype.writeIntLE = function (r, t, i, a) {
      if (r = +r, t = t >>> 0, !a) {
        var d = Math.pow(2, 8 * i - 1);
        At(this, r, t, i, d - 1, -d);
      }
      var s = 0,
        l = 1,
        p = 0;
      for (this[t] = r & 255; ++s < i && (l *= 256);) r < 0 && p === 0 && this[t + s - 1] !== 0 && (p = 1), this[t + s] = (r / l >> 0) - p & 255;
      return t + i;
    };
    R.prototype.writeIntBE = function (r, t, i, a) {
      if (r = +r, t = t >>> 0, !a) {
        var d = Math.pow(2, 8 * i - 1);
        At(this, r, t, i, d - 1, -d);
      }
      var s = i - 1,
        l = 1,
        p = 0;
      for (this[t + s] = r & 255; --s >= 0 && (l *= 256);) r < 0 && p === 0 && this[t + s + 1] !== 0 && (p = 1), this[t + s] = (r / l >> 0) - p & 255;
      return t + i;
    };
    R.prototype.writeInt8 = function (r, t, i) {
      return r = +r, t = t >>> 0, i || At(this, r, t, 1, 127, -128), r < 0 && (r = 255 + r + 1), this[t] = r & 255, t + 1;
    };
    R.prototype.writeInt16LE = function (r, t, i) {
      return r = +r, t = t >>> 0, i || At(this, r, t, 2, 32767, -32768), this[t] = r & 255, this[t + 1] = r >>> 8, t + 2;
    };
    R.prototype.writeInt16BE = function (r, t, i) {
      return r = +r, t = t >>> 0, i || At(this, r, t, 2, 32767, -32768), this[t] = r >>> 8, this[t + 1] = r & 255, t + 2;
    };
    R.prototype.writeInt32LE = function (r, t, i) {
      return r = +r, t = t >>> 0, i || At(this, r, t, 4, 2147483647, -2147483648), this[t] = r & 255, this[t + 1] = r >>> 8, this[t + 2] = r >>> 16, this[t + 3] = r >>> 24, t + 4;
    };
    R.prototype.writeInt32BE = function (r, t, i) {
      return r = +r, t = t >>> 0, i || At(this, r, t, 4, 2147483647, -2147483648), r < 0 && (r = 4294967295 + r + 1), this[t] = r >>> 24, this[t + 1] = r >>> 16, this[t + 2] = r >>> 8, this[t + 3] = r & 255, t + 4;
    };
    R.prototype.writeBigInt64LE = yi(function (r) {
      var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
      return nz(this, r, t, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
    });
    R.prototype.writeBigInt64BE = yi(function (r) {
      var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
      return oz(this, r, t, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
    });
    function iz(e, r, t, i, a, s) {
      if (t + i > e.length) throw new RangeError("Index out of range");
      if (t < 0) throw new RangeError("Index out of range");
    }
    function az(e, r, t, i, a) {
      return r = +r, t = t >>> 0, a || iz(e, r, t, 4, 34028234663852886e22, -34028234663852886e22), Ks.write(e, r, t, i, 23, 4), t + 4;
    }
    R.prototype.writeFloatLE = function (r, t, i) {
      return az(this, r, t, !0, i);
    };
    R.prototype.writeFloatBE = function (r, t, i) {
      return az(this, r, t, !1, i);
    };
    function sz(e, r, t, i, a) {
      return r = +r, t = t >>> 0, a || iz(e, r, t, 8, 17976931348623157e292, -17976931348623157e292), Ks.write(e, r, t, i, 52, 8), t + 8;
    }
    R.prototype.writeDoubleLE = function (r, t, i) {
      return sz(this, r, t, !0, i);
    };
    R.prototype.writeDoubleBE = function (r, t, i) {
      return sz(this, r, t, !1, i);
    };
    R.prototype.copy = function (r, t, i, a) {
      if (!R.isBuffer(r)) throw new TypeError("argument should be a Buffer");
      if (i || (i = 0), !a && a !== 0 && (a = this.length), t >= r.length && (t = r.length), t || (t = 0), a > 0 && a < i && (a = i), a === i || r.length === 0 || this.length === 0) return 0;
      if (t < 0) throw new RangeError("targetStart out of bounds");
      if (i < 0 || i >= this.length) throw new RangeError("Index out of range");
      if (a < 0) throw new RangeError("sourceEnd out of bounds");
      a > this.length && (a = this.length), r.length - t < a - i && (a = r.length - t + i);
      var s = a - i;
      return this === r && typeof Uint8Array.prototype.copyWithin == "function" ? this.copyWithin(t, i, a) : Uint8Array.prototype.set.call(r, this.subarray(i, a), t), s;
    };
    R.prototype.fill = function (r, t, i, a) {
      if (typeof r == "string") {
        if (typeof t == "string" ? (a = t, t = 0, i = this.length) : typeof i == "string" && (a = i, i = this.length), a !== void 0 && typeof a != "string") throw new TypeError("encoding must be a string");
        if (typeof a == "string" && !R.isEncoding(a)) throw new TypeError("Unknown encoding: " + a);
        if (r.length === 1) {
          var l = r.charCodeAt(0);
          (a === "utf8" && l < 128 || a === "latin1") && (r = l);
        }
      } else typeof r == "number" ? r = r & 255 : typeof r == "boolean" && (r = Number(r));
      if (t < 0 || this.length < t || this.length < i) throw new RangeError("Out of range index");
      if (i <= t) return this;
      t = t >>> 0, i = i === void 0 ? this.length : i >>> 0, r || (r = 0);
      var s;
      if (typeof r == "number") for (s = t; s < i; ++s) this[s] = r;else {
        var _l2 = R.isBuffer(r) ? r : R.from(r, a),
          p = _l2.length;
        if (p === 0) throw new TypeError('The value "' + r + '" is invalid for argument "value"');
        for (s = 0; s < i - t; ++s) this[s + t] = _l2[s % p];
      }
      return this;
    };
    var Gs = {};
    function US(e, r, t) {
      Gs[e] = /*#__PURE__*/function (_t2) {
        function _class() {
          var _this;
          _classCallCheck(this, _class);
          _this = _callSuper(this, _class), Object.defineProperty(_assertThisInitialized(_this), "message", {
            value: r.apply(_assertThisInitialized(_this), arguments),
            writable: !0,
            configurable: !0
          }), _this.name = "".concat(_this.name, " [").concat(e, "]"), _this.stack, delete _this.name;
          return _this;
        }
        _inherits(_class, _t2);
        return _createClass(_class, [{
          key: "code",
          get: function get() {
            return e;
          },
          set: function set(a) {
            Object.defineProperty(this, "code", {
              configurable: !0,
              enumerable: !0,
              value: a,
              writable: !0
            });
          }
        }, {
          key: "toString",
          value: function toString() {
            return "".concat(this.name, " [").concat(e, "]: ").concat(this.message);
          }
        }]);
      }(t);
    }
    US("ERR_BUFFER_OUT_OF_BOUNDS", function (e) {
      return e ? "".concat(e, " is outside of buffer bounds") : "Attempt to access memory outside buffer bounds";
    }, RangeError);
    US("ERR_INVALID_ARG_TYPE", function (e, r) {
      return "The \"".concat(e, "\" argument must be of type number. Received type ").concat(_typeof(r));
    }, TypeError);
    US("ERR_OUT_OF_RANGE", function (e, r, t) {
      var i = "The value of \"".concat(e, "\" is out of range."),
        a = t;
      return Number.isInteger(t) && Math.abs(t) > Math.pow(2, 32) ? a = QL(String(t)) : typeof t == "bigint" && (a = String(t), (t > Math.pow(BigInt(2), BigInt(32)) || t < -Math.pow(BigInt(2), BigInt(32))) && (a = QL(a)), a += "n"), i += " It must be ".concat(r, ". Received ").concat(a), i;
    }, RangeError);
    function QL(e) {
      var r = "",
        t = e.length,
        i = e[0] === "-" ? 1 : 0;
      for (; t >= i + 4; t -= 3) r = "_".concat(e.slice(t - 3, t)).concat(r);
      return "".concat(e.slice(0, t)).concat(r);
    }
    function xhe(e, r, t) {
      Ys(r, "offset"), (e[r] === void 0 || e[r + t] === void 0) && yc(r, e.length - (t + 1));
    }
    function uz(e, r, t, i, a, s) {
      if (e > t || e < r) {
        var l = typeof r == "bigint" ? "n" : "",
          p;
        throw s > 3 ? r === 0 || r === BigInt(0) ? p = ">= 0".concat(l, " and < 2").concat(l, " ** ").concat((s + 1) * 8).concat(l) : p = ">= -(2".concat(l, " ** ").concat((s + 1) * 8 - 1).concat(l, ") and < 2 ** ").concat((s + 1) * 8 - 1).concat(l) : p = ">= ".concat(r).concat(l, " and <= ").concat(t).concat(l), new Gs.ERR_OUT_OF_RANGE("value", p, e);
      }
      xhe(i, a, s);
    }
    function Ys(e, r) {
      if (typeof e != "number") throw new Gs.ERR_INVALID_ARG_TYPE(r, "number", e);
    }
    function yc(e, r, t) {
      throw Math.floor(e) !== e ? (Ys(e, t), new Gs.ERR_OUT_OF_RANGE(t || "offset", "an integer", e)) : r < 0 ? new Gs.ERR_BUFFER_OUT_OF_BOUNDS() : new Gs.ERR_OUT_OF_RANGE(t || "offset", ">= ".concat(t ? 1 : 0, " and <= ").concat(r), e);
    }
    var She = /[^+/0-9A-Za-z-_]/g;
    function bhe(e) {
      if (e = e.split("=")[0], e = e.trim().replace(She, ""), e.length < 2) return "";
      for (; e.length % 4 !== 0;) e = e + "=";
      return e;
    }
    function LS(e, r) {
      r = r || 1 / 0;
      var t,
        i = e.length,
        a = null,
        s = [];
      for (var l = 0; l < i; ++l) {
        if (t = e.charCodeAt(l), t > 55295 && t < 57344) {
          if (!a) {
            if (t > 56319) {
              (r -= 3) > -1 && s.push(239, 191, 189);
              continue;
            } else if (l + 1 === i) {
              (r -= 3) > -1 && s.push(239, 191, 189);
              continue;
            }
            a = t;
            continue;
          }
          if (t < 56320) {
            (r -= 3) > -1 && s.push(239, 191, 189), a = t;
            continue;
          }
          t = (a - 55296 << 10 | t - 56320) + 65536;
        } else a && (r -= 3) > -1 && s.push(239, 191, 189);
        if (a = null, t < 128) {
          if ((r -= 1) < 0) break;
          s.push(t);
        } else if (t < 2048) {
          if ((r -= 2) < 0) break;
          s.push(t >> 6 | 192, t & 63 | 128);
        } else if (t < 65536) {
          if ((r -= 3) < 0) break;
          s.push(t >> 12 | 224, t >> 6 & 63 | 128, t & 63 | 128);
        } else if (t < 1114112) {
          if ((r -= 4) < 0) break;
          s.push(t >> 18 | 240, t >> 12 & 63 | 128, t >> 6 & 63 | 128, t & 63 | 128);
        } else throw new Error("Invalid code point");
      }
      return s;
    }
    function whe(e) {
      var r = [];
      for (var t = 0; t < e.length; ++t) r.push(e.charCodeAt(t) & 255);
      return r;
    }
    function Ehe(e, r) {
      var t,
        i,
        a,
        s = [];
      for (var l = 0; l < e.length && !((r -= 2) < 0); ++l) t = e.charCodeAt(l), i = t >> 8, a = t % 256, s.push(a), s.push(i);
      return s;
    }
    function lz(e) {
      return DS.toByteArray(bhe(e));
    }
    function dm(e, r, t, i) {
      var a;
      for (a = 0; a < i && !(a + t >= r.length || a >= e.length); ++a) r[a + t] = e[a];
      return a;
    }
    function oo(e, r) {
      return e instanceof r || e != null && e.constructor != null && e.constructor.name != null && e.constructor.name === r.name;
    }
    function HS(e) {
      return e !== e;
    }
    var Che = function () {
      var e = "0123456789abcdef",
        r = new Array(256);
      for (var t = 0; t < 16; ++t) {
        var i = t * 16;
        for (var a = 0; a < 16; ++a) r[i + a] = e[t] + e[a];
      }
      return r;
    }();
    function yi(e) {
      return (typeof BigInt === "undefined" ? "undefined" : _typeof(BigInt)) > "u" ? Ihe : e;
    }
    function Ihe() {
      throw new Error("BigInt not supported");
    }
  });
  var Qz = h(function (Se) {
    "use strict";

    var Sc = Symbol.for("react.element"),
      Ghe = Symbol.for("react.portal"),
      Khe = Symbol.for("react.fragment"),
      Yhe = Symbol.for("react.strict_mode"),
      Xhe = Symbol.for("react.profiler"),
      Qhe = Symbol.for("react.provider"),
      Jhe = Symbol.for("react.context"),
      Zhe = Symbol.for("react.forward_ref"),
      eve = Symbol.for("react.suspense"),
      rve = Symbol.for("react.memo"),
      tve = Symbol.for("react.lazy"),
      zz = Symbol.iterator;
    function nve(e) {
      return e === null || _typeof(e) != "object" ? null : (e = zz && e[zz] || e["@@iterator"], typeof e == "function" ? e : null);
    }
    var Hz = {
        isMounted: function isMounted() {
          return !1;
        },
        enqueueForceUpdate: function enqueueForceUpdate() {},
        enqueueReplaceState: function enqueueReplaceState() {},
        enqueueSetState: function enqueueSetState() {}
      },
      $z = Object.assign,
      Vz = {};
    function Zs(e, r, t) {
      this.props = e, this.context = r, this.refs = Vz, this.updater = t || Hz;
    }
    Zs.prototype.isReactComponent = {};
    Zs.prototype.setState = function (e, r) {
      if (_typeof(e) != "object" && typeof e != "function" && e != null) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
      this.updater.enqueueSetState(this, e, r, "setState");
    };
    Zs.prototype.forceUpdate = function (e) {
      this.updater.enqueueForceUpdate(this, e, "forceUpdate");
    };
    function Wz() {}
    Wz.prototype = Zs.prototype;
    function JS(e, r, t) {
      this.props = e, this.context = r, this.refs = Vz, this.updater = t || Hz;
    }
    var ZS = JS.prototype = new Wz();
    ZS.constructor = JS;
    $z(ZS, Zs.prototype);
    ZS.isPureReactComponent = !0;
    var jz = Array.isArray,
      Gz = Object.prototype.hasOwnProperty,
      eb = {
        current: null
      },
      Kz = {
        key: !0,
        ref: !0,
        __self: !0,
        __source: !0
      };
    function Yz(e, r, t) {
      var i,
        a = {},
        s = null,
        l = null;
      if (r != null) for (i in r.ref !== void 0 && (l = r.ref), r.key !== void 0 && (s = "" + r.key), r) Gz.call(r, i) && !Kz.hasOwnProperty(i) && (a[i] = r[i]);
      var p = arguments.length - 2;
      if (p === 1) a.children = t;else if (1 < p) {
        for (var d = Array(p), v = 0; v < p; v++) d[v] = arguments[v + 2];
        a.children = d;
      }
      if (e && e.defaultProps) for (i in p = e.defaultProps, p) a[i] === void 0 && (a[i] = p[i]);
      return {
        $$typeof: Sc,
        type: e,
        key: s,
        ref: l,
        props: a,
        _owner: eb.current
      };
    }
    function ove(e, r) {
      return {
        $$typeof: Sc,
        type: e.type,
        key: r,
        ref: e.ref,
        props: e.props,
        _owner: e._owner
      };
    }
    function rb(e) {
      return _typeof(e) == "object" && e !== null && e.$$typeof === Sc;
    }
    function ive(e) {
      var r = {
        "=": "=0",
        ":": "=2"
      };
      return "$" + e.replace(/[=:]/g, function (t) {
        return r[t];
      });
    }
    var Uz = /\/+/g;
    function QS(e, r) {
      return _typeof(e) == "object" && e !== null && e.key != null ? ive("" + e.key) : r.toString(36);
    }
    function Sm(e, r, t, i, a) {
      var s = _typeof(e);
      (s === "undefined" || s === "boolean") && (e = null);
      var l = !1;
      if (e === null) l = !0;else switch (s) {
        case "string":
        case "number":
          l = !0;
          break;
        case "object":
          switch (e.$$typeof) {
            case Sc:
            case Ghe:
              l = !0;
          }
      }
      if (l) return l = e, a = a(l), e = i === "" ? "." + QS(l, 0) : i, jz(a) ? (t = "", e != null && (t = e.replace(Uz, "$&/") + "/"), Sm(a, r, t, "", function (v) {
        return v;
      })) : a != null && (rb(a) && (a = ove(a, t + (!a.key || l && l.key === a.key ? "" : ("" + a.key).replace(Uz, "$&/") + "/") + e)), r.push(a)), 1;
      if (l = 0, i = i === "" ? "." : i + ":", jz(e)) for (var p = 0; p < e.length; p++) {
        s = e[p];
        var d = i + QS(s, p);
        l += Sm(s, r, t, d, a);
      } else if (d = nve(e), typeof d == "function") for (e = d.call(e), p = 0; !(s = e.next()).done;) s = s.value, d = i + QS(s, p++), l += Sm(s, r, t, d, a);else if (s === "object") throw r = String(e), Error("Objects are not valid as a React child (found: " + (r === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : r) + "). If you meant to render a collection of children, use an array instead.");
      return l;
    }
    function xm(e, r, t) {
      if (e == null) return e;
      var i = [],
        a = 0;
      return Sm(e, i, "", "", function (s) {
        return r.call(t, s, a++);
      }), i;
    }
    function ave(e) {
      if (e._status === -1) {
        var r = e._result;
        r = r(), r.then(function (t) {
          (e._status === 0 || e._status === -1) && (e._status = 1, e._result = t);
        }, function (t) {
          (e._status === 0 || e._status === -1) && (e._status = 2, e._result = t);
        }), e._status === -1 && (e._status = 0, e._result = r);
      }
      if (e._status === 1) return e._result.default;
      throw e._result;
    }
    var ct = {
        current: null
      },
      bm = {
        transition: null
      },
      sve = {
        ReactCurrentDispatcher: ct,
        ReactCurrentBatchConfig: bm,
        ReactCurrentOwner: eb
      };
    function Xz() {
      throw Error("act(...) is not supported in production builds of React.");
    }
    Se.Children = {
      map: xm,
      forEach: function forEach(e, r, t) {
        xm(e, function () {
          r.apply(this, arguments);
        }, t);
      },
      count: function count(e) {
        var r = 0;
        return xm(e, function () {
          r++;
        }), r;
      },
      toArray: function toArray(e) {
        return xm(e, function (r) {
          return r;
        }) || [];
      },
      only: function only(e) {
        if (!rb(e)) throw Error("React.Children.only expected to receive a single React element child.");
        return e;
      }
    };
    Se.Component = Zs;
    Se.Fragment = Khe;
    Se.Profiler = Xhe;
    Se.PureComponent = JS;
    Se.StrictMode = Yhe;
    Se.Suspense = eve;
    Se.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = sve;
    Se.act = Xz;
    Se.cloneElement = function (e, r, t) {
      if (e == null) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + e + ".");
      var i = $z({}, e.props),
        a = e.key,
        s = e.ref,
        l = e._owner;
      if (r != null) {
        if (r.ref !== void 0 && (s = r.ref, l = eb.current), r.key !== void 0 && (a = "" + r.key), e.type && e.type.defaultProps) var p = e.type.defaultProps;
        for (d in r) Gz.call(r, d) && !Kz.hasOwnProperty(d) && (i[d] = r[d] === void 0 && p !== void 0 ? p[d] : r[d]);
      }
      var d = arguments.length - 2;
      if (d === 1) i.children = t;else if (1 < d) {
        p = Array(d);
        for (var v = 0; v < d; v++) p[v] = arguments[v + 2];
        i.children = p;
      }
      return {
        $$typeof: Sc,
        type: e.type,
        key: a,
        ref: s,
        props: i,
        _owner: l
      };
    };
    Se.createContext = function (e) {
      return e = {
        $$typeof: Jhe,
        _currentValue: e,
        _currentValue2: e,
        _threadCount: 0,
        Provider: null,
        Consumer: null,
        _defaultValue: null,
        _globalName: null
      }, e.Provider = {
        $$typeof: Qhe,
        _context: e
      }, e.Consumer = e;
    };
    Se.createElement = Yz;
    Se.createFactory = function (e) {
      var r = Yz.bind(null, e);
      return r.type = e, r;
    };
    Se.createRef = function () {
      return {
        current: null
      };
    };
    Se.forwardRef = function (e) {
      return {
        $$typeof: Zhe,
        render: e
      };
    };
    Se.isValidElement = rb;
    Se.lazy = function (e) {
      return {
        $$typeof: tve,
        _payload: {
          _status: -1,
          _result: e
        },
        _init: ave
      };
    };
    Se.memo = function (e, r) {
      return {
        $$typeof: rve,
        type: e,
        compare: r === void 0 ? null : r
      };
    };
    Se.startTransition = function (e) {
      var r = bm.transition;
      bm.transition = {};
      try {
        e();
      } finally {
        bm.transition = r;
      }
    };
    Se.unstable_act = Xz;
    Se.useCallback = function (e, r) {
      return ct.current.useCallback(e, r);
    };
    Se.useContext = function (e) {
      return ct.current.useContext(e);
    };
    Se.useDebugValue = function () {};
    Se.useDeferredValue = function (e) {
      return ct.current.useDeferredValue(e);
    };
    Se.useEffect = function (e, r) {
      return ct.current.useEffect(e, r);
    };
    Se.useId = function () {
      return ct.current.useId();
    };
    Se.useImperativeHandle = function (e, r, t) {
      return ct.current.useImperativeHandle(e, r, t);
    };
    Se.useInsertionEffect = function (e, r) {
      return ct.current.useInsertionEffect(e, r);
    };
    Se.useLayoutEffect = function (e, r) {
      return ct.current.useLayoutEffect(e, r);
    };
    Se.useMemo = function (e, r) {
      return ct.current.useMemo(e, r);
    };
    Se.useReducer = function (e, r, t) {
      return ct.current.useReducer(e, r, t);
    };
    Se.useRef = function (e) {
      return ct.current.useRef(e);
    };
    Se.useState = function (e) {
      return ct.current.useState(e);
    };
    Se.useSyncExternalStore = function (e, r, t) {
      return ct.current.useSyncExternalStore(e, r, t);
    };
    Se.useTransition = function () {
      return ct.current.useTransition();
    };
    Se.version = "18.3.1";
  });
  var Z = h(function (uMe, Jz) {
    "use strict";

    Jz.exports = Qz();
  });
  var G4 = h(function (Fe) {
    "use strict";

    function Eb(e, r) {
      var t = e.length;
      e.push(r);
      e: for (; 0 < t;) {
        var i = t - 1 >>> 1,
          a = e[i];
        if (0 < Ym(a, r)) e[i] = r, e[t] = a, t = i;else break e;
      }
    }
    function Mn(e) {
      return e.length === 0 ? null : e[0];
    }
    function Qm(e) {
      if (e.length === 0) return null;
      var r = e[0],
        t = e.pop();
      if (t !== r) {
        e[0] = t;
        e: for (var i = 0, a = e.length, s = a >>> 1; i < s;) {
          var l = 2 * (i + 1) - 1,
            p = e[l],
            d = l + 1,
            v = e[d];
          if (0 > Ym(p, t)) d < a && 0 > Ym(v, p) ? (e[i] = v, e[d] = t, i = d) : (e[i] = p, e[l] = t, i = l);else if (d < a && 0 > Ym(v, t)) e[i] = v, e[d] = t, i = d;else break e;
        }
      }
      return r;
    }
    function Ym(e, r) {
      var t = e.sortIndex - r.sortIndex;
      return t !== 0 ? t : e.id - r.id;
    }
    (typeof performance === "undefined" ? "undefined" : _typeof(performance)) == "object" && typeof performance.now == "function" ? (F4 = performance, Fe.unstable_now = function () {
      return F4.now();
    }) : (Sb = Date, L4 = Sb.now(), Fe.unstable_now = function () {
      return Sb.now() - L4;
    });
    var F4,
      Sb,
      L4,
      so = [],
      Ti = [],
      Jxe = 1,
      pn = null,
      Zr = 3,
      Jm = !1,
      Da = !1,
      Oc = !1,
      U4 = typeof setTimeout == "function" ? setTimeout : null,
      H4 = typeof clearTimeout == "function" ? clearTimeout : null,
      z4 = (typeof setImmediate === "undefined" ? "undefined" : _typeof(setImmediate)) < "u" ? setImmediate : null;
    (typeof navigator === "undefined" ? "undefined" : _typeof(navigator)) < "u" && navigator.scheduling !== void 0 && navigator.scheduling.isInputPending !== void 0 && navigator.scheduling.isInputPending.bind(navigator.scheduling);
    function Cb(e) {
      for (var r = Mn(Ti); r !== null;) {
        if (r.callback === null) Qm(Ti);else if (r.startTime <= e) Qm(Ti), r.sortIndex = r.expirationTime, Eb(so, r);else break;
        r = Mn(Ti);
      }
    }
    function Ib(e) {
      if (Oc = !1, Cb(e), !Da) if (Mn(so) !== null) Da = !0, qb(Pb);else {
        var r = Mn(Ti);
        r !== null && Tb(Ib, r.startTime - e);
      }
    }
    function Pb(e, r) {
      Da = !1, Oc && (Oc = !1, H4(Ac), Ac = -1), Jm = !0;
      var t = Zr;
      try {
        for (Cb(r), pn = Mn(so); pn !== null && (!(pn.expirationTime > r) || e && !W4());) {
          var i = pn.callback;
          if (typeof i == "function") {
            pn.callback = null, Zr = pn.priorityLevel;
            var a = i(pn.expirationTime <= r);
            r = Fe.unstable_now(), typeof a == "function" ? pn.callback = a : pn === Mn(so) && Qm(so), Cb(r);
          } else Qm(so);
          pn = Mn(so);
        }
        if (pn !== null) var s = !0;else {
          var l = Mn(Ti);
          l !== null && Tb(Ib, l.startTime - r), s = !1;
        }
        return s;
      } finally {
        pn = null, Zr = t, Jm = !1;
      }
    }
    var Zm = !1,
      Xm = null,
      Ac = -1,
      $4 = 5,
      V4 = -1;
    function W4() {
      return !(Fe.unstable_now() - V4 < $4);
    }
    function bb() {
      if (Xm !== null) {
        var e = Fe.unstable_now();
        V4 = e;
        var r = !0;
        try {
          r = Xm(!0, e);
        } finally {
          r ? Tc() : (Zm = !1, Xm = null);
        }
      } else Zm = !1;
    }
    var Tc;
    typeof z4 == "function" ? Tc = function Tc() {
      z4(bb);
    } : (typeof MessageChannel === "undefined" ? "undefined" : _typeof(MessageChannel)) < "u" ? (wb = new MessageChannel(), j4 = wb.port2, wb.port1.onmessage = bb, Tc = function Tc() {
      j4.postMessage(null);
    }) : Tc = function Tc() {
      U4(bb, 0);
    };
    var wb, j4;
    function qb(e) {
      Xm = e, Zm || (Zm = !0, Tc());
    }
    function Tb(e, r) {
      Ac = U4(function () {
        e(Fe.unstable_now());
      }, r);
    }
    Fe.unstable_IdlePriority = 5;
    Fe.unstable_ImmediatePriority = 1;
    Fe.unstable_LowPriority = 4;
    Fe.unstable_NormalPriority = 3;
    Fe.unstable_Profiling = null;
    Fe.unstable_UserBlockingPriority = 2;
    Fe.unstable_cancelCallback = function (e) {
      e.callback = null;
    };
    Fe.unstable_continueExecution = function () {
      Da || Jm || (Da = !0, qb(Pb));
    };
    Fe.unstable_forceFrameRate = function (e) {
      0 > e || 125 < e ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : $4 = 0 < e ? Math.floor(1e3 / e) : 5;
    };
    Fe.unstable_getCurrentPriorityLevel = function () {
      return Zr;
    };
    Fe.unstable_getFirstCallbackNode = function () {
      return Mn(so);
    };
    Fe.unstable_next = function (e) {
      switch (Zr) {
        case 1:
        case 2:
        case 3:
          var r = 3;
          break;
        default:
          r = Zr;
      }
      var t = Zr;
      Zr = r;
      try {
        return e();
      } finally {
        Zr = t;
      }
    };
    Fe.unstable_pauseExecution = function () {};
    Fe.unstable_requestPaint = function () {};
    Fe.unstable_runWithPriority = function (e, r) {
      switch (e) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
          break;
        default:
          e = 3;
      }
      var t = Zr;
      Zr = e;
      try {
        return r();
      } finally {
        Zr = t;
      }
    };
    Fe.unstable_scheduleCallback = function (e, r, t) {
      var i = Fe.unstable_now();
      switch (_typeof(t) == "object" && t !== null ? (t = t.delay, t = typeof t == "number" && 0 < t ? i + t : i) : t = i, e) {
        case 1:
          var a = -1;
          break;
        case 2:
          a = 250;
          break;
        case 5:
          a = 1073741823;
          break;
        case 4:
          a = 1e4;
          break;
        default:
          a = 5e3;
      }
      return a = t + a, e = {
        id: Jxe++,
        callback: r,
        priorityLevel: e,
        startTime: t,
        expirationTime: a,
        sortIndex: -1
      }, t > i ? (e.sortIndex = t, Eb(Ti, e), Mn(so) === null && e === Mn(Ti) && (Oc ? (H4(Ac), Ac = -1) : Oc = !0, Tb(Ib, t - i))) : (e.sortIndex = a, Eb(so, e), Da || Jm || (Da = !0, qb(Pb))), e;
    };
    Fe.unstable_shouldYield = W4;
    Fe.unstable_wrapCallback = function (e) {
      var r = Zr;
      return function () {
        var t = Zr;
        Zr = r;
        try {
          return e.apply(this, arguments);
        } finally {
          Zr = t;
        }
      };
    };
  });
  var Y4 = h(function (ALe, K4) {
    "use strict";

    K4.exports = G4();
  });
  var Q4 = h(function (_Le, X4) {
    X4.exports = function (r) {
      var t = {},
        i = Z(),
        a = Y4(),
        s = Object.assign;
      function l(n) {
        for (var o = "https://reactjs.org/docs/error-decoder.html?invariant=" + n, u = 1; u < arguments.length; u++) o += "&args[]=" + encodeURIComponent(arguments[u]);
        return "Minified React error #" + n + "; visit " + o + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
      }
      var p = i.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
        d = Symbol.for("react.element"),
        v = Symbol.for("react.portal"),
        g = Symbol.for("react.fragment"),
        x = Symbol.for("react.strict_mode"),
        S = Symbol.for("react.profiler"),
        b = Symbol.for("react.provider"),
        q = Symbol.for("react.context"),
        E = Symbol.for("react.forward_ref"),
        C = Symbol.for("react.suspense"),
        T = Symbol.for("react.suspense_list"),
        D = Symbol.for("react.memo"),
        M = Symbol.for("react.lazy");
      Symbol.for("react.scope"), Symbol.for("react.debug_trace_mode");
      var k = Symbol.for("react.offscreen");
      Symbol.for("react.legacy_hidden"), Symbol.for("react.cache"), Symbol.for("react.tracing_marker");
      var W = Symbol.iterator;
      function ee(n) {
        return n === null || _typeof(n) != "object" ? null : (n = W && n[W] || n["@@iterator"], typeof n == "function" ? n : null);
      }
      function N(n) {
        if (n == null) return null;
        if (typeof n == "function") return n.displayName || n.name || null;
        if (typeof n == "string") return n;
        switch (n) {
          case g:
            return "Fragment";
          case v:
            return "Portal";
          case S:
            return "Profiler";
          case x:
            return "StrictMode";
          case C:
            return "Suspense";
          case T:
            return "SuspenseList";
        }
        if (_typeof(n) == "object") switch (n.$$typeof) {
          case q:
            return (n.displayName || "Context") + ".Consumer";
          case b:
            return (n._context.displayName || "Context") + ".Provider";
          case E:
            var o = n.render;
            return n = n.displayName, n || (n = o.displayName || o.name || "", n = n !== "" ? "ForwardRef(" + n + ")" : "ForwardRef"), n;
          case D:
            return o = n.displayName || null, o !== null ? o : N(n.type) || "Memo";
          case M:
            o = n._payload, n = n._init;
            try {
              return N(n(o));
            } catch (_unused53) {}
        }
        return null;
      }
      function B(n) {
        var o = n.type;
        switch (n.tag) {
          case 24:
            return "Cache";
          case 9:
            return (o.displayName || "Context") + ".Consumer";
          case 10:
            return (o._context.displayName || "Context") + ".Provider";
          case 18:
            return "DehydratedFragment";
          case 11:
            return n = o.render, n = n.displayName || n.name || "", o.displayName || (n !== "" ? "ForwardRef(" + n + ")" : "ForwardRef");
          case 7:
            return "Fragment";
          case 5:
            return o;
          case 4:
            return "Portal";
          case 3:
            return "Root";
          case 6:
            return "Text";
          case 16:
            return N(o);
          case 8:
            return o === x ? "StrictMode" : "Mode";
          case 22:
            return "Offscreen";
          case 12:
            return "Profiler";
          case 21:
            return "Scope";
          case 13:
            return "Suspense";
          case 19:
            return "SuspenseList";
          case 25:
            return "TracingMarker";
          case 1:
          case 0:
          case 17:
          case 2:
          case 14:
          case 15:
            if (typeof o == "function") return o.displayName || o.name || null;
            if (typeof o == "string") return o;
        }
        return null;
      }
      function U(n) {
        var o = n,
          u = n;
        if (n.alternate) for (; o.return;) o = o.return;else {
          n = o;
          do o = n, o.flags & 4098 && (u = o.return), n = o.return; while (n);
        }
        return o.tag === 3 ? u : null;
      }
      function me(n) {
        if (U(n) !== n) throw Error(l(188));
      }
      function be(n) {
        var o = n.alternate;
        if (!o) {
          if (o = U(n), o === null) throw Error(l(188));
          return o !== n ? null : n;
        }
        for (var u = n, c = o;;) {
          var f = u.return;
          if (f === null) break;
          var m = f.alternate;
          if (m === null) {
            if (c = f.return, c !== null) {
              u = c;
              continue;
            }
            break;
          }
          if (f.child === m.child) {
            for (m = f.child; m;) {
              if (m === u) return me(f), n;
              if (m === c) return me(f), o;
              m = m.sibling;
            }
            throw Error(l(188));
          }
          if (u.return !== c.return) u = f, c = m;else {
            for (var y = !1, I = f.child; I;) {
              if (I === u) {
                y = !0, u = f, c = m;
                break;
              }
              if (I === c) {
                y = !0, c = f, u = m;
                break;
              }
              I = I.sibling;
            }
            if (!y) {
              for (I = m.child; I;) {
                if (I === u) {
                  y = !0, u = m, c = f;
                  break;
                }
                if (I === c) {
                  y = !0, c = m, u = f;
                  break;
                }
                I = I.sibling;
              }
              if (!y) throw Error(l(189));
            }
          }
          if (u.alternate !== c) throw Error(l(190));
        }
        if (u.tag !== 3) throw Error(l(188));
        return u.stateNode.current === u ? n : o;
      }
      function re(n) {
        return n = be(n), n !== null ? Ne(n) : null;
      }
      function Ne(n) {
        if (n.tag === 5 || n.tag === 6) return n;
        for (n = n.child; n !== null;) {
          var o = Ne(n);
          if (o !== null) return o;
          n = n.sibling;
        }
        return null;
      }
      function se(n) {
        if (n.tag === 5 || n.tag === 6) return n;
        for (n = n.child; n !== null;) {
          if (n.tag !== 4) {
            var o = se(n);
            if (o !== null) return o;
          }
          n = n.sibling;
        }
        return null;
      }
      var Qe = Array.isArray,
        Me = r.getPublicInstance,
        ve = r.getRootHostContext,
        Ht = r.getChildHostContext,
        Dn = r.prepareForCommit,
        ji = r.resetAfterCommit,
        tt = r.createInstance,
        ue = r.appendInitialChild,
        $r = r.finalizeInitialChildren,
        X = r.prepareUpdate,
        tr = r.shouldSetTextContent,
        Ge = r.createTextInstance,
        Bo = r.scheduleTimeout,
        o3 = r.cancelTimeout,
        bh = r.noTimeout,
        Hc = r.isPrimaryRenderer,
        Rt = r.supportsMutation,
        $c = r.supportsPersistence,
        $t = r.supportsHydration,
        i3 = r.getInstanceFromNode,
        a3 = r.preparePortalMount,
        s3 = r.getCurrentEventPriority,
        u3 = r.detachDeletedInstance,
        l3 = r.supportsMicrotasks,
        c3 = r.scheduleMicrotask,
        _u = r.supportsTestSelectors,
        f3 = r.findFiberRoot,
        p3 = r.getBoundingRect,
        d3 = r.getTextContent,
        Nu = r.isHiddenSubtree,
        m3 = r.matchAccessibilityRole,
        h3 = r.setFocusIfFocusable,
        v3 = r.setupIntersectionObserver,
        g3 = r.appendChild,
        y3 = r.appendChildToContainer,
        x3 = r.commitTextUpdate,
        S3 = r.commitMount,
        b3 = r.commitUpdate,
        w3 = r.insertBefore,
        E3 = r.insertInContainerBefore,
        C3 = r.removeChild,
        I3 = r.removeChildFromContainer,
        Vb = r.resetTextContent,
        P3 = r.hideInstance,
        q3 = r.hideTextInstance,
        T3 = r.unhideInstance,
        O3 = r.unhideTextInstance,
        A3 = r.clearContainer,
        _3 = r.cloneInstance,
        Wb = r.createContainerChildSet,
        Gb = r.appendChildToContainerChildSet,
        N3 = r.finalizeContainerChildren,
        wh = r.replaceContainerChildren,
        Kb = r.cloneHiddenInstance,
        Yb = r.cloneHiddenTextInstance,
        R3 = r.canHydrateInstance,
        M3 = r.canHydrateTextInstance,
        k3 = r.canHydrateSuspenseInstance,
        Xb = r.isSuspenseInstancePending,
        Eh = r.isSuspenseInstanceFallback,
        D3 = r.getSuspenseInstanceFallbackErrorDetails,
        B3 = r.registerSuspenseInstanceRetry,
        Vc = r.getNextHydratableSibling,
        F3 = r.getFirstHydratableChild,
        L3 = r.getFirstHydratableChildWithinContainer,
        z3 = r.getFirstHydratableChildWithinSuspenseInstance,
        j3 = r.hydrateInstance,
        U3 = r.hydrateTextInstance,
        H3 = r.hydrateSuspenseInstance,
        $3 = r.getNextHydratableInstanceAfterSuspenseInstance,
        V3 = r.commitHydratedContainer,
        W3 = r.commitHydratedSuspenseInstance,
        G3 = r.clearSuspenseBoundary,
        K3 = r.clearSuspenseBoundaryFromContainer,
        Y3 = r.shouldDeleteUnhydratedTailInstances,
        X3 = r.didNotMatchHydratedContainerTextInstance,
        Q3 = r.didNotMatchHydratedTextInstance,
        Ch;
      function Ru(n) {
        if (Ch === void 0) try {
          throw Error();
        } catch (u) {
          var o = u.stack.trim().match(/\n( *(at )?)/);
          Ch = o && o[1] || "";
        }
        return "\n" + Ch + n;
      }
      var Ih = !1;
      function Ph(n, o) {
        if (!n || Ih) return "";
        Ih = !0;
        var u = Error.prepareStackTrace;
        Error.prepareStackTrace = void 0;
        try {
          if (o) {
            if (o = function o() {
              throw Error();
            }, Object.defineProperty(o.prototype, "props", {
              set: function set() {
                throw Error();
              }
            }), (typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) == "object" && Reflect.construct) {
              try {
                Reflect.construct(o, []);
              } catch (z) {
                var c = z;
              }
              Reflect.construct(n, [], o);
            } else {
              try {
                o.call();
              } catch (z) {
                c = z;
              }
              n.call(o.prototype);
            }
          } else {
            try {
              throw Error();
            } catch (z) {
              c = z;
            }
            n();
          }
        } catch (z) {
          if (z && c && typeof z.stack == "string") {
            for (var f = z.stack.split("\n"), m = c.stack.split("\n"), y = f.length - 1, I = m.length - 1; 1 <= y && 0 <= I && f[y] !== m[I];) I--;
            for (; 1 <= y && 0 <= I; y--, I--) if (f[y] !== m[I]) {
              if (y !== 1 || I !== 1) do if (y--, I--, 0 > I || f[y] !== m[I]) {
                var A = "\n" + f[y].replace(" at new ", " at ");
                return n.displayName && A.includes("<anonymous>") && (A = A.replace("<anonymous>", n.displayName)), A;
              } while (1 <= y && 0 <= I);
              break;
            }
          }
        } finally {
          Ih = !1, Error.prepareStackTrace = u;
        }
        return (n = n ? n.displayName || n.name : "") ? Ru(n) : "";
      }
      var J3 = Object.prototype.hasOwnProperty,
        qh = [],
        Ua = -1;
      function Fo(n) {
        return {
          current: n
        };
      }
      function ze(n) {
        0 > Ua || (n.current = qh[Ua], qh[Ua] = null, Ua--);
      }
      function De(n, o) {
        Ua++, qh[Ua] = n.current, n.current = o;
      }
      var Lo = {},
        Vr = Fo(Lo),
        dt = Fo(!1),
        Ui = Lo;
      function Ha(n, o) {
        var u = n.type.contextTypes;
        if (!u) return Lo;
        var c = n.stateNode;
        if (c && c.__reactInternalMemoizedUnmaskedChildContext === o) return c.__reactInternalMemoizedMaskedChildContext;
        var f = {},
          m;
        for (m in u) f[m] = o[m];
        return c && (n = n.stateNode, n.__reactInternalMemoizedUnmaskedChildContext = o, n.__reactInternalMemoizedMaskedChildContext = f), f;
      }
      function mt(n) {
        return n = n.childContextTypes, n != null;
      }
      function Wc() {
        ze(dt), ze(Vr);
      }
      function Qb(n, o, u) {
        if (Vr.current !== Lo) throw Error(l(168));
        De(Vr, o), De(dt, u);
      }
      function Jb(n, o, u) {
        var c = n.stateNode;
        if (o = o.childContextTypes, typeof c.getChildContext != "function") return u;
        c = c.getChildContext();
        for (var f in c) if (!(f in o)) throw Error(l(108, B(n) || "Unknown", f));
        return s({}, u, c);
      }
      function Gc(n) {
        return n = (n = n.stateNode) && n.__reactInternalMemoizedMergedChildContext || Lo, Ui = Vr.current, De(Vr, n), De(dt, dt.current), !0;
      }
      function Zb(n, o, u) {
        var c = n.stateNode;
        if (!c) throw Error(l(169));
        u ? (n = Jb(n, o, Ui), c.__reactInternalMemoizedMergedChildContext = n, ze(dt), ze(Vr), De(Vr, n)) : ze(dt), De(dt, u);
      }
      var gn = Math.clz32 ? Math.clz32 : r6,
        Z3 = Math.log,
        e6 = Math.LN2;
      function r6(n) {
        return n >>>= 0, n === 0 ? 32 : 31 - (Z3(n) / e6 | 0) | 0;
      }
      var Kc = 64,
        Yc = 4194304;
      function Mu(n) {
        switch (n & -n) {
          case 1:
            return 1;
          case 2:
            return 2;
          case 4:
            return 4;
          case 8:
            return 8;
          case 16:
            return 16;
          case 32:
            return 32;
          case 64:
          case 128:
          case 256:
          case 512:
          case 1024:
          case 2048:
          case 4096:
          case 8192:
          case 16384:
          case 32768:
          case 65536:
          case 131072:
          case 262144:
          case 524288:
          case 1048576:
          case 2097152:
            return n & 4194240;
          case 4194304:
          case 8388608:
          case 16777216:
          case 33554432:
          case 67108864:
            return n & 130023424;
          case 134217728:
            return 134217728;
          case 268435456:
            return 268435456;
          case 536870912:
            return 536870912;
          case 1073741824:
            return 1073741824;
          default:
            return n;
        }
      }
      function Xc(n, o) {
        var u = n.pendingLanes;
        if (u === 0) return 0;
        var c = 0,
          f = n.suspendedLanes,
          m = n.pingedLanes,
          y = u & 268435455;
        if (y !== 0) {
          var I = y & ~f;
          I !== 0 ? c = Mu(I) : (m &= y, m !== 0 && (c = Mu(m)));
        } else y = u & ~f, y !== 0 ? c = Mu(y) : m !== 0 && (c = Mu(m));
        if (c === 0) return 0;
        if (o !== 0 && o !== c && !(o & f) && (f = c & -c, m = o & -o, f >= m || f === 16 && (m & 4194240) !== 0)) return o;
        if (c & 4 && (c |= u & 16), o = n.entangledLanes, o !== 0) for (n = n.entanglements, o &= c; 0 < o;) u = 31 - gn(o), f = 1 << u, c |= n[u], o &= ~f;
        return c;
      }
      function t6(n, o) {
        switch (n) {
          case 1:
          case 2:
          case 4:
            return o + 250;
          case 8:
          case 16:
          case 32:
          case 64:
          case 128:
          case 256:
          case 512:
          case 1024:
          case 2048:
          case 4096:
          case 8192:
          case 16384:
          case 32768:
          case 65536:
          case 131072:
          case 262144:
          case 524288:
          case 1048576:
          case 2097152:
            return o + 5e3;
          case 4194304:
          case 8388608:
          case 16777216:
          case 33554432:
          case 67108864:
            return -1;
          case 134217728:
          case 268435456:
          case 536870912:
          case 1073741824:
            return -1;
          default:
            return -1;
        }
      }
      function n6(n, o) {
        for (var u = n.suspendedLanes, c = n.pingedLanes, f = n.expirationTimes, m = n.pendingLanes; 0 < m;) {
          var y = 31 - gn(m),
            I = 1 << y,
            A = f[y];
          A === -1 ? (!(I & u) || I & c) && (f[y] = t6(I, o)) : A <= o && (n.expiredLanes |= I), m &= ~I;
        }
      }
      function Th(n) {
        return n = n.pendingLanes & -1073741825, n !== 0 ? n : n & 1073741824 ? 1073741824 : 0;
      }
      function ew() {
        var n = Kc;
        return Kc <<= 1, !(Kc & 4194240) && (Kc = 64), n;
      }
      function Oh(n) {
        for (var o = [], u = 0; 31 > u; u++) o.push(n);
        return o;
      }
      function ku(n, o, u) {
        n.pendingLanes |= o, o !== 536870912 && (n.suspendedLanes = 0, n.pingedLanes = 0), n = n.eventTimes, o = 31 - gn(o), n[o] = u;
      }
      function o6(n, o) {
        var u = n.pendingLanes & ~o;
        n.pendingLanes = o, n.suspendedLanes = 0, n.pingedLanes = 0, n.expiredLanes &= o, n.mutableReadLanes &= o, n.entangledLanes &= o, o = n.entanglements;
        var c = n.eventTimes;
        for (n = n.expirationTimes; 0 < u;) {
          var f = 31 - gn(u),
            m = 1 << f;
          o[f] = 0, c[f] = -1, n[f] = -1, u &= ~m;
        }
      }
      function Ah(n, o) {
        var u = n.entangledLanes |= o;
        for (n = n.entanglements; u;) {
          var c = 31 - gn(u),
            f = 1 << c;
          f & o | n[c] & o && (n[c] |= o), u &= ~f;
        }
      }
      var Pe = 0;
      function rw(n) {
        return n &= -n, 1 < n ? 4 < n ? n & 268435455 ? 16 : 536870912 : 4 : 1;
      }
      var _h = a.unstable_scheduleCallback,
        tw = a.unstable_cancelCallback,
        i6 = a.unstable_shouldYield,
        a6 = a.unstable_requestPaint,
        Tr = a.unstable_now,
        Nh = a.unstable_ImmediatePriority,
        s6 = a.unstable_UserBlockingPriority,
        Rh = a.unstable_NormalPriority,
        u6 = a.unstable_IdlePriority,
        Qc = null,
        Bn = null;
      function l6(n) {
        if (Bn && typeof Bn.onCommitFiberRoot == "function") try {
          Bn.onCommitFiberRoot(Qc, n, void 0, (n.current.flags & 128) === 128);
        } catch (_unused54) {}
      }
      function c6(n, o) {
        return n === o && (n !== 0 || 1 / n === 1 / o) || n !== n && o !== o;
      }
      var yn = typeof Object.is == "function" ? Object.is : c6,
        uo = null,
        Jc = !1,
        Mh = !1;
      function nw(n) {
        uo === null ? uo = [n] : uo.push(n);
      }
      function f6(n) {
        Jc = !0, nw(n);
      }
      function Fn() {
        if (!Mh && uo !== null) {
          Mh = !0;
          var n = 0,
            o = Pe;
          try {
            var u = uo;
            for (Pe = 1; n < u.length; n++) {
              var c = u[n];
              do c = c(!0); while (c !== null);
            }
            uo = null, Jc = !1;
          } catch (f) {
            throw uo !== null && (uo = uo.slice(n + 1)), _h(Nh, Fn), f;
          } finally {
            Pe = o, Mh = !1;
          }
        }
        return null;
      }
      var $a = [],
        Va = 0,
        Zc = null,
        ef = 0,
        Vt = [],
        Wt = 0,
        Hi = null,
        lo = 1,
        co = "";
      function $i(n, o) {
        $a[Va++] = ef, $a[Va++] = Zc, Zc = n, ef = o;
      }
      function ow(n, o, u) {
        Vt[Wt++] = lo, Vt[Wt++] = co, Vt[Wt++] = Hi, Hi = n;
        var c = lo;
        n = co;
        var f = 32 - gn(c) - 1;
        c &= ~(1 << f), u += 1;
        var m = 32 - gn(o) + f;
        if (30 < m) {
          var y = f - f % 5;
          m = (c & (1 << y) - 1).toString(32), c >>= y, f -= y, lo = 1 << 32 - gn(o) + f | u << f | c, co = m + n;
        } else lo = 1 << m | u << f | c, co = n;
      }
      function kh(n) {
        n.return !== null && ($i(n, 1), ow(n, 1, 0));
      }
      function Dh(n) {
        for (; n === Zc;) Zc = $a[--Va], $a[Va] = null, ef = $a[--Va], $a[Va] = null;
        for (; n === Hi;) Hi = Vt[--Wt], Vt[Wt] = null, co = Vt[--Wt], Vt[Wt] = null, lo = Vt[--Wt], Vt[Wt] = null;
      }
      var Mt = null,
        Gt = null,
        Ke = !1,
        Du = !1,
        xn = null;
      function iw(n, o) {
        var u = Jt(5, null, null, 0);
        u.elementType = "DELETED", u.stateNode = o, u.return = n, o = n.deletions, o === null ? (n.deletions = [u], n.flags |= 16) : o.push(u);
      }
      function aw(n, o) {
        switch (n.tag) {
          case 5:
            return o = R3(o, n.type, n.pendingProps), o !== null ? (n.stateNode = o, Mt = n, Gt = F3(o), !0) : !1;
          case 6:
            return o = M3(o, n.pendingProps), o !== null ? (n.stateNode = o, Mt = n, Gt = null, !0) : !1;
          case 13:
            if (o = k3(o), o !== null) {
              var u = Hi !== null ? {
                id: lo,
                overflow: co
              } : null;
              return n.memoizedState = {
                dehydrated: o,
                treeContext: u,
                retryLane: 1073741824
              }, u = Jt(18, null, null, 0), u.stateNode = o, u.return = n, n.child = u, Mt = n, Gt = null, !0;
            }
            return !1;
          default:
            return !1;
        }
      }
      function Bh(n) {
        return (n.mode & 1) !== 0 && (n.flags & 128) === 0;
      }
      function Fh(n) {
        if (Ke) {
          var o = Gt;
          if (o) {
            var u = o;
            if (!aw(n, o)) {
              if (Bh(n)) throw Error(l(418));
              o = Vc(u);
              var c = Mt;
              o && aw(n, o) ? iw(c, u) : (n.flags = n.flags & -4097 | 2, Ke = !1, Mt = n);
            }
          } else {
            if (Bh(n)) throw Error(l(418));
            n.flags = n.flags & -4097 | 2, Ke = !1, Mt = n;
          }
        }
      }
      function sw(n) {
        for (n = n.return; n !== null && n.tag !== 5 && n.tag !== 3 && n.tag !== 13;) n = n.return;
        Mt = n;
      }
      function rf(n) {
        if (!$t || n !== Mt) return !1;
        if (!Ke) return sw(n), Ke = !0, !1;
        if (n.tag !== 3 && (n.tag !== 5 || Y3(n.type) && !tr(n.type, n.memoizedProps))) {
          var o = Gt;
          if (o) {
            if (Bh(n)) throw uw(), Error(l(418));
            for (; o;) iw(n, o), o = Vc(o);
          }
        }
        if (sw(n), n.tag === 13) {
          if (!$t) throw Error(l(316));
          if (n = n.memoizedState, n = n !== null ? n.dehydrated : null, !n) throw Error(l(317));
          Gt = $3(n);
        } else Gt = Mt ? Vc(n.stateNode) : null;
        return !0;
      }
      function uw() {
        for (var n = Gt; n;) n = Vc(n);
      }
      function Wa() {
        $t && (Gt = Mt = null, Du = Ke = !1);
      }
      function Lh(n) {
        xn === null ? xn = [n] : xn.push(n);
      }
      var p6 = p.ReactCurrentBatchConfig;
      function tf(n, o) {
        if (yn(n, o)) return !0;
        if (_typeof(n) != "object" || n === null || _typeof(o) != "object" || o === null) return !1;
        var u = Object.keys(n),
          c = Object.keys(o);
        if (u.length !== c.length) return !1;
        for (c = 0; c < u.length; c++) {
          var f = u[c];
          if (!J3.call(o, f) || !yn(n[f], o[f])) return !1;
        }
        return !0;
      }
      function d6(n) {
        switch (n.tag) {
          case 5:
            return Ru(n.type);
          case 16:
            return Ru("Lazy");
          case 13:
            return Ru("Suspense");
          case 19:
            return Ru("SuspenseList");
          case 0:
          case 2:
          case 15:
            return n = Ph(n.type, !1), n;
          case 11:
            return n = Ph(n.type.render, !1), n;
          case 1:
            return n = Ph(n.type, !0), n;
          default:
            return "";
        }
      }
      function Bu(n, o, u) {
        if (n = u.ref, n !== null && typeof n != "function" && _typeof(n) != "object") {
          if (u._owner) {
            if (u = u._owner, u) {
              if (u.tag !== 1) throw Error(l(309));
              var c = u.stateNode;
            }
            if (!c) throw Error(l(147, n));
            var f = c,
              m = "" + n;
            return o !== null && o.ref !== null && typeof o.ref == "function" && o.ref._stringRef === m ? o.ref : (o = function o(y) {
              var I = f.refs;
              y === null ? delete I[m] : I[m] = y;
            }, o._stringRef = m, o);
          }
          if (typeof n != "string") throw Error(l(284));
          if (!u._owner) throw Error(l(290, n));
        }
        return n;
      }
      function nf(n, o) {
        throw n = Object.prototype.toString.call(o), Error(l(31, n === "[object Object]" ? "object with keys {" + Object.keys(o).join(", ") + "}" : n));
      }
      function lw(n) {
        var o = n._init;
        return o(n._payload);
      }
      function cw(n) {
        function o(O, P) {
          if (n) {
            var _ = O.deletions;
            _ === null ? (O.deletions = [P], O.flags |= 16) : _.push(P);
          }
        }
        function u(O, P) {
          if (!n) return null;
          for (; P !== null;) o(O, P), P = P.sibling;
          return null;
        }
        function c(O, P) {
          for (O = new Map(); P !== null;) P.key !== null ? O.set(P.key, P) : O.set(P.index, P), P = P.sibling;
          return O;
        }
        function f(O, P) {
          return O = Wo(O, P), O.index = 0, O.sibling = null, O;
        }
        function m(O, P, _) {
          return O.index = _, n ? (_ = O.alternate, _ !== null ? (_ = _.index, _ < P ? (O.flags |= 2, P) : _) : (O.flags |= 2, P)) : (O.flags |= 1048576, P);
        }
        function y(O) {
          return n && O.alternate === null && (O.flags |= 2), O;
        }
        function I(O, P, _, $) {
          return P === null || P.tag !== 6 ? (P = Mv(_, O.mode, $), P.return = O, P) : (P = f(P, _), P.return = O, P);
        }
        function A(O, P, _, $) {
          var te = _.type;
          return te === g ? G(O, P, _.props.children, $, _.key) : P !== null && (P.elementType === te || _typeof(te) == "object" && te !== null && te.$$typeof === M && lw(te) === P.type) ? ($ = f(P, _.props), $.ref = Bu(O, P, _), $.return = O, $) : ($ = kf(_.type, _.key, _.props, null, O.mode, $), $.ref = Bu(O, P, _), $.return = O, $);
        }
        function z(O, P, _, $) {
          return P === null || P.tag !== 4 || P.stateNode.containerInfo !== _.containerInfo || P.stateNode.implementation !== _.implementation ? (P = kv(_, O.mode, $), P.return = O, P) : (P = f(P, _.children || []), P.return = O, P);
        }
        function G(O, P, _, $, te) {
          return P === null || P.tag !== 7 ? (P = Qi(_, O.mode, $, te), P.return = O, P) : (P = f(P, _), P.return = O, P);
        }
        function ce(O, P, _) {
          if (typeof P == "string" && P !== "" || typeof P == "number") return P = Mv("" + P, O.mode, _), P.return = O, P;
          if (_typeof(P) == "object" && P !== null) {
            switch (P.$$typeof) {
              case d:
                return _ = kf(P.type, P.key, P.props, null, O.mode, _), _.ref = Bu(O, null, P), _.return = O, _;
              case v:
                return P = kv(P, O.mode, _), P.return = O, P;
              case M:
                var $ = P._init;
                return ce(O, $(P._payload), _);
            }
            if (Qe(P) || ee(P)) return P = Qi(P, O.mode, _, null), P.return = O, P;
            nf(O, P);
          }
          return null;
        }
        function H(O, P, _, $) {
          var te = P !== null ? P.key : null;
          if (typeof _ == "string" && _ !== "" || typeof _ == "number") return te !== null ? null : I(O, P, "" + _, $);
          if (_typeof(_) == "object" && _ !== null) {
            switch (_.$$typeof) {
              case d:
                return _.key === te ? A(O, P, _, $) : null;
              case v:
                return _.key === te ? z(O, P, _, $) : null;
              case M:
                return te = _._init, H(O, P, te(_._payload), $);
            }
            if (Qe(_) || ee(_)) return te !== null ? null : G(O, P, _, $, null);
            nf(O, _);
          }
          return null;
        }
        function je(O, P, _, $, te) {
          if (typeof $ == "string" && $ !== "" || typeof $ == "number") return O = O.get(_) || null, I(P, O, "" + $, te);
          if (_typeof($) == "object" && $ !== null) {
            switch ($.$$typeof) {
              case d:
                return O = O.get($.key === null ? _ : $.key) || null, A(P, O, $, te);
              case v:
                return O = O.get($.key === null ? _ : $.key) || null, z(P, O, $, te);
              case M:
                var he = $._init;
                return je(O, P, _, he($._payload), te);
            }
            if (Qe($) || ee($)) return O = O.get(_) || null, G(P, O, $, te, null);
            nf(P, $);
          }
          return null;
        }
        function ke(O, P, _, $) {
          for (var te = null, he = null, fe = P, qe = P = 0, _r = null; fe !== null && qe < _.length; qe++) {
            fe.index > qe ? (_r = fe, fe = null) : _r = fe.sibling;
            var Te = H(O, fe, _[qe], $);
            if (Te === null) {
              fe === null && (fe = _r);
              break;
            }
            n && fe && Te.alternate === null && o(O, fe), P = m(Te, P, qe), he === null ? te = Te : he.sibling = Te, he = Te, fe = _r;
          }
          if (qe === _.length) return u(O, fe), Ke && $i(O, qe), te;
          if (fe === null) {
            for (; qe < _.length; qe++) fe = ce(O, _[qe], $), fe !== null && (P = m(fe, P, qe), he === null ? te = fe : he.sibling = fe, he = fe);
            return Ke && $i(O, qe), te;
          }
          for (fe = c(O, fe); qe < _.length; qe++) _r = je(fe, O, qe, _[qe], $), _r !== null && (n && _r.alternate !== null && fe.delete(_r.key === null ? qe : _r.key), P = m(_r, P, qe), he === null ? te = _r : he.sibling = _r, he = _r);
          return n && fe.forEach(function (Go) {
            return o(O, Go);
          }), Ke && $i(O, qe), te;
        }
        function yt(O, P, _, $) {
          var te = ee(_);
          if (typeof te != "function") throw Error(l(150));
          if (_ = te.call(_), _ == null) throw Error(l(151));
          for (var he = te = null, fe = P, qe = P = 0, _r = null, Te = _.next(); fe !== null && !Te.done; qe++, Te = _.next()) {
            fe.index > qe ? (_r = fe, fe = null) : _r = fe.sibling;
            var Go = H(O, fe, Te.value, $);
            if (Go === null) {
              fe === null && (fe = _r);
              break;
            }
            n && fe && Go.alternate === null && o(O, fe), P = m(Go, P, qe), he === null ? te = Go : he.sibling = Go, he = Go, fe = _r;
          }
          if (Te.done) return u(O, fe), Ke && $i(O, qe), te;
          if (fe === null) {
            for (; !Te.done; qe++, Te = _.next()) Te = ce(O, Te.value, $), Te !== null && (P = m(Te, P, qe), he === null ? te = Te : he.sibling = Te, he = Te);
            return Ke && $i(O, qe), te;
          }
          for (fe = c(O, fe); !Te.done; qe++, Te = _.next()) Te = je(fe, O, qe, Te.value, $), Te !== null && (n && Te.alternate !== null && fe.delete(Te.key === null ? qe : Te.key), P = m(Te, P, qe), he === null ? te = Te : he.sibling = Te, he = Te);
          return n && fe.forEach(function (H6) {
            return o(O, H6);
          }), Ke && $i(O, qe), te;
        }
        function ho(O, P, _, $) {
          if (_typeof(_) == "object" && _ !== null && _.type === g && _.key === null && (_ = _.props.children), _typeof(_) == "object" && _ !== null) {
            switch (_.$$typeof) {
              case d:
                e: {
                  for (var te = _.key, he = P; he !== null;) {
                    if (he.key === te) {
                      if (te = _.type, te === g) {
                        if (he.tag === 7) {
                          u(O, he.sibling), P = f(he, _.props.children), P.return = O, O = P;
                          break e;
                        }
                      } else if (he.elementType === te || _typeof(te) == "object" && te !== null && te.$$typeof === M && lw(te) === he.type) {
                        u(O, he.sibling), P = f(he, _.props), P.ref = Bu(O, he, _), P.return = O, O = P;
                        break e;
                      }
                      u(O, he);
                      break;
                    } else o(O, he);
                    he = he.sibling;
                  }
                  _.type === g ? (P = Qi(_.props.children, O.mode, $, _.key), P.return = O, O = P) : ($ = kf(_.type, _.key, _.props, null, O.mode, $), $.ref = Bu(O, P, _), $.return = O, O = $);
                }
                return y(O);
              case v:
                e: {
                  for (he = _.key; P !== null;) {
                    if (P.key === he) {
                      if (P.tag === 4 && P.stateNode.containerInfo === _.containerInfo && P.stateNode.implementation === _.implementation) {
                        u(O, P.sibling), P = f(P, _.children || []), P.return = O, O = P;
                        break e;
                      } else {
                        u(O, P);
                        break;
                      }
                    } else o(O, P);
                    P = P.sibling;
                  }
                  P = kv(_, O.mode, $), P.return = O, O = P;
                }
                return y(O);
              case M:
                return he = _._init, ho(O, P, he(_._payload), $);
            }
            if (Qe(_)) return ke(O, P, _, $);
            if (ee(_)) return yt(O, P, _, $);
            nf(O, _);
          }
          return typeof _ == "string" && _ !== "" || typeof _ == "number" ? (_ = "" + _, P !== null && P.tag === 6 ? (u(O, P.sibling), P = f(P, _), P.return = O, O = P) : (u(O, P), P = Mv(_, O.mode, $), P.return = O, O = P), y(O)) : u(O, P);
        }
        return ho;
      }
      var Ga = cw(!0),
        fw = cw(!1),
        of = Fo(null),
        af = null,
        Ka = null,
        zh = null;
      function jh() {
        zh = Ka = af = null;
      }
      function pw(n, o, u) {
        Hc ? (De(of, o._currentValue), o._currentValue = u) : (De(of, o._currentValue2), o._currentValue2 = u);
      }
      function Uh(n) {
        var o = of.current;
        ze(of), Hc ? n._currentValue = o : n._currentValue2 = o;
      }
      function Hh(n, o, u) {
        for (; n !== null;) {
          var c = n.alternate;
          if ((n.childLanes & o) !== o ? (n.childLanes |= o, c !== null && (c.childLanes |= o)) : c !== null && (c.childLanes & o) !== o && (c.childLanes |= o), n === u) break;
          n = n.return;
        }
      }
      function Ya(n, o) {
        af = n, zh = Ka = null, n = n.dependencies, n !== null && n.firstContext !== null && (n.lanes & o && (ht = !0), n.firstContext = null);
      }
      function Kt(n) {
        var o = Hc ? n._currentValue : n._currentValue2;
        if (zh !== n) if (n = {
          context: n,
          memoizedValue: o,
          next: null
        }, Ka === null) {
          if (af === null) throw Error(l(308));
          Ka = n, af.dependencies = {
            lanes: 0,
            firstContext: n
          };
        } else Ka = Ka.next = n;
        return o;
      }
      var Vi = null;
      function $h(n) {
        Vi === null ? Vi = [n] : Vi.push(n);
      }
      function dw(n, o, u, c) {
        var f = o.interleaved;
        return f === null ? (u.next = u, $h(o)) : (u.next = f.next, f.next = u), o.interleaved = u, Ln(n, c);
      }
      function Ln(n, o) {
        n.lanes |= o;
        var u = n.alternate;
        for (u !== null && (u.lanes |= o), u = n, n = n.return; n !== null;) n.childLanes |= o, u = n.alternate, u !== null && (u.childLanes |= o), u = n, n = n.return;
        return u.tag === 3 ? u.stateNode : null;
      }
      var zo = !1;
      function Vh(n) {
        n.updateQueue = {
          baseState: n.memoizedState,
          firstBaseUpdate: null,
          lastBaseUpdate: null,
          shared: {
            pending: null,
            interleaved: null,
            lanes: 0
          },
          effects: null
        };
      }
      function mw(n, o) {
        n = n.updateQueue, o.updateQueue === n && (o.updateQueue = {
          baseState: n.baseState,
          firstBaseUpdate: n.firstBaseUpdate,
          lastBaseUpdate: n.lastBaseUpdate,
          shared: n.shared,
          effects: n.effects
        });
      }
      function fo(n, o) {
        return {
          eventTime: n,
          lane: o,
          tag: 0,
          payload: null,
          callback: null,
          next: null
        };
      }
      function jo(n, o, u) {
        var c = n.updateQueue;
        if (c === null) return null;
        if (c = c.shared, ye & 2) {
          var f = c.pending;
          return f === null ? o.next = o : (o.next = f.next, f.next = o), c.pending = o, Ln(n, u);
        }
        return f = c.interleaved, f === null ? (o.next = o, $h(c)) : (o.next = f.next, f.next = o), c.interleaved = o, Ln(n, u);
      }
      function sf(n, o, u) {
        if (o = o.updateQueue, o !== null && (o = o.shared, (u & 4194240) !== 0)) {
          var c = o.lanes;
          c &= n.pendingLanes, u |= c, o.lanes = u, Ah(n, u);
        }
      }
      function hw(n, o) {
        var u = n.updateQueue,
          c = n.alternate;
        if (c !== null && (c = c.updateQueue, u === c)) {
          var f = null,
            m = null;
          if (u = u.firstBaseUpdate, u !== null) {
            do {
              var y = {
                eventTime: u.eventTime,
                lane: u.lane,
                tag: u.tag,
                payload: u.payload,
                callback: u.callback,
                next: null
              };
              m === null ? f = m = y : m = m.next = y, u = u.next;
            } while (u !== null);
            m === null ? f = m = o : m = m.next = o;
          } else f = m = o;
          u = {
            baseState: c.baseState,
            firstBaseUpdate: f,
            lastBaseUpdate: m,
            shared: c.shared,
            effects: c.effects
          }, n.updateQueue = u;
          return;
        }
        n = u.lastBaseUpdate, n === null ? u.firstBaseUpdate = o : n.next = o, u.lastBaseUpdate = o;
      }
      function uf(n, o, u, c) {
        var f = n.updateQueue;
        zo = !1;
        var m = f.firstBaseUpdate,
          y = f.lastBaseUpdate,
          I = f.shared.pending;
        if (I !== null) {
          f.shared.pending = null;
          var A = I,
            z = A.next;
          A.next = null, y === null ? m = z : y.next = z, y = A;
          var G = n.alternate;
          G !== null && (G = G.updateQueue, I = G.lastBaseUpdate, I !== y && (I === null ? G.firstBaseUpdate = z : I.next = z, G.lastBaseUpdate = A));
        }
        if (m !== null) {
          var ce = f.baseState;
          y = 0, G = z = A = null, I = m;
          do {
            var H = I.lane,
              je = I.eventTime;
            if ((c & H) === H) {
              G !== null && (G = G.next = {
                eventTime: je,
                lane: 0,
                tag: I.tag,
                payload: I.payload,
                callback: I.callback,
                next: null
              });
              e: {
                var ke = n,
                  yt = I;
                switch (H = o, je = u, yt.tag) {
                  case 1:
                    if (ke = yt.payload, typeof ke == "function") {
                      ce = ke.call(je, ce, H);
                      break e;
                    }
                    ce = ke;
                    break e;
                  case 3:
                    ke.flags = ke.flags & -65537 | 128;
                  case 0:
                    if (ke = yt.payload, H = typeof ke == "function" ? ke.call(je, ce, H) : ke, H == null) break e;
                    ce = s({}, ce, H);
                    break e;
                  case 2:
                    zo = !0;
                }
              }
              I.callback !== null && I.lane !== 0 && (n.flags |= 64, H = f.effects, H === null ? f.effects = [I] : H.push(I));
            } else je = {
              eventTime: je,
              lane: H,
              tag: I.tag,
              payload: I.payload,
              callback: I.callback,
              next: null
            }, G === null ? (z = G = je, A = ce) : G = G.next = je, y |= H;
            if (I = I.next, I === null) {
              if (I = f.shared.pending, I === null) break;
              H = I, I = H.next, H.next = null, f.lastBaseUpdate = H, f.shared.pending = null;
            }
          } while (!0);
          if (G === null && (A = ce), f.baseState = A, f.firstBaseUpdate = z, f.lastBaseUpdate = G, o = f.shared.interleaved, o !== null) {
            f = o;
            do y |= f.lane, f = f.next; while (f !== o);
          } else m === null && (f.shared.lanes = 0);
          Gi |= y, n.lanes = y, n.memoizedState = ce;
        }
      }
      function vw(n, o, u) {
        if (n = o.effects, o.effects = null, n !== null) for (o = 0; o < n.length; o++) {
          var c = n[o],
            f = c.callback;
          if (f !== null) {
            if (c.callback = null, c = u, typeof f != "function") throw Error(l(191, f));
            f.call(c);
          }
        }
      }
      var Fu = {},
        Yt = Fo(Fu),
        Lu = Fo(Fu),
        Xa = Fo(Fu);
      function zn(n) {
        if (n === Fu) throw Error(l(174));
        return n;
      }
      function Wh(n, o) {
        De(Xa, o), De(Lu, n), De(Yt, Fu), n = ve(o), ze(Yt), De(Yt, n);
      }
      function Qa() {
        ze(Yt), ze(Lu), ze(Xa);
      }
      function gw(n) {
        var o = zn(Xa.current),
          u = zn(Yt.current);
        o = Ht(u, n.type, o), u !== o && (De(Lu, n), De(Yt, o));
      }
      function Gh(n) {
        Lu.current === n && (ze(Yt), ze(Lu));
      }
      var Je = Fo(0);
      function lf(n) {
        for (var o = n; o !== null;) {
          if (o.tag === 13) {
            var u = o.memoizedState;
            if (u !== null && (u = u.dehydrated, u === null || Xb(u) || Eh(u))) return o;
          } else if (o.tag === 19 && o.memoizedProps.revealOrder !== void 0) {
            if (o.flags & 128) return o;
          } else if (o.child !== null) {
            o.child.return = o, o = o.child;
            continue;
          }
          if (o === n) break;
          for (; o.sibling === null;) {
            if (o.return === null || o.return === n) return null;
            o = o.return;
          }
          o.sibling.return = o.return, o = o.sibling;
        }
        return null;
      }
      var Kh = [];
      function Yh() {
        for (var n = 0; n < Kh.length; n++) {
          var o = Kh[n];
          Hc ? o._workInProgressVersionPrimary = null : o._workInProgressVersionSecondary = null;
        }
        Kh.length = 0;
      }
      var cf = p.ReactCurrentDispatcher,
        Xh = p.ReactCurrentBatchConfig,
        Wi = 0,
        Ze = null,
        gr = null,
        Or = null,
        ff = !1,
        zu = !1,
        ju = 0,
        m6 = 0;
      function Wr() {
        throw Error(l(321));
      }
      function Qh(n, o) {
        if (o === null) return !1;
        for (var u = 0; u < o.length && u < n.length; u++) if (!yn(n[u], o[u])) return !1;
        return !0;
      }
      function Jh(n, o, u, c, f, m) {
        if (Wi = m, Ze = o, o.memoizedState = null, o.updateQueue = null, o.lanes = 0, cf.current = n === null || n.memoizedState === null ? y6 : x6, n = u(c, f), zu) {
          m = 0;
          do {
            if (zu = !1, ju = 0, 25 <= m) throw Error(l(301));
            m += 1, Or = gr = null, o.updateQueue = null, cf.current = S6, n = u(c, f);
          } while (zu);
        }
        if (cf.current = mf, o = gr !== null && gr.next !== null, Wi = 0, Or = gr = Ze = null, ff = !1, o) throw Error(l(300));
        return n;
      }
      function Zh() {
        var n = ju !== 0;
        return ju = 0, n;
      }
      function jn() {
        var n = {
          memoizedState: null,
          baseState: null,
          baseQueue: null,
          queue: null,
          next: null
        };
        return Or === null ? Ze.memoizedState = Or = n : Or = Or.next = n, Or;
      }
      function Xt() {
        if (gr === null) {
          var n = Ze.alternate;
          n = n !== null ? n.memoizedState : null;
        } else n = gr.next;
        var o = Or === null ? Ze.memoizedState : Or.next;
        if (o !== null) Or = o, gr = n;else {
          if (n === null) throw Error(l(310));
          gr = n, n = {
            memoizedState: gr.memoizedState,
            baseState: gr.baseState,
            baseQueue: gr.baseQueue,
            queue: gr.queue,
            next: null
          }, Or === null ? Ze.memoizedState = Or = n : Or = Or.next = n;
        }
        return Or;
      }
      function Uu(n, o) {
        return typeof o == "function" ? o(n) : o;
      }
      function ev(n) {
        var o = Xt(),
          u = o.queue;
        if (u === null) throw Error(l(311));
        u.lastRenderedReducer = n;
        var c = gr,
          f = c.baseQueue,
          m = u.pending;
        if (m !== null) {
          if (f !== null) {
            var y = f.next;
            f.next = m.next, m.next = y;
          }
          c.baseQueue = f = m, u.pending = null;
        }
        if (f !== null) {
          m = f.next, c = c.baseState;
          var I = y = null,
            A = null,
            z = m;
          do {
            var G = z.lane;
            if ((Wi & G) === G) A !== null && (A = A.next = {
              lane: 0,
              action: z.action,
              hasEagerState: z.hasEagerState,
              eagerState: z.eagerState,
              next: null
            }), c = z.hasEagerState ? z.eagerState : n(c, z.action);else {
              var ce = {
                lane: G,
                action: z.action,
                hasEagerState: z.hasEagerState,
                eagerState: z.eagerState,
                next: null
              };
              A === null ? (I = A = ce, y = c) : A = A.next = ce, Ze.lanes |= G, Gi |= G;
            }
            z = z.next;
          } while (z !== null && z !== m);
          A === null ? y = c : A.next = I, yn(c, o.memoizedState) || (ht = !0), o.memoizedState = c, o.baseState = y, o.baseQueue = A, u.lastRenderedState = c;
        }
        if (n = u.interleaved, n !== null) {
          f = n;
          do m = f.lane, Ze.lanes |= m, Gi |= m, f = f.next; while (f !== n);
        } else f === null && (u.lanes = 0);
        return [o.memoizedState, u.dispatch];
      }
      function rv(n) {
        var o = Xt(),
          u = o.queue;
        if (u === null) throw Error(l(311));
        u.lastRenderedReducer = n;
        var c = u.dispatch,
          f = u.pending,
          m = o.memoizedState;
        if (f !== null) {
          u.pending = null;
          var y = f = f.next;
          do m = n(m, y.action), y = y.next; while (y !== f);
          yn(m, o.memoizedState) || (ht = !0), o.memoizedState = m, o.baseQueue === null && (o.baseState = m), u.lastRenderedState = m;
        }
        return [m, c];
      }
      function yw() {}
      function xw(n, o) {
        var u = Ze,
          c = Xt(),
          f = o(),
          m = !yn(c.memoizedState, f);
        if (m && (c.memoizedState = f, ht = !0), c = c.queue, tv(ww.bind(null, u, c, n), [n]), c.getSnapshot !== o || m || Or !== null && Or.memoizedState.tag & 1) {
          if (u.flags |= 2048, Hu(9, bw.bind(null, u, c, f, o), void 0, null), Ar === null) throw Error(l(349));
          Wi & 30 || Sw(u, o, f);
        }
        return f;
      }
      function Sw(n, o, u) {
        n.flags |= 16384, n = {
          getSnapshot: o,
          value: u
        }, o = Ze.updateQueue, o === null ? (o = {
          lastEffect: null,
          stores: null
        }, Ze.updateQueue = o, o.stores = [n]) : (u = o.stores, u === null ? o.stores = [n] : u.push(n));
      }
      function bw(n, o, u, c) {
        o.value = u, o.getSnapshot = c, Ew(o) && Cw(n);
      }
      function ww(n, o, u) {
        return u(function () {
          Ew(o) && Cw(n);
        });
      }
      function Ew(n) {
        var o = n.getSnapshot;
        n = n.value;
        try {
          var u = o();
          return !yn(n, u);
        } catch (_unused55) {
          return !0;
        }
      }
      function Cw(n) {
        var o = Ln(n, 1);
        o !== null && Qt(o, n, 1, -1);
      }
      function Iw(n) {
        var o = jn();
        return typeof n == "function" && (n = n()), o.memoizedState = o.baseState = n, n = {
          pending: null,
          interleaved: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: Uu,
          lastRenderedState: n
        }, o.queue = n, n = n.dispatch = g6.bind(null, Ze, n), [o.memoizedState, n];
      }
      function Hu(n, o, u, c) {
        return n = {
          tag: n,
          create: o,
          destroy: u,
          deps: c,
          next: null
        }, o = Ze.updateQueue, o === null ? (o = {
          lastEffect: null,
          stores: null
        }, Ze.updateQueue = o, o.lastEffect = n.next = n) : (u = o.lastEffect, u === null ? o.lastEffect = n.next = n : (c = u.next, u.next = n, n.next = c, o.lastEffect = n)), n;
      }
      function Pw() {
        return Xt().memoizedState;
      }
      function pf(n, o, u, c) {
        var f = jn();
        Ze.flags |= n, f.memoizedState = Hu(1 | o, u, void 0, c === void 0 ? null : c);
      }
      function df(n, o, u, c) {
        var f = Xt();
        c = c === void 0 ? null : c;
        var m = void 0;
        if (gr !== null) {
          var y = gr.memoizedState;
          if (m = y.destroy, c !== null && Qh(c, y.deps)) {
            f.memoizedState = Hu(o, u, m, c);
            return;
          }
        }
        Ze.flags |= n, f.memoizedState = Hu(1 | o, u, m, c);
      }
      function qw(n, o) {
        return pf(8390656, 8, n, o);
      }
      function tv(n, o) {
        return df(2048, 8, n, o);
      }
      function Tw(n, o) {
        return df(4, 2, n, o);
      }
      function Ow(n, o) {
        return df(4, 4, n, o);
      }
      function Aw(n, o) {
        if (typeof o == "function") return n = n(), o(n), function () {
          o(null);
        };
        if (o != null) return n = n(), o.current = n, function () {
          o.current = null;
        };
      }
      function _w(n, o, u) {
        return u = u != null ? u.concat([n]) : null, df(4, 4, Aw.bind(null, o, n), u);
      }
      function nv() {}
      function Nw(n, o) {
        var u = Xt();
        o = o === void 0 ? null : o;
        var c = u.memoizedState;
        return c !== null && o !== null && Qh(o, c[1]) ? c[0] : (u.memoizedState = [n, o], n);
      }
      function Rw(n, o) {
        var u = Xt();
        o = o === void 0 ? null : o;
        var c = u.memoizedState;
        return c !== null && o !== null && Qh(o, c[1]) ? c[0] : (n = n(), u.memoizedState = [n, o], n);
      }
      function Mw(n, o, u) {
        return Wi & 21 ? (yn(u, o) || (u = ew(), Ze.lanes |= u, Gi |= u, n.baseState = !0), o) : (n.baseState && (n.baseState = !1, ht = !0), n.memoizedState = u);
      }
      function h6(n, o) {
        var u = Pe;
        Pe = u !== 0 && 4 > u ? u : 4, n(!0);
        var c = Xh.transition;
        Xh.transition = {};
        try {
          n(!1), o();
        } finally {
          Pe = u, Xh.transition = c;
        }
      }
      function kw() {
        return Xt().memoizedState;
      }
      function v6(n, o, u) {
        var c = $o(n);
        if (u = {
          lane: c,
          action: u,
          hasEagerState: !1,
          eagerState: null,
          next: null
        }, Dw(n)) Bw(o, u);else if (u = dw(n, o, u, c), u !== null) {
          var f = Yr();
          Qt(u, n, c, f), Fw(u, o, c);
        }
      }
      function g6(n, o, u) {
        var c = $o(n),
          f = {
            lane: c,
            action: u,
            hasEagerState: !1,
            eagerState: null,
            next: null
          };
        if (Dw(n)) Bw(o, f);else {
          var m = n.alternate;
          if (n.lanes === 0 && (m === null || m.lanes === 0) && (m = o.lastRenderedReducer, m !== null)) try {
            var y = o.lastRenderedState,
              I = m(y, u);
            if (f.hasEagerState = !0, f.eagerState = I, yn(I, y)) {
              var A = o.interleaved;
              A === null ? (f.next = f, $h(o)) : (f.next = A.next, A.next = f), o.interleaved = f;
              return;
            }
          } catch (_unused56) {} finally {}
          u = dw(n, o, f, c), u !== null && (f = Yr(), Qt(u, n, c, f), Fw(u, o, c));
        }
      }
      function Dw(n) {
        var o = n.alternate;
        return n === Ze || o !== null && o === Ze;
      }
      function Bw(n, o) {
        zu = ff = !0;
        var u = n.pending;
        u === null ? o.next = o : (o.next = u.next, u.next = o), n.pending = o;
      }
      function Fw(n, o, u) {
        if (u & 4194240) {
          var c = o.lanes;
          c &= n.pendingLanes, u |= c, o.lanes = u, Ah(n, u);
        }
      }
      var mf = {
          readContext: Kt,
          useCallback: Wr,
          useContext: Wr,
          useEffect: Wr,
          useImperativeHandle: Wr,
          useInsertionEffect: Wr,
          useLayoutEffect: Wr,
          useMemo: Wr,
          useReducer: Wr,
          useRef: Wr,
          useState: Wr,
          useDebugValue: Wr,
          useDeferredValue: Wr,
          useTransition: Wr,
          useMutableSource: Wr,
          useSyncExternalStore: Wr,
          useId: Wr,
          unstable_isNewReconciler: !1
        },
        y6 = {
          readContext: Kt,
          useCallback: function useCallback(n, o) {
            return jn().memoizedState = [n, o === void 0 ? null : o], n;
          },
          useContext: Kt,
          useEffect: qw,
          useImperativeHandle: function useImperativeHandle(n, o, u) {
            return u = u != null ? u.concat([n]) : null, pf(4194308, 4, Aw.bind(null, o, n), u);
          },
          useLayoutEffect: function useLayoutEffect(n, o) {
            return pf(4194308, 4, n, o);
          },
          useInsertionEffect: function useInsertionEffect(n, o) {
            return pf(4, 2, n, o);
          },
          useMemo: function useMemo(n, o) {
            var u = jn();
            return o = o === void 0 ? null : o, n = n(), u.memoizedState = [n, o], n;
          },
          useReducer: function useReducer(n, o, u) {
            var c = jn();
            return o = u !== void 0 ? u(o) : o, c.memoizedState = c.baseState = o, n = {
              pending: null,
              interleaved: null,
              lanes: 0,
              dispatch: null,
              lastRenderedReducer: n,
              lastRenderedState: o
            }, c.queue = n, n = n.dispatch = v6.bind(null, Ze, n), [c.memoizedState, n];
          },
          useRef: function useRef(n) {
            var o = jn();
            return n = {
              current: n
            }, o.memoizedState = n;
          },
          useState: Iw,
          useDebugValue: nv,
          useDeferredValue: function useDeferredValue(n) {
            return jn().memoizedState = n;
          },
          useTransition: function useTransition() {
            var n = Iw(!1),
              o = n[0];
            return n = h6.bind(null, n[1]), jn().memoizedState = n, [o, n];
          },
          useMutableSource: function useMutableSource() {},
          useSyncExternalStore: function useSyncExternalStore(n, o, u) {
            var c = Ze,
              f = jn();
            if (Ke) {
              if (u === void 0) throw Error(l(407));
              u = u();
            } else {
              if (u = o(), Ar === null) throw Error(l(349));
              Wi & 30 || Sw(c, o, u);
            }
            f.memoizedState = u;
            var m = {
              value: u,
              getSnapshot: o
            };
            return f.queue = m, qw(ww.bind(null, c, m, n), [n]), c.flags |= 2048, Hu(9, bw.bind(null, c, m, u, o), void 0, null), u;
          },
          useId: function useId() {
            var n = jn(),
              o = Ar.identifierPrefix;
            if (Ke) {
              var u = co,
                c = lo;
              u = (c & ~(1 << 32 - gn(c) - 1)).toString(32) + u, o = ":" + o + "R" + u, u = ju++, 0 < u && (o += "H" + u.toString(32)), o += ":";
            } else u = m6++, o = ":" + o + "r" + u.toString(32) + ":";
            return n.memoizedState = o;
          },
          unstable_isNewReconciler: !1
        },
        x6 = {
          readContext: Kt,
          useCallback: Nw,
          useContext: Kt,
          useEffect: tv,
          useImperativeHandle: _w,
          useInsertionEffect: Tw,
          useLayoutEffect: Ow,
          useMemo: Rw,
          useReducer: ev,
          useRef: Pw,
          useState: function useState() {
            return ev(Uu);
          },
          useDebugValue: nv,
          useDeferredValue: function useDeferredValue(n) {
            var o = Xt();
            return Mw(o, gr.memoizedState, n);
          },
          useTransition: function useTransition() {
            var n = ev(Uu)[0],
              o = Xt().memoizedState;
            return [n, o];
          },
          useMutableSource: yw,
          useSyncExternalStore: xw,
          useId: kw,
          unstable_isNewReconciler: !1
        },
        S6 = {
          readContext: Kt,
          useCallback: Nw,
          useContext: Kt,
          useEffect: tv,
          useImperativeHandle: _w,
          useInsertionEffect: Tw,
          useLayoutEffect: Ow,
          useMemo: Rw,
          useReducer: rv,
          useRef: Pw,
          useState: function useState() {
            return rv(Uu);
          },
          useDebugValue: nv,
          useDeferredValue: function useDeferredValue(n) {
            var o = Xt();
            return gr === null ? o.memoizedState = n : Mw(o, gr.memoizedState, n);
          },
          useTransition: function useTransition() {
            var n = rv(Uu)[0],
              o = Xt().memoizedState;
            return [n, o];
          },
          useMutableSource: yw,
          useSyncExternalStore: xw,
          useId: kw,
          unstable_isNewReconciler: !1
        };
      function Sn(n, o) {
        if (n && n.defaultProps) {
          o = s({}, o), n = n.defaultProps;
          for (var u in n) o[u] === void 0 && (o[u] = n[u]);
          return o;
        }
        return o;
      }
      function ov(n, o, u, c) {
        o = n.memoizedState, u = u(c, o), u = u == null ? o : s({}, o, u), n.memoizedState = u, n.lanes === 0 && (n.updateQueue.baseState = u);
      }
      var hf = {
        isMounted: function isMounted(n) {
          return (n = n._reactInternals) ? U(n) === n : !1;
        },
        enqueueSetState: function enqueueSetState(n, o, u) {
          n = n._reactInternals;
          var c = Yr(),
            f = $o(n),
            m = fo(c, f);
          m.payload = o, u != null && (m.callback = u), o = jo(n, m, f), o !== null && (Qt(o, n, f, c), sf(o, n, f));
        },
        enqueueReplaceState: function enqueueReplaceState(n, o, u) {
          n = n._reactInternals;
          var c = Yr(),
            f = $o(n),
            m = fo(c, f);
          m.tag = 1, m.payload = o, u != null && (m.callback = u), o = jo(n, m, f), o !== null && (Qt(o, n, f, c), sf(o, n, f));
        },
        enqueueForceUpdate: function enqueueForceUpdate(n, o) {
          n = n._reactInternals;
          var u = Yr(),
            c = $o(n),
            f = fo(u, c);
          f.tag = 2, o != null && (f.callback = o), o = jo(n, f, c), o !== null && (Qt(o, n, c, u), sf(o, n, c));
        }
      };
      function Lw(n, o, u, c, f, m, y) {
        return n = n.stateNode, typeof n.shouldComponentUpdate == "function" ? n.shouldComponentUpdate(c, m, y) : o.prototype && o.prototype.isPureReactComponent ? !tf(u, c) || !tf(f, m) : !0;
      }
      function zw(n, o, u) {
        var c = !1,
          f = Lo,
          m = o.contextType;
        return _typeof(m) == "object" && m !== null ? m = Kt(m) : (f = mt(o) ? Ui : Vr.current, c = o.contextTypes, m = (c = c != null) ? Ha(n, f) : Lo), o = new o(u, m), n.memoizedState = o.state !== null && o.state !== void 0 ? o.state : null, o.updater = hf, n.stateNode = o, o._reactInternals = n, c && (n = n.stateNode, n.__reactInternalMemoizedUnmaskedChildContext = f, n.__reactInternalMemoizedMaskedChildContext = m), o;
      }
      function jw(n, o, u, c) {
        n = o.state, typeof o.componentWillReceiveProps == "function" && o.componentWillReceiveProps(u, c), typeof o.UNSAFE_componentWillReceiveProps == "function" && o.UNSAFE_componentWillReceiveProps(u, c), o.state !== n && hf.enqueueReplaceState(o, o.state, null);
      }
      function iv(n, o, u, c) {
        var f = n.stateNode;
        f.props = u, f.state = n.memoizedState, f.refs = {}, Vh(n);
        var m = o.contextType;
        _typeof(m) == "object" && m !== null ? f.context = Kt(m) : (m = mt(o) ? Ui : Vr.current, f.context = Ha(n, m)), f.state = n.memoizedState, m = o.getDerivedStateFromProps, typeof m == "function" && (ov(n, o, m, u), f.state = n.memoizedState), typeof o.getDerivedStateFromProps == "function" || typeof f.getSnapshotBeforeUpdate == "function" || typeof f.UNSAFE_componentWillMount != "function" && typeof f.componentWillMount != "function" || (o = f.state, typeof f.componentWillMount == "function" && f.componentWillMount(), typeof f.UNSAFE_componentWillMount == "function" && f.UNSAFE_componentWillMount(), o !== f.state && hf.enqueueReplaceState(f, f.state, null), uf(n, u, f, c), f.state = n.memoizedState), typeof f.componentDidMount == "function" && (n.flags |= 4194308);
      }
      function Ja(n, o) {
        try {
          var u = "",
            c = o;
          do u += d6(c), c = c.return; while (c);
          var f = u;
        } catch (m) {
          f = "\nError generating stack: " + m.message + "\n" + m.stack;
        }
        return {
          value: n,
          source: o,
          stack: f,
          digest: null
        };
      }
      function av(n, o, u) {
        return {
          value: n,
          source: null,
          stack: u !== null && u !== void 0 ? u : null,
          digest: o !== null && o !== void 0 ? o : null
        };
      }
      function sv(n, o) {
        try {
          console.error(o.value);
        } catch (u) {
          setTimeout(function () {
            throw u;
          });
        }
      }
      var b6 = typeof WeakMap == "function" ? WeakMap : Map;
      function Uw(n, o, u) {
        u = fo(-1, u), u.tag = 3, u.payload = {
          element: null
        };
        var c = o.value;
        return u.callback = function () {
          Of || (Of = !0, qv = c), sv(n, o);
        }, u;
      }
      function Hw(n, o, u) {
        u = fo(-1, u), u.tag = 3;
        var c = n.type.getDerivedStateFromError;
        if (typeof c == "function") {
          var f = o.value;
          u.payload = function () {
            return c(f);
          }, u.callback = function () {
            sv(n, o);
          };
        }
        var m = n.stateNode;
        return m !== null && typeof m.componentDidCatch == "function" && (u.callback = function () {
          sv(n, o), typeof c != "function" && (Uo === null ? Uo = new Set([this]) : Uo.add(this));
          var y = o.stack;
          this.componentDidCatch(o.value, {
            componentStack: y !== null ? y : ""
          });
        }), u;
      }
      function $w(n, o, u) {
        var c = n.pingCache;
        if (c === null) {
          c = n.pingCache = new b6();
          var f = new Set();
          c.set(o, f);
        } else f = c.get(o), f === void 0 && (f = new Set(), c.set(o, f));
        f.has(u) || (f.add(u), n = k6.bind(null, n, o, u), o.then(n, n));
      }
      function Vw(n) {
        do {
          var o;
          if ((o = n.tag === 13) && (o = n.memoizedState, o = o !== null ? o.dehydrated !== null : !0), o) return n;
          n = n.return;
        } while (n !== null);
        return null;
      }
      function Ww(n, o, u, c, f) {
        return n.mode & 1 ? (n.flags |= 65536, n.lanes = f, n) : (n === o ? n.flags |= 65536 : (n.flags |= 128, u.flags |= 131072, u.flags &= -52805, u.tag === 1 && (u.alternate === null ? u.tag = 17 : (o = fo(-1, 1), o.tag = 2, jo(u, o, 1))), u.lanes |= 1), n);
      }
      var w6 = p.ReactCurrentOwner,
        ht = !1;
      function nt(n, o, u, c) {
        o.child = n === null ? fw(o, null, u, c) : Ga(o, n.child, u, c);
      }
      function Gw(n, o, u, c, f) {
        u = u.render;
        var m = o.ref;
        return Ya(o, f), c = Jh(n, o, u, c, m, f), u = Zh(), n !== null && !ht ? (o.updateQueue = n.updateQueue, o.flags &= -2053, n.lanes &= ~f, po(n, o, f)) : (Ke && u && kh(o), o.flags |= 1, nt(n, o, c, f), o.child);
      }
      function Kw(n, o, u, c, f) {
        if (n === null) {
          var m = u.type;
          return typeof m == "function" && !Rv(m) && m.defaultProps === void 0 && u.compare === null && u.defaultProps === void 0 ? (o.tag = 15, o.type = m, Yw(n, o, m, c, f)) : (n = kf(u.type, null, c, o, o.mode, f), n.ref = o.ref, n.return = o, o.child = n);
        }
        if (m = n.child, !(n.lanes & f)) {
          var y = m.memoizedProps;
          if (u = u.compare, u = u !== null ? u : tf, u(y, c) && n.ref === o.ref) return po(n, o, f);
        }
        return o.flags |= 1, n = Wo(m, c), n.ref = o.ref, n.return = o, o.child = n;
      }
      function Yw(n, o, u, c, f) {
        if (n !== null) {
          var m = n.memoizedProps;
          if (tf(m, c) && n.ref === o.ref) if (ht = !1, o.pendingProps = c = m, (n.lanes & f) !== 0) n.flags & 131072 && (ht = !0);else return o.lanes = n.lanes, po(n, o, f);
        }
        return uv(n, o, u, c, f);
      }
      function Xw(n, o, u) {
        var c = o.pendingProps,
          f = c.children,
          m = n !== null ? n.memoizedState : null;
        if (c.mode === "hidden") {
          if (!(o.mode & 1)) o.memoizedState = {
            baseLanes: 0,
            cachePool: null,
            transitions: null
          }, De(es, kt), kt |= u;else {
            if (!(u & 1073741824)) return n = m !== null ? m.baseLanes | u : u, o.lanes = o.childLanes = 1073741824, o.memoizedState = {
              baseLanes: n,
              cachePool: null,
              transitions: null
            }, o.updateQueue = null, De(es, kt), kt |= n, null;
            o.memoizedState = {
              baseLanes: 0,
              cachePool: null,
              transitions: null
            }, c = m !== null ? m.baseLanes : u, De(es, kt), kt |= c;
          }
        } else m !== null ? (c = m.baseLanes | u, o.memoizedState = null) : c = u, De(es, kt), kt |= c;
        return nt(n, o, f, u), o.child;
      }
      function Qw(n, o) {
        var u = o.ref;
        (n === null && u !== null || n !== null && n.ref !== u) && (o.flags |= 512, o.flags |= 2097152);
      }
      function uv(n, o, u, c, f) {
        var m = mt(u) ? Ui : Vr.current;
        return m = Ha(o, m), Ya(o, f), u = Jh(n, o, u, c, m, f), c = Zh(), n !== null && !ht ? (o.updateQueue = n.updateQueue, o.flags &= -2053, n.lanes &= ~f, po(n, o, f)) : (Ke && c && kh(o), o.flags |= 1, nt(n, o, u, f), o.child);
      }
      function Jw(n, o, u, c, f) {
        if (mt(u)) {
          var m = !0;
          Gc(o);
        } else m = !1;
        if (Ya(o, f), o.stateNode === null) gf(n, o), zw(o, u, c), iv(o, u, c, f), c = !0;else if (n === null) {
          var y = o.stateNode,
            I = o.memoizedProps;
          y.props = I;
          var A = y.context,
            z = u.contextType;
          _typeof(z) == "object" && z !== null ? z = Kt(z) : (z = mt(u) ? Ui : Vr.current, z = Ha(o, z));
          var G = u.getDerivedStateFromProps,
            ce = typeof G == "function" || typeof y.getSnapshotBeforeUpdate == "function";
          ce || typeof y.UNSAFE_componentWillReceiveProps != "function" && typeof y.componentWillReceiveProps != "function" || (I !== c || A !== z) && jw(o, y, c, z), zo = !1;
          var H = o.memoizedState;
          y.state = H, uf(o, c, y, f), A = o.memoizedState, I !== c || H !== A || dt.current || zo ? (typeof G == "function" && (ov(o, u, G, c), A = o.memoizedState), (I = zo || Lw(o, u, I, c, H, A, z)) ? (ce || typeof y.UNSAFE_componentWillMount != "function" && typeof y.componentWillMount != "function" || (typeof y.componentWillMount == "function" && y.componentWillMount(), typeof y.UNSAFE_componentWillMount == "function" && y.UNSAFE_componentWillMount()), typeof y.componentDidMount == "function" && (o.flags |= 4194308)) : (typeof y.componentDidMount == "function" && (o.flags |= 4194308), o.memoizedProps = c, o.memoizedState = A), y.props = c, y.state = A, y.context = z, c = I) : (typeof y.componentDidMount == "function" && (o.flags |= 4194308), c = !1);
        } else {
          y = o.stateNode, mw(n, o), I = o.memoizedProps, z = o.type === o.elementType ? I : Sn(o.type, I), y.props = z, ce = o.pendingProps, H = y.context, A = u.contextType, _typeof(A) == "object" && A !== null ? A = Kt(A) : (A = mt(u) ? Ui : Vr.current, A = Ha(o, A));
          var je = u.getDerivedStateFromProps;
          (G = typeof je == "function" || typeof y.getSnapshotBeforeUpdate == "function") || typeof y.UNSAFE_componentWillReceiveProps != "function" && typeof y.componentWillReceiveProps != "function" || (I !== ce || H !== A) && jw(o, y, c, A), zo = !1, H = o.memoizedState, y.state = H, uf(o, c, y, f);
          var ke = o.memoizedState;
          I !== ce || H !== ke || dt.current || zo ? (typeof je == "function" && (ov(o, u, je, c), ke = o.memoizedState), (z = zo || Lw(o, u, z, c, H, ke, A) || !1) ? (G || typeof y.UNSAFE_componentWillUpdate != "function" && typeof y.componentWillUpdate != "function" || (typeof y.componentWillUpdate == "function" && y.componentWillUpdate(c, ke, A), typeof y.UNSAFE_componentWillUpdate == "function" && y.UNSAFE_componentWillUpdate(c, ke, A)), typeof y.componentDidUpdate == "function" && (o.flags |= 4), typeof y.getSnapshotBeforeUpdate == "function" && (o.flags |= 1024)) : (typeof y.componentDidUpdate != "function" || I === n.memoizedProps && H === n.memoizedState || (o.flags |= 4), typeof y.getSnapshotBeforeUpdate != "function" || I === n.memoizedProps && H === n.memoizedState || (o.flags |= 1024), o.memoizedProps = c, o.memoizedState = ke), y.props = c, y.state = ke, y.context = A, c = z) : (typeof y.componentDidUpdate != "function" || I === n.memoizedProps && H === n.memoizedState || (o.flags |= 4), typeof y.getSnapshotBeforeUpdate != "function" || I === n.memoizedProps && H === n.memoizedState || (o.flags |= 1024), c = !1);
        }
        return lv(n, o, u, c, m, f);
      }
      function lv(n, o, u, c, f, m) {
        Qw(n, o);
        var y = (o.flags & 128) !== 0;
        if (!c && !y) return f && Zb(o, u, !1), po(n, o, m);
        c = o.stateNode, w6.current = o;
        var I = y && typeof u.getDerivedStateFromError != "function" ? null : c.render();
        return o.flags |= 1, n !== null && y ? (o.child = Ga(o, n.child, null, m), o.child = Ga(o, null, I, m)) : nt(n, o, I, m), o.memoizedState = c.state, f && Zb(o, u, !0), o.child;
      }
      function Zw(n) {
        var o = n.stateNode;
        o.pendingContext ? Qb(n, o.pendingContext, o.pendingContext !== o.context) : o.context && Qb(n, o.context, !1), Wh(n, o.containerInfo);
      }
      function eE(n, o, u, c, f) {
        return Wa(), Lh(f), o.flags |= 256, nt(n, o, u, c), o.child;
      }
      var cv = {
        dehydrated: null,
        treeContext: null,
        retryLane: 0
      };
      function fv(n) {
        return {
          baseLanes: n,
          cachePool: null,
          transitions: null
        };
      }
      function rE(n, o, u) {
        var c = o.pendingProps,
          f = Je.current,
          m = !1,
          y = (o.flags & 128) !== 0,
          I;
        if ((I = y) || (I = n !== null && n.memoizedState === null ? !1 : (f & 2) !== 0), I ? (m = !0, o.flags &= -129) : (n === null || n.memoizedState !== null) && (f |= 1), De(Je, f & 1), n === null) return Fh(o), n = o.memoizedState, n !== null && (n = n.dehydrated, n !== null) ? (o.mode & 1 ? Eh(n) ? o.lanes = 8 : o.lanes = 1073741824 : o.lanes = 1, null) : (y = c.children, n = c.fallback, m ? (c = o.mode, m = o.child, y = {
          mode: "hidden",
          children: y
        }, !(c & 1) && m !== null ? (m.childLanes = 0, m.pendingProps = y) : m = Df(y, c, 0, null), n = Qi(n, c, u, null), m.return = o, n.return = o, m.sibling = n, o.child = m, o.child.memoizedState = fv(u), o.memoizedState = cv, n) : pv(o, y));
        if (f = n.memoizedState, f !== null && (I = f.dehydrated, I !== null)) return E6(n, o, y, c, I, f, u);
        if (m) {
          m = c.fallback, y = o.mode, f = n.child, I = f.sibling;
          var A = {
            mode: "hidden",
            children: c.children
          };
          return !(y & 1) && o.child !== f ? (c = o.child, c.childLanes = 0, c.pendingProps = A, o.deletions = null) : (c = Wo(f, A), c.subtreeFlags = f.subtreeFlags & 14680064), I !== null ? m = Wo(I, m) : (m = Qi(m, y, u, null), m.flags |= 2), m.return = o, c.return = o, c.sibling = m, o.child = c, c = m, m = o.child, y = n.child.memoizedState, y = y === null ? fv(u) : {
            baseLanes: y.baseLanes | u,
            cachePool: null,
            transitions: y.transitions
          }, m.memoizedState = y, m.childLanes = n.childLanes & ~u, o.memoizedState = cv, c;
        }
        return m = n.child, n = m.sibling, c = Wo(m, {
          mode: "visible",
          children: c.children
        }), !(o.mode & 1) && (c.lanes = u), c.return = o, c.sibling = null, n !== null && (u = o.deletions, u === null ? (o.deletions = [n], o.flags |= 16) : u.push(n)), o.child = c, o.memoizedState = null, c;
      }
      function pv(n, o) {
        return o = Df({
          mode: "visible",
          children: o
        }, n.mode, 0, null), o.return = n, n.child = o;
      }
      function vf(n, o, u, c) {
        return c !== null && Lh(c), Ga(o, n.child, null, u), n = pv(o, o.pendingProps.children), n.flags |= 2, o.memoizedState = null, n;
      }
      function E6(n, o, u, c, f, m, y) {
        if (u) return o.flags & 256 ? (o.flags &= -257, c = av(Error(l(422))), vf(n, o, y, c)) : o.memoizedState !== null ? (o.child = n.child, o.flags |= 128, null) : (m = c.fallback, f = o.mode, c = Df({
          mode: "visible",
          children: c.children
        }, f, 0, null), m = Qi(m, f, y, null), m.flags |= 2, c.return = o, m.return = o, c.sibling = m, o.child = c, o.mode & 1 && Ga(o, n.child, null, y), o.child.memoizedState = fv(y), o.memoizedState = cv, m);
        if (!(o.mode & 1)) return vf(n, o, y, null);
        if (Eh(f)) return c = D3(f).digest, m = Error(l(419)), c = av(m, c, void 0), vf(n, o, y, c);
        if (u = (y & n.childLanes) !== 0, ht || u) {
          if (c = Ar, c !== null) {
            switch (y & -y) {
              case 4:
                f = 2;
                break;
              case 16:
                f = 8;
                break;
              case 64:
              case 128:
              case 256:
              case 512:
              case 1024:
              case 2048:
              case 4096:
              case 8192:
              case 16384:
              case 32768:
              case 65536:
              case 131072:
              case 262144:
              case 524288:
              case 1048576:
              case 2097152:
              case 4194304:
              case 8388608:
              case 16777216:
              case 33554432:
              case 67108864:
                f = 32;
                break;
              case 536870912:
                f = 268435456;
                break;
              default:
                f = 0;
            }
            f = f & (c.suspendedLanes | y) ? 0 : f, f !== 0 && f !== m.retryLane && (m.retryLane = f, Ln(n, f), Qt(c, n, f, -1));
          }
          return Nv(), c = av(Error(l(421))), vf(n, o, y, c);
        }
        return Xb(f) ? (o.flags |= 128, o.child = n.child, o = D6.bind(null, n), B3(f, o), null) : (n = m.treeContext, $t && (Gt = z3(f), Mt = o, Ke = !0, xn = null, Du = !1, n !== null && (Vt[Wt++] = lo, Vt[Wt++] = co, Vt[Wt++] = Hi, lo = n.id, co = n.overflow, Hi = o)), o = pv(o, c.children), o.flags |= 4096, o);
      }
      function tE(n, o, u) {
        n.lanes |= o;
        var c = n.alternate;
        c !== null && (c.lanes |= o), Hh(n.return, o, u);
      }
      function dv(n, o, u, c, f) {
        var m = n.memoizedState;
        m === null ? n.memoizedState = {
          isBackwards: o,
          rendering: null,
          renderingStartTime: 0,
          last: c,
          tail: u,
          tailMode: f
        } : (m.isBackwards = o, m.rendering = null, m.renderingStartTime = 0, m.last = c, m.tail = u, m.tailMode = f);
      }
      function nE(n, o, u) {
        var c = o.pendingProps,
          f = c.revealOrder,
          m = c.tail;
        if (nt(n, o, c.children, u), c = Je.current, c & 2) c = c & 1 | 2, o.flags |= 128;else {
          if (n !== null && n.flags & 128) e: for (n = o.child; n !== null;) {
            if (n.tag === 13) n.memoizedState !== null && tE(n, u, o);else if (n.tag === 19) tE(n, u, o);else if (n.child !== null) {
              n.child.return = n, n = n.child;
              continue;
            }
            if (n === o) break e;
            for (; n.sibling === null;) {
              if (n.return === null || n.return === o) break e;
              n = n.return;
            }
            n.sibling.return = n.return, n = n.sibling;
          }
          c &= 1;
        }
        if (De(Je, c), !(o.mode & 1)) o.memoizedState = null;else switch (f) {
          case "forwards":
            for (u = o.child, f = null; u !== null;) n = u.alternate, n !== null && lf(n) === null && (f = u), u = u.sibling;
            u = f, u === null ? (f = o.child, o.child = null) : (f = u.sibling, u.sibling = null), dv(o, !1, f, u, m);
            break;
          case "backwards":
            for (u = null, f = o.child, o.child = null; f !== null;) {
              if (n = f.alternate, n !== null && lf(n) === null) {
                o.child = f;
                break;
              }
              n = f.sibling, f.sibling = u, u = f, f = n;
            }
            dv(o, !0, u, null, m);
            break;
          case "together":
            dv(o, !1, null, null, void 0);
            break;
          default:
            o.memoizedState = null;
        }
        return o.child;
      }
      function gf(n, o) {
        !(o.mode & 1) && n !== null && (n.alternate = null, o.alternate = null, o.flags |= 2);
      }
      function po(n, o, u) {
        if (n !== null && (o.dependencies = n.dependencies), Gi |= o.lanes, !(u & o.childLanes)) return null;
        if (n !== null && o.child !== n.child) throw Error(l(153));
        if (o.child !== null) {
          for (n = o.child, u = Wo(n, n.pendingProps), o.child = u, u.return = o; n.sibling !== null;) n = n.sibling, u = u.sibling = Wo(n, n.pendingProps), u.return = o;
          u.sibling = null;
        }
        return o.child;
      }
      function C6(n, o, u) {
        switch (o.tag) {
          case 3:
            Zw(o), Wa();
            break;
          case 5:
            gw(o);
            break;
          case 1:
            mt(o.type) && Gc(o);
            break;
          case 4:
            Wh(o, o.stateNode.containerInfo);
            break;
          case 10:
            pw(o, o.type._context, o.memoizedProps.value);
            break;
          case 13:
            var c = o.memoizedState;
            if (c !== null) return c.dehydrated !== null ? (De(Je, Je.current & 1), o.flags |= 128, null) : u & o.child.childLanes ? rE(n, o, u) : (De(Je, Je.current & 1), n = po(n, o, u), n !== null ? n.sibling : null);
            De(Je, Je.current & 1);
            break;
          case 19:
            if (c = (u & o.childLanes) !== 0, n.flags & 128) {
              if (c) return nE(n, o, u);
              o.flags |= 128;
            }
            var f = o.memoizedState;
            if (f !== null && (f.rendering = null, f.tail = null, f.lastEffect = null), De(Je, Je.current), c) break;
            return null;
          case 22:
          case 23:
            return o.lanes = 0, Xw(n, o, u);
        }
        return po(n, o, u);
      }
      function Un(n) {
        n.flags |= 4;
      }
      function oE(n, o) {
        if (n !== null && n.child === o.child) return !0;
        if (o.flags & 16) return !1;
        for (n = o.child; n !== null;) {
          if (n.flags & 12854 || n.subtreeFlags & 12854) return !1;
          n = n.sibling;
        }
        return !0;
      }
      var _$u, Vu, yf, xf;
      if (Rt) _$u = function $u(n, o) {
        for (var u = o.child; u !== null;) {
          if (u.tag === 5 || u.tag === 6) ue(n, u.stateNode);else if (u.tag !== 4 && u.child !== null) {
            u.child.return = u, u = u.child;
            continue;
          }
          if (u === o) break;
          for (; u.sibling === null;) {
            if (u.return === null || u.return === o) return;
            u = u.return;
          }
          u.sibling.return = u.return, u = u.sibling;
        }
      }, Vu = function Vu() {}, yf = function yf(n, o, u, c, f) {
        if (n = n.memoizedProps, n !== c) {
          var m = o.stateNode,
            y = zn(Yt.current);
          u = X(m, u, n, c, f, y), (o.updateQueue = u) && Un(o);
        }
      }, xf = function xf(n, o, u, c) {
        u !== c && Un(o);
      };else if ($c) {
        _$u = function $u(n, o, u, c) {
          for (var f = o.child; f !== null;) {
            if (f.tag === 5) {
              var m = f.stateNode;
              u && c && (m = Kb(m, f.type, f.memoizedProps, f)), ue(n, m);
            } else if (f.tag === 6) m = f.stateNode, u && c && (m = Yb(m, f.memoizedProps, f)), ue(n, m);else if (f.tag !== 4) {
              if (f.tag === 22 && f.memoizedState !== null) m = f.child, m !== null && (m.return = f), _$u(n, f, !0, !0);else if (f.child !== null) {
                f.child.return = f, f = f.child;
                continue;
              }
            }
            if (f === o) break;
            for (; f.sibling === null;) {
              if (f.return === null || f.return === o) return;
              f = f.return;
            }
            f.sibling.return = f.return, f = f.sibling;
          }
        };
        var _iE = function iE(n, o, u, c) {
          for (var f = o.child; f !== null;) {
            if (f.tag === 5) {
              var m = f.stateNode;
              u && c && (m = Kb(m, f.type, f.memoizedProps, f)), Gb(n, m);
            } else if (f.tag === 6) m = f.stateNode, u && c && (m = Yb(m, f.memoizedProps, f)), Gb(n, m);else if (f.tag !== 4) {
              if (f.tag === 22 && f.memoizedState !== null) m = f.child, m !== null && (m.return = f), _iE(n, f, !0, !0);else if (f.child !== null) {
                f.child.return = f, f = f.child;
                continue;
              }
            }
            if (f === o) break;
            for (; f.sibling === null;) {
              if (f.return === null || f.return === o) return;
              f = f.return;
            }
            f.sibling.return = f.return, f = f.sibling;
          }
        };
        Vu = function Vu(n, o) {
          var u = o.stateNode;
          if (!oE(n, o)) {
            n = u.containerInfo;
            var c = Wb(n);
            _iE(c, o, !1, !1), u.pendingChildren = c, Un(o), N3(n, c);
          }
        }, yf = function yf(n, o, u, c, f) {
          var m = n.stateNode,
            y = n.memoizedProps;
          if ((n = oE(n, o)) && y === c) o.stateNode = m;else {
            var I = o.stateNode,
              A = zn(Yt.current),
              z = null;
            y !== c && (z = X(I, u, y, c, f, A)), n && z === null ? o.stateNode = m : (m = _3(m, z, u, y, c, o, n, I), $r(m, u, c, f, A) && Un(o), o.stateNode = m, n ? Un(o) : _$u(m, o, !1, !1));
          }
        }, xf = function xf(n, o, u, c) {
          u !== c ? (n = zn(Xa.current), u = zn(Yt.current), o.stateNode = Ge(c, n, u, o), Un(o)) : o.stateNode = n.stateNode;
        };
      } else Vu = function Vu() {}, yf = function yf() {}, xf = function xf() {};
      function Wu(n, o) {
        if (!Ke) switch (n.tailMode) {
          case "hidden":
            o = n.tail;
            for (var u = null; o !== null;) o.alternate !== null && (u = o), o = o.sibling;
            u === null ? n.tail = null : u.sibling = null;
            break;
          case "collapsed":
            u = n.tail;
            for (var c = null; u !== null;) u.alternate !== null && (c = u), u = u.sibling;
            c === null ? o || n.tail === null ? n.tail = null : n.tail.sibling = null : c.sibling = null;
        }
      }
      function Gr(n) {
        var o = n.alternate !== null && n.alternate.child === n.child,
          u = 0,
          c = 0;
        if (o) for (var f = n.child; f !== null;) u |= f.lanes | f.childLanes, c |= f.subtreeFlags & 14680064, c |= f.flags & 14680064, f.return = n, f = f.sibling;else for (f = n.child; f !== null;) u |= f.lanes | f.childLanes, c |= f.subtreeFlags, c |= f.flags, f.return = n, f = f.sibling;
        return n.subtreeFlags |= c, n.childLanes = u, o;
      }
      function I6(n, o, u) {
        var c = o.pendingProps;
        switch (Dh(o), o.tag) {
          case 2:
          case 16:
          case 15:
          case 0:
          case 11:
          case 7:
          case 8:
          case 12:
          case 9:
          case 14:
            return Gr(o), null;
          case 1:
            return mt(o.type) && Wc(), Gr(o), null;
          case 3:
            return u = o.stateNode, Qa(), ze(dt), ze(Vr), Yh(), u.pendingContext && (u.context = u.pendingContext, u.pendingContext = null), (n === null || n.child === null) && (rf(o) ? Un(o) : n === null || n.memoizedState.isDehydrated && !(o.flags & 256) || (o.flags |= 1024, xn !== null && (Av(xn), xn = null))), Vu(n, o), Gr(o), null;
          case 5:
            Gh(o), u = zn(Xa.current);
            var f = o.type;
            if (n !== null && o.stateNode != null) yf(n, o, f, c, u), n.ref !== o.ref && (o.flags |= 512, o.flags |= 2097152);else {
              if (!c) {
                if (o.stateNode === null) throw Error(l(166));
                return Gr(o), null;
              }
              if (n = zn(Yt.current), rf(o)) {
                if (!$t) throw Error(l(175));
                n = j3(o.stateNode, o.type, o.memoizedProps, u, n, o, !Du), o.updateQueue = n, n !== null && Un(o);
              } else {
                var m = tt(f, c, u, n, o);
                _$u(m, o, !1, !1), o.stateNode = m, $r(m, f, c, u, n) && Un(o);
              }
              o.ref !== null && (o.flags |= 512, o.flags |= 2097152);
            }
            return Gr(o), null;
          case 6:
            if (n && o.stateNode != null) xf(n, o, n.memoizedProps, c);else {
              if (typeof c != "string" && o.stateNode === null) throw Error(l(166));
              if (n = zn(Xa.current), u = zn(Yt.current), rf(o)) {
                if (!$t) throw Error(l(176));
                if (n = o.stateNode, u = o.memoizedProps, (c = U3(n, u, o, !Du)) && (f = Mt, f !== null)) switch (f.tag) {
                  case 3:
                    X3(f.stateNode.containerInfo, n, u, (f.mode & 1) !== 0);
                    break;
                  case 5:
                    Q3(f.type, f.memoizedProps, f.stateNode, n, u, (f.mode & 1) !== 0);
                }
                c && Un(o);
              } else o.stateNode = Ge(c, n, u, o);
            }
            return Gr(o), null;
          case 13:
            if (ze(Je), c = o.memoizedState, n === null || n.memoizedState !== null && n.memoizedState.dehydrated !== null) {
              if (Ke && Gt !== null && o.mode & 1 && !(o.flags & 128)) uw(), Wa(), o.flags |= 98560, f = !1;else if (f = rf(o), c !== null && c.dehydrated !== null) {
                if (n === null) {
                  if (!f) throw Error(l(318));
                  if (!$t) throw Error(l(344));
                  if (f = o.memoizedState, f = f !== null ? f.dehydrated : null, !f) throw Error(l(317));
                  H3(f, o);
                } else Wa(), !(o.flags & 128) && (o.memoizedState = null), o.flags |= 4;
                Gr(o), f = !1;
              } else xn !== null && (Av(xn), xn = null), f = !0;
              if (!f) return o.flags & 65536 ? o : null;
            }
            return o.flags & 128 ? (o.lanes = u, o) : (u = c !== null, u !== (n !== null && n.memoizedState !== null) && u && (o.child.flags |= 8192, o.mode & 1 && (n === null || Je.current & 1 ? yr === 0 && (yr = 3) : Nv())), o.updateQueue !== null && (o.flags |= 4), Gr(o), null);
          case 4:
            return Qa(), Vu(n, o), n === null && a3(o.stateNode.containerInfo), Gr(o), null;
          case 10:
            return Uh(o.type._context), Gr(o), null;
          case 17:
            return mt(o.type) && Wc(), Gr(o), null;
          case 19:
            if (ze(Je), f = o.memoizedState, f === null) return Gr(o), null;
            if (c = (o.flags & 128) !== 0, m = f.rendering, m === null) {
              if (c) Wu(f, !1);else {
                if (yr !== 0 || n !== null && n.flags & 128) for (n = o.child; n !== null;) {
                  if (m = lf(n), m !== null) {
                    for (o.flags |= 128, Wu(f, !1), n = m.updateQueue, n !== null && (o.updateQueue = n, o.flags |= 4), o.subtreeFlags = 0, n = u, u = o.child; u !== null;) c = u, f = n, c.flags &= 14680066, m = c.alternate, m === null ? (c.childLanes = 0, c.lanes = f, c.child = null, c.subtreeFlags = 0, c.memoizedProps = null, c.memoizedState = null, c.updateQueue = null, c.dependencies = null, c.stateNode = null) : (c.childLanes = m.childLanes, c.lanes = m.lanes, c.child = m.child, c.subtreeFlags = 0, c.deletions = null, c.memoizedProps = m.memoizedProps, c.memoizedState = m.memoizedState, c.updateQueue = m.updateQueue, c.type = m.type, f = m.dependencies, c.dependencies = f === null ? null : {
                      lanes: f.lanes,
                      firstContext: f.firstContext
                    }), u = u.sibling;
                    return De(Je, Je.current & 1 | 2), o.child;
                  }
                  n = n.sibling;
                }
                f.tail !== null && Tr() > Pv && (o.flags |= 128, c = !0, Wu(f, !1), o.lanes = 4194304);
              }
            } else {
              if (!c) if (n = lf(m), n !== null) {
                if (o.flags |= 128, c = !0, n = n.updateQueue, n !== null && (o.updateQueue = n, o.flags |= 4), Wu(f, !0), f.tail === null && f.tailMode === "hidden" && !m.alternate && !Ke) return Gr(o), null;
              } else 2 * Tr() - f.renderingStartTime > Pv && u !== 1073741824 && (o.flags |= 128, c = !0, Wu(f, !1), o.lanes = 4194304);
              f.isBackwards ? (m.sibling = o.child, o.child = m) : (n = f.last, n !== null ? n.sibling = m : o.child = m, f.last = m);
            }
            return f.tail !== null ? (o = f.tail, f.rendering = o, f.tail = o.sibling, f.renderingStartTime = Tr(), o.sibling = null, n = Je.current, De(Je, c ? n & 1 | 2 : n & 1), o) : (Gr(o), null);
          case 22:
          case 23:
            return _v(), u = o.memoizedState !== null, n !== null && n.memoizedState !== null !== u && (o.flags |= 8192), u && o.mode & 1 ? kt & 1073741824 && (Gr(o), Rt && o.subtreeFlags & 6 && (o.flags |= 8192)) : Gr(o), null;
          case 24:
            return null;
          case 25:
            return null;
        }
        throw Error(l(156, o.tag));
      }
      function P6(n, o) {
        switch (Dh(o), o.tag) {
          case 1:
            return mt(o.type) && Wc(), n = o.flags, n & 65536 ? (o.flags = n & -65537 | 128, o) : null;
          case 3:
            return Qa(), ze(dt), ze(Vr), Yh(), n = o.flags, n & 65536 && !(n & 128) ? (o.flags = n & -65537 | 128, o) : null;
          case 5:
            return Gh(o), null;
          case 13:
            if (ze(Je), n = o.memoizedState, n !== null && n.dehydrated !== null) {
              if (o.alternate === null) throw Error(l(340));
              Wa();
            }
            return n = o.flags, n & 65536 ? (o.flags = n & -65537 | 128, o) : null;
          case 19:
            return ze(Je), null;
          case 4:
            return Qa(), null;
          case 10:
            return Uh(o.type._context), null;
          case 22:
          case 23:
            return _v(), null;
          case 24:
            return null;
          default:
            return null;
        }
      }
      var Sf = !1,
        Kr = !1,
        q6 = typeof WeakSet == "function" ? WeakSet : Set,
        V = null;
      function Za(n, o) {
        var u = n.ref;
        if (u !== null) if (typeof u == "function") try {
          u(null);
        } catch (c) {
          Ye(n, o, c);
        } else u.current = null;
      }
      function mv(n, o, u) {
        try {
          u();
        } catch (c) {
          Ye(n, o, c);
        }
      }
      var aE = !1;
      function T6(n, o) {
        for (Dn(n.containerInfo), V = o; V !== null;) if (n = V, o = n.child, (n.subtreeFlags & 1028) !== 0 && o !== null) o.return = n, V = o;else for (; V !== null;) {
          n = V;
          try {
            var u = n.alternate;
            if (n.flags & 1024) switch (n.tag) {
              case 0:
              case 11:
              case 15:
                break;
              case 1:
                if (u !== null) {
                  var c = u.memoizedProps,
                    f = u.memoizedState,
                    m = n.stateNode,
                    y = m.getSnapshotBeforeUpdate(n.elementType === n.type ? c : Sn(n.type, c), f);
                  m.__reactInternalSnapshotBeforeUpdate = y;
                }
                break;
              case 3:
                Rt && A3(n.stateNode.containerInfo);
                break;
              case 5:
              case 6:
              case 4:
              case 17:
                break;
              default:
                throw Error(l(163));
            }
          } catch (I) {
            Ye(n, n.return, I);
          }
          if (o = n.sibling, o !== null) {
            o.return = n.return, V = o;
            break;
          }
          V = n.return;
        }
        return u = aE, aE = !1, u;
      }
      function Gu(n, o, u) {
        var c = o.updateQueue;
        if (c = c !== null ? c.lastEffect : null, c !== null) {
          var f = c = c.next;
          do {
            if ((f.tag & n) === n) {
              var m = f.destroy;
              f.destroy = void 0, m !== void 0 && mv(o, u, m);
            }
            f = f.next;
          } while (f !== c);
        }
      }
      function bf(n, o) {
        if (o = o.updateQueue, o = o !== null ? o.lastEffect : null, o !== null) {
          var u = o = o.next;
          do {
            if ((u.tag & n) === n) {
              var c = u.create;
              u.destroy = c();
            }
            u = u.next;
          } while (u !== o);
        }
      }
      function hv(n) {
        var o = n.ref;
        if (o !== null) {
          var u = n.stateNode;
          switch (n.tag) {
            case 5:
              n = Me(u);
              break;
            default:
              n = u;
          }
          typeof o == "function" ? o(n) : o.current = n;
        }
      }
      function sE(n) {
        var o = n.alternate;
        o !== null && (n.alternate = null, sE(o)), n.child = null, n.deletions = null, n.sibling = null, n.tag === 5 && (o = n.stateNode, o !== null && u3(o)), n.stateNode = null, n.return = null, n.dependencies = null, n.memoizedProps = null, n.memoizedState = null, n.pendingProps = null, n.stateNode = null, n.updateQueue = null;
      }
      function uE(n) {
        return n.tag === 5 || n.tag === 3 || n.tag === 4;
      }
      function lE(n) {
        e: for (;;) {
          for (; n.sibling === null;) {
            if (n.return === null || uE(n.return)) return null;
            n = n.return;
          }
          for (n.sibling.return = n.return, n = n.sibling; n.tag !== 5 && n.tag !== 6 && n.tag !== 18;) {
            if (n.flags & 2 || n.child === null || n.tag === 4) continue e;
            n.child.return = n, n = n.child;
          }
          if (!(n.flags & 2)) return n.stateNode;
        }
      }
      function vv(n, o, u) {
        var c = n.tag;
        if (c === 5 || c === 6) n = n.stateNode, o ? E3(u, n, o) : y3(u, n);else if (c !== 4 && (n = n.child, n !== null)) for (vv(n, o, u), n = n.sibling; n !== null;) vv(n, o, u), n = n.sibling;
      }
      function gv(n, o, u) {
        var c = n.tag;
        if (c === 5 || c === 6) n = n.stateNode, o ? w3(u, n, o) : g3(u, n);else if (c !== 4 && (n = n.child, n !== null)) for (gv(n, o, u), n = n.sibling; n !== null;) gv(n, o, u), n = n.sibling;
      }
      var Fr = null,
        bn = !1;
      function Hn(n, o, u) {
        for (u = u.child; u !== null;) yv(n, o, u), u = u.sibling;
      }
      function yv(n, o, u) {
        if (Bn && typeof Bn.onCommitFiberUnmount == "function") try {
          Bn.onCommitFiberUnmount(Qc, u);
        } catch (_unused57) {}
        switch (u.tag) {
          case 5:
            Kr || Za(u, o);
          case 6:
            if (Rt) {
              var c = Fr,
                f = bn;
              Fr = null, Hn(n, o, u), Fr = c, bn = f, Fr !== null && (bn ? I3(Fr, u.stateNode) : C3(Fr, u.stateNode));
            } else Hn(n, o, u);
            break;
          case 18:
            Rt && Fr !== null && (bn ? K3(Fr, u.stateNode) : G3(Fr, u.stateNode));
            break;
          case 4:
            Rt ? (c = Fr, f = bn, Fr = u.stateNode.containerInfo, bn = !0, Hn(n, o, u), Fr = c, bn = f) : ($c && (c = u.stateNode.containerInfo, f = Wb(c), wh(c, f)), Hn(n, o, u));
            break;
          case 0:
          case 11:
          case 14:
          case 15:
            if (!Kr && (c = u.updateQueue, c !== null && (c = c.lastEffect, c !== null))) {
              f = c = c.next;
              do {
                var m = f,
                  y = m.destroy;
                m = m.tag, y !== void 0 && (m & 2 || m & 4) && mv(u, o, y), f = f.next;
              } while (f !== c);
            }
            Hn(n, o, u);
            break;
          case 1:
            if (!Kr && (Za(u, o), c = u.stateNode, typeof c.componentWillUnmount == "function")) try {
              c.props = u.memoizedProps, c.state = u.memoizedState, c.componentWillUnmount();
            } catch (I) {
              Ye(u, o, I);
            }
            Hn(n, o, u);
            break;
          case 21:
            Hn(n, o, u);
            break;
          case 22:
            u.mode & 1 ? (Kr = (c = Kr) || u.memoizedState !== null, Hn(n, o, u), Kr = c) : Hn(n, o, u);
            break;
          default:
            Hn(n, o, u);
        }
      }
      function cE(n) {
        var o = n.updateQueue;
        if (o !== null) {
          n.updateQueue = null;
          var u = n.stateNode;
          u === null && (u = n.stateNode = new q6()), o.forEach(function (c) {
            var f = B6.bind(null, n, c);
            u.has(c) || (u.add(c), c.then(f, f));
          });
        }
      }
      function wn(n, o) {
        var u = o.deletions;
        if (u !== null) for (var c = 0; c < u.length; c++) {
          var f = u[c];
          try {
            var m = n,
              y = o;
            if (Rt) {
              var I = y;
              e: for (; I !== null;) {
                switch (I.tag) {
                  case 5:
                    Fr = I.stateNode, bn = !1;
                    break e;
                  case 3:
                    Fr = I.stateNode.containerInfo, bn = !0;
                    break e;
                  case 4:
                    Fr = I.stateNode.containerInfo, bn = !0;
                    break e;
                }
                I = I.return;
              }
              if (Fr === null) throw Error(l(160));
              yv(m, y, f), Fr = null, bn = !1;
            } else yv(m, y, f);
            var A = f.alternate;
            A !== null && (A.return = null), f.return = null;
          } catch (z) {
            Ye(f, o, z);
          }
        }
        if (o.subtreeFlags & 12854) for (o = o.child; o !== null;) fE(o, n), o = o.sibling;
      }
      function fE(n, o) {
        var u = n.alternate,
          c = n.flags;
        switch (n.tag) {
          case 0:
          case 11:
          case 14:
          case 15:
            if (wn(o, n), $n(n), c & 4) {
              try {
                Gu(3, n, n.return), bf(3, n);
              } catch (H) {
                Ye(n, n.return, H);
              }
              try {
                Gu(5, n, n.return);
              } catch (H) {
                Ye(n, n.return, H);
              }
            }
            break;
          case 1:
            wn(o, n), $n(n), c & 512 && u !== null && Za(u, u.return);
            break;
          case 5:
            if (wn(o, n), $n(n), c & 512 && u !== null && Za(u, u.return), Rt) {
              if (n.flags & 32) {
                var f = n.stateNode;
                try {
                  Vb(f);
                } catch (H) {
                  Ye(n, n.return, H);
                }
              }
              if (c & 4 && (f = n.stateNode, f != null)) {
                var m = n.memoizedProps;
                if (u = u !== null ? u.memoizedProps : m, c = n.type, o = n.updateQueue, n.updateQueue = null, o !== null) try {
                  b3(f, o, c, u, m, n);
                } catch (H) {
                  Ye(n, n.return, H);
                }
              }
            }
            break;
          case 6:
            if (wn(o, n), $n(n), c & 4 && Rt) {
              if (n.stateNode === null) throw Error(l(162));
              f = n.stateNode, m = n.memoizedProps, u = u !== null ? u.memoizedProps : m;
              try {
                x3(f, u, m);
              } catch (H) {
                Ye(n, n.return, H);
              }
            }
            break;
          case 3:
            if (wn(o, n), $n(n), c & 4) {
              if (Rt && $t && u !== null && u.memoizedState.isDehydrated) try {
                V3(o.containerInfo);
              } catch (H) {
                Ye(n, n.return, H);
              }
              if ($c) {
                f = o.containerInfo, m = o.pendingChildren;
                try {
                  wh(f, m);
                } catch (H) {
                  Ye(n, n.return, H);
                }
              }
            }
            break;
          case 4:
            if (wn(o, n), $n(n), c & 4 && $c) {
              m = n.stateNode, f = m.containerInfo, m = m.pendingChildren;
              try {
                wh(f, m);
              } catch (H) {
                Ye(n, n.return, H);
              }
            }
            break;
          case 13:
            wn(o, n), $n(n), f = n.child, f.flags & 8192 && (m = f.memoizedState !== null, f.stateNode.isHidden = m, !m || f.alternate !== null && f.alternate.memoizedState !== null || (Iv = Tr())), c & 4 && cE(n);
            break;
          case 22:
            var y = u !== null && u.memoizedState !== null;
            if (n.mode & 1 ? (Kr = (u = Kr) || y, wn(o, n), Kr = u) : wn(o, n), $n(n), c & 8192) {
              if (u = n.memoizedState !== null, (n.stateNode.isHidden = u) && !y && n.mode & 1) for (V = n, c = n.child; c !== null;) {
                for (o = V = c; V !== null;) {
                  y = V;
                  var I = y.child;
                  switch (y.tag) {
                    case 0:
                    case 11:
                    case 14:
                    case 15:
                      Gu(4, y, y.return);
                      break;
                    case 1:
                      Za(y, y.return);
                      var A = y.stateNode;
                      if (typeof A.componentWillUnmount == "function") {
                        var z = y,
                          G = y.return;
                        try {
                          var ce = z;
                          A.props = ce.memoizedProps, A.state = ce.memoizedState, A.componentWillUnmount();
                        } catch (H) {
                          Ye(z, G, H);
                        }
                      }
                      break;
                    case 5:
                      Za(y, y.return);
                      break;
                    case 22:
                      if (y.memoizedState !== null) {
                        mE(o);
                        continue;
                      }
                  }
                  I !== null ? (I.return = y, V = I) : mE(o);
                }
                c = c.sibling;
              }
              if (Rt) {
                e: if (c = null, Rt) for (o = n;;) {
                  if (o.tag === 5) {
                    if (c === null) {
                      c = o;
                      try {
                        f = o.stateNode, u ? P3(f) : T3(o.stateNode, o.memoizedProps);
                      } catch (H) {
                        Ye(n, n.return, H);
                      }
                    }
                  } else if (o.tag === 6) {
                    if (c === null) try {
                      m = o.stateNode, u ? q3(m) : O3(m, o.memoizedProps);
                    } catch (H) {
                      Ye(n, n.return, H);
                    }
                  } else if ((o.tag !== 22 && o.tag !== 23 || o.memoizedState === null || o === n) && o.child !== null) {
                    o.child.return = o, o = o.child;
                    continue;
                  }
                  if (o === n) break e;
                  for (; o.sibling === null;) {
                    if (o.return === null || o.return === n) break e;
                    c === o && (c = null), o = o.return;
                  }
                  c === o && (c = null), o.sibling.return = o.return, o = o.sibling;
                }
              }
            }
            break;
          case 19:
            wn(o, n), $n(n), c & 4 && cE(n);
            break;
          case 21:
            break;
          default:
            wn(o, n), $n(n);
        }
      }
      function $n(n) {
        var o = n.flags;
        if (o & 2) {
          try {
            if (Rt) {
              e: {
                for (var u = n.return; u !== null;) {
                  if (uE(u)) {
                    var c = u;
                    break e;
                  }
                  u = u.return;
                }
                throw Error(l(160));
              }
              switch (c.tag) {
                case 5:
                  var f = c.stateNode;
                  c.flags & 32 && (Vb(f), c.flags &= -33);
                  var m = lE(n);
                  gv(n, m, f);
                  break;
                case 3:
                case 4:
                  var y = c.stateNode.containerInfo,
                    I = lE(n);
                  vv(n, I, y);
                  break;
                default:
                  throw Error(l(161));
              }
            }
          } catch (A) {
            Ye(n, n.return, A);
          }
          n.flags &= -3;
        }
        o & 4096 && (n.flags &= -4097);
      }
      function O6(n, o, u) {
        V = n, pE(n, o, u);
      }
      function pE(n, o, u) {
        for (var c = (n.mode & 1) !== 0; V !== null;) {
          var f = V,
            m = f.child;
          if (f.tag === 22 && c) {
            var y = f.memoizedState !== null || Sf;
            if (!y) {
              var I = f.alternate,
                A = I !== null && I.memoizedState !== null || Kr;
              I = Sf;
              var z = Kr;
              if (Sf = y, (Kr = A) && !z) for (V = f; V !== null;) y = V, A = y.child, y.tag === 22 && y.memoizedState !== null ? hE(f) : A !== null ? (A.return = y, V = A) : hE(f);
              for (; m !== null;) V = m, pE(m, o, u), m = m.sibling;
              V = f, Sf = I, Kr = z;
            }
            dE(n, o, u);
          } else f.subtreeFlags & 8772 && m !== null ? (m.return = f, V = m) : dE(n, o, u);
        }
      }
      function dE(n) {
        for (; V !== null;) {
          var o = V;
          if (o.flags & 8772) {
            var u = o.alternate;
            try {
              if (o.flags & 8772) switch (o.tag) {
                case 0:
                case 11:
                case 15:
                  Kr || bf(5, o);
                  break;
                case 1:
                  var c = o.stateNode;
                  if (o.flags & 4 && !Kr) if (u === null) c.componentDidMount();else {
                    var f = o.elementType === o.type ? u.memoizedProps : Sn(o.type, u.memoizedProps);
                    c.componentDidUpdate(f, u.memoizedState, c.__reactInternalSnapshotBeforeUpdate);
                  }
                  var m = o.updateQueue;
                  m !== null && vw(o, m, c);
                  break;
                case 3:
                  var y = o.updateQueue;
                  if (y !== null) {
                    if (u = null, o.child !== null) switch (o.child.tag) {
                      case 5:
                        u = Me(o.child.stateNode);
                        break;
                      case 1:
                        u = o.child.stateNode;
                    }
                    vw(o, y, u);
                  }
                  break;
                case 5:
                  var I = o.stateNode;
                  u === null && o.flags & 4 && S3(I, o.type, o.memoizedProps, o);
                  break;
                case 6:
                  break;
                case 4:
                  break;
                case 12:
                  break;
                case 13:
                  if ($t && o.memoizedState === null) {
                    var A = o.alternate;
                    if (A !== null) {
                      var z = A.memoizedState;
                      if (z !== null) {
                        var G = z.dehydrated;
                        G !== null && W3(G);
                      }
                    }
                  }
                  break;
                case 19:
                case 17:
                case 21:
                case 22:
                case 23:
                case 25:
                  break;
                default:
                  throw Error(l(163));
              }
              Kr || o.flags & 512 && hv(o);
            } catch (ce) {
              Ye(o, o.return, ce);
            }
          }
          if (o === n) {
            V = null;
            break;
          }
          if (u = o.sibling, u !== null) {
            u.return = o.return, V = u;
            break;
          }
          V = o.return;
        }
      }
      function mE(n) {
        for (; V !== null;) {
          var o = V;
          if (o === n) {
            V = null;
            break;
          }
          var u = o.sibling;
          if (u !== null) {
            u.return = o.return, V = u;
            break;
          }
          V = o.return;
        }
      }
      function hE(n) {
        for (; V !== null;) {
          var o = V;
          try {
            switch (o.tag) {
              case 0:
              case 11:
              case 15:
                var u = o.return;
                try {
                  bf(4, o);
                } catch (A) {
                  Ye(o, u, A);
                }
                break;
              case 1:
                var c = o.stateNode;
                if (typeof c.componentDidMount == "function") {
                  var f = o.return;
                  try {
                    c.componentDidMount();
                  } catch (A) {
                    Ye(o, f, A);
                  }
                }
                var m = o.return;
                try {
                  hv(o);
                } catch (A) {
                  Ye(o, m, A);
                }
                break;
              case 5:
                var y = o.return;
                try {
                  hv(o);
                } catch (A) {
                  Ye(o, y, A);
                }
            }
          } catch (A) {
            Ye(o, o.return, A);
          }
          if (o === n) {
            V = null;
            break;
          }
          var I = o.sibling;
          if (I !== null) {
            I.return = o.return, V = I;
            break;
          }
          V = o.return;
        }
      }
      var wf = 0,
        Ef = 1,
        Cf = 2,
        If = 3,
        Pf = 4;
      if (typeof Symbol == "function" && Symbol.for) {
        var Ku = Symbol.for;
        wf = Ku("selector.component"), Ef = Ku("selector.has_pseudo_class"), Cf = Ku("selector.role"), If = Ku("selector.test_id"), Pf = Ku("selector.text");
      }
      function xv(n) {
        var o = i3(n);
        if (o != null) {
          if (typeof o.memoizedProps["data-testname"] != "string") throw Error(l(364));
          return o;
        }
        if (n = f3(n), n === null) throw Error(l(362));
        return n.stateNode.current;
      }
      function Sv(n, o) {
        switch (o.$$typeof) {
          case wf:
            if (n.type === o.value) return !0;
            break;
          case Ef:
            e: {
              o = o.value, n = [n, 0];
              for (var u = 0; u < n.length;) {
                var c = n[u++],
                  f = n[u++],
                  m = o[f];
                if (c.tag !== 5 || !Nu(c)) {
                  for (; m != null && Sv(c, m);) f++, m = o[f];
                  if (f === o.length) {
                    o = !0;
                    break e;
                  } else for (c = c.child; c !== null;) n.push(c, f), c = c.sibling;
                }
              }
              o = !1;
            }
            return o;
          case Cf:
            if (n.tag === 5 && m3(n.stateNode, o.value)) return !0;
            break;
          case Pf:
            if ((n.tag === 5 || n.tag === 6) && (n = d3(n), n !== null && 0 <= n.indexOf(o.value))) return !0;
            break;
          case If:
            if (n.tag === 5 && (n = n.memoizedProps["data-testname"], typeof n == "string" && n.toLowerCase() === o.value.toLowerCase())) return !0;
            break;
          default:
            throw Error(l(365));
        }
        return !1;
      }
      function bv(n) {
        switch (n.$$typeof) {
          case wf:
            return "<" + (N(n.value) || "Unknown") + ">";
          case Ef:
            return ":has(" + (bv(n) || "") + ")";
          case Cf:
            return '[role="' + n.value + '"]';
          case Pf:
            return '"' + n.value + '"';
          case If:
            return '[data-testname="' + n.value + '"]';
          default:
            throw Error(l(365));
        }
      }
      function vE(n, o) {
        var u = [];
        n = [n, 0];
        for (var c = 0; c < n.length;) {
          var f = n[c++],
            m = n[c++],
            y = o[m];
          if (f.tag !== 5 || !Nu(f)) {
            for (; y != null && Sv(f, y);) m++, y = o[m];
            if (m === o.length) u.push(f);else for (f = f.child; f !== null;) n.push(f, m), f = f.sibling;
          }
        }
        return u;
      }
      function wv(n, o) {
        if (!_u) throw Error(l(363));
        n = xv(n), n = vE(n, o), o = [], n = Array.from(n);
        for (var u = 0; u < n.length;) {
          var c = n[u++];
          if (c.tag === 5) Nu(c) || o.push(c.stateNode);else for (c = c.child; c !== null;) n.push(c), c = c.sibling;
        }
        return o;
      }
      var A6 = Math.ceil,
        qf = p.ReactCurrentDispatcher,
        Ev = p.ReactCurrentOwner,
        lr = p.ReactCurrentBatchConfig,
        ye = 0,
        Ar = null,
        fr = null,
        Lr = 0,
        kt = 0,
        es = Fo(0),
        yr = 0,
        Yu = null,
        Gi = 0,
        Tf = 0,
        Cv = 0,
        Xu = null,
        vt = null,
        Iv = 0,
        Pv = 1 / 0,
        mo = null;
      function rs() {
        Pv = Tr() + 500;
      }
      var Of = !1,
        qv = null,
        Uo = null,
        Af = !1,
        Ho = null,
        _f = 0,
        Qu = 0,
        Tv = null,
        Nf = -1,
        Rf = 0;
      function Yr() {
        return ye & 6 ? Tr() : Nf !== -1 ? Nf : Nf = Tr();
      }
      function $o(n) {
        return n.mode & 1 ? ye & 2 && Lr !== 0 ? Lr & -Lr : p6.transition !== null ? (Rf === 0 && (Rf = ew()), Rf) : (n = Pe, n !== 0 ? n : s3()) : 1;
      }
      function Qt(n, o, u, c) {
        if (50 < Qu) throw Qu = 0, Tv = null, Error(l(185));
        ku(n, u, c), (!(ye & 2) || n !== Ar) && (n === Ar && (!(ye & 2) && (Tf |= u), yr === 4 && Vo(n, Lr)), gt(n, c), u === 1 && ye === 0 && !(o.mode & 1) && (rs(), Jc && Fn()));
      }
      function gt(n, o) {
        var u = n.callbackNode;
        n6(n, o);
        var c = Xc(n, n === Ar ? Lr : 0);
        if (c === 0) u !== null && tw(u), n.callbackNode = null, n.callbackPriority = 0;else if (o = c & -c, n.callbackPriority !== o) {
          if (u != null && tw(u), o === 1) n.tag === 0 ? f6(yE.bind(null, n)) : nw(yE.bind(null, n)), l3 ? c3(function () {
            !(ye & 6) && Fn();
          }) : _h(Nh, Fn), u = null;else {
            switch (rw(c)) {
              case 1:
                u = Nh;
                break;
              case 4:
                u = s6;
                break;
              case 16:
                u = Rh;
                break;
              case 536870912:
                u = u6;
                break;
              default:
                u = Rh;
            }
            u = qE(u, gE.bind(null, n));
          }
          n.callbackPriority = o, n.callbackNode = u;
        }
      }
      function gE(n, o) {
        if (Nf = -1, Rf = 0, ye & 6) throw Error(l(327));
        var u = n.callbackNode;
        if (Xi() && n.callbackNode !== u) return null;
        var c = Xc(n, n === Ar ? Lr : 0);
        if (c === 0) return null;
        if (c & 30 || c & n.expiredLanes || o) o = Mf(n, c);else {
          o = c;
          var f = ye;
          ye |= 2;
          var m = bE();
          (Ar !== n || Lr !== o) && (mo = null, rs(), Ki(n, o));
          do try {
            R6();
            break;
          } catch (I) {
            SE(n, I);
          } while (!0);
          jh(), qf.current = m, ye = f, fr !== null ? o = 0 : (Ar = null, Lr = 0, o = yr);
        }
        if (o !== 0) {
          if (o === 2 && (f = Th(n), f !== 0 && (c = f, o = Ov(n, f))), o === 1) throw u = Yu, Ki(n, 0), Vo(n, c), gt(n, Tr()), u;
          if (o === 6) Vo(n, c);else {
            if (f = n.current.alternate, !(c & 30) && !_6(f) && (o = Mf(n, c), o === 2 && (m = Th(n), m !== 0 && (c = m, o = Ov(n, m))), o === 1)) throw u = Yu, Ki(n, 0), Vo(n, c), gt(n, Tr()), u;
            switch (n.finishedWork = f, n.finishedLanes = c, o) {
              case 0:
              case 1:
                throw Error(l(345));
              case 2:
                Yi(n, vt, mo);
                break;
              case 3:
                if (Vo(n, c), (c & 130023424) === c && (o = Iv + 500 - Tr(), 10 < o)) {
                  if (Xc(n, 0) !== 0) break;
                  if (f = n.suspendedLanes, (f & c) !== c) {
                    Yr(), n.pingedLanes |= n.suspendedLanes & f;
                    break;
                  }
                  n.timeoutHandle = Bo(Yi.bind(null, n, vt, mo), o);
                  break;
                }
                Yi(n, vt, mo);
                break;
              case 4:
                if (Vo(n, c), (c & 4194240) === c) break;
                for (o = n.eventTimes, f = -1; 0 < c;) {
                  var y = 31 - gn(c);
                  m = 1 << y, y = o[y], y > f && (f = y), c &= ~m;
                }
                if (c = f, c = Tr() - c, c = (120 > c ? 120 : 480 > c ? 480 : 1080 > c ? 1080 : 1920 > c ? 1920 : 3e3 > c ? 3e3 : 4320 > c ? 4320 : 1960 * A6(c / 1960)) - c, 10 < c) {
                  n.timeoutHandle = Bo(Yi.bind(null, n, vt, mo), c);
                  break;
                }
                Yi(n, vt, mo);
                break;
              case 5:
                Yi(n, vt, mo);
                break;
              default:
                throw Error(l(329));
            }
          }
        }
        return gt(n, Tr()), n.callbackNode === u ? gE.bind(null, n) : null;
      }
      function Ov(n, o) {
        var u = Xu;
        return n.current.memoizedState.isDehydrated && (Ki(n, o).flags |= 256), n = Mf(n, o), n !== 2 && (o = vt, vt = u, o !== null && Av(o)), n;
      }
      function Av(n) {
        vt === null ? vt = n : vt.push.apply(vt, n);
      }
      function _6(n) {
        for (var o = n;;) {
          if (o.flags & 16384) {
            var u = o.updateQueue;
            if (u !== null && (u = u.stores, u !== null)) for (var c = 0; c < u.length; c++) {
              var f = u[c],
                m = f.getSnapshot;
              f = f.value;
              try {
                if (!yn(m(), f)) return !1;
              } catch (_unused58) {
                return !1;
              }
            }
          }
          if (u = o.child, o.subtreeFlags & 16384 && u !== null) u.return = o, o = u;else {
            if (o === n) break;
            for (; o.sibling === null;) {
              if (o.return === null || o.return === n) return !0;
              o = o.return;
            }
            o.sibling.return = o.return, o = o.sibling;
          }
        }
        return !0;
      }
      function Vo(n, o) {
        for (o &= ~Cv, o &= ~Tf, n.suspendedLanes |= o, n.pingedLanes &= ~o, n = n.expirationTimes; 0 < o;) {
          var u = 31 - gn(o),
            c = 1 << u;
          n[u] = -1, o &= ~c;
        }
      }
      function yE(n) {
        if (ye & 6) throw Error(l(327));
        Xi();
        var o = Xc(n, 0);
        if (!(o & 1)) return gt(n, Tr()), null;
        var u = Mf(n, o);
        if (n.tag !== 0 && u === 2) {
          var c = Th(n);
          c !== 0 && (o = c, u = Ov(n, c));
        }
        if (u === 1) throw u = Yu, Ki(n, 0), Vo(n, o), gt(n, Tr()), u;
        if (u === 6) throw Error(l(345));
        return n.finishedWork = n.current.alternate, n.finishedLanes = o, Yi(n, vt, mo), gt(n, Tr()), null;
      }
      function xE(n) {
        Ho !== null && Ho.tag === 0 && !(ye & 6) && Xi();
        var o = ye;
        ye |= 1;
        var u = lr.transition,
          c = Pe;
        try {
          if (lr.transition = null, Pe = 1, n) return n();
        } finally {
          Pe = c, lr.transition = u, ye = o, !(ye & 6) && Fn();
        }
      }
      function _v() {
        kt = es.current, ze(es);
      }
      function Ki(n, o) {
        n.finishedWork = null, n.finishedLanes = 0;
        var u = n.timeoutHandle;
        if (u !== bh && (n.timeoutHandle = bh, o3(u)), fr !== null) for (u = fr.return; u !== null;) {
          var c = u;
          switch (Dh(c), c.tag) {
            case 1:
              c = c.type.childContextTypes, c != null && Wc();
              break;
            case 3:
              Qa(), ze(dt), ze(Vr), Yh();
              break;
            case 5:
              Gh(c);
              break;
            case 4:
              Qa();
              break;
            case 13:
              ze(Je);
              break;
            case 19:
              ze(Je);
              break;
            case 10:
              Uh(c.type._context);
              break;
            case 22:
            case 23:
              _v();
          }
          u = u.return;
        }
        if (Ar = n, fr = n = Wo(n.current, null), Lr = kt = o, yr = 0, Yu = null, Cv = Tf = Gi = 0, vt = Xu = null, Vi !== null) {
          for (o = 0; o < Vi.length; o++) if (u = Vi[o], c = u.interleaved, c !== null) {
            u.interleaved = null;
            var f = c.next,
              m = u.pending;
            if (m !== null) {
              var y = m.next;
              m.next = f, c.next = y;
            }
            u.pending = c;
          }
          Vi = null;
        }
        return n;
      }
      function SE(n, o) {
        do {
          var u = fr;
          try {
            if (jh(), cf.current = mf, ff) {
              for (var c = Ze.memoizedState; c !== null;) {
                var f = c.queue;
                f !== null && (f.pending = null), c = c.next;
              }
              ff = !1;
            }
            if (Wi = 0, Or = gr = Ze = null, zu = !1, ju = 0, Ev.current = null, u === null || u.return === null) {
              yr = 1, Yu = o, fr = null;
              break;
            }
            e: {
              var m = n,
                y = u.return,
                I = u,
                A = o;
              if (o = Lr, I.flags |= 32768, A !== null && _typeof(A) == "object" && typeof A.then == "function") {
                var z = A,
                  G = I,
                  ce = G.tag;
                if (!(G.mode & 1) && (ce === 0 || ce === 11 || ce === 15)) {
                  var H = G.alternate;
                  H ? (G.updateQueue = H.updateQueue, G.memoizedState = H.memoizedState, G.lanes = H.lanes) : (G.updateQueue = null, G.memoizedState = null);
                }
                var je = Vw(y);
                if (je !== null) {
                  je.flags &= -257, Ww(je, y, I, m, o), je.mode & 1 && $w(m, z, o), o = je, A = z;
                  var ke = o.updateQueue;
                  if (ke === null) {
                    var yt = new Set();
                    yt.add(A), o.updateQueue = yt;
                  } else ke.add(A);
                  break e;
                } else {
                  if (!(o & 1)) {
                    $w(m, z, o), Nv();
                    break e;
                  }
                  A = Error(l(426));
                }
              } else if (Ke && I.mode & 1) {
                var ho = Vw(y);
                if (ho !== null) {
                  !(ho.flags & 65536) && (ho.flags |= 256), Ww(ho, y, I, m, o), Lh(Ja(A, I));
                  break e;
                }
              }
              m = A = Ja(A, I), yr !== 4 && (yr = 2), Xu === null ? Xu = [m] : Xu.push(m), m = y;
              do {
                switch (m.tag) {
                  case 3:
                    m.flags |= 65536, o &= -o, m.lanes |= o;
                    var O = Uw(m, A, o);
                    hw(m, O);
                    break e;
                  case 1:
                    I = A;
                    var P = m.type,
                      _ = m.stateNode;
                    if (!(m.flags & 128) && (typeof P.getDerivedStateFromError == "function" || _ !== null && typeof _.componentDidCatch == "function" && (Uo === null || !Uo.has(_)))) {
                      m.flags |= 65536, o &= -o, m.lanes |= o;
                      var $ = Hw(m, I, o);
                      hw(m, $);
                      break e;
                    }
                }
                m = m.return;
              } while (m !== null);
            }
            EE(u);
          } catch (te) {
            o = te, fr === u && u !== null && (fr = u = u.return);
            continue;
          }
          break;
        } while (!0);
      }
      function bE() {
        var n = qf.current;
        return qf.current = mf, n === null ? mf : n;
      }
      function Nv() {
        (yr === 0 || yr === 3 || yr === 2) && (yr = 4), Ar === null || !(Gi & 268435455) && !(Tf & 268435455) || Vo(Ar, Lr);
      }
      function Mf(n, o) {
        var u = ye;
        ye |= 2;
        var c = bE();
        (Ar !== n || Lr !== o) && (mo = null, Ki(n, o));
        do try {
          N6();
          break;
        } catch (f) {
          SE(n, f);
        } while (!0);
        if (jh(), ye = u, qf.current = c, fr !== null) throw Error(l(261));
        return Ar = null, Lr = 0, yr;
      }
      function N6() {
        for (; fr !== null;) wE(fr);
      }
      function R6() {
        for (; fr !== null && !i6();) wE(fr);
      }
      function wE(n) {
        var o = PE(n.alternate, n, kt);
        n.memoizedProps = n.pendingProps, o === null ? EE(n) : fr = o, Ev.current = null;
      }
      function EE(n) {
        var o = n;
        do {
          var u = o.alternate;
          if (n = o.return, o.flags & 32768) {
            if (u = P6(u, o), u !== null) {
              u.flags &= 32767, fr = u;
              return;
            }
            if (n !== null) n.flags |= 32768, n.subtreeFlags = 0, n.deletions = null;else {
              yr = 6, fr = null;
              return;
            }
          } else if (u = I6(u, o, kt), u !== null) {
            fr = u;
            return;
          }
          if (o = o.sibling, o !== null) {
            fr = o;
            return;
          }
          fr = o = n;
        } while (o !== null);
        yr === 0 && (yr = 5);
      }
      function Yi(n, o, u) {
        var c = Pe,
          f = lr.transition;
        try {
          lr.transition = null, Pe = 1, M6(n, o, u, c);
        } finally {
          lr.transition = f, Pe = c;
        }
        return null;
      }
      function M6(n, o, u, c) {
        do Xi(); while (Ho !== null);
        if (ye & 6) throw Error(l(327));
        u = n.finishedWork;
        var f = n.finishedLanes;
        if (u === null) return null;
        if (n.finishedWork = null, n.finishedLanes = 0, u === n.current) throw Error(l(177));
        n.callbackNode = null, n.callbackPriority = 0;
        var m = u.lanes | u.childLanes;
        if (o6(n, m), n === Ar && (fr = Ar = null, Lr = 0), !(u.subtreeFlags & 2064) && !(u.flags & 2064) || Af || (Af = !0, qE(Rh, function () {
          return Xi(), null;
        })), m = (u.flags & 15990) !== 0, u.subtreeFlags & 15990 || m) {
          m = lr.transition, lr.transition = null;
          var y = Pe;
          Pe = 1;
          var I = ye;
          ye |= 4, Ev.current = null, T6(n, u), fE(u, n), ji(n.containerInfo), n.current = u, O6(u, n, f), a6(), ye = I, Pe = y, lr.transition = m;
        } else n.current = u;
        if (Af && (Af = !1, Ho = n, _f = f), m = n.pendingLanes, m === 0 && (Uo = null), l6(u.stateNode, c), gt(n, Tr()), o !== null) for (c = n.onRecoverableError, u = 0; u < o.length; u++) f = o[u], c(f.value, {
          componentStack: f.stack,
          digest: f.digest
        });
        if (Of) throw Of = !1, n = qv, qv = null, n;
        return _f & 1 && n.tag !== 0 && Xi(), m = n.pendingLanes, m & 1 ? n === Tv ? Qu++ : (Qu = 0, Tv = n) : Qu = 0, Fn(), null;
      }
      function Xi() {
        if (Ho !== null) {
          var n = rw(_f),
            o = lr.transition,
            u = Pe;
          try {
            if (lr.transition = null, Pe = 16 > n ? 16 : n, Ho === null) var c = !1;else {
              if (n = Ho, Ho = null, _f = 0, ye & 6) throw Error(l(331));
              var f = ye;
              for (ye |= 4, V = n.current; V !== null;) {
                var m = V,
                  y = m.child;
                if (V.flags & 16) {
                  var I = m.deletions;
                  if (I !== null) {
                    for (var A = 0; A < I.length; A++) {
                      var z = I[A];
                      for (V = z; V !== null;) {
                        var G = V;
                        switch (G.tag) {
                          case 0:
                          case 11:
                          case 15:
                            Gu(8, G, m);
                        }
                        var ce = G.child;
                        if (ce !== null) ce.return = G, V = ce;else for (; V !== null;) {
                          G = V;
                          var H = G.sibling,
                            je = G.return;
                          if (sE(G), G === z) {
                            V = null;
                            break;
                          }
                          if (H !== null) {
                            H.return = je, V = H;
                            break;
                          }
                          V = je;
                        }
                      }
                    }
                    var ke = m.alternate;
                    if (ke !== null) {
                      var yt = ke.child;
                      if (yt !== null) {
                        ke.child = null;
                        do {
                          var ho = yt.sibling;
                          yt.sibling = null, yt = ho;
                        } while (yt !== null);
                      }
                    }
                    V = m;
                  }
                }
                if (m.subtreeFlags & 2064 && y !== null) y.return = m, V = y;else e: for (; V !== null;) {
                  if (m = V, m.flags & 2048) switch (m.tag) {
                    case 0:
                    case 11:
                    case 15:
                      Gu(9, m, m.return);
                  }
                  var O = m.sibling;
                  if (O !== null) {
                    O.return = m.return, V = O;
                    break e;
                  }
                  V = m.return;
                }
              }
              var P = n.current;
              for (V = P; V !== null;) {
                y = V;
                var _ = y.child;
                if (y.subtreeFlags & 2064 && _ !== null) _.return = y, V = _;else e: for (y = P; V !== null;) {
                  if (I = V, I.flags & 2048) try {
                    switch (I.tag) {
                      case 0:
                      case 11:
                      case 15:
                        bf(9, I);
                    }
                  } catch (te) {
                    Ye(I, I.return, te);
                  }
                  if (I === y) {
                    V = null;
                    break e;
                  }
                  var $ = I.sibling;
                  if ($ !== null) {
                    $.return = I.return, V = $;
                    break e;
                  }
                  V = I.return;
                }
              }
              if (ye = f, Fn(), Bn && typeof Bn.onPostCommitFiberRoot == "function") try {
                Bn.onPostCommitFiberRoot(Qc, n);
              } catch (_unused59) {}
              c = !0;
            }
            return c;
          } finally {
            Pe = u, lr.transition = o;
          }
        }
        return !1;
      }
      function CE(n, o, u) {
        o = Ja(u, o), o = Uw(n, o, 1), n = jo(n, o, 1), o = Yr(), n !== null && (ku(n, 1, o), gt(n, o));
      }
      function Ye(n, o, u) {
        if (n.tag === 3) CE(n, n, u);else for (; o !== null;) {
          if (o.tag === 3) {
            CE(o, n, u);
            break;
          } else if (o.tag === 1) {
            var c = o.stateNode;
            if (typeof o.type.getDerivedStateFromError == "function" || typeof c.componentDidCatch == "function" && (Uo === null || !Uo.has(c))) {
              n = Ja(u, n), n = Hw(o, n, 1), o = jo(o, n, 1), n = Yr(), o !== null && (ku(o, 1, n), gt(o, n));
              break;
            }
          }
          o = o.return;
        }
      }
      function k6(n, o, u) {
        var c = n.pingCache;
        c !== null && c.delete(o), o = Yr(), n.pingedLanes |= n.suspendedLanes & u, Ar === n && (Lr & u) === u && (yr === 4 || yr === 3 && (Lr & 130023424) === Lr && 500 > Tr() - Iv ? Ki(n, 0) : Cv |= u), gt(n, o);
      }
      function IE(n, o) {
        o === 0 && (n.mode & 1 ? (o = Yc, Yc <<= 1, !(Yc & 130023424) && (Yc = 4194304)) : o = 1);
        var u = Yr();
        n = Ln(n, o), n !== null && (ku(n, o, u), gt(n, u));
      }
      function D6(n) {
        var o = n.memoizedState,
          u = 0;
        o !== null && (u = o.retryLane), IE(n, u);
      }
      function B6(n, o) {
        var u = 0;
        switch (n.tag) {
          case 13:
            var c = n.stateNode,
              f = n.memoizedState;
            f !== null && (u = f.retryLane);
            break;
          case 19:
            c = n.stateNode;
            break;
          default:
            throw Error(l(314));
        }
        c !== null && c.delete(o), IE(n, u);
      }
      var PE;
      PE = function PE(n, o, u) {
        if (n !== null) {
          if (n.memoizedProps !== o.pendingProps || dt.current) ht = !0;else {
            if (!(n.lanes & u) && !(o.flags & 128)) return ht = !1, C6(n, o, u);
            ht = !!(n.flags & 131072);
          }
        } else ht = !1, Ke && o.flags & 1048576 && ow(o, ef, o.index);
        switch (o.lanes = 0, o.tag) {
          case 2:
            var c = o.type;
            gf(n, o), n = o.pendingProps;
            var f = Ha(o, Vr.current);
            Ya(o, u), f = Jh(null, o, c, n, f, u);
            var m = Zh();
            return o.flags |= 1, _typeof(f) == "object" && f !== null && typeof f.render == "function" && f.$$typeof === void 0 ? (o.tag = 1, o.memoizedState = null, o.updateQueue = null, mt(c) ? (m = !0, Gc(o)) : m = !1, o.memoizedState = f.state !== null && f.state !== void 0 ? f.state : null, Vh(o), f.updater = hf, o.stateNode = f, f._reactInternals = o, iv(o, c, n, u), o = lv(null, o, c, !0, m, u)) : (o.tag = 0, Ke && m && kh(o), nt(null, o, f, u), o = o.child), o;
          case 16:
            c = o.elementType;
            e: {
              switch (gf(n, o), n = o.pendingProps, f = c._init, c = f(c._payload), o.type = c, f = o.tag = L6(c), n = Sn(c, n), f) {
                case 0:
                  o = uv(null, o, c, n, u);
                  break e;
                case 1:
                  o = Jw(null, o, c, n, u);
                  break e;
                case 11:
                  o = Gw(null, o, c, n, u);
                  break e;
                case 14:
                  o = Kw(null, o, c, Sn(c.type, n), u);
                  break e;
              }
              throw Error(l(306, c, ""));
            }
            return o;
          case 0:
            return c = o.type, f = o.pendingProps, f = o.elementType === c ? f : Sn(c, f), uv(n, o, c, f, u);
          case 1:
            return c = o.type, f = o.pendingProps, f = o.elementType === c ? f : Sn(c, f), Jw(n, o, c, f, u);
          case 3:
            e: {
              if (Zw(o), n === null) throw Error(l(387));
              c = o.pendingProps, m = o.memoizedState, f = m.element, mw(n, o), uf(o, c, null, u);
              var y = o.memoizedState;
              if (c = y.element, $t && m.isDehydrated) {
                if (m = {
                  element: c,
                  isDehydrated: !1,
                  cache: y.cache,
                  pendingSuspenseBoundaries: y.pendingSuspenseBoundaries,
                  transitions: y.transitions
                }, o.updateQueue.baseState = m, o.memoizedState = m, o.flags & 256) {
                  f = Ja(Error(l(423)), o), o = eE(n, o, c, u, f);
                  break e;
                } else if (c !== f) {
                  f = Ja(Error(l(424)), o), o = eE(n, o, c, u, f);
                  break e;
                } else for ($t && (Gt = L3(o.stateNode.containerInfo), Mt = o, Ke = !0, xn = null, Du = !1), u = fw(o, null, c, u), o.child = u; u;) u.flags = u.flags & -3 | 4096, u = u.sibling;
              } else {
                if (Wa(), c === f) {
                  o = po(n, o, u);
                  break e;
                }
                nt(n, o, c, u);
              }
              o = o.child;
            }
            return o;
          case 5:
            return gw(o), n === null && Fh(o), c = o.type, f = o.pendingProps, m = n !== null ? n.memoizedProps : null, y = f.children, tr(c, f) ? y = null : m !== null && tr(c, m) && (o.flags |= 32), Qw(n, o), nt(n, o, y, u), o.child;
          case 6:
            return n === null && Fh(o), null;
          case 13:
            return rE(n, o, u);
          case 4:
            return Wh(o, o.stateNode.containerInfo), c = o.pendingProps, n === null ? o.child = Ga(o, null, c, u) : nt(n, o, c, u), o.child;
          case 11:
            return c = o.type, f = o.pendingProps, f = o.elementType === c ? f : Sn(c, f), Gw(n, o, c, f, u);
          case 7:
            return nt(n, o, o.pendingProps, u), o.child;
          case 8:
            return nt(n, o, o.pendingProps.children, u), o.child;
          case 12:
            return nt(n, o, o.pendingProps.children, u), o.child;
          case 10:
            e: {
              if (c = o.type._context, f = o.pendingProps, m = o.memoizedProps, y = f.value, pw(o, c, y), m !== null) if (yn(m.value, y)) {
                if (m.children === f.children && !dt.current) {
                  o = po(n, o, u);
                  break e;
                }
              } else for (m = o.child, m !== null && (m.return = o); m !== null;) {
                var I = m.dependencies;
                if (I !== null) {
                  y = m.child;
                  for (var A = I.firstContext; A !== null;) {
                    if (A.context === c) {
                      if (m.tag === 1) {
                        A = fo(-1, u & -u), A.tag = 2;
                        var z = m.updateQueue;
                        if (z !== null) {
                          z = z.shared;
                          var G = z.pending;
                          G === null ? A.next = A : (A.next = G.next, G.next = A), z.pending = A;
                        }
                      }
                      m.lanes |= u, A = m.alternate, A !== null && (A.lanes |= u), Hh(m.return, u, o), I.lanes |= u;
                      break;
                    }
                    A = A.next;
                  }
                } else if (m.tag === 10) y = m.type === o.type ? null : m.child;else if (m.tag === 18) {
                  if (y = m.return, y === null) throw Error(l(341));
                  y.lanes |= u, I = y.alternate, I !== null && (I.lanes |= u), Hh(y, u, o), y = m.sibling;
                } else y = m.child;
                if (y !== null) y.return = m;else for (y = m; y !== null;) {
                  if (y === o) {
                    y = null;
                    break;
                  }
                  if (m = y.sibling, m !== null) {
                    m.return = y.return, y = m;
                    break;
                  }
                  y = y.return;
                }
                m = y;
              }
              nt(n, o, f.children, u), o = o.child;
            }
            return o;
          case 9:
            return f = o.type, c = o.pendingProps.children, Ya(o, u), f = Kt(f), c = c(f), o.flags |= 1, nt(n, o, c, u), o.child;
          case 14:
            return c = o.type, f = Sn(c, o.pendingProps), f = Sn(c.type, f), Kw(n, o, c, f, u);
          case 15:
            return Yw(n, o, o.type, o.pendingProps, u);
          case 17:
            return c = o.type, f = o.pendingProps, f = o.elementType === c ? f : Sn(c, f), gf(n, o), o.tag = 1, mt(c) ? (n = !0, Gc(o)) : n = !1, Ya(o, u), zw(o, c, f), iv(o, c, f, u), lv(null, o, c, !0, n, u);
          case 19:
            return nE(n, o, u);
          case 22:
            return Xw(n, o, u);
        }
        throw Error(l(156, o.tag));
      };
      function qE(n, o) {
        return _h(n, o);
      }
      function F6(n, o, u, c) {
        this.tag = n, this.key = u, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = o, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = c, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
      }
      function Jt(n, o, u, c) {
        return new F6(n, o, u, c);
      }
      function Rv(n) {
        return n = n.prototype, !(!n || !n.isReactComponent);
      }
      function L6(n) {
        if (typeof n == "function") return Rv(n) ? 1 : 0;
        if (n != null) {
          if (n = n.$$typeof, n === E) return 11;
          if (n === D) return 14;
        }
        return 2;
      }
      function Wo(n, o) {
        var u = n.alternate;
        return u === null ? (u = Jt(n.tag, o, n.key, n.mode), u.elementType = n.elementType, u.type = n.type, u.stateNode = n.stateNode, u.alternate = n, n.alternate = u) : (u.pendingProps = o, u.type = n.type, u.flags = 0, u.subtreeFlags = 0, u.deletions = null), u.flags = n.flags & 14680064, u.childLanes = n.childLanes, u.lanes = n.lanes, u.child = n.child, u.memoizedProps = n.memoizedProps, u.memoizedState = n.memoizedState, u.updateQueue = n.updateQueue, o = n.dependencies, u.dependencies = o === null ? null : {
          lanes: o.lanes,
          firstContext: o.firstContext
        }, u.sibling = n.sibling, u.index = n.index, u.ref = n.ref, u;
      }
      function kf(n, o, u, c, f, m) {
        var y = 2;
        if (c = n, typeof n == "function") Rv(n) && (y = 1);else if (typeof n == "string") y = 5;else e: switch (n) {
          case g:
            return Qi(u.children, f, m, o);
          case x:
            y = 8, f |= 8;
            break;
          case S:
            return n = Jt(12, u, o, f | 2), n.elementType = S, n.lanes = m, n;
          case C:
            return n = Jt(13, u, o, f), n.elementType = C, n.lanes = m, n;
          case T:
            return n = Jt(19, u, o, f), n.elementType = T, n.lanes = m, n;
          case k:
            return Df(u, f, m, o);
          default:
            if (_typeof(n) == "object" && n !== null) switch (n.$$typeof) {
              case b:
                y = 10;
                break e;
              case q:
                y = 9;
                break e;
              case E:
                y = 11;
                break e;
              case D:
                y = 14;
                break e;
              case M:
                y = 16, c = null;
                break e;
            }
            throw Error(l(130, n == null ? n : _typeof(n), ""));
        }
        return o = Jt(y, u, o, f), o.elementType = n, o.type = c, o.lanes = m, o;
      }
      function Qi(n, o, u, c) {
        return n = Jt(7, n, c, o), n.lanes = u, n;
      }
      function Df(n, o, u, c) {
        return n = Jt(22, n, c, o), n.elementType = k, n.lanes = u, n.stateNode = {
          isHidden: !1
        }, n;
      }
      function Mv(n, o, u) {
        return n = Jt(6, n, null, o), n.lanes = u, n;
      }
      function kv(n, o, u) {
        return o = Jt(4, n.children !== null ? n.children : [], n.key, o), o.lanes = u, o.stateNode = {
          containerInfo: n.containerInfo,
          pendingChildren: null,
          implementation: n.implementation
        }, o;
      }
      function z6(n, o, u, c, f) {
        this.tag = o, this.containerInfo = n, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = bh, this.callbackNode = this.pendingContext = this.context = null, this.callbackPriority = 0, this.eventTimes = Oh(0), this.expirationTimes = Oh(-1), this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = Oh(0), this.identifierPrefix = c, this.onRecoverableError = f, $t && (this.mutableSourceEagerHydrationData = null);
      }
      function TE(n, o, u, c, f, m, y, I, A) {
        return n = new z6(n, o, u, I, A), o === 1 ? (o = 1, m === !0 && (o |= 8)) : o = 0, m = Jt(3, null, null, o), n.current = m, m.stateNode = n, m.memoizedState = {
          element: c,
          isDehydrated: u,
          cache: null,
          transitions: null,
          pendingSuspenseBoundaries: null
        }, Vh(m), n;
      }
      function OE(n) {
        if (!n) return Lo;
        n = n._reactInternals;
        e: {
          if (U(n) !== n || n.tag !== 1) throw Error(l(170));
          var o = n;
          do {
            switch (o.tag) {
              case 3:
                o = o.stateNode.context;
                break e;
              case 1:
                if (mt(o.type)) {
                  o = o.stateNode.__reactInternalMemoizedMergedChildContext;
                  break e;
                }
            }
            o = o.return;
          } while (o !== null);
          throw Error(l(171));
        }
        if (n.tag === 1) {
          var u = n.type;
          if (mt(u)) return Jb(n, u, o);
        }
        return o;
      }
      function AE(n) {
        var o = n._reactInternals;
        if (o === void 0) throw typeof n.render == "function" ? Error(l(188)) : (n = Object.keys(n).join(","), Error(l(268, n)));
        return n = re(o), n === null ? null : n.stateNode;
      }
      function _E(n, o) {
        if (n = n.memoizedState, n !== null && n.dehydrated !== null) {
          var u = n.retryLane;
          n.retryLane = u !== 0 && u < o ? u : o;
        }
      }
      function Bf(n, o) {
        _E(n, o), (n = n.alternate) && _E(n, o);
      }
      function j6(n) {
        return n = re(n), n === null ? null : n.stateNode;
      }
      function U6() {
        return null;
      }
      return t.attemptContinuousHydration = function (n) {
        if (n.tag === 13) {
          var o = Ln(n, 134217728);
          if (o !== null) {
            var u = Yr();
            Qt(o, n, 134217728, u);
          }
          Bf(n, 134217728);
        }
      }, t.attemptDiscreteHydration = function (n) {
        if (n.tag === 13) {
          var o = Ln(n, 1);
          if (o !== null) {
            var u = Yr();
            Qt(o, n, 1, u);
          }
          Bf(n, 1);
        }
      }, t.attemptHydrationAtCurrentPriority = function (n) {
        if (n.tag === 13) {
          var o = $o(n),
            u = Ln(n, o);
          if (u !== null) {
            var c = Yr();
            Qt(u, n, o, c);
          }
          Bf(n, o);
        }
      }, t.attemptSynchronousHydration = function (n) {
        switch (n.tag) {
          case 3:
            var o = n.stateNode;
            if (o.current.memoizedState.isDehydrated) {
              var u = Mu(o.pendingLanes);
              u !== 0 && (Ah(o, u | 1), gt(o, Tr()), !(ye & 6) && (rs(), Fn()));
            }
            break;
          case 13:
            xE(function () {
              var c = Ln(n, 1);
              if (c !== null) {
                var f = Yr();
                Qt(c, n, 1, f);
              }
            }), Bf(n, 1);
        }
      }, t.batchedUpdates = function (n, o) {
        var u = ye;
        ye |= 1;
        try {
          return n(o);
        } finally {
          ye = u, ye === 0 && (rs(), Jc && Fn());
        }
      }, t.createComponentSelector = function (n) {
        return {
          $$typeof: wf,
          value: n
        };
      }, t.createContainer = function (n, o, u, c, f, m, y) {
        return TE(n, o, !1, null, u, c, f, m, y);
      }, t.createHasPseudoClassSelector = function (n) {
        return {
          $$typeof: Ef,
          value: n
        };
      }, t.createHydrationContainer = function (n, o, u, c, f, m, y, I, A) {
        return n = TE(u, c, !0, n, f, m, y, I, A), n.context = OE(null), u = n.current, c = Yr(), f = $o(u), m = fo(c, f), m.callback = o !== null && o !== void 0 ? o : null, jo(u, m, f), n.current.lanes = f, ku(n, f, c), gt(n, c), n;
      }, t.createPortal = function (n, o, u) {
        var c = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
        return {
          $$typeof: v,
          key: c == null ? null : "" + c,
          children: n,
          containerInfo: o,
          implementation: u
        };
      }, t.createRoleSelector = function (n) {
        return {
          $$typeof: Cf,
          value: n
        };
      }, t.createTestNameSelector = function (n) {
        return {
          $$typeof: If,
          value: n
        };
      }, t.createTextSelector = function (n) {
        return {
          $$typeof: Pf,
          value: n
        };
      }, t.deferredUpdates = function (n) {
        var o = Pe,
          u = lr.transition;
        try {
          return lr.transition = null, Pe = 16, n();
        } finally {
          Pe = o, lr.transition = u;
        }
      }, t.discreteUpdates = function (n, o, u, c, f) {
        var m = Pe,
          y = lr.transition;
        try {
          return lr.transition = null, Pe = 1, n(o, u, c, f);
        } finally {
          Pe = m, lr.transition = y, ye === 0 && rs();
        }
      }, t.findAllNodes = wv, t.findBoundingRects = function (n, o) {
        if (!_u) throw Error(l(363));
        o = wv(n, o), n = [];
        for (var u = 0; u < o.length; u++) n.push(p3(o[u]));
        for (o = n.length - 1; 0 < o; o--) {
          u = n[o];
          for (var c = u.x, f = c + u.width, m = u.y, y = m + u.height, I = o - 1; 0 <= I; I--) if (o !== I) {
            var A = n[I],
              z = A.x,
              G = z + A.width,
              ce = A.y,
              H = ce + A.height;
            if (c >= z && m >= ce && f <= G && y <= H) {
              n.splice(o, 1);
              break;
            } else if (c !== z || u.width !== A.width || H < m || ce > y) {
              if (!(m !== ce || u.height !== A.height || G < c || z > f)) {
                z > c && (A.width += z - c, A.x = c), G < f && (A.width = f - z), n.splice(o, 1);
                break;
              }
            } else {
              ce > m && (A.height += ce - m, A.y = m), H < y && (A.height = y - ce), n.splice(o, 1);
              break;
            }
          }
        }
        return n;
      }, t.findHostInstance = AE, t.findHostInstanceWithNoPortals = function (n) {
        return n = be(n), n = n !== null ? se(n) : null, n === null ? null : n.stateNode;
      }, t.findHostInstanceWithWarning = function (n) {
        return AE(n);
      }, t.flushControlled = function (n) {
        var o = ye;
        ye |= 1;
        var u = lr.transition,
          c = Pe;
        try {
          lr.transition = null, Pe = 1, n();
        } finally {
          Pe = c, lr.transition = u, ye = o, ye === 0 && (rs(), Fn());
        }
      }, t.flushPassiveEffects = Xi, t.flushSync = xE, t.focusWithin = function (n, o) {
        if (!_u) throw Error(l(363));
        for (n = xv(n), o = vE(n, o), o = Array.from(o), n = 0; n < o.length;) {
          var u = o[n++];
          if (!Nu(u)) {
            if (u.tag === 5 && h3(u.stateNode)) return !0;
            for (u = u.child; u !== null;) o.push(u), u = u.sibling;
          }
        }
        return !1;
      }, t.getCurrentUpdatePriority = function () {
        return Pe;
      }, t.getFindAllNodesFailureDescription = function (n, o) {
        if (!_u) throw Error(l(363));
        var u = 0,
          c = [];
        n = [xv(n), 0];
        for (var f = 0; f < n.length;) {
          var m = n[f++],
            y = n[f++],
            I = o[y];
          if ((m.tag !== 5 || !Nu(m)) && (Sv(m, I) && (c.push(bv(I)), y++, y > u && (u = y)), y < o.length)) for (m = m.child; m !== null;) n.push(m, y), m = m.sibling;
        }
        if (u < o.length) {
          for (n = []; u < o.length; u++) n.push(bv(o[u]));
          return "findAllNodes was able to match part of the selector:\n  " + (c.join(" > ") + "\n\nNo matching component was found for:\n  ") + n.join(" > ");
        }
        return null;
      }, t.getPublicRootInstance = function (n) {
        if (n = n.current, !n.child) return null;
        switch (n.child.tag) {
          case 5:
            return Me(n.child.stateNode);
          default:
            return n.child.stateNode;
        }
      }, t.injectIntoDevTools = function (n) {
        if (n = {
          bundleType: n.bundleType,
          version: n.version,
          rendererPackageName: n.rendererPackageName,
          rendererConfig: n.rendererConfig,
          overrideHookState: null,
          overrideHookStateDeletePath: null,
          overrideHookStateRenamePath: null,
          overrideProps: null,
          overridePropsDeletePath: null,
          overridePropsRenamePath: null,
          setErrorHandler: null,
          setSuspenseHandler: null,
          scheduleUpdate: null,
          currentDispatcherRef: p.ReactCurrentDispatcher,
          findHostInstanceByFiber: j6,
          findFiberByHostInstance: n.findFiberByHostInstance || U6,
          findHostInstancesForRefresh: null,
          scheduleRefresh: null,
          scheduleRoot: null,
          setRefreshHandler: null,
          getCurrentFiber: null,
          reconcilerVersion: "18.3.1"
        }, (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === "undefined" ? "undefined" : _typeof(__REACT_DEVTOOLS_GLOBAL_HOOK__)) > "u") n = !1;else {
          var o = __REACT_DEVTOOLS_GLOBAL_HOOK__;
          if (o.isDisabled || !o.supportsFiber) n = !0;else {
            try {
              Qc = o.inject(n), Bn = o;
            } catch (_unused60) {}
            n = !!o.checkDCE;
          }
        }
        return n;
      }, t.isAlreadyRendering = function () {
        return !1;
      }, t.observeVisibleRects = function (n, o, u, c) {
        if (!_u) throw Error(l(363));
        n = wv(n, o);
        var f = v3(n, u, c).disconnect;
        return {
          disconnect: function disconnect() {
            f();
          }
        };
      }, t.registerMutableSourceForHydration = function (n, o) {
        var u = o._getVersion;
        u = u(o._source), n.mutableSourceEagerHydrationData == null ? n.mutableSourceEagerHydrationData = [o, u] : n.mutableSourceEagerHydrationData.push(o, u);
      }, t.runWithPriority = function (n, o) {
        var u = Pe;
        try {
          return Pe = n, o();
        } finally {
          Pe = u;
        }
      }, t.shouldError = function () {
        return null;
      }, t.shouldSuspend = function () {
        return !1;
      }, t.updateContainer = function (n, o, u, c) {
        var f = o.current,
          m = Yr(),
          y = $o(f);
        return u = OE(u), o.context === null ? o.context = u : o.pendingContext = u, o = fo(m, y), o.payload = {
          element: n
        }, c = c === void 0 ? null : c, c !== null && (o.callback = c), n = jo(f, o, y), n !== null && (Qt(n, f, y, m), sf(n, f, y)), y;
      }, t;
    };
  });
  var Z4 = h(function (NLe, J4) {
    "use strict";

    J4.exports = Q4();
  });
  var ej = h(function (Ba) {
    "use strict";

    Ba.ConcurrentRoot = 1;
    Ba.ContinuousEventPriority = 4;
    Ba.DefaultEventPriority = 16;
    Ba.DiscreteEventPriority = 1;
    Ba.IdleEventPriority = 536870912;
    Ba.LegacyRoot = 0;
  });
  var tj = h(function (MLe, rj) {
    "use strict";

    rj.exports = ej();
  });
  var lj = h(function (uj) {
    "use strict";

    var Nc = Z();
    function e0e(e, r) {
      return e === r && (e !== 0 || 1 / e === 1 / r) || e !== e && r !== r;
    }
    var r0e = typeof Object.is == "function" ? Object.is : e0e,
      t0e = Nc.useSyncExternalStore,
      n0e = Nc.useRef,
      o0e = Nc.useEffect,
      i0e = Nc.useMemo,
      a0e = Nc.useDebugValue;
    uj.useSyncExternalStoreWithSelector = function (e, r, t, i, a) {
      var s = n0e(null);
      if (s.current === null) {
        var l = {
          hasValue: !1,
          value: null
        };
        s.current = l;
      } else l = s.current;
      s = i0e(function () {
        function d(b) {
          if (!v) {
            if (v = !0, g = b, b = i(b), a !== void 0 && l.hasValue) {
              var q = l.value;
              if (a(q, b)) return x = q;
            }
            return x = b;
          }
          if (q = x, r0e(g, b)) return q;
          var E = i(b);
          return a !== void 0 && a(q, E) ? q : (g = b, x = E);
        }
        var v = !1,
          g,
          x,
          S = t === void 0 ? null : t;
        return [function () {
          return d(r());
        }, S === null ? void 0 : function () {
          return d(S());
        }];
      }, [r, t, i, a]);
      var p = t0e(e, s[0], s[1]);
      return o0e(function () {
        l.hasValue = !0, l.value = p;
      }, [p]), a0e(p), p;
    };
  });
  var fj = h(function (QLe, cj) {
    "use strict";

    cj.exports = lj();
  });
  var VAe = j(Q1()),
    WAe = j(vI()),
    GAe = j(wI()),
    KAe = j(TI()),
    YAe = j(kI()),
    XAe = j(Rq()),
    QAe = j(Fq()),
    JAe = j(Wq()),
    ZAe = j(BT()),
    e_e = j(UT()),
    r_e = j(GT()),
    t_e = j(JT()),
    n_e = j(tA()),
    o_e = j(pA()),
    i_e = j(Py()),
    a_e = j(Py()),
    s_e = j(qA()),
    u_e = j(NA()),
    l_e = j(jA()),
    c_e = j(VA()),
    f_e = j(YA()),
    p_e = j(rR()),
    d_e = j(kM()),
    m_e = j(bD()),
    fL = j(sF()),
    gS = j(YF()),
    yS = j(tL()),
    pL = j(sL());
  var Cr;
  function vS() {
    return Cr || (Cr = Function("return this")(), Cr);
  }
  Cr = vS();
  Cr.globalThis = Cr;
  Cr.global = Cr;
  Cr.Uint8Array = Array;
  Cr.self = Cr;
  var ac = (_Cr$console = Cr.console) === null || _Cr$console === void 0 ? void 0 : _Cr$console.log;
  Cr.console = {
    log: ac !== null && ac !== void 0 ? ac : Cr.print,
    error: ac !== null && ac !== void 0 ? ac : Cr.print,
    info: ac !== null && ac !== void 0 ? ac : Cr.print,
    debug: ac !== null && ac !== void 0 ? ac : Cr.print,
    warn: ac !== null && ac !== void 0 ? ac : Cr.print
  };
  function bme(e) {
    return e("return this");
  }
  var uL = (typeof globalThis === "undefined" ? "undefined" : _typeof(globalThis)) < "u" ? globalThis : (typeof global === "undefined" ? "undefined" : _typeof(global)) < "u" ? global : (typeof self === "undefined" ? "undefined" : _typeof(self)) < "u" ? self : (typeof window === "undefined" ? "undefined" : _typeof(window)) < "u" ? window : bme(Function);
  function Ud(e, r) {
    return _typeof(uL[e]) > "u" ? r : uL[e];
  }
  var Hd = /*#__PURE__*/function () {
    function Hd() {
      _classCallCheck(this, Hd);
    }
    return _createClass(Hd, [{
      key: "encode",
      value: function encode(r) {
        var t = r.length,
          i = new Uint8Array(t);
        for (var a = 0; a < t; a++) i[a] = r.charCodeAt(a);
        return i;
      }
    }]);
  }();
  var lL = Ud("TextEncoder", Hd);
  var $d = /*#__PURE__*/function () {
    function $d(r) {
      _classCallCheck(this, $d);
      _defineProperty(this, "__encoding", void 0);
      this.__encoding = r;
    }
    return _createClass($d, [{
      key: "decode",
      value: function decode(r) {
        var t = "";
        for (var i = 0, a = r.length; i < a; i++) t += String.fromCharCode(r[i]);
        return t;
      }
    }]);
  }();
  var cL = Ud("TextDecoder", $d);
  var eo = vS();
  eo.TextEncoder = lL;
  eo.TextDecoder = cL;
  eo.Map = yS.default;
  eo.WeakMap = yS.default;
  eo.Set = gS.default;
  eo.WeakSet = gS.default;
  eo.Symbol = pL.default;
  eo.Promise = fL.default;
  eo.performance || (eo.performance = {
    now: function now() {
      return +new Date();
    }
  });
  Array.prototype.fill || (Array.prototype.fill = function (e, r, t) {
    r === void 0 && (r = 0), t === void 0 && (t = this.length), r = r >= 0 ? r : Math.max(0, this.length + r), t = t >= 0 ? t : Math.max(0, this.length + t);
    for (var i = r; i < t; i++) this[i] = e;
    return this;
  });
  function wme(e, r) {
    return e.__proto__ = r, e;
  }
  function Eme(e, r) {
    for (var t in r) Object.prototype.hasOwnProperty.call(e, t) || (e[t] = r[t]);
    return e;
  }
  Object.setPrototypeOf = {
    __proto__: []
  } instanceof Array ? wme : Eme;
  var dL = ["!", "@", "$", "%", "^", "&", "*", "(", ")", "-", "_", "=", "+", "[", "]", "{", "}", "\\", "|", ";", ":", '"', ",", ".", "<", ">", "/", "?", "`", "~"],
    mL = ["ESC", "ENTER", "BS", "SPACE"],
    xS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"],
    SS = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"],
    zs = "mpv-easy-config";
  function Nr(e) {
    return e.replaceAll("\\\\", "//").replaceAll("\\", "/");
  }
  function qn(e) {
    var _Nr$split$at;
    return (_Nr$split$at = Nr(e).split("/").at(-1)) === null || _Nr$split$at === void 0 ? void 0 : _Nr$split$at.split("?").at(0);
  }
  function js(e) {
    var _qn;
    var r = (_qn = qn(e)) === null || _qn === void 0 ? void 0 : _qn.split(".");
    if (!(!(r !== null && r !== void 0 && r.length) || r.length === 1)) return r.at(-1);
  }
  function hL(e) {
    return e.replaceAll("//", "\\").replaceAll("/", "\\");
  }
  var Wd = "3g2,3gp,asf,avi,f4v,flv,h264,h265,m2ts,m4v,mkv,mov,mp4,mp4v,mpeg,mpg,ogm,ogv,rm,rmvb,ts,vob,webm,wmv,y4m,m4s".split(","),
    Gd = "aac,ac3,aiff,ape,au,cue,dsf,dts,flac,m4a,mid,midi,mka,mp3,mp4a,oga,ogg,opus,spx,tak,tta,wav,weba,wma,wv".split(","),
    Kd = "apng,avif,bmp,gif,j2k,jp2,jfif,jpeg,jpg,jxl,mj2,png,svg,tga,tif,tiff,webp".split(","),
    uc = "aqt,ass,gsub,idx,jss,lrc,mks,pgs,pjs,psb,rt,sbv,slt,smi,sub,sup,srt,ssa,ssf,ttxt,txt,usf,vt,vtt".split(",");
  function wS(e, r) {
    if (!(e !== null && e !== void 0 && e.length)) return !1;
    var _iterator2 = _createForOfIteratorHelper(r),
      _step2;
    try {
      for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
        var t = _step2.value;
        if (e.endsWith(".".concat(t))) return !0;
      }
    } catch (err) {
      _iterator2.e(err);
    } finally {
      _iterator2.f();
    }
    return !1;
  }
  function Ime(e, r) {
    if (!(e !== null && e !== void 0 && e.length)) return !1;
    var _iterator3 = _createForOfIteratorHelper(r),
      _step3;
    try {
      for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
        var t = _step3.value;
        if (e.startsWith(t)) return !0;
      }
    } catch (err) {
      _iterator3.e(err);
    } finally {
      _iterator3.f();
    }
    return !1;
  }
  function tn(e) {
    return Ime(e, ["http", "webdav", "dav"]);
  }
  function Us(e) {
    var r = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : Wd;
    return wS(e, r);
  }
  function gL(e) {
    var r = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : Gd;
    return wS(e, r);
  }
  function yL(e) {
    var r = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : Kd;
    return wS(e, r);
  }
  function $e(e) {
    var r = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : !1;
    var t = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : !0;
    var i = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : !0;
    var a = ya({
      name: "subprocess",
      args: e,
      playback_only: r,
      capture_stdout: t,
      capture_stderr: i
    });
    if (a.status < 0) throw new Error("subprocess error status:".concat(a.status, " stderr:").concat(a.stderr));
    return a.stdout;
  }
  function nn(e) {
    var r = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : !1;
    var t = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : !0;
    var i = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : !0;
    return new Promise(function (a, s) {
      Yd({
        name: "subprocess",
        args: e,
        playback_only: r,
        capture_stdout: t,
        capture_stderr: i
      }, function (l, p, d) {
        l ? p.status < 0 ? s(p.stderr) : a(p.stdout) : s(d);
      });
    });
  }
  var Pme = {
    windows: "windows",
    linux: "linux",
    osx: "darwin",
    mac: "darwin",
    darwin: "darwin",
    "^mingw": "windows",
    "^cygwin": "windows",
    bsd$: "darwin",
    sunos: "darwin",
    android: "android"
  };
  var Vd;
  function Be() {
    if (Vd) return Vd;
    function e() {
      return fc("platform");
    }
    var r;
    function t() {
      if (r) return r;
      var a = ($e(["uname", "-s"]) || "").toLowerCase();
      r = "windows";
      for (var _i2 = 0, _Object$entries = Object.entries(Pme); _i2 < _Object$entries.length; _i2++) {
        var _Object$entries$_i = _slicedToArray(_Object$entries[_i2], 2),
          s = _Object$entries$_i[0],
          l = _Object$entries$_i[1];
        if (a.match(new RegExp(s))) {
          r = l;
          break;
        }
      }
      return r;
    }
    return Vd = e() || t(), Vd;
  }
  var ci = /*#__PURE__*/function () {
    function e(r, t, i, a) {
      _classCallCheck(this, e);
      this.x = r;
      this.y = t;
      this.width = i;
      this.height = a;
    }
    return _createClass(e, [{
      key: "x0",
      get: function get() {
        return this.x;
      }
    }, {
      key: "y0",
      get: function get() {
        return this.y;
      }
    }, {
      key: "x1",
      get: function get() {
        return this.x + this.width;
      }
    }, {
      key: "y1",
      get: function get() {
        return this.y + this.height;
      }
    }, {
      key: "toCoord",
      value: function toCoord() {
        return {
          x0: this.x0,
          y0: this.y0,
          x1: this.x1,
          y1: this.y1
        };
      }
    }, {
      key: "hasPoint",
      value: function hasPoint(r, t) {
        return r >= this.x0 && r <= this.x1 && t >= this.y0 && t <= this.y1;
      }
    }, {
      key: "placeCenter",
      value: function placeCenter(r) {
        var t = (this.width - r.width) / 2,
          i = (this.height - r.height) / 2,
          a = this.x + t,
          s = this.y + i;
        return new e(a, s, r.width, r.height);
      }
    }, {
      key: "scale",
      value: function scale(r) {
        return new e(this.x * r, this.y * r, this.width * r, this.height * r);
      }
    }], [{
      key: "fromCoord",
      value: function fromCoord(r) {
        return new e(r.x0, r.y0, r.x1 - r.x0, r.y1 - r.y0);
      }
    }]);
  }();
  var vL = !1,
    sc = -1,
    bS = 0;
  function lc() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 720;
    return vL || (vL = !0, sc = ut("osd-height") || 0, bS = e / sc, bL("osd-height", function (r) {
      sc !== r && r && (sc = r, bS = e / sc);
    })), bS;
  }
  function cc() {
    var e = [],
      r = ut("playlist-count") || 0;
    for (var t = 0; t < r; t++) {
      var _or;
      var i = Nr((_or = or("playlist/".concat(t, "/filename"))) !== null && _or !== void 0 ? _or : "");
      i.length && e.push(i);
    }
    return e;
  }
  function xL(e) {
    var r = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
    var t = cc(),
      i = t.length,
      a = Nr(or("path") || "");
    if (i === 0) {
      var _iterator4 = _createForOfIteratorHelper(e),
        _step4;
      try {
        for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
          var p = _step4.value;
          pe("loadfile \"".concat(p, "\" append"));
        }
      } catch (err) {
        _iterator4.e(err);
      } finally {
        _iterator4.f();
      }
      pe("playlist-play-index ".concat(r));
      return;
    }
    var s = t.indexOf(a);
    if (e.indexOf(a) === -1) {
      var _iterator5 = _createForOfIteratorHelper(e),
        _step5;
      try {
        for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
          var _p4 = _step5.value;
          pe("loadfile \"".concat(_p4, "\" append"));
        }
      } catch (err) {
        _iterator5.e(err);
      } finally {
        _iterator5.f();
      }
      pe("playlist-play-index ".concat(r + t.length));
      for (var _p3 = 0; _p3 < t.length; _p3++) pe("playlist-remove 0");
      return;
    }
    if (JSON.stringify(t) === JSON.stringify(e)) {
      s !== r && pe("playlist-play-index ".concat(r));
      return;
    }
    if (s === -1) {
      var _iterator6 = _createForOfIteratorHelper(e),
        _step6;
      try {
        for (_iterator6.s(); !(_step6 = _iterator6.n()).done;) {
          var _p6 = _step6.value;
          pe("loadfile \"".concat(_p6, "\" append"));
        }
      } catch (err) {
        _iterator6.e(err);
      } finally {
        _iterator6.f();
      }
      pe("playlist-play-index ".concat(r + i));
      for (var _p5 = 0; _p5 < t.length; _p5++) pe("playlist-remove 0");
    } else {
      for (var _p7 = 0; _p7 < s; _p7++) pe("playlist-remove 0");
      for (var _p8 = 0; _p8 < i - s - 1; _p8++) pe("playlist-remove 1");
      for (var _p9 = 0; _p9 < e.length; _p9++) _p9 !== r && pe("loadfile \"".concat(e[_p9], "\" insert-at ").concat(_p9));
      ut("playlist-pos") !== r && pe("playlist-play-index ".concat(r));
    }
  }
  function SL(e) {
    var r = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "replace";
    pe("loadfile ".concat(e, " ").concat(r));
  }
  function Tn(e, r) {
    Jr(e, r), print(e);
  }
  function Ae() {
    return globalThis.mp;
  }
  function pe(e) {
    return Ae().command(e);
  }
  function fi() {
    var _Ae;
    return (_Ae = Ae()).commandv.apply(_Ae, arguments);
  }
  function ya(e) {
    return Ae().command_native(e);
  }
  function Yd(e, r) {
    return Ae().command_native_async(e, r);
  }
  function fc(e, r) {
    return Ae().get_property(e, r);
  }
  function on(e, r) {
    return !!Ae().get_property_bool(e, r);
  }
  function or(e, r) {
    return Ae().get_property_native(e, r);
  }
  function ut(e, r) {
    return Ae().get_property_number(e, r);
  }
  function pi(e, r) {
    return Ae().get_property_native(e, r);
  }
  function wL(e, r) {
    return Ae().set_property(e, r);
  }
  function ir(e, r) {
    return Ae().set_property_bool(e, r);
  }
  function Jd(e, r) {
    return Ae().set_property(e, r);
  }
  function Ur(e, r) {
    return Ae().set_property_number(e, r);
  }
  function ro(e, r) {
    return Ae().set_property_native(e, r);
  }
  function lt(e, r, t, i) {
    return Ae().add_key_binding(e, r, t, i);
  }
  function Zd(e) {
    return Ae().remove_key_binding(e);
  }
  function EL(e, r) {
    return Ae().register_event(e, r);
  }
  function Lt(e, r, t) {
    return Ae().observe_property(e, r, t);
  }
  function bL(e, r) {
    return Lt(e, "number", function (t, i) {
      return r(i);
    });
  }
  function Jr(e, r) {
    return Ae().osd_message(e, r);
  }
  function pc(e, r) {
    return Ae().register_script_message(e, r);
  }
  function ES() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "ass-events";
    return Ae().create_osd_overlay(e);
  }
  function CL() {
    return Ae().get_osd_size();
  }
  var Xd;
  function dc() {
    return Xd || (Xd = Nr(Ae().get_script_file().split("/").slice(0, -1).join("/")), Xd);
  }
  var Qd;
  function Hs() {
    return Qd || (Qd = _e(dc(), zs), Qd);
  }
  function mc() {
    var _Ae$msg;
    return (_Ae$msg = Ae().msg).error.apply(_Ae$msg, arguments);
  }
  function IL(e, r) {
    return Ae().utils.readdir(e, r);
  }
  function hc(e) {
    return Ae().utils.file_info(e);
  }
  function qme(e) {
    return Ae().utils.split_path(e);
  }
  function _e() {
    for (var _len = arguments.length, e = new Array(_len), _key = 0; _key < _len; _key++) {
      e[_key] = arguments[_key];
    }
    return Nr(e.reduce(function (r, t) {
      return Ae().utils.join_path(r, t);
    }));
  }
  function em(e) {
    return Ae().utils.getenv(e);
  }
  function rm(e, r) {
    return Ae().utils.read_file(e, r);
  }
  function to(e, r) {
    var t = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "file://";
    return Ae().utils.write_file(t + e, r);
  }
  function an() {
    return globalThis.print.apply(globalThis, arguments);
  }
  function tm() {
    var e = ya(["expand-path", "~~home/"]),
      r = Be() === "windows" ? "mpv.exe" : "mpv",
      t = _e.apply(void 0, _toConsumableArray(qme(e).slice(0, -1)).concat([r]));
    return Be() === "windows" ? t.replaceAll("/", "\\\\") : t;
  }
  function di(e, r, t) {
    return Math.max(r, Math.min(e, t));
  }
  function PL() {
    return Math.random().toString(36).slice(2);
  }
  function Tt(e) {
    return !!hc(e);
  }
  function CS(e) {
    var _hc;
    return !!((_hc = hc(e)) !== null && _hc !== void 0 && _hc.is_dir);
  }
  function mi(e) {
    if (!(e !== null && e !== void 0 && e.length)) return;
    var r = e.split("/").slice(0, -1).join("/");
    if (CS(r)) return r;
  }
  function nm() {
    try {
      switch (Be()) {
        case "windows":
          {
            var e = on("ontop");
            e && ir("ontop", !1);
            var r = $e(["powershell", "-NoProfile", "-Command", "\nTrap {\n  Write-Error -ErrorRecord $_\n  Exit 1\n}\n\nAdd-Type -AssemblyName PresentationFramework\n\n$u8 = [System.Text.Encoding]::UTF8\n$out = [Console]::OpenStandardOutput()\n\n$ofd = New-Object -TypeName Microsoft.Win32.OpenFileDialog\n$ofd.Multiselect = $true\n\nIf ($ofd.ShowDialog() -eq $true) {\n  ForEach ($filename in $ofd.FileNames) {\n    $u8filename = $u8.GetBytes(\"$filename`n\")\n    $out.Write($u8filename, 0, $u8filename.Length)\n  }\n}\n"]);
            return e && ir("ontop", !0), r.trim().split("\n").map(function (i) {
              return i.trim();
            }).filter(function (i) {
              return Tt(i);
            });
          }
        default:
          return [];
      }
    } catch (e) {
      mc("openDialog error: ".concat(e));
    }
    return [];
  }
  var Ome = j(NL());
  function im(e) {
    return JSON.parse(e);
  }
  var sn = /*#__PURE__*/function () {
      function sn(r) {
        _classCallCheck(this, sn);
        this.name = r;
      }
      return _createClass(sn, [{
        key: "value",
        get: function get() {
          return ut(this.name);
        },
        set: function set(r) {
          Ur(this.name, r);
        }
      }, {
        key: "set",
        value: function set(r) {
          return this.value = r, this;
        }
      }, {
        key: "get",
        value: function get() {
          return this.value;
        }
      }, {
        key: "observe",
        value: function observe(r) {
          var t;
          Lt(this.name, "number", function (i, a) {
            (t !== a || _typeof(t) > "u") && (r(a), t = a);
          });
        }
      }]);
    }(),
    On = /*#__PURE__*/function () {
      function On(r) {
        _classCallCheck(this, On);
        this.name = r;
      }
      return _createClass(On, [{
        key: "value",
        get: function get() {
          return on(this.name);
        },
        set: function set(r) {
          ir(this.name, r);
        }
      }, {
        key: "set",
        value: function set(r) {
          return this.value = r, this;
        }
      }, {
        key: "on",
        value: function on() {
          return this.set(!0);
        }
      }, {
        key: "off",
        value: function off() {
          return this.set(!1);
        }
      }, {
        key: "cycle",
        value: function cycle() {
          return this.set(!this.value);
        }
      }, {
        key: "get",
        value: function get() {
          return this.value;
        }
      }, {
        key: "observe",
        value: function observe(r) {
          var t;
          Lt(this.name, "bool", function (i, a) {
            (t !== a || _typeof(t) > "u") && (r(a), t = a);
          });
        }
      }]);
    }(),
    Vs = /*#__PURE__*/function () {
      function Vs(r) {
        _classCallCheck(this, Vs);
        this.name = r;
      }
      return _createClass(Vs, [{
        key: "value",
        get: function get() {
          return or(this.name);
        },
        set: function set(r) {
          Jd(this.name, r);
        }
      }, {
        key: "set",
        value: function set(r) {
          return this.value = r, this;
        }
      }, {
        key: "get",
        value: function get() {
          return this.value;
        }
      }, {
        key: "observe",
        value: function observe(r) {
          var t;
          Lt(this.name, "string", function (i, a) {
            (t !== a || _typeof(t) > "u") && (r(a), t = a);
          });
        }
      }]);
    }(),
    Ot = /*#__PURE__*/function () {
      function Ot(r) {
        _classCallCheck(this, Ot);
        this.name = r;
      }
      return _createClass(Ot, [{
        key: "value",
        get: function get() {
          return pi(this.name);
        },
        set: function set(r) {
          ro(this.name, r);
        }
      }, {
        key: "set",
        value: function set(r) {
          return this.value = r, this;
        }
      }, {
        key: "get",
        value: function get() {
          return this.value;
        }
      }, {
        key: "observe",
        value: function observe(r) {
          var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : Object.is;
          var i;
          Lt(this.name, "native", function (a, s) {
            (_typeof(i) > "u" || !t(s, i)) && (i = s, r(s));
          });
        }
      }]);
    }();
  function RL(e, r, t) {
    var i = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : "powershell";
    to(e, r);
    var a = $e([i, e]);
    return t && (a = rm(t)), a;
  }
  function ML(e) {
    var r = Be(),
      _ref = r === "windows" ? ["cmd", "/c"] : ["sh", "-c"],
      _ref2 = _slicedToArray(_ref, 2),
      t = _ref2[0],
      i = _ref2[1];
    try {
      return $e([t, i, "where ".concat(e)]).length > 0;
    } catch (_unused61) {
      return !1;
    }
  }
  var Ws;
  function Ame() {
    if (Ws) return Ws;
    var e = $e(["powershell", "-c", 'Get-ItemProperty -Path "HKCU:\\Control Panel\\Cursors"']).trim();
    Ws = {
      Arrow: "",
      Hand: ""
    };
    var _iterator7 = _createForOfIteratorHelper(e.split("\n")),
      _step7;
    try {
      for (_iterator7.s(); !(_step7 = _iterator7.n()).done;) {
        var r = _step7.value;
        var t = r.indexOf(":"),
          i = r.slice(0, t).trim(),
          a = r.slice(t + 1).trim();
        i === "Arrow" ? Ws.Arrow = a : i === "Hand" && (Ws.Hand = a);
      }
    } catch (err) {
      _iterator7.e(err);
    } finally {
      _iterator7.f();
    }
    return Ws;
  }
  var qS;
  function TS(e) {
    qS || (qS = Ame());
    var r = qS[e];
    if (!r.length) return;
    var t = "Set-ItemProperty -Path 'HKCU:\\Control Panel\\Cursors' -Name 'Arrow' -Value '".concat(r, "';\nAdd-Type -TypeDefinition @'\npublic class SysParamsInfo {\n    [System.Runtime.InteropServices.DllImport(\"user32.dll\", EntryPoint = \"SystemParametersInfo\")]\n    public static extern bool SystemParametersInfo(uint uiAction, uint uiParam, uint pvParam, uint fWinIni);\n\n    const int SPI_SETCURSORS = 0x0057;\n    const int SPIF_UPDATEINIFILE = 0x01;\n    const int SPIF_SENDCHANGE = 0x02;\n\n    public static void CursorHasChanged() {\n        SystemParametersInfo(SPI_SETCURSORS, 0, 0, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);\n    }\n}\n'@\n[SysParamsInfo]::CursorHasChanged()"),
      a = _e(dc(), zs, "mpv_easy_tool_set_mouse_style.ps1");
    RL(a, t);
  }
  function kL(e) {
    return e |= 0, e < 60 ? "s" : e < 3600 ? "m:s" : "h:m:s";
  }
  function am(e, r) {
    switch (e |= 0, r) {
      case "s":
        return e.toString();
      case "m:s":
        {
          var t = e / 60 | 0,
            i = t.toString().padStart(2, "0"),
            a = (e - t * 60).toString().padStart(2, "0");
          return "".concat(i, ":").concat(a);
        }
      case "h:m:s":
        {
          var _t3 = e / 3600 | 0,
            _i3 = _t3.toString().padStart(2, "0"),
            _a2 = (e - _t3 * 3600) / 60 | 0,
            s = _a2.toString().padStart(2, "0"),
            l = (e - _t3 * 3600 - _a2 * 60).toString().padStart(2, "0");
          return "".concat(_i3, ":").concat(s, ":").concat(l);
        }
      default:
        throw new Error("formatTime error: second ".concat(e, " format ").concat(r));
    }
  }
  function DL(e, r) {
    if (!e) throw new Error(r || "Assertion failed");
  }
  function sm(e) {
    return Nme(e), Number.parseFloat(e.slice(0, -1)) / 100;
  }
  function _me(e) {
    return e.endsWith("%");
  }
  function Nme(e) {
    DL(_me(e), "not a valid percentage string: ".concat(e));
  }
  var um = [];
  function Rme() {
    for (var r = 0; r < um.length; r++) {
      var t = um[r];
      if (t && !t.busy) return t.busy = !0, t.overlay;
    }
    var e = ES();
    return e.remove = function () {
      e.hidden = !0, e.data = "", e.compute_bounds = !1, e.update(), um[e.id || 0].busy = !1;
    }, um[e.id || 0] = {
      overlay: e,
      busy: !0
    }, e;
  }
  var hi = /*#__PURE__*/function () {
    function hi() {
      var r = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      _classCallCheck(this, hi);
      _defineProperty(this, "overlay", void 0);
      _defineProperty(this, "cache", void 0);
      _defineProperty(this, "_lastResY", void 0);
      _defineProperty(this, "_lastResX", void 0);
      _defineProperty(this, "_lastHidden", void 0);
      _defineProperty(this, "_lastComputeBounds", void 0);
      _defineProperty(this, "_lastData", void 0);
      _defineProperty(this, "_lastZ", void 0);
      _defineProperty(this, "_lastRect", void 0);
      var _r$hidden = r.hidden,
        t = _r$hidden === void 0 ? !1 : _r$hidden,
        _r$resX = r.resX,
        i = _r$resX === void 0 ? 0 : _r$resX,
        _r$resY = r.resY,
        a = _r$resY === void 0 ? 720 : _r$resY,
        _r$z = r.z,
        s = _r$z === void 0 ? 0 : _r$z,
        _r$computeBounds = r.computeBounds,
        l = _r$computeBounds === void 0 ? !0 : _r$computeBounds,
        _r$data = r.data,
        p = _r$data === void 0 ? "" : _r$data,
        _r$cache = r.cache,
        d = _r$cache === void 0 ? !1 : _r$cache,
        _r$overlay = r.overlay,
        v = _r$overlay === void 0 ? Rme() : _r$overlay;
      v.res_x = i, v.res_y = a, v.hidden = t, v.compute_bounds = l, v.data = p, v.z = s, this.cache = d, this.overlay = v;
    }
    return _createClass(hi, [{
      key: "hidden",
      get: function get() {
        return this.overlay.hidden;
      },
      set: function set(r) {
        this.overlay.hidden = r;
      }
    }, {
      key: "computeBounds",
      get: function get() {
        return this.overlay.compute_bounds;
      },
      set: function set(r) {
        this.overlay.compute_bounds = r;
      }
    }, {
      key: "z",
      get: function get() {
        return this.overlay.z;
      },
      set: function set(r) {
        this.overlay.z = r;
      }
    }, {
      key: "data",
      get: function get() {
        return this.overlay.data;
      },
      set: function set(r) {
        this.overlay.data = r;
      }
    }, {
      key: "resX",
      get: function get() {
        return this.overlay.res_x;
      },
      set: function set(r) {
        this.overlay.res_x = r;
      }
    }, {
      key: "resY",
      get: function get() {
        return this.overlay.res_y;
      },
      set: function set(r) {
        this.overlay.res_y = r;
      }
    }, {
      key: "remove",
      value: function remove() {
        this.overlay.remove();
      }
    }, {
      key: "update",
      value: function update() {
        var r = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
        if (this.cache) {
          if (this._lastResX === this.resX && this._lastResY === this.resY && this._lastHidden === this.hidden && this._lastComputeBounds === this.computeBounds && this._lastData === this.data && this._lastZ === this.z) return this._lastRect;
          this._lastResY = this.resY, this._lastResX = this.resX, this._lastHidden = this.hidden, this._lastComputeBounds = this.computeBounds, this._lastData = this.data, this._lastZ = this.z;
          var i = this.overlay.update();
          return this._lastRect = ci.fromCoord(i).scale(r), this._lastRect;
        }
        var t = this.overlay.update();
        return ci.fromCoord(t).scale(r);
      }
    }]);
  }();
  var BL = 64,
    OS = new Array(BL).map(function () {
      return !1;
    }),
    lm = /*#__PURE__*/function () {
      function lm(r) {
        _classCallCheck(this, lm);
        _defineProperty(this, "x", 0);
        _defineProperty(this, "y", 0);
        _defineProperty(this, "file", "");
        _defineProperty(this, "offset", 0);
        _defineProperty(this, "fmt", "bgra");
        _defineProperty(this, "w", 0);
        _defineProperty(this, "h", 0);
        _defineProperty(this, "stride", 0);
        this.id = r;
        if (OS[r]) throw new Error("overlay's id has already been used.".concat(r));
        if (r < 0 || r >= BL) throw new Error("overlay's id must be in the range [0, 63]".concat(r));
        OS[r] = !0;
      }
      return _createClass(lm, [{
        key: "update",
        value: function update() {
          var r = "overlay-add ".concat(this.id, " ").concat(this.x, " ").concat(this.y, " \"").concat(this.file, "\" 0 ").concat(this.fmt, " ").concat(this.w, " ").concat(this.h, " ").concat(this.stride);
          pe(r);
        }
      }, {
        key: "remove",
        value: function remove() {
          pe("overlay-remove ".concat(this.id));
        }
      }, {
        key: "destroy",
        value: function destroy() {
          OS[this.id] = !1;
        }
      }]);
    }();
  var gi = {};
  Ju(gi, {
    ListReg: function ListReg() {
      return _S;
    },
    MoviesReg: function MoviesReg() {
      return AS;
    },
    StreamReg: function StreamReg() {
      return FL;
    },
    detailsReg: function detailsReg() {
      return NS;
    },
    getInfo: function getInfo() {
      return RS;
    },
    getNameFromUrl: function getNameFromUrl() {
      return Gme;
    },
    getPlayableListFromUrl: function getPlayableListFromUrl() {
      return Vme;
    },
    getPlayableListFromUrlAsync: function getPlayableListFromUrlAsync() {
      return Wme;
    },
    getPlaybackinfo: function getPlaybackinfo() {
      return jL;
    },
    getPlaybackinfoAsync: function getPlaybackinfoAsync() {
      return UL;
    },
    getPlaylist: function getPlaylist() {
      return LL;
    },
    getPlaylistAsync: function getPlaylistAsync() {
      return zL;
    },
    getUserId: function getUserId() {
      return jme;
    },
    getUserIdAsync: function getUserIdAsync() {
      return Ume;
    },
    getView: function getView() {
      return Hme;
    },
    getViewAsync: function getViewAsync() {
      return $me;
    },
    isJellyfin: function isJellyfin() {
      return zme;
    },
    videoReg: function videoReg() {
      return Lme;
    }
  });
  var Mme = "mpv-easy-ext",
    Oo = function Oo() {
      return _e(Hs(), Mme);
    },
    kme = "mpv-easy-ext-macos",
    Dme = "mpv-easy-ext-windows",
    Bme = "mpv-easy-ext-android",
    Fme = "mpv-easy-ext-linux";
  function dr() {
    var e = Be();
    switch (e) {
      case "darwin":
        return _e(Oo(), kme);
      case "linux":
        return _e(Oo(), Fme);
      case "windows":
        return _e(Oo(), Dme);
      case "android":
        return _e(Oo(), Bme);
      default:
        throw new Error("mpv-easy-ext not support os: ".concat(e));
    }
  }
  var AS = /^(https?):\/\/(.*?)\/web\/index.html#\!\/movies.html\?topParentId=(.*?)$/,
    _S = /^(https?):\/\/(.*?)\/web\/index.html#!\/list.html\?parentId=(.*?)&serverId=(.*?)$/,
    NS = /^(https?):\/\/(.*?)\/web\/index.html#!\/details\?id=(.*?)&serverId=(.*?)$/,
    Lme = /^(https?):\/\/(.*?)\/web\/index.html#!\/video$/,
    FL = /^(https?):\/\/(.*?)\/Videos\/(.*?)\/stream/;
  function zme(e) {
    return [AS, NS, FL, _S].some(function (r) {
      return r.test(e);
    });
  }
  function RS(e) {
    var r = e.match(AS);
    if (r) return {
      protocol: r[1],
      host: r[2],
      topParentId: r[3]
    };
    var t = e.match(NS);
    if (t) return {
      protocol: t[1],
      host: t[2],
      id: t[3],
      serverId: t[4]
    };
    var i = e.match(_S);
    if (i) return {
      protocol: i[1],
      host: i[2],
      topParentId: i[3]
    };
  }
  var vi = "jellyfin";
  function jme(e, r, t) {
    var i = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : dr();
    return $e([i, vi, "userid", e, r, t]);
  }
  function Ume(e, r, t) {
    var i = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : dr();
    return nn([i, vi, "userid", e, r, t]);
  }
  function Hme(e, r, t) {
    var i = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : dr();
    var a = $e([i, vi, "view", e, r, t]);
    return JSON.parse(a);
  }
  function $me(_x2, _x3, _x4) {
    return _$me.apply(this, arguments);
  }
  function _$me() {
    _$me = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee(e, r, t) {
      var i,
        a,
        _args = arguments;
      return _regeneratorRuntime().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            i = _args.length > 3 && _args[3] !== undefined ? _args[3] : dr();
            _context.next = 3;
            return nn([i, vi, "view", e, r, t]);
          case 3:
            a = _context.sent;
            return _context.abrupt("return", im(a));
          case 5:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }));
    return _$me.apply(this, arguments);
  }
  function LL(e, r, t, i) {
    var a = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : dr();
    var s = $e([a, vi, "playlist", e, r, t, i]);
    return JSON.parse(s);
  }
  function zL(_x5, _x6, _x7, _x8) {
    return _zL.apply(this, arguments);
  }
  function _zL() {
    _zL = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2(e, r, t, i) {
      var a,
        s,
        _args2 = arguments;
      return _regeneratorRuntime().wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            a = _args2.length > 4 && _args2[4] !== undefined ? _args2[4] : dr();
            _context2.next = 3;
            return nn([a, vi, "playlist", e, r, t, i]);
          case 3:
            s = _context2.sent;
            return _context2.abrupt("return", im(s));
          case 5:
          case "end":
            return _context2.stop();
        }
      }, _callee2);
    }));
    return _zL.apply(this, arguments);
  }
  function jL(e, r, t, i) {
    var a = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : dr();
    var s = $e([a, vi, "playbackinfo", e, r, t, i]);
    return JSON.parse(s);
  }
  function UL(_x9, _x10, _x11, _x12) {
    return _UL.apply(this, arguments);
  }
  function _UL() {
    _UL = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3(e, r, t, i) {
      var a,
        s,
        _args3 = arguments;
      return _regeneratorRuntime().wrap(function _callee3$(_context3) {
        while (1) switch (_context3.prev = _context3.next) {
          case 0:
            a = _args3.length > 4 && _args3[4] !== undefined ? _args3[4] : dr();
            _context3.next = 3;
            return nn([a, vi, "playbackinfo", e, r, t, i]);
          case 3:
            s = _context3.sent;
            return _context3.abrupt("return", im(s));
          case 5:
          case "end":
            return _context3.stop();
        }
      }, _callee3);
    }));
    return _UL.apply(this, arguments);
  }
  var gc = {};
  function Vme(e, r, t) {
    var i = RS(e);
    if (!i) return [];
    var a = i.host,
      s = i.topParentId,
      l = i.id,
      p = i.protocol,
      d = "".concat(p, "://").concat(a);
    return s ? LL(d, r, t, s).Items.map(function (g) {
      var x = g.Id,
        S = g.Name,
        b = "".concat(d, "/Videos/").concat(x, "/stream?Static=true");
      return gc[b] = S, {
        name: S,
        path: b
      };
    }) : l ? jL(d, r, t, l).MediaSources.map(function (g) {
      var x = "".concat(d, "/Videos/").concat(g.Id, "/stream?Static=true");
      return gc[x] = g.Path, {
        path: x,
        name: g.Path
      };
    }) : [];
  }
  function Wme(_x13, _x14, _x15) {
    return _Wme.apply(this, arguments);
  }
  function _Wme() {
    _Wme = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee4(e, r, t) {
      var i, a, s, l, p, d;
      return _regeneratorRuntime().wrap(function _callee4$(_context4) {
        while (1) switch (_context4.prev = _context4.next) {
          case 0:
            i = RS(e);
            if (i) {
              _context4.next = 3;
              break;
            }
            return _context4.abrupt("return", []);
          case 3:
            a = i.host, s = i.topParentId, l = i.id, p = i.protocol, d = "".concat(p, "://").concat(a);
            if (!s) {
              _context4.next = 10;
              break;
            }
            _context4.next = 7;
            return zL(d, r, t, s);
          case 7:
            _context4.t0 = _context4.sent.Items.map(function (g) {
              var x = g.Id,
                S = g.Name,
                b = "".concat(d, "/Videos/").concat(x, "/stream?Static=true");
              return gc[b] = S, {
                name: S,
                path: b
              };
            });
            _context4.next = 18;
            break;
          case 10:
            if (!l) {
              _context4.next = 16;
              break;
            }
            _context4.next = 13;
            return UL(d, r, t, l);
          case 13:
            _context4.t1 = _context4.sent.MediaSources.map(function (g) {
              var x = "".concat(d, "/Videos/").concat(g.Id, "/stream?Static=true");
              return gc[x] = g.Path, {
                path: x,
                name: g.Path
              };
            });
            _context4.next = 17;
            break;
          case 16:
            _context4.t1 = [];
          case 17:
            _context4.t0 = _context4.t1;
          case 18:
            return _context4.abrupt("return", _context4.t0);
          case 19:
          case "end":
            return _context4.stop();
        }
      }, _callee4);
    }));
    return _Wme.apply(this, arguments);
  }
  function Gme(e) {
    return gc[e];
  }
  function cm(e) {
    var r = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : dr();
    return $e([r, "fs", "mkdir", JSON.stringify(e)]);
  }
  function HL(e) {
    var r = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : dr();
    return $e([r, "fs", "remove_file", JSON.stringify(e)]);
  }
  var fz = j(cz());
  function pz() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : dr();
    var r = $e([e, "clipboard", "get"]);
    return JSON.parse(r);
  }
  function mm(e) {
    var r = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : dr();
    try {
      var t = fz.Buffer.from(e).toString("base64");
      return $e([r, "clipboard", "set", JSON.stringify(t)]), !0;
    } catch (t) {
      return mc(t), !1;
    }
  }
  function dz(e) {
    var r = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : dr();
    try {
      return $e([r, "clipboard", "set-image", JSON.stringify(e)]), !0;
    } catch (t) {
      return mc(t), !1;
    }
  }
  var vz = "%[a-f0-9]{2}",
    mz = new RegExp("(" + vz + ")|([^%]+?)", "gi"),
    hz = new RegExp("(" + vz + ")+", "gi");
  function $S(e, r) {
    try {
      return [decodeURIComponent(e.join(""))];
    } catch (_unused62) {}
    if (e.length === 1) return e;
    r = r || 1;
    var t = e.slice(0, r),
      i = e.slice(r);
    return Array.prototype.concat.call([], $S(t), $S(i));
  }
  function Phe(e) {
    try {
      return decodeURIComponent(e);
    } catch (_unused63) {
      var r = e.match(mz) || [];
      for (var t = 1; t < r.length; t++) e = $S(r, t).join(""), r = e.match(mz) || [];
      return e;
    }
  }
  function qhe(e) {
    var r = {
        "%FE%FF": "��",
        "%FF%FE": "��"
      },
      t = hz.exec(e);
    for (; t;) {
      try {
        r[t[0]] = decodeURIComponent(t[0]);
      } catch (_unused64) {
        var a = Phe(t[0]);
        a !== t[0] && (r[t[0]] = a);
      }
      t = hz.exec(e);
    }
    r["%C2"] = "�";
    var i = Object.keys(r);
    for (var _i5 = 0, _i4 = i; _i5 < _i4.length; _i5++) {
      var _a3 = _i4[_i5];
      e = e.replace(new RegExp(_a3, "g"), r[_a3]);
    }
    return e;
  }
  function VS(e) {
    if (typeof e != "string") throw new TypeError("Expected `encodedURI` to be of type `string`, got `" + _typeof(e) + "`");
    try {
      return decodeURIComponent(e);
    } catch (_unused65) {
      return qhe(e);
    }
  }
  function gz(e) {
    var r = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : dr();
    return JSON.parse($e([r, "fetch", JSON.stringify(e)]));
  }
  function yz(_x16) {
    return _yz.apply(this, arguments);
  }
  function _yz() {
    _yz = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee5(e) {
      var r,
        _args5 = arguments;
      return _regeneratorRuntime().wrap(function _callee5$(_context5) {
        while (1) switch (_context5.prev = _context5.next) {
          case 0:
            r = _args5.length > 1 && _args5[1] !== undefined ? _args5[1] : dr();
            _context5.t0 = JSON;
            _context5.next = 4;
            return nn([r, "fetch", JSON.stringify(e)]);
          case 4:
            _context5.t1 = _context5.sent;
            return _context5.abrupt("return", _context5.t0.parse.call(_context5.t0, _context5.t1));
          case 6:
          case "end":
            return _context5.stop();
        }
      }, _callee5);
    }));
    return _yz.apply(this, arguments);
  }
  function xz(e) {
    var r = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : dr();
    var t = $e([r, "webdav", "list", JSON.stringify(e)]);
    return JSON.parse(t).response.map(function (l) {
      return VS(l.href);
    }).filter(function (l) {
      var _qn2;
      return !!((_qn2 = qn(l)) !== null && _qn2 !== void 0 && _qn2.length);
    });
  }
  function xc() {
    return em("TMPDIR") || em("TMP") || em("tmp") || "./";
  }
  var vm = {};
  Ju(vm, {
    BangumiReg: function BangumiReg() {
      return wz;
    },
    LiveReg: function LiveReg() {
      return Ez;
    },
    MainReg: function MainReg() {
      return Sz;
    },
    PopularReg: function PopularReg() {
      return bz;
    },
    SpaceReg: function SpaceReg() {
      return Cz;
    },
    VideoReg: function VideoReg() {
      return WS;
    },
    getAid: function getAid() {
      return Ohe;
    },
    getBV: function getBV() {
      return The;
    },
    getBvid: function getBvid() {
      return Iz;
    },
    getCids: function getCids() {
      return Ahe;
    },
    getEpisodes: function getEpisodes() {
      return _he;
    },
    getSections: function getSections() {
      return Pz;
    },
    getVideoData: function getVideoData() {
      return Nhe;
    },
    isBilibili: function isBilibili() {
      return hm;
    }
  });
  var WS = /^https?:\/\/(.*?)\.bilibili.com\/video\/BV(.*?)\//,
    Sz = /^https?:\/\/(.*?)\.bilibili\.com\/(\?spm_id_from=(.*?))?\/?/,
    bz = /^https?:\/\/(.*?)\.bilibili\.com\/v\/popular/,
    wz = /^https?:\/\/(.*?)\.bilibili\.com\/bangumi/,
    Ez = /^https?:\/\/live.bilibili.com\/(.*?)/,
    Cz = /^https?:\/\/space.bilibili.com\/(.*?)/;
  function hm(e) {
    return [WS, Sz, bz, wz, Ez, Cz].some(function (r) {
      return r.test(e);
    });
  }
  function The(e) {
    var _e$match;
    return hm(e) ? (_e$match = e.match(WS)) === null || _e$match === void 0 ? void 0 : _e$match[2] : void 0;
  }
  function Ohe() {
    return globalThis === null || globalThis === void 0 ? void 0 : globalThis.__INITIAL_STATE__.aid;
  }
  function Iz() {
    return globalThis === null || globalThis === void 0 ? void 0 : globalThis.__INITIAL_STATE__.bvid;
  }
  function Ahe() {
    var e = Iz();
    return globalThis === null || globalThis === void 0 ? void 0 : globalThis.__INITIAL_STATE__.cidMap[e].cids;
  }
  function Pz() {
    return globalThis === null || globalThis === void 0 ? void 0 : globalThis.__INITIAL_STATE__.sections;
  }
  function _he() {
    var e = Pz(),
      r = [];
    for (var t in e) {
      var i = e[t].episodes;
      r.push(i);
    }
    return r.flat();
  }
  function Nhe() {
    return globalThis === null || globalThis === void 0 ? void 0 : globalThis.__INITIAL_STATE__.videoData;
  }
  var gm = {};
  Ju(gm, {
    TvReg: function TvReg() {
      return qz;
    },
    VideoReg: function VideoReg() {
      return Tz;
    },
    isTwitch: function isTwitch() {
      return GS;
    }
  });
  var qz = /^(?:https?:\/\/)(.*?).twitch\.tv\/(.*?)$/,
    Tz = /^(?:https?:\/\/)(.*?).twitch\.tv\/(.*?)\/video\/(.*?)$/;
  function GS(e) {
    return [qz, Tz].some(function (r) {
      return r.test(e);
    });
  }
  var ym = {};
  Ju(ym, {
    ListReg: function ListReg() {
      return khe;
    },
    MainPageReg: function MainPageReg() {
      return Rhe;
    },
    MyVideosReg: function MyVideosReg() {
      return Mhe;
    },
    VideoReg: function VideoReg() {
      return Dhe;
    },
    YoutubeRegex: function YoutubeRegex() {
      return Oz;
    },
    isYoutube: function isYoutube() {
      return KS;
    }
  });
  var Oz = /^(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/,
    Rhe = /^(?:https?:\/\/)(.*?)\.youtube\.(.*?)\/?$/,
    Mhe = /^(?:https?:\/\/)(.*?).youtube\.(.*?)\/@(.*?)\/videos\/?/,
    khe = /^(?:https?:\/\/)(.*?).youtube\.(.*?)\/watch\?v=(.*?)&list=(.*?)/,
    Dhe = /^(?:https?:\/\/)(.*?).youtube\.(.*?)\/watch\?v=(.*?)$/;
  function KS(e) {
    return Oz.test(e);
  }
  function Ea(e) {
    return [KS, hm, GS].some(function (r) {
      return r(e);
    });
  }
  function Az() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : fc("path");
    if (!(e !== null && e !== void 0 && e.length) || Ea(e)) return;
    var r = (pi("track-list") || []).filter(function (t) {
      return t.type === "sub";
    });
    if (tn(e)) {
      var t = uc.map(function (a) {
          var s = e.split(".").slice(0, -1);
          return s.push(a), s.join(".");
        }),
        i = xc();
      var _iterator8 = _createForOfIteratorHelper(t),
        _step8;
      try {
        var _loop2 = function _loop2() {
          var a = _step8.value;
          var s = qn(a);
          if (s !== null && s !== void 0 && s.length && !r.find(function (l) {
            return l.title === s;
          })) try {
            var _l$text;
            var l = gz(a);
            if (l.status !== 200 || !((_l$text = l.text) !== null && _l$text !== void 0 && _l$text.length)) return 1; // continue
            var p = _e(i, s);
            to(p, l.text), fi("sub-add", p);
          } catch (l) {
            print("loadRemoteSubtitle error:", l);
          }
        };
        for (_iterator8.s(); !(_step8 = _iterator8.n()).done;) {
          if (_loop2()) continue;
        }
      } catch (err) {
        _iterator8.e(err);
      } finally {
        _iterator8.f();
      }
    } else {
      var _t4 = uc.map(function (i) {
        var a = e.split(".").slice(0, -1);
        return a.push(i), a.join(".");
      });
      var _iterator9 = _createForOfIteratorHelper(_t4),
        _step9;
      try {
        var _loop3 = function _loop3() {
          var i = _step9.value;
          var a = qn(i);
          r.find(function (s) {
            return s.title === a;
          }) || Tt(i) && fi("sub-add", i);
        };
        for (_iterator9.s(); !(_step9 = _iterator9.n()).done;) {
          _loop3();
        }
      } catch (err) {
        _iterator9.e(err);
      } finally {
        _iterator9.f();
      }
    }
  }
  function _z() {
    return _z2.apply(this, arguments);
  }
  function _z2() {
    _z2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee6() {
      var e,
        r,
        t,
        i,
        _iterator45,
        _step45,
        _loop7,
        _t7,
        _iterator46,
        _step46,
        _loop8,
        _args8 = arguments;
      return _regeneratorRuntime().wrap(function _callee6$(_context8) {
        while (1) switch (_context8.prev = _context8.next) {
          case 0:
            e = _args8.length > 0 && _args8[0] !== undefined ? _args8[0] : fc("path");
            if (!(!(e !== null && e !== void 0 && e.length) || Ea(e))) {
              _context8.next = 3;
              break;
            }
            return _context8.abrupt("return");
          case 3:
            r = (pi("track-list") || []).filter(function (t) {
              return t.type === "sub";
            });
            if (!tn(e)) {
              _context8.next = 26;
              break;
            }
            t = uc.map(function (a) {
              var s = e.split(".").slice(0, -1);
              return s.push(a), s.join(".");
            }), i = xc();
            _iterator45 = _createForOfIteratorHelper(t);
            _context8.prev = 7;
            _loop7 = /*#__PURE__*/_regeneratorRuntime().mark(function _loop7() {
              var a, s, _l$text2, l, p;
              return _regeneratorRuntime().wrap(function _loop7$(_context6) {
                while (1) switch (_context6.prev = _context6.next) {
                  case 0:
                    a = _step45.value;
                    s = qn(a);
                    if (!(s !== null && s !== void 0 && s.length && !r.find(function (l) {
                      return l.title === s;
                    }))) {
                      _context6.next = 16;
                      break;
                    }
                    _context6.prev = 3;
                    _context6.next = 6;
                    return yz(a);
                  case 6:
                    l = _context6.sent;
                    if (!(l.status !== 200 || !((_l$text2 = l.text) !== null && _l$text2 !== void 0 && _l$text2.length))) {
                      _context6.next = 9;
                      break;
                    }
                    return _context6.abrupt("return", 1);
                  case 9:
                    p = _e(i, s);
                    to(p, l.text), fi("sub-add", p);
                    _context6.next = 16;
                    break;
                  case 13:
                    _context6.prev = 13;
                    _context6.t0 = _context6["catch"](3);
                    print("loadRemoteSubtitle error:", _context6.t0);
                  case 16:
                  case "end":
                    return _context6.stop();
                }
              }, _loop7, null, [[3, 13]]);
            });
            _iterator45.s();
          case 10:
            if ((_step45 = _iterator45.n()).done) {
              _context8.next = 16;
              break;
            }
            return _context8.delegateYield(_loop7(), "t0", 12);
          case 12:
            if (!_context8.t0) {
              _context8.next = 14;
              break;
            }
            return _context8.abrupt("continue", 14);
          case 14:
            _context8.next = 10;
            break;
          case 16:
            _context8.next = 21;
            break;
          case 18:
            _context8.prev = 18;
            _context8.t1 = _context8["catch"](7);
            _iterator45.e(_context8.t1);
          case 21:
            _context8.prev = 21;
            _iterator45.f();
            return _context8.finish(21);
          case 24:
            _context8.next = 43;
            break;
          case 26:
            _t7 = uc.map(function (i) {
              var a = e.split(".").slice(0, -1);
              return a.push(i), a.join(".");
            });
            _iterator46 = _createForOfIteratorHelper(_t7);
            _context8.prev = 28;
            _loop8 = /*#__PURE__*/_regeneratorRuntime().mark(function _loop8() {
              var i, a;
              return _regeneratorRuntime().wrap(function _loop8$(_context7) {
                while (1) switch (_context7.prev = _context7.next) {
                  case 0:
                    i = _step46.value;
                    a = qn(i);
                    r.find(function (s) {
                      return s.title === a;
                    }) || Tt(i) && fi("sub-add", i);
                  case 3:
                  case "end":
                    return _context7.stop();
                }
              }, _loop8);
            });
            _iterator46.s();
          case 31:
            if ((_step46 = _iterator46.n()).done) {
              _context8.next = 35;
              break;
            }
            return _context8.delegateYield(_loop8(), "t2", 33);
          case 33:
            _context8.next = 31;
            break;
          case 35:
            _context8.next = 40;
            break;
          case 37:
            _context8.prev = 37;
            _context8.t3 = _context8["catch"](28);
            _iterator46.e(_context8.t3);
          case 40:
            _context8.prev = 40;
            _iterator46.f();
            return _context8.finish(40);
          case 43:
          case "end":
            return _context8.stop();
        }
      }, _callee6, null, [[7, 18, 21, 24], [28, 37, 40, 43]]);
    }));
    return _z2.apply(this, arguments);
  }
  function Bhe(e, r) {
    var t = "\nWindows Registry Editor Version 5.00\n[HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Google\\Chrome]\n\"ExternalProtocolDialogShowAlwaysOpenCheckbox\"=dword:00000001\n\n[HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Edge]\n\"ExternalProtocolDialogShowAlwaysOpenCheckbox\"=dword:00000001\n\n[HKEY_CLASSES_ROOT\\mpv-easy]\n@=\"mpv-easy\"\n\"URL Protocol\"=\"\"\n\n[HKEY_CLASSES_ROOT\\mpv-easy\\DefaultIcon]\n@=\"\"\n\n[HKEY_CLASSES_ROOT\\mpv-easy\\shell]\n@=\"\"\n\n[HKEY_CLASSES_ROOT\\mpv-easy\\shell\\open]\n@=\"\"\n\n[HKEY_CLASSES_ROOT\\mpv-easy\\shell\\open\\command]\n@=\"".concat(r, " ").concat(e, " %1\"\n\n").trim(),
      i = _e(xc(), "set-protocol-hook-windows.reg");
    to(i, t);
    var a = ["cmd", "/c", "regedit.exe /S ".concat(i.replaceAll("/", "\\"))];
    $e(a);
  }
  function Nz(e, r) {
    var t = Be();
    switch (t) {
      case "windows":
        try {
          return Bhe(e, r), !0;
        } catch (i) {
          console.log("windows setProtocolHook error: ".concat(i));
        }
      default:
        console.log("".concat(t, " not support setProtocolHook"));
    }
  }
  var Fhe = "mpv-easy-play-with-macos",
    Lhe = "mpv-easy-play-with-windows",
    zhe = "mpv-easy-play-with-android",
    jhe = "mpv-easy-play-with-linux";
  function Rz() {
    var e = Be();
    switch (e) {
      case "darwin":
        return _e(Oo(), Fhe);
      case "linux":
        return _e(Oo(), jhe);
      case "windows":
        return _e(Oo(), Lhe).replaceAll("/", "\\\\");
      case "android":
        return _e(Oo(), zhe);
      default:
        throw new Error("mpv-easy-ext not support os: ".concat(e));
    }
  }
  function Uhe(e) {
    nn(["powershell", "-c", "Start-Process explorer.exe \"/select,".concat(hL(e), "\"")]);
  }
  function Mz(e) {
    switch (Be()) {
      case "windows":
        {
          Uhe(e);
          break;
        }
    }
  }
  function Hhe(e) {
    nn(["powershell", "-c", "Start-Process ".concat(e)]);
  }
  function kz(e) {
    switch (Be()) {
      case "windows":
        {
          Hhe(e);
          break;
        }
    }
  }
  var io = "@mpv-easy/autoload",
    Dz = {
      image: !0,
      video: !0,
      audio: !0,
      maxSize: 64
    };
  function Qs(e, r, t) {
    var i = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : void 0;
    if (tn(t)) return [];
    var s = (IL(t, "files") || []).filter(function (v) {
      return e.video && Us(v, i !== void 0 ? [i].concat(_toConsumableArray(Wd)) : Wd) || e.audio && gL(v, i !== void 0 ? [i].concat(_toConsumableArray(Gd)) : Gd) || e.image && yL(v, i !== void 0 ? [i].concat(_toConsumableArray(Kd)) : Kd);
    }).map(function (v) {
      return _e(t, v);
    }).sort(function (v, g) {
      return v.localeCompare(g);
    });
    s.length > e.maxSize && print("load too many videos(".concat(s.length, ")"));
    var l = r ? s.indexOf(r) : -1;
    if (l === -1) return s.slice(0, e.maxSize);
    var p = Math.max(l - (e.maxSize >> 1), 0),
      d = p + e.maxSize;
    return s.slice(p, d);
  }
  function $he(e, r, t) {
    var i = Nr(or("path") || "");
    if (tn(i)) {
      if (Ea(i)) return;
      cc().includes(i) || e([i], 0);
      return;
    }
    var a = mi(i);
    if (!a) return;
    var s = js(i),
      l = Qs(t, i, a, s || "");
    if (JSON.stringify(l) === JSON.stringify(r())) return;
    var p = l.indexOf(i);
    e(l, p === -1 ? 0 : p);
  }
  var Bz = function Bz(e, r) {
    return {
      name: io,
      create: function create() {
        var t = e[io];
        EL("start-file", function () {
          $he(r.updatePlaylist, r.getPlaylist, t);
        });
      },
      destroy: function destroy() {}
    };
  };
  var Js = "@mpv-easy/jellyfin",
    YS = {
      userName: "",
      apiKey: ""
    },
    Fz = function Fz(e, r) {
      return {
        name: Js,
        defaultConfig: YS,
        create: function create() {},
        destroy: function destroy() {}
      };
    };
  function Vhe(e, r) {
    var t = [];
    if (!(e !== null && e !== void 0 && e.length)) return t;
    var i = r[Ca].osdDuration;
    if (tn(e)) {
      if (Us(e)) return [Nr(e)];
      if (ym.isYoutube(e)) return i && Tn("play youtube: ".concat(e), i), [e];
      if (vm.isBilibili(e)) return i && Tn("play bilibili: ".concat(e), i), [e];
      if (gm.isTwitch(e)) return i && Tn("play twitch: ".concat(e), i), [e];
      try {
        return xz(e).map(function (a) {
          return Nr(e + a);
        }).filter(function (a) {
          return Us(a);
        });
      } catch (a) {
        print("webdav error: ", a);
      }
      if (gi.isJellyfin(e)) {
        var _a$apiKey, _a$userName;
        var a = r[Js];
        if ((_a$apiKey = a.apiKey) !== null && _a$apiKey !== void 0 && _a$apiKey.length && (_a$userName = a.userName) !== null && _a$userName !== void 0 && _a$userName.length) try {
          var s = gi.getPlayableListFromUrl(e, a.apiKey, a.userName).sort(function (l, p) {
            return l.name.localeCompare(p.name);
          }).map(function (l) {
            return l.path;
          });
          return i && Tn("play jellyfin: ".concat(e), i), s;
        } catch (s) {
          print(s), i && Tn("Please add jellyfin apiKey and username first", i);
        } else i && Tn("Please add jellyfin apiKey and username first", i);
        return [];
      }
      return [e];
    }
    if (Us(e)) {
      var _a4 = r[io],
        _s2 = mi(e);
      return _s2 ? Qs(_a4, e, _s2, js(e) || "") : [];
    }
    if (CS(e)) {
      var _a5 = r[io];
      return Qs(_a5, void 0, e, void 0);
    }
    return [];
  }
  function Whe(e, r) {
    var t = pz().trim().replace(/\\/g, "/"),
      i = Vhe(t, e);
    if (i !== null && i !== void 0 && i.length) {
      var a = i.indexOf(t);
      a !== -1 ? r.updatePlaylist(i, a) : r.updatePlaylist(i, 0);
    }
  }
  var Ca = "@mpv-easy/clip-play",
    XS = {
      key: "ctrl+v",
      osdDuration: 3
    },
    Lz = function Lz(e, r) {
      return {
        name: Ca,
        defaultConfig: XS,
        create: function create() {
          var t = e[Ca].key;
          lt(t, Ca, function () {
            Whe(e, r);
          });
        },
        destroy: function destroy() {}
      };
    };
  var Zz = j(Z()),
    e8 = j(Z()),
    K = (0, e8.forwardRef)(function (e, r) {
      return e.display !== "none" && Zz.default.createElement("mpv-box", _objectSpread({
        ref: r
      }, e));
    });
  var Si = j(Z());
  function uve(e) {
    return e.endsWith("Hover");
  }
  function lve(e) {
    return e.slice(0, -5);
  }
  function cve(e) {
    var r = {};
    for (var t in e) {
      var i = lve(t),
        a = e[t];
      uve(t) && (r[i] = a);
    }
    return r;
  }
  var de = Si.default.forwardRef(function (_ref3, a) {
    var e = _ref3.prefix,
      r = _ref3.postfix,
      t = _ref3.text,
      i = _objectWithoutProperties(_ref3, _excluded);
    var s = cve(i),
      _ref4 = (0, Si.useState)(!1),
      _ref5 = _slicedToArray(_ref4, 2),
      l = _ref5[0],
      p = _ref5[1];
    return Si.default.createElement(K, _objectSpread(_objectSpread(_objectSpread({
      display: "flex"
    }, i), l ? s : {}), {}, {
      ref: a,
      onMouseDown: function onMouseDown(d) {
        var _i$onMouseDown;
        (_i$onMouseDown = i.onMouseDown) === null || _i$onMouseDown === void 0 || _i$onMouseDown.call(i, d);
      },
      onMouseEnter: function onMouseEnter(d) {
        var _i$onMouseEnter;
        p(!0), i.enableMouseStyle && TS("Hand"), (_i$onMouseEnter = i.onMouseEnter) === null || _i$onMouseEnter === void 0 ? void 0 : _i$onMouseEnter.call(i, d);
      },
      onMouseLeave: function onMouseLeave(d) {
        var _i$onMouseLeave;
        p(!1), i.enableMouseStyle && TS("Arrow"), (_i$onMouseLeave = i.onMouseLeave) === null || _i$onMouseLeave === void 0 ? void 0 : _i$onMouseLeave.call(i, d);
      }
    }), e && Si.default.createElement(K, {
      id: "button-prefix-".concat(i.id),
      pointerEvents: "none",
      text: e
    }), t && Si.default.createElement(K, {
      id: "button-text-".concat(i.id),
      pointerEvents: "none",
      text: t
    }), r && Si.default.createElement(K, {
      id: "button-postfix-".concat(i.id),
      pointerEvents: "none",
      text: r
    }), i.children);
  });
  var fve = j(Z()),
    tb = j(Z());
  var ao = j(Z());
  function pve() {
    this.__data__ = [], this.size = 0;
  }
  var r8 = pve;
  function dve(e, r) {
    return e === r || e !== e && r !== r;
  }
  var wm = dve;
  function mve(e, r) {
    for (var t = e.length; t--;) if (wm(e[t][0], r)) return t;
    return -1;
  }
  var bi = mve;
  var hve = Array.prototype,
    vve = hve.splice;
  function gve(e) {
    var r = this.__data__,
      t = bi(r, e);
    if (t < 0) return !1;
    var i = r.length - 1;
    return t == i ? r.pop() : vve.call(r, t, 1), --this.size, !0;
  }
  var t8 = gve;
  function yve(e) {
    var r = this.__data__,
      t = bi(r, e);
    return t < 0 ? void 0 : r[t][1];
  }
  var n8 = yve;
  function xve(e) {
    return bi(this.__data__, e) > -1;
  }
  var o8 = xve;
  function Sve(e, r) {
    var t = this.__data__,
      i = bi(t, e);
    return i < 0 ? (++this.size, t.push([e, r])) : t[i][1] = r, this;
  }
  var i8 = Sve;
  function eu(e) {
    var r = -1,
      t = e == null ? 0 : e.length;
    for (this.clear(); ++r < t;) {
      var i = e[r];
      this.set(i[0], i[1]);
    }
  }
  eu.prototype.clear = r8;
  eu.prototype.delete = t8;
  eu.prototype.get = n8;
  eu.prototype.has = o8;
  eu.prototype.set = i8;
  var wi = eu;
  function bve() {
    this.__data__ = new wi(), this.size = 0;
  }
  var a8 = bve;
  function wve(e) {
    var r = this.__data__,
      t = r.delete(e);
    return this.size = r.size, t;
  }
  var s8 = wve;
  function Eve(e) {
    return this.__data__.get(e);
  }
  var u8 = Eve;
  function Cve(e) {
    return this.__data__.has(e);
  }
  var l8 = Cve;
  var Ive = (typeof global === "undefined" ? "undefined" : _typeof(global)) == "object" && global && global.Object === Object && global,
    Em = Ive;
  var Pve = (typeof self === "undefined" ? "undefined" : _typeof(self)) == "object" && self && self.Object === Object && self,
    qve = Em || Pve || Function("return this")(),
    mr = qve;
  var Tve = mr.Symbol,
    _o = Tve;
  var c8 = Object.prototype,
    Ove = c8.hasOwnProperty,
    Ave = c8.toString,
    bc = _o ? _o.toStringTag : void 0;
  function _ve(e) {
    var r = Ove.call(e, bc),
      t = e[bc];
    try {
      e[bc] = void 0;
      var i = !0;
    } catch (_unused66) {}
    var a = Ave.call(e);
    return i && (r ? e[bc] = t : delete e[bc]), a;
  }
  var f8 = _ve;
  var Nve = Object.prototype,
    Rve = Nve.toString;
  function Mve(e) {
    return Rve.call(e);
  }
  var p8 = Mve;
  var kve = "[object Null]",
    Dve = "[object Undefined]",
    d8 = _o ? _o.toStringTag : void 0;
  function Bve(e) {
    return e == null ? e === void 0 ? Dve : kve : d8 && d8 in Object(e) ? f8(e) : p8(e);
  }
  var An = Bve;
  function Fve(e) {
    var r = _typeof(e);
    return e != null && (r == "object" || r == "function");
  }
  var _n = Fve;
  var Lve = "[object AsyncFunction]",
    zve = "[object Function]",
    jve = "[object GeneratorFunction]",
    Uve = "[object Proxy]";
  function Hve(e) {
    if (!_n(e)) return !1;
    var r = An(e);
    return r == zve || r == jve || r == Lve || r == Uve;
  }
  var Cm = Hve;
  var $ve = mr["__core-js_shared__"],
    Im = $ve;
  var m8 = function () {
    var e = /[^.]+$/.exec(Im && Im.keys && Im.keys.IE_PROTO || "");
    return e ? "Symbol(src)_1." + e : "";
  }();
  function Vve(e) {
    return !!m8 && m8 in e;
  }
  var h8 = Vve;
  var Wve = Function.prototype,
    Gve = Wve.toString;
  function Kve(e) {
    if (e != null) {
      try {
        return Gve.call(e);
      } catch (_unused67) {}
      try {
        return e + "";
      } catch (_unused68) {}
    }
    return "";
  }
  var No = Kve;
  var Yve = /[\\^$.*+?()[\]{}|]/g,
    Xve = /^\[object .+?Constructor\]$/,
    Qve = Function.prototype,
    Jve = Object.prototype,
    Zve = Qve.toString,
    ege = Jve.hasOwnProperty,
    rge = RegExp("^" + Zve.call(ege).replace(Yve, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
  function tge(e) {
    if (!_n(e) || h8(e)) return !1;
    var r = Cm(e) ? rge : Xve;
    return r.test(No(e));
  }
  var v8 = tge;
  function nge(e, r) {
    return e === null || e === void 0 ? void 0 : e[r];
  }
  var g8 = nge;
  function oge(e, r) {
    var t = g8(e, r);
    return v8(t) ? t : void 0;
  }
  var ln = oge;
  var ige = ln(mr, "Map"),
    Ei = ige;
  var age = ln(Object, "create"),
    Ro = age;
  function sge() {
    this.__data__ = Ro ? Ro(null) : {}, this.size = 0;
  }
  var y8 = sge;
  function uge(e) {
    var r = this.has(e) && delete this.__data__[e];
    return this.size -= r ? 1 : 0, r;
  }
  var x8 = uge;
  var lge = "__lodash_hash_undefined__",
    cge = Object.prototype,
    fge = cge.hasOwnProperty;
  function pge(e) {
    var r = this.__data__;
    if (Ro) {
      var t = r[e];
      return t === lge ? void 0 : t;
    }
    return fge.call(r, e) ? r[e] : void 0;
  }
  var S8 = pge;
  var dge = Object.prototype,
    mge = dge.hasOwnProperty;
  function hge(e) {
    var r = this.__data__;
    return Ro ? r[e] !== void 0 : mge.call(r, e);
  }
  var b8 = hge;
  var vge = "__lodash_hash_undefined__";
  function gge(e, r) {
    var t = this.__data__;
    return this.size += this.has(e) ? 0 : 1, t[e] = Ro && r === void 0 ? vge : r, this;
  }
  var w8 = gge;
  function ru(e) {
    var r = -1,
      t = e == null ? 0 : e.length;
    for (this.clear(); ++r < t;) {
      var i = e[r];
      this.set(i[0], i[1]);
    }
  }
  ru.prototype.clear = y8;
  ru.prototype.delete = x8;
  ru.prototype.get = S8;
  ru.prototype.has = b8;
  ru.prototype.set = w8;
  var nb = ru;
  function yge() {
    this.size = 0, this.__data__ = {
      hash: new nb(),
      map: new (Ei || wi)(),
      string: new nb()
    };
  }
  var E8 = yge;
  function xge(e) {
    var r = _typeof(e);
    return r == "string" || r == "number" || r == "symbol" || r == "boolean" ? e !== "__proto__" : e === null;
  }
  var C8 = xge;
  function Sge(e, r) {
    var t = e.__data__;
    return C8(r) ? t[typeof r == "string" ? "string" : "hash"] : t.map;
  }
  var Ci = Sge;
  function bge(e) {
    var r = Ci(this, e).delete(e);
    return this.size -= r ? 1 : 0, r;
  }
  var I8 = bge;
  function wge(e) {
    return Ci(this, e).get(e);
  }
  var P8 = wge;
  function Ege(e) {
    return Ci(this, e).has(e);
  }
  var q8 = Ege;
  function Cge(e, r) {
    var t = Ci(this, e),
      i = t.size;
    return t.set(e, r), this.size += t.size == i ? 0 : 1, this;
  }
  var T8 = Cge;
  function tu(e) {
    var r = -1,
      t = e == null ? 0 : e.length;
    for (this.clear(); ++r < t;) {
      var i = e[r];
      this.set(i[0], i[1]);
    }
  }
  tu.prototype.clear = E8;
  tu.prototype.delete = I8;
  tu.prototype.get = P8;
  tu.prototype.has = q8;
  tu.prototype.set = T8;
  var Pm = tu;
  var Ige = 200;
  function Pge(e, r) {
    var t = this.__data__;
    if (t instanceof wi) {
      var i = t.__data__;
      if (!Ei || i.length < Ige - 1) return i.push([e, r]), this.size = ++t.size, this;
      t = this.__data__ = new Pm(i);
    }
    return t.set(e, r), this.size = t.size, this;
  }
  var O8 = Pge;
  function nu(e) {
    var r = this.__data__ = new wi(e);
    this.size = r.size;
  }
  nu.prototype.clear = a8;
  nu.prototype.delete = s8;
  nu.prototype.get = u8;
  nu.prototype.has = l8;
  nu.prototype.set = O8;
  var qm = nu;
  var qge = "__lodash_hash_undefined__";
  function Tge(e) {
    return this.__data__.set(e, qge), this;
  }
  var A8 = Tge;
  function Oge(e) {
    return this.__data__.has(e);
  }
  var _8 = Oge;
  function Tm(e) {
    var r = -1,
      t = e == null ? 0 : e.length;
    for (this.__data__ = new Pm(); ++r < t;) this.add(e[r]);
  }
  Tm.prototype.add = Tm.prototype.push = A8;
  Tm.prototype.has = _8;
  var N8 = Tm;
  function Age(e, r) {
    for (var t = -1, i = e == null ? 0 : e.length; ++t < i;) if (r(e[t], t, e)) return !0;
    return !1;
  }
  var R8 = Age;
  function _ge(e, r) {
    return e.has(r);
  }
  var M8 = _ge;
  var Nge = 1,
    Rge = 2;
  function Mge(e, r, t, i, a, s) {
    var l = t & Nge,
      p = e.length,
      d = r.length;
    if (p != d && !(l && d > p)) return !1;
    var v = s.get(e),
      g = s.get(r);
    if (v && g) return v == r && g == e;
    var x = -1,
      S = !0,
      b = t & Rge ? new N8() : void 0;
    for (s.set(e, r), s.set(r, e); ++x < p;) {
      var q = e[x],
        E = r[x];
      if (i) var C = l ? i(E, q, x, r, e, s) : i(q, E, x, e, r, s);
      if (C !== void 0) {
        if (C) continue;
        S = !1;
        break;
      }
      if (b) {
        if (!R8(r, function (T, D) {
          if (!M8(b, D) && (q === T || a(q, T, t, i, s))) return b.push(D);
        })) {
          S = !1;
          break;
        }
      } else if (!(q === E || a(q, E, t, i, s))) {
        S = !1;
        break;
      }
    }
    return s.delete(e), s.delete(r), S;
  }
  var Om = Mge;
  var kge = mr.Uint8Array,
    ob = kge;
  function Dge(e) {
    var r = -1,
      t = Array(e.size);
    return e.forEach(function (i, a) {
      t[++r] = [a, i];
    }), t;
  }
  var k8 = Dge;
  function Bge(e) {
    var r = -1,
      t = Array(e.size);
    return e.forEach(function (i) {
      t[++r] = i;
    }), t;
  }
  var D8 = Bge;
  var Fge = 1,
    Lge = 2,
    zge = "[object Boolean]",
    jge = "[object Date]",
    Uge = "[object Error]",
    Hge = "[object Map]",
    $ge = "[object Number]",
    Vge = "[object RegExp]",
    Wge = "[object Set]",
    Gge = "[object String]",
    Kge = "[object Symbol]",
    Yge = "[object ArrayBuffer]",
    Xge = "[object DataView]",
    B8 = _o ? _o.prototype : void 0,
    ib = B8 ? B8.valueOf : void 0;
  function Qge(e, r, t, i, a, s, l) {
    switch (t) {
      case Xge:
        if (e.byteLength != r.byteLength || e.byteOffset != r.byteOffset) return !1;
        e = e.buffer, r = r.buffer;
      case Yge:
        return !(e.byteLength != r.byteLength || !s(new ob(e), new ob(r)));
      case zge:
      case jge:
      case $ge:
        return wm(+e, +r);
      case Uge:
        return e.name == r.name && e.message == r.message;
      case Vge:
      case Gge:
        return e == r + "";
      case Hge:
        var p = k8;
      case Wge:
        var d = i & Fge;
        if (p || (p = D8), e.size != r.size && !d) return !1;
        var v = l.get(e);
        if (v) return v == r;
        i |= Lge, l.set(e, r);
        var g = Om(p(e), p(r), i, a, s, l);
        return l.delete(e), g;
      case Kge:
        if (ib) return ib.call(e) == ib.call(r);
    }
    return !1;
  }
  var F8 = Qge;
  function Jge(e, r) {
    for (var t = -1, i = r.length, a = e.length; ++t < i;) e[a + t] = r[t];
    return e;
  }
  var L8 = Jge;
  var Zge = Array.isArray,
    Ia = Zge;
  function eye(e, r, t) {
    var i = r(e);
    return Ia(e) ? i : L8(i, t(e));
  }
  var z8 = eye;
  function rye(e, r) {
    for (var t = -1, i = e == null ? 0 : e.length, a = 0, s = []; ++t < i;) {
      var l = e[t];
      r(l, t, e) && (s[a++] = l);
    }
    return s;
  }
  var j8 = rye;
  function tye() {
    return [];
  }
  var U8 = tye;
  var nye = Object.prototype,
    oye = nye.propertyIsEnumerable,
    H8 = Object.getOwnPropertySymbols,
    iye = H8 ? function (e) {
      return e == null ? [] : (e = Object(e), j8(H8(e), function (r) {
        return oye.call(e, r);
      }));
    } : U8,
    $8 = iye;
  function aye(e, r) {
    for (var t = -1, i = Array(e); ++t < e;) i[t] = r(t);
    return i;
  }
  var V8 = aye;
  function sye(e) {
    return e != null && _typeof(e) == "object";
  }
  var Nn = sye;
  var uye = "[object Arguments]";
  function lye(e) {
    return Nn(e) && An(e) == uye;
  }
  var ab = lye;
  var W8 = Object.prototype,
    cye = W8.hasOwnProperty,
    fye = W8.propertyIsEnumerable,
    pye = ab(function () {
      return arguments;
    }()) ? ab : function (e) {
      return Nn(e) && cye.call(e, "callee") && !fye.call(e, "callee");
    },
    G8 = pye;
  function dye() {
    return !1;
  }
  var K8 = dye;
  var Q8 = (typeof exports === "undefined" ? "undefined" : _typeof(exports)) == "object" && exports && !exports.nodeType && exports,
    Y8 = Q8 && (typeof module === "undefined" ? "undefined" : _typeof(module)) == "object" && module && !module.nodeType && module,
    mye = Y8 && Y8.exports === Q8,
    X8 = mye ? mr.Buffer : void 0,
    hye = X8 ? X8.isBuffer : void 0,
    vye = hye || K8,
    wc = vye;
  var gye = 9007199254740991,
    yye = /^(?:0|[1-9]\d*)$/;
  function xye(e, r) {
    var _r2;
    var t = _typeof(e);
    return r = (_r2 = r) !== null && _r2 !== void 0 ? _r2 : gye, !!r && (t == "number" || t != "symbol" && yye.test(e)) && e > -1 && e % 1 == 0 && e < r;
  }
  var J8 = xye;
  var Sye = 9007199254740991;
  function bye(e) {
    return typeof e == "number" && e > -1 && e % 1 == 0 && e <= Sye;
  }
  var Am = bye;
  var wye = "[object Arguments]",
    Eye = "[object Array]",
    Cye = "[object Boolean]",
    Iye = "[object Date]",
    Pye = "[object Error]",
    qye = "[object Function]",
    Tye = "[object Map]",
    Oye = "[object Number]",
    Aye = "[object Object]",
    _ye = "[object RegExp]",
    Nye = "[object Set]",
    Rye = "[object String]",
    Mye = "[object WeakMap]",
    kye = "[object ArrayBuffer]",
    Dye = "[object DataView]",
    Bye = "[object Float32Array]",
    Fye = "[object Float64Array]",
    Lye = "[object Int8Array]",
    zye = "[object Int16Array]",
    jye = "[object Int32Array]",
    Uye = "[object Uint8Array]",
    Hye = "[object Uint8ClampedArray]",
    $ye = "[object Uint16Array]",
    Vye = "[object Uint32Array]",
    Ve = {};
  Ve[Bye] = Ve[Fye] = Ve[Lye] = Ve[zye] = Ve[jye] = Ve[Uye] = Ve[Hye] = Ve[$ye] = Ve[Vye] = !0;
  Ve[wye] = Ve[Eye] = Ve[kye] = Ve[Cye] = Ve[Dye] = Ve[Iye] = Ve[Pye] = Ve[qye] = Ve[Tye] = Ve[Oye] = Ve[Aye] = Ve[_ye] = Ve[Nye] = Ve[Rye] = Ve[Mye] = !1;
  function Wye(e) {
    return Nn(e) && Am(e.length) && !!Ve[An(e)];
  }
  var Z8 = Wye;
  function Gye(e) {
    return function (r) {
      return e(r);
    };
  }
  var e4 = Gye;
  var r4 = (typeof exports === "undefined" ? "undefined" : _typeof(exports)) == "object" && exports && !exports.nodeType && exports,
    Ec = r4 && (typeof module === "undefined" ? "undefined" : _typeof(module)) == "object" && module && !module.nodeType && module,
    Kye = Ec && Ec.exports === r4,
    sb = Kye && Em.process,
    Yye = function () {
      try {
        var e = Ec && Ec.require && Ec.require("util").types;
        return e || sb && sb.binding && sb.binding("util");
      } catch (_unused69) {}
    }(),
    ub = Yye;
  var t4 = ub && ub.isTypedArray,
    Xye = t4 ? e4(t4) : Z8,
    _m = Xye;
  var Qye = Object.prototype,
    Jye = Qye.hasOwnProperty;
  function Zye(e, r) {
    var t = Ia(e),
      i = !t && G8(e),
      a = !t && !i && wc(e),
      s = !t && !i && !a && _m(e),
      l = t || i || a || s,
      p = l ? V8(e.length, String) : [],
      d = p.length;
    for (var v in e) (r || Jye.call(e, v)) && !(l && (v == "length" || a && (v == "offset" || v == "parent") || s && (v == "buffer" || v == "byteLength" || v == "byteOffset") || J8(v, d))) && p.push(v);
    return p;
  }
  var n4 = Zye;
  var exe = Object.prototype;
  function rxe(e) {
    var r = e && e.constructor,
      t = typeof r == "function" && r.prototype || exe;
    return e === t;
  }
  var o4 = rxe;
  function txe(e, r) {
    return function (t) {
      return e(r(t));
    };
  }
  var i4 = txe;
  var nxe = i4(Object.keys, Object),
    a4 = nxe;
  var oxe = Object.prototype,
    ixe = oxe.hasOwnProperty;
  function axe(e) {
    if (!o4(e)) return a4(e);
    var r = [];
    for (var t in Object(e)) ixe.call(e, t) && t != "constructor" && r.push(t);
    return r;
  }
  var s4 = axe;
  function sxe(e) {
    return e != null && Am(e.length) && !Cm(e);
  }
  var u4 = sxe;
  function uxe(e) {
    return u4(e) ? n4(e) : s4(e);
  }
  var l4 = uxe;
  function lxe(e) {
    return z8(e, l4, $8);
  }
  var lb = lxe;
  var cxe = 1,
    fxe = Object.prototype,
    pxe = fxe.hasOwnProperty;
  function dxe(e, r, t, i, a, s) {
    var l = t & cxe,
      p = lb(e),
      d = p.length,
      v = lb(r),
      g = v.length;
    if (d != g && !l) return !1;
    for (var x = d; x--;) {
      var S = p[x];
      if (!(l ? S in r : pxe.call(r, S))) return !1;
    }
    var b = s.get(e),
      q = s.get(r);
    if (b && q) return b == r && q == e;
    var E = !0;
    s.set(e, r), s.set(r, e);
    for (var C = l; ++x < d;) {
      S = p[x];
      var T = e[S],
        D = r[S];
      if (i) var M = l ? i(D, T, S, r, e, s) : i(T, D, S, e, r, s);
      if (!(M === void 0 ? T === D || a(T, D, t, i, s) : M)) {
        E = !1;
        break;
      }
      C || (C = S == "constructor");
    }
    if (E && !C) {
      var k = e.constructor,
        W = r.constructor;
      k != W && "constructor" in e && "constructor" in r && !(typeof k == "function" && k instanceof k && typeof W == "function" && W instanceof W) && (E = !1);
    }
    return s.delete(e), s.delete(r), E;
  }
  var c4 = dxe;
  var mxe = ln(mr, "DataView"),
    Nm = mxe;
  var hxe = ln(mr, "Promise"),
    Rm = hxe;
  var vxe = ln(mr, "Set"),
    Mm = vxe;
  var gxe = ln(mr, "WeakMap"),
    km = gxe;
  var f4 = "[object Map]",
    yxe = "[object Object]",
    p4 = "[object Promise]",
    d4 = "[object Set]",
    m4 = "[object WeakMap]",
    h4 = "[object DataView]",
    xxe = No(Nm),
    Sxe = No(Ei),
    bxe = No(Rm),
    wxe = No(Mm),
    Exe = No(km),
    Pa = An;
  (Nm && Pa(new Nm(new ArrayBuffer(1))) != h4 || Ei && Pa(new Ei()) != f4 || Rm && Pa(Rm.resolve()) != p4 || Mm && Pa(new Mm()) != d4 || km && Pa(new km()) != m4) && (Pa = function Pa(e) {
    var r = An(e),
      t = r == yxe ? e.constructor : void 0,
      i = t ? No(t) : "";
    if (i) switch (i) {
      case xxe:
        return h4;
      case Sxe:
        return f4;
      case bxe:
        return p4;
      case wxe:
        return d4;
      case Exe:
        return m4;
    }
    return r;
  });
  var cb = Pa;
  var Cxe = 1,
    v4 = "[object Arguments]",
    g4 = "[object Array]",
    Dm = "[object Object]",
    Ixe = Object.prototype,
    y4 = Ixe.hasOwnProperty;
  function Pxe(e, r, t, i, a, s) {
    var l = Ia(e),
      p = Ia(r),
      d = l ? g4 : cb(e),
      v = p ? g4 : cb(r);
    d = d == v4 ? Dm : d, v = v == v4 ? Dm : v;
    var g = d == Dm,
      x = v == Dm,
      S = d == v;
    if (S && wc(e)) {
      if (!wc(r)) return !1;
      l = !0, g = !1;
    }
    if (S && !g) return s || (s = new qm()), l || _m(e) ? Om(e, r, t, i, a, s) : F8(e, r, d, t, i, a, s);
    if (!(t & Cxe)) {
      var b = g && y4.call(e, "__wrapped__"),
        q = x && y4.call(r, "__wrapped__");
      if (b || q) {
        var E = b ? e.value() : e,
          C = q ? r.value() : r;
        return s || (s = new qm()), a(E, C, t, i, s);
      }
    }
    return S ? (s || (s = new qm()), c4(e, r, t, i, a, s)) : !1;
  }
  var x4 = Pxe;
  function S4(e, r, t, i, a) {
    return e === r ? !0 : e == null || r == null || !Nn(e) && !Nn(r) ? e !== e && r !== r : x4(e, r, t, i, S4, a);
  }
  var b4 = S4;
  function qxe(e, r) {
    return b4(e, r);
  }
  var Cc = qxe;
  var Txe = function Txe() {
      return mr.Date.now();
    },
    Bm = Txe;
  var Oxe = /\s/;
  function Axe(e) {
    for (var r = e.length; r-- && Oxe.test(e.charAt(r)););
    return r;
  }
  var w4 = Axe;
  var _xe = /^\s+/;
  function Nxe(e) {
    return e && e.slice(0, w4(e) + 1).replace(_xe, "");
  }
  var E4 = Nxe;
  var Rxe = "[object Symbol]";
  function Mxe(e) {
    return _typeof(e) == "symbol" || Nn(e) && An(e) == Rxe;
  }
  var C4 = Mxe;
  var I4 = NaN,
    kxe = /^[-+]0x[0-9a-f]+$/i,
    Dxe = /^0b[01]+$/i,
    Bxe = /^0o[0-7]+$/i,
    Fxe = parseInt;
  function Lxe(e) {
    if (typeof e == "number") return e;
    if (C4(e)) return I4;
    if (_n(e)) {
      var r = typeof e.valueOf == "function" ? e.valueOf() : e;
      e = _n(r) ? r + "" : r;
    }
    if (typeof e != "string") return e === 0 ? e : +e;
    e = E4(e);
    var t = Dxe.test(e);
    return t || Bxe.test(e) ? Fxe(e.slice(2), t ? 2 : 8) : kxe.test(e) ? I4 : +e;
  }
  var qa = Lxe;
  var zxe = "Expected a function",
    jxe = Math.max,
    Uxe = Math.min;
  function Hxe(e, r, t) {
    var i,
      a,
      s,
      l,
      p,
      d,
      v = 0,
      g = !1,
      x = !1,
      S = !0;
    if (typeof e != "function") throw new TypeError(zxe);
    r = qa(r) || 0, _n(t) && (g = !!t.leading, x = "maxWait" in t, s = x ? jxe(qa(t.maxWait) || 0, r) : s, S = "trailing" in t ? !!t.trailing : S);
    function b(ee) {
      var N = i,
        B = a;
      return i = a = void 0, v = ee, l = e.apply(B, N), l;
    }
    function q(ee) {
      return v = ee, p = setTimeout(T, r), g ? b(ee) : l;
    }
    function E(ee) {
      var N = ee - d,
        B = ee - v,
        U = r - N;
      return x ? Uxe(U, s - B) : U;
    }
    function C(ee) {
      var N = ee - d,
        B = ee - v;
      return d === void 0 || N >= r || N < 0 || x && B >= s;
    }
    function T() {
      var ee = Bm();
      if (C(ee)) return D(ee);
      p = setTimeout(T, E(ee));
    }
    function D(ee) {
      return p = void 0, S && i ? b(ee) : (i = a = void 0, l);
    }
    function M() {
      p !== void 0 && clearTimeout(p), v = 0, i = d = a = p = void 0;
    }
    function k() {
      return p === void 0 ? l : D(Bm());
    }
    function W() {
      var ee = Bm(),
        N = C(ee);
      if (i = arguments, a = this, d = ee, N) {
        if (p === void 0) return q(d);
        if (x) return clearTimeout(p), p = setTimeout(T, r), b(d);
      }
      return p === void 0 && (p = setTimeout(T, r)), l;
    }
    return W.cancel = M, W.flush = k, W;
  }
  var P4 = Hxe;
  var $xe = "Expected a function";
  function Vxe(e, r, t) {
    var i = !0,
      a = !0;
    if (typeof e != "function") throw new TypeError($xe);
    return _n(t) && (i = "leading" in t ? !!t.leading : i, a = "trailing" in t ? !!t.trailing : a), P4(e, r, {
      leading: i,
      maxWait: r,
      trailing: a
    });
  }
  var Rn = Vxe;
  var Mo = {
    AliceBlue: 15792383,
    AntiqueWhite: 16444375,
    Aqua: 65535,
    Aquamarine: 8388564,
    Azure: 15794175,
    Beige: 16119260,
    Bisque: 16770244,
    Black: 0,
    BlanchedAlmond: 16772045,
    Blue: 255,
    BlueViolet: 9055202,
    Brown: 10824234,
    BurlyWood: 14596231,
    CadetBlue: 6266528,
    Chartreuse: 8388352,
    Chocolate: 13789470,
    Coral: 16744272,
    CornflowerBlue: 6591981,
    Cornsilk: 16775388,
    Crimson: 14423100,
    Cyan: 65535,
    DarkBlue: 139,
    DarkCyan: 35723,
    DarkGoldenRod: 12092939,
    DarkGray: 11119017,
    DarkGrey: 11119017,
    DarkGreen: 25600,
    DarkKhaki: 12433259,
    DarkMagenta: 9109643,
    DarkOliveGreen: 5597999,
    DarkOrange: 16747520,
    DarkOrchid: 10040012,
    DarkRed: 9109504,
    DarkSalmon: 15308410,
    DarkSeaGreen: 9419919,
    DarkSlateBlue: 4734347,
    DarkSlateGray: 3100495,
    DarkSlateGrey: 3100495,
    DarkTurquoise: 52945,
    DarkViolet: 9699539,
    DeepPink: 16716947,
    DeepSkyBlue: 49151,
    DimGray: 6908265,
    DimGrey: 6908265,
    DodgerBlue: 2003199,
    FireBrick: 11674146,
    FloralWhite: 16775920,
    ForestGreen: 2263842,
    Fuchsia: 16711935,
    Gainsboro: 14474460,
    GhostWhite: 16316671,
    Gold: 16766720,
    GoldenRod: 14329120,
    Gray: 8421504,
    Grey: 8421504,
    Green: 32768,
    GreenYellow: 11403055,
    HoneyDew: 15794160,
    HotPink: 16738740,
    IndianRed: 13458524,
    Indigo: 4915330,
    Ivory: 16777200,
    Khaki: 15787660,
    Lavender: 15132410,
    LavenderBlush: 16773365,
    LawnGreen: 8190976,
    LemonChiffon: 16775885,
    LightBlue: 11393254,
    LightCoral: 15761536,
    LightCyan: 14745599,
    LightGoldenRodYellow: 16448210,
    LightGray: 13882323,
    LightGrey: 13882323,
    LightGreen: 9498256,
    LightPink: 16758465,
    LightSalmon: 16752762,
    LightSeaGreen: 2142890,
    LightSkyBlue: 8900346,
    LightSlateGray: 7833753,
    LightSlateGrey: 7833753,
    LightSteelBlue: 11584734,
    LightYellow: 16777184,
    Lime: 65280,
    LimeGreen: 3329330,
    Linen: 16445670,
    Magenta: 16711935,
    Maroon: 8388608,
    MediumAquaMarine: 6737322,
    MediumBlue: 205,
    MediumOrchid: 12211667,
    MediumPurple: 9662683,
    MediumSeaGreen: 3978097,
    MediumSlateBlue: 8087790,
    MediumSpringGreen: 64154,
    MediumTurquoise: 4772300,
    MediumVioletRed: 13047173,
    MidnightBlue: 1644912,
    MintCream: 16121850,
    MistyRose: 16770273,
    Moccasin: 16770229,
    NavajoWhite: 16768685,
    Navy: 128,
    OldLace: 16643558,
    Olive: 8421376,
    OliveDrab: 7048739,
    Orange: 16753920,
    OrangeRed: 16729344,
    Orchid: 14315734,
    PaleGoldenRod: 15657130,
    PaleGreen: 10025880,
    PaleTurquoise: 11529966,
    PaleVioletRed: 14381203,
    PapayaWhip: 16773077,
    PeachPuff: 16767673,
    Peru: 13468991,
    Pink: 16761035,
    Plum: 14524637,
    PowderBlue: 11591910,
    Purple: 8388736,
    RebeccaPurple: 6697881,
    Red: 16711680,
    RosyBrown: 12357519,
    RoyalBlue: 4286945,
    SaddleBrown: 9127187,
    Salmon: 16416882,
    SandyBrown: 16032864,
    SeaGreen: 3050327,
    SeaShell: 16774638,
    Sienna: 10506797,
    Silver: 12632256,
    SkyBlue: 8900331,
    SlateBlue: 6970061,
    SlateGray: 7372944,
    SlateGrey: 7372944,
    Snow: 16775930,
    SpringGreen: 65407,
    SteelBlue: 4620980,
    Tan: 13808780,
    Teal: 32896,
    Thistle: 14204888,
    Tomato: 16737095,
    Turquoise: 4251856,
    Violet: 15631086,
    Wheat: 16113331,
    White: 16777215,
    WhiteSmoke: 16119285,
    Yellow: 16776960,
    YellowGreen: 10145074
  };
  function ft(e) {
    return e < 0 ? e + 255 : e;
  }
  function ge(e) {
    return e < 0 ? e + 4294967295 + 1 : e;
  }
  function Oa(e) {
    var r = {};
    for (var _i6 = 0, _Object$keys = Object.keys(Mo); _i6 < _Object$keys.length; _i6++) {
      var t = _Object$keys[_i6];
      r[t] = e(t);
    }
    return r;
  }
  var Ta = /*#__PURE__*/function () {
    function Ta(r) {
      _classCallCheck(this, Ta);
      Object.defineProperty(this, "color", {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: void 0
      }), Object.defineProperty(this, "bitCount", {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: 6
      }), this.color = typeof r == "number" ? r : parseInt(r, 16);
    }
    return _createClass(Ta, [{
      key: "toBgr",
      value: function toBgr() {
        return this.toRgba().toBgr();
      }
    }, {
      key: "toBgra",
      value: function toBgra() {
        return this.toRgba().toBgra();
      }
    }, {
      key: "toRgb",
      value: function toRgb() {
        return this.toRgba().toRgb();
      }
    }, {
      key: "toHex",
      value: function toHex() {
        var r = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
        var t = this.color.toString(16).padStart(this.bitCount, "0");
        return (r + t).toUpperCase();
      }
    }]);
  }();
  var cn = /*#__PURE__*/function (_Ta) {
    function e() {
      var _this2;
      _classCallCheck(this, e);
      _this2 = _callSuper(this, e, arguments), Object.defineProperty(_assertThisInitialized(_this2), "bitCount", {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: 8
      });
      return _this2;
    }
    _inherits(e, _Ta);
    return _createClass(e, [{
      key: "toRgba",
      value: function toRgba() {
        return new e(this.color);
      }
    }, {
      key: "fromRgba",
      value: function fromRgba(r) {
        return new e(r.color);
      }
    }, {
      key: "red",
      get: function get() {
        return ft(this.color >> 24 & 255);
      },
      set: function set(r) {
        this.color = ge(this.color & 16777215 | ge(r << 24));
      }
    }, {
      key: "green",
      get: function get() {
        return ft(this.color >> 16 & 255);
      },
      set: function set(r) {
        this.color = ge(this.color & 4278255615 | ge(r << 16));
      }
    }, {
      key: "blue",
      get: function get() {
        return ft(this.color >> 8 & 255);
      },
      set: function set(r) {
        this.color = ge(this.color & 4294902015 | ge(r << 8));
      }
    }, {
      key: "alpha",
      get: function get() {
        return ft(this.color & 255);
      },
      set: function set(r) {
        this.color = ge(this.color & 4294967040 | ge(r << 0));
      }
    }, {
      key: "setRed",
      value: function setRed(r) {
        return this.red = r, this;
      }
    }, {
      key: "setGreen",
      value: function setGreen(r) {
        return this.green = r, this;
      }
    }, {
      key: "setBlue",
      value: function setBlue(r) {
        return this.blue = r, this;
      }
    }, {
      key: "setAlpha",
      value: function setAlpha(r) {
        return this.alpha = r, this;
      }
    }, {
      key: "invert",
      value: function invert() {
        var r = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : !1;
        var t = ge((255 - this.red << 24) + (255 - this.green << 16) + (255 - this.blue << 8) + (r ? 255 - this.alpha : this.alpha));
        return new e(t);
      }
    }, {
      key: "toRgb",
      value: function toRgb() {
        return Aa.fromRgba(this);
      }
    }, {
      key: "toBgr",
      value: function toBgr() {
        return Ic.fromRgba(this);
      }
    }, {
      key: "toBgra",
      value: function toBgra() {
        return _a.fromRgba(this);
      }
    }], [{
      key: "fromName",
      value: function fromName(r) {
        return new e(Mo[r] * 256 + 255);
      }
    }]);
  }(Ta);
  Object.defineProperty(cn, "Colors", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Oa(cn.fromName)
  });
  var Aa = /*#__PURE__*/function (_Ta2) {
    function e() {
      var _this3;
      _classCallCheck(this, e);
      _this3 = _callSuper(this, e, arguments), Object.defineProperty(_assertThisInitialized(_this3), "bitCount", {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: 6
      });
      return _this3;
    }
    _inherits(e, _Ta2);
    return _createClass(e, [{
      key: "red",
      get: function get() {
        return ft(this.color >> 16 & 255);
      },
      set: function set(r) {
        this.color = ge(this.color & 65535 | ge(r << 16));
      }
    }, {
      key: "green",
      get: function get() {
        return ft(this.color >> 8 & 255);
      },
      set: function set(r) {
        this.color = ge(this.color & 16711935 | ge(r << 8));
      }
    }, {
      key: "blue",
      get: function get() {
        return ft(this.color & 255);
      },
      set: function set(r) {
        this.color = ge(this.color & 16776960 | ge(r << 0));
      }
    }, {
      key: "setRed",
      value: function setRed(r) {
        return this.red = r, this;
      }
    }, {
      key: "setGreen",
      value: function setGreen(r) {
        return this.green = r, this;
      }
    }, {
      key: "setBlue",
      value: function setBlue(r) {
        return this.blue = r, this;
      }
    }, {
      key: "toRgba",
      value: function toRgba() {
        var r = ge((this.red << 24) + (this.green << 16) + (this.blue << 8) + 255);
        return new cn(r);
      }
    }, {
      key: "invert",
      value: function invert() {
        var r = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : !1;
        return e.fromRgba(this.toRgba().invert(r));
      }
    }], [{
      key: "fromRgba",
      value: function fromRgba(r) {
        var t = ge((r.red << 16) + (r.green << 8) + r.blue);
        return new e(t);
      }
    }, {
      key: "fromName",
      value: function fromName(r) {
        return new e(Mo[r]);
      }
    }]);
  }(Ta);
  Object.defineProperty(Aa, "Colors", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Oa(Aa.fromName)
  });
  var Ic = /*#__PURE__*/function (_Ta3) {
    function e() {
      var _this4;
      _classCallCheck(this, e);
      _this4 = _callSuper(this, e, arguments), Object.defineProperty(_assertThisInitialized(_this4), "bitCount", {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: 6
      });
      return _this4;
    }
    _inherits(e, _Ta3);
    return _createClass(e, [{
      key: "blue",
      get: function get() {
        return ft(this.color >> 16 & 255);
      },
      set: function set(r) {
        this.color = ge(this.color & 65535 | ge(r << 16));
      }
    }, {
      key: "green",
      get: function get() {
        return ft(this.color >> 8 & 255);
      },
      set: function set(r) {
        this.color = ge(this.color & 16711935 | ge(r << 8));
      }
    }, {
      key: "red",
      get: function get() {
        return ft(this.color & 255);
      },
      set: function set(r) {
        this.color = ge(this.color & 16776960 | ge(r << 0));
      }
    }, {
      key: "setRed",
      value: function setRed(r) {
        return this.red = r, this;
      }
    }, {
      key: "setGreen",
      value: function setGreen(r) {
        return this.green = r, this;
      }
    }, {
      key: "setBlue",
      value: function setBlue(r) {
        return this.blue = r, this;
      }
    }, {
      key: "toRgba",
      value: function toRgba() {
        var r = ge((this.blue << 24) + (this.green << 16) + (this.red << 8) + 255);
        return new cn(r);
      }
    }, {
      key: "invert",
      value: function invert() {
        var r = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : !1;
        return e.fromRgba(this.toRgba().invert(r));
      }
    }], [{
      key: "fromRgba",
      value: function fromRgba(r) {
        var t = ge((r.blue << 16) + (r.green << 8) + r.red);
        return new e(t);
      }
    }, {
      key: "fromName",
      value: function fromName(r) {
        return e.fromRgba(cn.fromName(r));
      }
    }]);
  }(Ta);
  Object.defineProperty(Ic, "Colors", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Oa(Ic.fromName)
  });
  var _a = /*#__PURE__*/function (_Ta4) {
    function e() {
      var _this5;
      _classCallCheck(this, e);
      _this5 = _callSuper(this, e, arguments), Object.defineProperty(_assertThisInitialized(_this5), "bitCount", {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: 8
      });
      return _this5;
    }
    _inherits(e, _Ta4);
    return _createClass(e, [{
      key: "blue",
      get: function get() {
        return ft(this.color >> 24 & 255);
      },
      set: function set(r) {
        this.color = ge(this.color & 16777215 | ge(r << 24));
      }
    }, {
      key: "green",
      get: function get() {
        return ft(this.color >> 16 & 255);
      },
      set: function set(r) {
        this.color = ge(this.color & 4278255615 | ge(r << 16));
      }
    }, {
      key: "red",
      get: function get() {
        return ft(this.color >> 8 & 255);
      },
      set: function set(r) {
        this.color = ge(this.color & 4294902015 | ge(r << 8));
      }
    }, {
      key: "alpha",
      get: function get() {
        return ft(this.color & 255);
      },
      set: function set(r) {
        this.color = ge(this.color & 4294967040 | ge(r << 0));
      }
    }, {
      key: "setRed",
      value: function setRed(r) {
        return this.red = r, this;
      }
    }, {
      key: "setGreen",
      value: function setGreen(r) {
        return this.green = r, this;
      }
    }, {
      key: "setBlue",
      value: function setBlue(r) {
        return this.blue = r, this;
      }
    }, {
      key: "setAlpha",
      value: function setAlpha(r) {
        return this.alpha = r, this;
      }
    }, {
      key: "toRgba",
      value: function toRgba() {
        var r = ge((this.red << 24) + (this.green << 16) + (this.blue << 8) + this.alpha);
        return new cn(r);
      }
    }, {
      key: "invert",
      value: function invert() {
        var r = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : !1;
        return e.fromRgba(this.toRgba().invert(r));
      }
    }], [{
      key: "fromRgba",
      value: function fromRgba(r) {
        var t = ge((r.blue << 24) + (r.green << 16) + (r.red << 8) + r.alpha);
        return new e(t);
      }
    }, {
      key: "fromName",
      value: function fromName(r) {
        return e.fromRgba(cn.fromName(r));
      }
    }]);
  }(Ta);
  Object.defineProperty(_a, "Colors", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Oa(_a.fromName)
  });
  var Fm = /*#__PURE__*/function (_a6) {
    function e() {
      _classCallCheck(this, e);
      return _callSuper(this, e, arguments);
    }
    _inherits(e, _a6);
    return _createClass(e, [{
      key: "toRgba",
      value: function toRgba() {
        var r = ge((this.red << 24) + (this.green << 16) + (this.blue << 8) + (255 - this.alpha));
        return new cn(r);
      }
    }, {
      key: "invert",
      value: function invert() {
        var r = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : !1;
        return e.fromRgba(this.toRgba().invert(r));
      }
    }], [{
      key: "fromRgba",
      value: function fromRgba(r) {
        var t = ge((r.blue << 24) + (r.green << 16) + (r.red << 8) + (255 - r.alpha));
        return new e(t);
      }
    }, {
      key: "fromName",
      value: function fromName(r) {
        return e.fromRgba(cn.fromName(r));
      }
    }]);
  }(_a);
  Object.defineProperty(Fm, "Colors", {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: Oa(Fm.fromName)
  });
  var Lm = .551915024494,
    Ii = /*#__PURE__*/function () {
      function Ii() {
        var r = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
        var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "";
        _classCallCheck(this, Ii);
        _defineProperty(this, "_scale", void 0);
        _defineProperty(this, "_text", void 0);
        this._text = t, this._scale = r;
      }
      return _createClass(Ii, [{
        key: "newEvent",
        value: function newEvent() {
          return this._text.length > 0 && (this._text += "\n"), this;
        }
      }, {
        key: "font",
        value: function font(r) {
          return this.append("{\\fn".concat(r, "}"));
        }
      }, {
        key: "scale",
        value: function scale(r) {
          return this._scale = r, this;
        }
      }, {
        key: "text",
        value: function text(r) {
          return this._text = r, this;
        }
      }, {
        key: "drawStart",
        value: function drawStart() {
          return this._text = "".concat(this._text, "{\\p").concat(this._scale, "}"), this;
        }
      }, {
        key: "drawStop",
        value: function drawStop() {
          return this._text = "".concat(this._text, "{\\p0}"), this;
        }
      }, {
        key: "coord",
        value: function coord(r, t) {
          var i = Math.pow(2, this._scale - 1),
            a = Math.ceil(r * i),
            s = Math.ceil(t * i);
          return this._text = "".concat(this._text, " ").concat(a, " ").concat(s), this;
        }
      }, {
        key: "append",
        value: function append(r) {
          return this._text += r, this;
        }
      }, {
        key: "merge",
        value: function merge(r) {
          return this._text += r.text, this;
        }
      }, {
        key: "pos",
        value: function pos(r, t) {
          return this.append("{\\pos(".concat(r, ",").concat(t, ")}"));
        }
      }, {
        key: "an",
        value: function an(r) {
          return this.append("{\\an".concat(r, "}"));
        }
      }, {
        key: "moveTo",
        value: function moveTo(r, t) {
          return this.append(" m").coord(r, t);
        }
      }, {
        key: "lineTo",
        value: function lineTo(r, t) {
          return this.append(" l").coord(r, t);
        }
      }, {
        key: "bezierCurve",
        value: function bezierCurve(r, t, i, a, s, l) {
          return this.append(" b").coord(r, t).coord(i, a).coord(s, l);
        }
      }, {
        key: "q",
        value: function q(r) {
          return this.append("{\\q".concat(r, "}"));
        }
      }, {
        key: "borderSize",
        value: function borderSize(r) {
          return this.append("{\\bord".concat(r, "}"));
        }
      }, {
        key: "fontBorderSize",
        value: function fontBorderSize(r) {
          return this.append("{\\bord".concat(r, "}"));
        }
      }, {
        key: "borderColor",
        value: function borderColor(r) {
          return this.append("{\\3c&H".concat(r, "&}"));
        }
      }, {
        key: "blur",
        value: function blur(r) {
          return this.append("{\\blur".concat(r, "}"));
        }
      }, {
        key: "blurX",
        value: function blurX(r) {
          return this.append("{\\blurX".concat(r, "}"));
        }
      }, {
        key: "blurY",
        value: function blurY(r) {
          return this.append("{\\blurY".concat(r, "}"));
        }
      }, {
        key: "fontSize",
        value: function fontSize(r) {
          return this.append("{\\fs".concat(r, "}"));
        }
      }, {
        key: "fontBorderAlpha",
        value: function fontBorderAlpha(r) {
          if (r.length !== 2) throw new Error("alpha error: ".concat(r));
          return this.append("{\\3a&H".concat(r, "}"));
        }
      }, {
        key: "fontBorderColor",
        value: function fontBorderColor(r) {
          if (r.length === 6) return this.append("{\\3c".concat(r, "&}"));
          if (r.length === 8) return this.append("{\\3c&".concat(r.slice(0, 6), "&}")).fontBorderAlpha(r.slice(-2));
          throw new Error("color error: ".concat(r));
        }
      }, {
        key: "newLine",
        value: function newLine() {
          return this.append("\r");
        }
      }, {
        key: "rectCcw",
        value: function rectCcw(r, t, i, a) {
          return this.moveTo(r, t).lineTo(r, a).lineTo(i, a).lineTo(i, t);
        }
      }, {
        key: "rectCw",
        value: function rectCw(r, t, i, a) {
          return this.moveTo(r, t).lineTo(i, t).lineTo(i, a).lineTo(r, a);
        }
      }, {
        key: "hexagonCw",
        value: function hexagonCw(r, t, i, a, s) {
          var l = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : s;
          return this.moveTo(r + s, t), r !== i && this.lineTo(i - l, t), this.lineTo(i, t + l), r !== i && this.lineTo(i - l, a), this.lineTo(r + s, a), this.lineTo(r, t + s), this;
        }
      }, {
        key: "hexagonCcw",
        value: function hexagonCcw(r, t, i, a, s) {
          var l = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : s;
          return this.moveTo(r + s, t), this.lineTo(r, t + s), this.lineTo(r + s, a), r !== i && this.lineTo(i - l, a), this.lineTo(i, t + l), r !== i && this.lineTo(i - l, t), this;
        }
      }, {
        key: "roundRectCw",
        value: function roundRectCw(r, t, i, a, s) {
          var l = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : s;
          var p = Lm * s,
            d = Lm * l;
          return this.moveTo(r + s, t), this.lineTo(i - l, t), l > 0 && this.bezierCurve(i - l + d, t, i, t + l - d, i, t + l), this.lineTo(i, a - l), l > 0 && this.bezierCurve(i, a - l + d, i - l + d, a, i - l, a), this.lineTo(r + s, a), s > 0 && this.bezierCurve(r + s - p, a, r, a - s + p, r, a - s), this.lineTo(r, t + s), s > 0 && this.bezierCurve(r, t + s - p, r + s - p, t, r + s, t), this;
        }
      }, {
        key: "roundRectCcw",
        value: function roundRectCcw(r, t, i, a, s) {
          var l = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : s;
          var p = Lm * s,
            d = Lm * l;
          return this.moveTo(r + s, t), s > 0 && this.bezierCurve(r + s - p, t, r, t + s - p, r, t + s), this.lineTo(r, a - s), s > 0 && this.bezierCurve(r, a - s + p, r + s - p, a, r + s, a), this.lineTo(i - l, a), l > 0 && this.bezierCurve(i - l + d, a, i, a - l + d, i, a - l), this.lineTo(i, t + l), l > 0 && this.bezierCurve(i, t + l - d, i - l + d, t, i - l, t), this;
        }
      }, {
        key: "drawTriangle",
        value: function drawTriangle(r, t, i, a, s, l) {
          return this.moveTo(r, t).lineTo(i, a).lineTo(s, l).lineTo(r, t);
        }
      }, {
        key: "drawRrhCw",
        value: function drawRrhCw(r, t, i, a, s, l, p) {
          return l ? this.hexagonCw(r, t, i, a, s, p) : this.roundRectCw(r, t, i, a, s, p);
        }
      }, {
        key: "drawRrHCcw",
        value: function drawRrHCcw(r, t, i, a, s, l, p) {
          return l ? this.hexagonCcw(r, t, i, a, s, p) : this.roundRectCcw(r, t, i, a, s, p);
        }
      }, {
        key: "end",
        value: function end() {
          return this.append(" s");
        }
      }, {
        key: "color",
        value: function color(r) {
          if (typeof r == "number" && (r = r.toString(16).padStart(6, "0")), r.length === 8) return this.append("{\\c&".concat(r.slice(0, 6), "&}")).alpha(r.slice(-2));
          if (r.length === 6) return this.append("{\\c&".concat(r, "&}"));
          throw new Error("AssDraw color error: ".concat(r));
        }
      }, {
        key: "colorText",
        value: function colorText(r, t) {
          return this.color(r).append(t);
        }
      }, {
        key: "alpha",
        value: function alpha(r) {
          return typeof r == "number" && (r = r.toString(16).padStart(2, "0")), this.append("{\\alpha&H".concat(r.padStart(2, "0"), "}"));
        }
      }, {
        key: "toString",
        value: function toString() {
          return this._text;
        }
      }]);
    }();
  var _loop4 = function _loop4() {
    var r = e.charAt(0).toLowerCase() + e.slice(1),
      t = new Aa(Mo[e]);
    _typeof(t.color) > "u" && (t.color = Mo[e]);
    var i = t.toHex();
    Ii.prototype[r] = function () {
      return this.color(i);
    }, Ii.prototype["".concat(r, "Text")] = function (a) {
      return this.colorText(i, a);
    };
  };
  for (var e in Mo) {
    _loop4();
  }
  function q4(_ref6) {
    var e = _ref6.x,
      r = _ref6.y,
      _ref6$borderSize = _ref6.borderSize,
      t = _ref6$borderSize === void 0 ? 0 : _ref6$borderSize,
      _ref6$color = _ref6.color,
      i = _ref6$color === void 0 ? "00000000" : _ref6$color,
      a = _ref6.width,
      s = _ref6.height,
      _ref6$borderColor = _ref6.borderColor,
      l = _ref6$borderColor === void 0 ? "00000000" : _ref6$borderColor,
      _ref6$borderRadius = _ref6.borderRadius,
      p = _ref6$borderRadius === void 0 ? 0 : _ref6$borderRadius;
    return new Ii().color(i).drawStart().pos(e, r).borderSize(t).borderColor(l).roundRectCw(0, 0, a, s, p).end().toString();
  }
  function T4(_ref7) {
    var e = _ref7.x,
      r = _ref7.y,
      t = _ref7.width,
      i = _ref7.height,
      a = _ref7.borderSize,
      s = _ref7.borderColor;
    return new Ii().color(s).drawStart().borderSize(0).pos(e, r).rectCw(0, 0, t, a).rectCw(0, 0, a, i).rectCw(0, i - a, t, i).rectCw(t - a, 0, t, i).toString();
  }
  function O4() {
    var _ref8 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      _ref8$onlyFirst = _ref8.onlyFirst,
      e = _ref8$onlyFirst === void 0 ? !1 : _ref8$onlyFirst;
    var r = ["[\\u001B\\u009B][[\\]()#;?]*(?:(?:(?:(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]+)*|[a-zA-Z\\d]+(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]*)*)?\\u0007)", "(?:(?:\\d{1,4}(?:;\\d{0,4})*)?[\\dA-PR-TZcf-nq-uy=><~]))"].join("|");
    return new RegExp(r, e ? void 0 : "g");
  }
  var lFe = O4();
  function Na(e, r) {
    if (!e) throw new Error(r || "Assertion failed");
  }
  var Ra = /*#__PURE__*/function () {
    function e(r, t, i, a) {
      _classCallCheck(this, e);
      _defineProperty(this, "x", void 0);
      _defineProperty(this, "y", void 0);
      _defineProperty(this, "width", void 0);
      _defineProperty(this, "height", void 0);
      this.x = r, this.y = t, this.width = i, this.height = a;
    }
    return _createClass(e, [{
      key: "x0",
      get: function get() {
        return this.x;
      }
    }, {
      key: "y0",
      get: function get() {
        return this.y;
      }
    }, {
      key: "x1",
      get: function get() {
        return this.x + this.width;
      }
    }, {
      key: "y1",
      get: function get() {
        return this.y + this.height;
      }
    }, {
      key: "toCoord",
      value: function toCoord() {
        return {
          x0: this.x0,
          y0: this.y0,
          x1: this.x1,
          y1: this.y1
        };
      }
    }, {
      key: "hasPoint",
      value: function hasPoint(r, t) {
        return r >= this.x0 && r <= this.x1 && t >= this.y0 && t <= this.y1;
      }
    }, {
      key: "placeCenter",
      value: function placeCenter(r) {
        var t = (this.width - r.width) / 2,
          i = (this.height - r.height) / 2,
          a = this.x + t,
          s = this.y + i;
        return new e(a, s, r.width, r.height);
      }
    }, {
      key: "scale",
      value: function scale(r) {
        return new e(this.x * r, this.y * r, this.width * r, this.height * r);
      }
    }], [{
      key: "fromCoord",
      value: function fromCoord(r) {
        return new e(r.x0, r.y0, r.x1 - r.x0, r.y1 - r.y0);
      }
    }]);
  }();
  function ou(e) {
    return Wxe(e), Number.parseFloat(e.slice(0, -1)) / 100;
  }
  function fb(e) {
    return e.endsWith("%");
  }
  function Wxe(e) {
    Na(fb(e), "not a valid percentage string: ".concat(e));
  }
  var zm = /*#__PURE__*/function () {
      function zm(r, t, i, a, s) {
        _classCallCheck(this, zm);
        _defineProperty(this, "event", void 0);
        _defineProperty(this, "x", void 0);
        _defineProperty(this, "y", void 0);
        _defineProperty(this, "hover", void 0);
        _defineProperty(this, "target", void 0);
        _defineProperty(this, "bubbles", !0);
        _defineProperty(this, "defaultPrevented", !1);
        _defineProperty(this, "source", void 0);
        this.source = r, this.x = t, this.y = i, this.event = s, this.hover = a;
      }
      return _createClass(zm, [{
        key: "preventDefault",
        value: function preventDefault() {
          this.defaultPrevented = !0;
        }
      }, {
        key: "clientX",
        get: function get() {
          return this.x;
        }
      }, {
        key: "clientY",
        get: function get() {
          return this.y;
        }
      }, {
        key: "offsetX",
        get: function get() {
          var _this$target;
          return this.x - (((_this$target = this.target) === null || _this$target === void 0 ? void 0 : _this$target.layoutNode.x) || 0);
        }
      }, {
        key: "offsetY",
        get: function get() {
          var _this$target2;
          return this.y - (((_this$target2 = this.target) === null || _this$target2 === void 0 ? void 0 : _this$target2.layoutNode.y) || 0);
        }
      }, {
        key: "stopPropagation",
        value: function stopPropagation() {
          this.bubbles = !1;
        }
      }]);
    }(),
    jm = /*#__PURE__*/function (_Ra) {
      function jm() {
        var _this6;
        var r = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
        var t = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
        var i = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
        var a = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 0;
        var s = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 0;
        var l = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : 0;
        var p = arguments.length > 6 && arguments[6] !== undefined ? arguments[6] : !1;
        var d = arguments.length > 7 && arguments[7] !== undefined ? arguments[7] : new Ra(0, 0, 0, 0);
        var v = arguments.length > 8 && arguments[8] !== undefined ? arguments[8] : 0;
        var g = arguments.length > 9 && arguments[9] !== undefined ? arguments[9] : 0;
        var x = arguments.length > 10 && arguments[10] !== undefined ? arguments[10] : !1;
        var S = arguments.length > 11 && arguments[11] !== undefined ? arguments[11] : !1;
        var b = arguments.length > 12 && arguments[12] !== undefined ? arguments[12] : !1;
        var q = arguments.length > 13 && arguments[13] !== undefined ? arguments[13] : !1;
        var E = arguments.length > 14 && arguments[14] !== undefined ? arguments[14] : !1;
        var C = arguments.length > 15 && arguments[15] !== undefined ? arguments[15] : !1;
        _classCallCheck(this, jm);
        (_this6 = _callSuper(this, jm, [r, t, i, a]), _defineProperty(_assertThisInitialized(_this6), "x", void 0), _defineProperty(_assertThisInitialized(_this6), "y", void 0), _defineProperty(_assertThisInitialized(_this6), "width", void 0), _defineProperty(_assertThisInitialized(_this6), "height", void 0), _defineProperty(_assertThisInitialized(_this6), "padding", void 0), _defineProperty(_assertThisInitialized(_this6), "border", void 0), _defineProperty(_assertThisInitialized(_this6), "hide", void 0), _defineProperty(_assertThisInitialized(_this6), "textRect", void 0), _defineProperty(_assertThisInitialized(_this6), "computedSizeCount", void 0), _defineProperty(_assertThisInitialized(_this6), "computedLayoutCount", void 0), _defineProperty(_assertThisInitialized(_this6), "_hideCache", void 0), _defineProperty(_assertThisInitialized(_this6), "_renderCache", void 0), _defineProperty(_assertThisInitialized(_this6), "_mouseDown", void 0), _defineProperty(_assertThisInitialized(_this6), "_mouseUp", void 0), _defineProperty(_assertThisInitialized(_this6), "_mouseIn", void 0), _defineProperty(_assertThisInitialized(_this6), "_focus", void 0)), _this6.x = r, _this6.y = t, _this6.width = i, _this6.height = a, _this6.padding = s, _this6.border = l, _this6.hide = p, _this6.textRect = d, _this6.computedSizeCount = v, _this6.computedLayoutCount = g, _this6._hideCache = x, _this6._renderCache = S, _this6._mouseDown = b, _this6._mouseUp = q, _this6._mouseIn = E, _this6._focus = C;
        return _this6;
      }
      _inherits(jm, _Ra);
      return _createClass(jm);
    }(Ra),
    Um = ["onClick", "onMouseDown", "onMouseUp", "onMouseMove", "onMousePress", "onMouseEnter", "onMouseLeave", "onWheelDown", "onWheelUp", "onBlur", "onFocus"];
  function Hm(e, r) {
    r.parentNode && Pc(r.parentNode, r), r.parentNode = e, e.childNodes.push(r);
  }
  function pb(e, r, t) {
    r.parentNode && Pc(r.parentNode, r), r.parentNode = e;
    var i = e.childNodes.indexOf(t);
    if (i >= 0) {
      e.childNodes.splice(i, 0, r);
      return;
    }
    e.childNodes.push(r);
  }
  function Pc(e, r) {
    r.parentNode = void 0;
    var t = e.childNodes.indexOf(r);
    t >= 0 && e.childNodes.splice(t, 1);
  }
  function A4(e, r, t) {
    e.attributes[r] = t;
  }
  function _4(e) {
    for (var _i7 = 0, _arr = ["top", "left", "bottom", "right"]; _i7 < _arr.length; _i7++) {
      var r = _arr[_i7];
      if (_typeof(e.attributes[r]) < "u") return !0;
    }
    return !1;
  }
  function Pi(e, r, t) {
    var i = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 0;
    var a = i;
    switch (_typeof(r)) {
      case "number":
        {
          a = r;
          break;
        }
      case "undefined":
        break;
      case "string":
        return fb(r) ? oe(e.parentNode, t) * ou(r) : Number.parseFloat(r);
      default:
        throw new Error("len type error: ".concat(r));
    }
    return a;
  }
  function Gxe(e) {
    return e.attributes.position === "absolute" || _4(e) || _typeof(e.attributes.x) < "u" || _typeof(e.attributes.y) < "u";
  }
  var Kxe = 1;
  function db(e, r) {
    return r ? e.attributes.width : e.attributes.height;
  }
  function hr(e, r) {
    return r ? e.layoutNode.x : e.layoutNode.y;
  }
  function oe(e, r) {
    return r ? e.layoutNode.width : e.layoutNode.height;
  }
  function we(e, r, t) {
    t ? e.layoutNode.x = r : e.layoutNode.y = r;
  }
  function iu(e, r, t) {
    t ? e.layoutNode.width = r : e.layoutNode.height = r;
  }
  var $m = /*#__PURE__*/function () {
    function $m() {
      _classCallCheck(this, $m);
      _defineProperty(this, "rootNode", void 0);
      _defineProperty(this, "renderCount", 0);
      _defineProperty(this, "maxRenderCount", 1024);
      this.rootNode = this.customCreateRootNode();
    }
    return _createClass($m, [{
      key: "rerender",
      value: function rerender() {
        this.renderCount = (this.renderCount + 1) % this.maxRenderCount, this.renderNode(this.rootNode, this.renderCount, 0);
      }
    }, {
      key: "computedNodeTLBR",
      value: function computedNodeTLBR(r) {
        var t = r.attributes,
          i = r.layoutNode,
          a = r.parentNode ? r.parentNode : r;
        for (; a && a.attributes.position === "absolute";) a = a.parentNode;
        switch (Na(!(_typeof(t.left) < "u" && _typeof(t.right) < "u"), "absolute position: do not set both left and right"), Na(!(_typeof(t.top) < "u" && _typeof(t.bottom) < "u"), "absolute position: do not set both top and bottom"), we(r, a.layoutNode.x, !0), we(r, a.layoutNode.y, !1), _typeof(t.left)) {
          case "number":
            {
              i.x = a.layoutNode.x + t.left;
              break;
            }
          case "undefined":
            break;
          case "string":
            {
              i.x = a.layoutNode.x + a.layoutNode.width * ou(t.left);
              break;
            }
          default:
            throw new Error("left type error: ".concat(t.left));
        }
        switch (_typeof(t.right)) {
          case "number":
            {
              i.x = a.layoutNode.x + a.layoutNode.width - t.right - i.width;
              break;
            }
          case "string":
            {
              i.x = a.layoutNode.x + a.layoutNode.width - i.width - a.layoutNode.width * ou(t.right);
              break;
            }
          case "undefined":
            break;
          default:
            throw new Error("right type error: ".concat(t.right));
        }
        switch (_typeof(t.top)) {
          case "number":
            {
              i.y = a.layoutNode.y + t.top;
              break;
            }
          case "string":
            {
              i.y = a.layoutNode.y + a.layoutNode.height * ou(t.top);
              break;
            }
          case "undefined":
            break;
          default:
            throw new Error("bottom type top: ".concat(t.top));
        }
        switch (_typeof(t.bottom)) {
          case "number":
            {
              i.y = a.layoutNode.y + a.layoutNode.height - t.bottom - i.height;
              break;
            }
          case "string":
            {
              i.y = a.layoutNode.y + a.layoutNode.height - i.height - a.layoutNode.height * ou(t.bottom);
              break;
            }
          case "undefined":
            break;
          default:
            throw new Error("bottom type bottom: ".concat(t.bottom));
        }
      }
    }, {
      key: "computeZIndex",
      value: function computeZIndex(r) {
        var t = r.attributes;
        if (typeof t.zIndex == "number") return t.zIndex;
        var i = r.parentNode,
          a = 1;
        for (; i;) {
          var _i8;
          if (_typeof(i.attributes.zIndex) > "u" && (i = i.parentNode, a += Kxe), i && typeof ((_i8 = i) === null || _i8 === void 0 || (_i8 = _i8.attributes) === null || _i8 === void 0 ? void 0 : _i8.zIndex) == "number") return i.attributes.zIndex + a;
        }
        return a;
      }
    }, {
      key: "computeNodeSize",
      value: function computeNodeSize(r, t, i) {
        var a = r.attributes,
          s = r.layoutNode,
          l = r.attributes.flexDirection !== "row";
        if (r.layoutNode.computedSizeCount === t) return;
        s.computedSizeCount = t;
        var p = this.computeZIndex(r);
        if (this.customComputeZIndex(r, p, t, i), this.customIsRootNode(r)) {
          var _iterator10 = _createForOfIteratorHelper(r.childNodes),
            _step10;
          try {
            for (_iterator10.s(); !(_step10 = _iterator10.n()).done;) {
              var E = _step10.value;
              this.computeNodeSize(E, t, i + 1);
            }
          } catch (err) {
            _iterator10.e(err);
          } finally {
            _iterator10.f();
          }
          return;
        }
        var d = Pi(r, a.padding, l);
        s.padding = d;
        var v = Pi(r, a.borderSize, l);
        s.border = v;
        var g = d * 2 + v * 2,
          x = db(r, l),
          S = db(r, !l),
          b = x === void 0 || x === "auto",
          q = S === void 0 || S === "auto";
        if (typeof a.text == "string") {
          var _this$customMeasureNo = this.customMeasureNode(r),
            _E2 = _this$customMeasureNo.width,
            C = _this$customMeasureNo.height;
          s.textRect = new Ra(s.textRect.x, s.textRect.y, _E2, C), b ? s.width = g + _E2 : s.width = g + Pi(r, x, !0), q ? s.height = g + C : s.height = g + Pi(r, S, !1);
          var _iterator11 = _createForOfIteratorHelper(r.childNodes),
            _step11;
          try {
            for (_iterator11.s(); !(_step11 = _iterator11.n()).done;) {
              var _T2 = _step11.value;
              this.computeNodeSize(_T2, t, i + 1);
            }
          } catch (err) {
            _iterator11.e(err);
          } finally {
            _iterator11.f();
          }
          return;
        }
        if (b || q) {
          var _E3 = 0,
            _C2 = 0,
            _T3 = 0,
            _D2 = 0;
          b || this.computeNodeSizeAxis(r, x, l, g), q || this.computeNodeSizeAxis(r, S, !l, g);
          var _iterator12 = _createForOfIteratorHelper(r.childNodes),
            _step12;
          try {
            for (_iterator12.s(); !(_step12 = _iterator12.n()).done;) {
              var _M3 = _step12.value;
              if (this.computeNodeSize(_M3, t, i + 1), _M3.attributes.position === "absolute") continue;
              var k = oe(_M3, l),
                W = oe(_M3, !l);
              _E3 = Math.max(_E3, k), _C2 = Math.max(_C2, W), _T3 += k, _D2 += W;
            }
          } catch (err) {
            _iterator12.e(err);
          } finally {
            _iterator12.f();
          }
          if (b && (l ? iu(r, _T3 + g, !0) : iu(r, _C2 + g, !0)), q && (l ? iu(r, _C2 + g, !1) : iu(r, _T3 + g, !1)), r.attributes.alignContent === "stretch") {
            var _iterator13 = _createForOfIteratorHelper(r.childNodes),
              _step13;
            try {
              for (_iterator13.s(); !(_step13 = _iterator13.n()).done;) {
                var _M2 = _step13.value;
                l ? _typeof(_M2.attributes.height) > "u" && (_M2.layoutNode.height = r.layoutNode.height - g) : _typeof(_M2.attributes.width) > "u" && (_M2.layoutNode.width = r.layoutNode.width - g);
              }
            } catch (err) {
              _iterator13.e(err);
            } finally {
              _iterator13.f();
            }
          }
        } else {
          this.computeNodeSizeAxis(r, x, l, g), this.computeNodeSizeAxis(r, S, !l, g);
          var _E4 = 0,
            _C3 = 0;
          var _iterator14 = _createForOfIteratorHelper(r.childNodes),
            _step14;
          try {
            for (_iterator14.s(); !(_step14 = _iterator14.n()).done;) {
              var _T5 = _step14.value;
              this.computeNodeSize(_T5, t, i + 1);
              var _D3 = oe(_T5, l),
                _M4 = oe(_T5, !l);
              _E4 = Math.max(_E4, _D3), _C3 = Math.max(_C3, _M4);
            }
          } catch (err) {
            _iterator14.e(err);
          } finally {
            _iterator14.f();
          }
          if (r.attributes.alignContent === "stretch") {
            var _iterator15 = _createForOfIteratorHelper(r.childNodes),
              _step15;
            try {
              for (_iterator15.s(); !(_step15 = _iterator15.n()).done;) {
                var _T4 = _step15.value;
                l ? _typeof(_T4.attributes.height) > "u" && (_T4.layoutNode.height = r.layoutNode.height - g) : _typeof(_T4.attributes.width) > "u" && (_T4.layoutNode.width = r.layoutNode.width - g);
              }
            } catch (err) {
              _iterator15.e(err);
            } finally {
              _iterator15.f();
            }
          }
        }
      }
    }, {
      key: "computeNodeSizeAxis",
      value: function computeNodeSizeAxis(r, t, i, a) {
        if (typeof t == "number") {
          var s = t + a;
          iu(r, s, i);
          return;
        }
        if (typeof t == "string") {
          Na(t.endsWith("%"), "length string must end with %");
          var _s3 = db(r.parentNode, i);
          Na(!(_s3 === "auto" || _s3 === void 0), "The parent of a node of relative size cannot be auto or undefined");
          var l = Pi(r, t, i) + a;
          iu(r, l, i);
          return;
        }
        throw new Error("computeNodeSize error, not support length: ".concat(t));
      }
    }, {
      key: "computedNodeAlign",
      value: function computedNodeAlign(r) {
        var t = r.attributes,
          i = t.flexDirection !== "row",
          _t$justifyContent = t.justifyContent,
          a = _t$justifyContent === void 0 ? "start" : _t$justifyContent,
          _t$alignItems = t.alignItems,
          s = _t$alignItems === void 0 ? "start" : _t$alignItems,
          l = r.childNodes.filter(function (N) {
            return !Gxe(N);
          });
        a === "end" && l.reverse();
        var p = r.layoutNode.padding + r.layoutNode.border,
          d = hr(r, i) + p,
          v = hr(r, !i) + p,
          g = oe(r, i) - p * 2,
          x = oe(r, !i) - p * 2,
          S = d + g,
          b = d + g,
          q = v + x,
          E = 0,
          C = 0,
          T = 0,
          D = 0,
          M = 0,
          k = 0,
          W = 0,
          ee = 0;
        switch (a) {
          case "start":
            switch (s) {
              case "space-between":
              case "start":
                {
                  E = d, C = v;
                  var _iterator16 = _createForOfIteratorHelper(l),
                    _step16;
                  try {
                    for (_iterator16.s(); !(_step16 = _iterator16.n()).done;) {
                      var N = _step16.value;
                      var B = oe(N, i),
                        U = oe(N, !i);
                      k = Math.max(k, U), M = Math.max(M, B), E + B > b ? (C += k, we(N, d, i), we(N, C, !i), E = d + B) : (we(N, E, i), we(N, C, !i), E += B);
                    }
                  } catch (err) {
                    _iterator16.e(err);
                  } finally {
                    _iterator16.f();
                  }
                  return;
                }
              case "end":
                {
                  E = d, C = q;
                  var _iterator17 = _createForOfIteratorHelper(l),
                    _step17;
                  try {
                    for (_iterator17.s(); !(_step17 = _iterator17.n()).done;) {
                      var _N2 = _step17.value;
                      var _B2 = oe(_N2, i),
                        _U2 = oe(_N2, !i);
                      k = Math.max(k, _U2), M = Math.max(M, _B2), E + _B2 > b ? (C += k, we(_N2, d, i), we(_N2, C - _U2, !i), E = d + _B2) : (we(_N2, E, i), we(_N2, C - _U2, !i), E += _B2);
                    }
                  } catch (err) {
                    _iterator17.e(err);
                  } finally {
                    _iterator17.f();
                  }
                  return;
                }
              case "center":
                {
                  var _iterator18 = _createForOfIteratorHelper(l),
                    _step18;
                  try {
                    for (_iterator18.s(); !(_step18 = _iterator18.n()).done;) {
                      var _N3 = _step18.value;
                      var _B3 = oe(_N3, i),
                        _U3 = oe(_N3, !i),
                        me = hr(_N3, i),
                        be = hr(_N3, !i);
                      W += _B3, k = Math.max(k, _U3);
                    }
                  } catch (err) {
                    _iterator18.e(err);
                  } finally {
                    _iterator18.f();
                  }
                  E = d, C = v;
                  var _iterator19 = _createForOfIteratorHelper(l),
                    _step19;
                  try {
                    for (_iterator19.s(); !(_step19 = _iterator19.n()).done;) {
                      var _N4 = _step19.value;
                      var _B4 = oe(_N4, i),
                        _U4 = oe(_N4, !i),
                        _me2 = hr(_N4, i),
                        _be2 = hr(_N4, !i);
                      E + _B4 > S ? (C += k, we(_N4, d, i), we(_N4, C, !i), E = d + _B4) : (we(_N4, E, i), we(_N4, C + (x - _U4) / 2, !i), E += _B4);
                    }
                  } catch (err) {
                    _iterator19.e(err);
                  } finally {
                    _iterator19.f();
                  }
                  return;
                }
            }
          case "end":
            switch (s) {
              case "space-between":
              case "start":
                {
                  E = b, C = v;
                  var _iterator20 = _createForOfIteratorHelper(l),
                    _step20;
                  try {
                    for (_iterator20.s(); !(_step20 = _iterator20.n()).done;) {
                      var _N5 = _step20.value;
                      var _B5 = oe(_N5, i),
                        _U5 = oe(_N5, !i);
                      k = Math.max(k, _U5), M = Math.max(M, _B5), E - _B5 < d ? (C -= k, we(_N5, b - _B5, i), we(_N5, C, !i), E -= _B5) : (we(_N5, E - _B5, i), we(_N5, C, !i), E -= _B5);
                    }
                  } catch (err) {
                    _iterator20.e(err);
                  } finally {
                    _iterator20.f();
                  }
                  return;
                }
              case "end":
                {
                  E = b, C = q;
                  var _iterator21 = _createForOfIteratorHelper(l),
                    _step21;
                  try {
                    for (_iterator21.s(); !(_step21 = _iterator21.n()).done;) {
                      var _N6 = _step21.value;
                      var _B6 = oe(_N6, i),
                        _U6 = oe(_N6, !i);
                      k = Math.max(k, _U6), M = Math.max(M, _B6), E - _B6 < d ? (C -= k, we(_N6, b - _B6, i), we(_N6, C - _U6, !i), E -= _B6) : (we(_N6, E - _B6, i), we(_N6, C - _U6, !i), E -= _B6);
                    }
                  } catch (err) {
                    _iterator21.e(err);
                  } finally {
                    _iterator21.f();
                  }
                  return;
                }
              case "center":
                {
                  E = b, C = v;
                  var _iterator22 = _createForOfIteratorHelper(l),
                    _step22;
                  try {
                    for (_iterator22.s(); !(_step22 = _iterator22.n()).done;) {
                      var _N7 = _step22.value;
                      var _B7 = oe(_N7, i),
                        _U7 = oe(_N7, !i);
                      k = Math.max(k, _U7), M = Math.max(M, _B7);
                    }
                  } catch (err) {
                    _iterator22.e(err);
                  } finally {
                    _iterator22.f();
                  }
                  var _iterator23 = _createForOfIteratorHelper(l),
                    _step23;
                  try {
                    for (_iterator23.s(); !(_step23 = _iterator23.n()).done;) {
                      var _N8 = _step23.value;
                      var _B8 = oe(_N8, i),
                        _U8 = oe(_N8, !i),
                        _me3 = hr(_N8, i),
                        _be3 = hr(_N8, !i),
                        re = E - _B8;
                      re < d || (we(_N8, re, i), we(_N8, C + (k - _U8) / 2, !i), E -= _B8);
                    }
                  } catch (err) {
                    _iterator23.e(err);
                  } finally {
                    _iterator23.f();
                  }
                  return;
                }
            }
          case "center":
            switch (s) {
              case "space-between":
              case "start":
                {
                  C = v;
                  var _iterator24 = _createForOfIteratorHelper(l),
                    _step24;
                  try {
                    for (_iterator24.s(); !(_step24 = _iterator24.n()).done;) {
                      var _N9 = _step24.value;
                      var _B9 = oe(_N9, i),
                        _U9 = oe(_N9, !i);
                      k = Math.max(k, _U9), M = Math.max(M, _B9), W += _B9;
                    }
                  } catch (err) {
                    _iterator24.e(err);
                  } finally {
                    _iterator24.f();
                  }
                  E = d + (g - W) / 2;
                  var _iterator25 = _createForOfIteratorHelper(l),
                    _step25;
                  try {
                    for (_iterator25.s(); !(_step25 = _iterator25.n()).done;) {
                      var _N10 = _step25.value;
                      var _B10 = oe(_N10, i),
                        _U10 = oe(_N10, !i),
                        _me4 = hr(_N10, i),
                        _be4 = hr(_N10, !i);
                      E + _B10 > b || (we(_N10, E, i), we(_N10, C, !i), E += _B10);
                    }
                  } catch (err) {
                    _iterator25.e(err);
                  } finally {
                    _iterator25.f();
                  }
                  return;
                }
              case "end":
                {
                  C = q;
                  var _iterator26 = _createForOfIteratorHelper(l),
                    _step26;
                  try {
                    for (_iterator26.s(); !(_step26 = _iterator26.n()).done;) {
                      var _N11 = _step26.value;
                      var _B11 = oe(_N11, i),
                        _U11 = oe(_N11, !i);
                      k = Math.max(k, _U11), M = Math.max(M, _B11), W += _B11;
                    }
                  } catch (err) {
                    _iterator26.e(err);
                  } finally {
                    _iterator26.f();
                  }
                  E = d + (g - W) / 2;
                  var _iterator27 = _createForOfIteratorHelper(l),
                    _step27;
                  try {
                    for (_iterator27.s(); !(_step27 = _iterator27.n()).done;) {
                      var _N12 = _step27.value;
                      var _B12 = oe(_N12, i),
                        _U12 = oe(_N12, !i),
                        _me5 = hr(_N12, i),
                        _be5 = hr(_N12, !i);
                      E + _B12 > b || (we(_N12, E, i), we(_N12, C - _U12, !i), E += _B12);
                    }
                  } catch (err) {
                    _iterator27.e(err);
                  } finally {
                    _iterator27.f();
                  }
                  return;
                }
              case "center":
                {
                  C = v;
                  var _iterator28 = _createForOfIteratorHelper(l),
                    _step28;
                  try {
                    for (_iterator28.s(); !(_step28 = _iterator28.n()).done;) {
                      var _N13 = _step28.value;
                      var _B13 = oe(_N13, i),
                        _U13 = oe(_N13, !i);
                      k = Math.max(k, _U13), M = Math.max(M, _B13), W += _B13;
                    }
                  } catch (err) {
                    _iterator28.e(err);
                  } finally {
                    _iterator28.f();
                  }
                  E = d + (g - W) / 2;
                  var _iterator29 = _createForOfIteratorHelper(l),
                    _step29;
                  try {
                    for (_iterator29.s(); !(_step29 = _iterator29.n()).done;) {
                      var _N14 = _step29.value;
                      var _B14 = oe(_N14, i),
                        _U14 = oe(_N14, !i),
                        _me6 = hr(_N14, i),
                        _be6 = hr(_N14, !i);
                      E + _B14 > b || (we(_N14, E, i), we(_N14, C + (x - _U14) / 2, !i), E += _B14);
                    }
                  } catch (err) {
                    _iterator29.e(err);
                  } finally {
                    _iterator29.f();
                  }
                  return;
                }
            }
          case "space-between":
            switch (s) {
              case "space-between":
              case "start":
                {
                  C = v;
                  var _iterator30 = _createForOfIteratorHelper(l),
                    _step30;
                  try {
                    for (_iterator30.s(); !(_step30 = _iterator30.n()).done;) {
                      var _B16 = _step30.value;
                      var _U16 = oe(_B16, i),
                        _me8 = oe(_B16, !i);
                      k = Math.max(k, _me8), M = Math.max(M, _U16), W += _U16;
                    }
                  } catch (err) {
                    _iterator30.e(err);
                  } finally {
                    _iterator30.f();
                  }
                  E = d;
                  var _N15 = (g - W) / (l.length - 1);
                  for (var _B15 = 0; _B15 < l.length; _B15++) {
                    var _U15 = l[_B15],
                      _me7 = oe(_U15, i),
                      _be7 = oe(_U15, !i),
                      _re2 = hr(_U15, i),
                      Ne = hr(_U15, !i);
                    E + _me7 > b || (we(_U15, E, i), we(_U15, C, !i), E += _me7 + _N15);
                  }
                  return;
                }
              case "end":
                {
                  C = q;
                  var _iterator31 = _createForOfIteratorHelper(l),
                    _step31;
                  try {
                    for (_iterator31.s(); !(_step31 = _iterator31.n()).done;) {
                      var _B18 = _step31.value;
                      var _U18 = oe(_B18, i),
                        _me10 = oe(_B18, !i);
                      k = Math.max(k, _me10), M = Math.max(M, _U18), W += _U18;
                    }
                  } catch (err) {
                    _iterator31.e(err);
                  } finally {
                    _iterator31.f();
                  }
                  E = d;
                  var _N16 = (g - W) / (l.length - 1);
                  for (var _B17 = 0; _B17 < l.length; _B17++) {
                    var _U17 = l[_B17],
                      _me9 = oe(_U17, i),
                      _be8 = oe(_U17, !i),
                      _re3 = hr(_U17, i),
                      _Ne = hr(_U17, !i);
                    E + _me9 > b || (we(_U17, E, i), we(_U17, C - _be8, !i), E += _me9 + _N16);
                  }
                  return;
                }
              case "center":
                {
                  C = v;
                  var _iterator32 = _createForOfIteratorHelper(l),
                    _step32;
                  try {
                    for (_iterator32.s(); !(_step32 = _iterator32.n()).done;) {
                      var _B20 = _step32.value;
                      var _U20 = oe(_B20, i),
                        _me12 = oe(_B20, !i);
                      k = Math.max(k, _me12), M = Math.max(M, _U20), W += _U20;
                    }
                  } catch (err) {
                    _iterator32.e(err);
                  } finally {
                    _iterator32.f();
                  }
                  E = d;
                  var _N17 = (g - W) / (l.length - 1);
                  for (var _B19 = 0; _B19 < l.length; _B19++) {
                    var _U19 = l[_B19],
                      _me11 = oe(_U19, i),
                      _be9 = oe(_U19, !i),
                      _re4 = hr(_U19, i),
                      _Ne2 = hr(_U19, !i);
                    E + _me11 > b || (we(_U19, E, i), we(_U19, C + (x - _be9) / 2, !i), E += _me11 + _N17);
                  }
                  return;
                }
            }
        }
        throw new Error("not support flex align: ".concat(a, " ").concat(s));
      }
    }, {
      key: "computeNodeLayout",
      value: function computeNodeLayout(r, t) {
        var i = r.layoutNode,
          a = r.attributes;
        if (i.computedLayoutCount !== t) {
          switch (i.computedLayoutCount = t, _4(r) && this.computedNodeTLBR(r), typeof a.x == "number" && (i.x = a.x), typeof a.y == "number" && (i.y = a.y), a.position) {
            case "relative":
            case void 0:
              {
                r.childNodes.length && r.attributes.display === "flex" && this.computedNodeAlign(r);
                break;
              }
            case "absolute":
              {
                r.childNodes.length && r.attributes.display === "flex" && this.computedNodeAlign(r);
                break;
              }
            default:
              throw new Error("error position: ".concat(a.position));
          }
          var _iterator33 = _createForOfIteratorHelper(r.childNodes),
            _step33;
          try {
            for (_iterator33.s(); !(_step33 = _iterator33.n()).done;) {
              var s = _step33.value;
              this.computeNodeLayout(s, t);
            }
          } catch (err) {
            _iterator33.e(err);
          } finally {
            _iterator33.f();
          }
        }
      }
    }, {
      key: "computedLayout",
      value: function computedLayout(r, t) {
        r.layoutNode.computedLayoutCount !== t && (this.computeNodeSize(r, t, 0), this.computeNodeLayout(r, t));
      }
    }, {
      key: "renderNode",
      value: function renderNode(r, t, i) {
        this.computedLayout(this.rootNode, t), this.customRenderNode(r, t, i);
        var _iterator34 = _createForOfIteratorHelper(r.childNodes),
          _step34;
        try {
          for (_iterator34.s(); !(_step34 = _iterator34.n()).done;) {
            var a = _step34.value;
            this.renderNode(a, t, i + 1);
          }
        } catch (err) {
          _iterator34.e(err);
        } finally {
          _iterator34.f();
        }
      }
    }, {
      key: "dispatchMouseEventInner",
      value: function dispatchMouseEventInner(r, t, i) {
        if (!(r.attributes.hide || r.attributes.pointerEvents === "none")) {
          var _iterator35 = _createForOfIteratorHelper(r.childNodes),
            _step35;
          try {
            for (_iterator35.s(); !(_step35 = _iterator35.n()).done;) {
              var a = _step35.value;
              this.dispatchMouseEventInner(a, t, i);
            }
          } catch (err) {
            _iterator35.e(err);
          } finally {
            _iterator35.f();
          }
          this.dispatchMouseEventForNode(r, t, i);
        }
      }
    }, {
      key: "dispatchMouseEvent",
      value: function dispatchMouseEvent(r, t) {
        var i = {
          onClick: [],
          onMouseDown: [],
          onMouseUp: [],
          onMouseMove: [],
          onMousePress: [],
          onMouseEnter: [],
          onMouseLeave: [],
          onWheelDown: [],
          onWheelUp: [],
          onBlur: [],
          onFocus: []
        };
        this.dispatchMouseEventInner(r, t, i);
        for (var _i9 = 0, _Um = Um; _i9 < _Um.length; _i9++) {
          var _s$0$attributes$a, _s$0$attributes;
          var a = _Um[_i9];
          var s = i[a];
          if (!s.length) continue;
          s.length === 1 && ((_s$0$attributes$a = (_s$0$attributes = s[0].attributes)[a]) === null || _s$0$attributes$a === void 0 ? void 0 : _s$0$attributes$a.call(_s$0$attributes, t));
          var l = s.sort(function (p, d) {
            return (d.attributes.zIndex || 0) - (p.attributes.zIndex || 0);
          });
          var _iterator36 = _createForOfIteratorHelper(l),
            _step36;
          try {
            for (_iterator36.s(); !(_step36 = _iterator36.n()).done;) {
              var _p$attributes$a, _p$attributes;
              var p = _step36.value;
              t.bubbles && ((_p$attributes$a = (_p$attributes = p.attributes)[a]) === null || _p$attributes$a === void 0 ? void 0 : _p$attributes$a.call(_p$attributes, t));
            }
          } catch (err) {
            _iterator36.e(err);
          } finally {
            _iterator36.f();
          }
        }
      }
    }, {
      key: "dispatchMouseEventForNode",
      value: function dispatchMouseEventForNode(r, t, i) {
        if (!t.bubbles || r.attributes.pointerEvents === "none" || r.attributes.hide) return;
        var a = r.layoutNode;
        if (r.layoutNode.hasPoint(t.x, t.y)) {
          if (_typeof(t.target) > "u" && (t.target = r), t.hover) {
            if (this.customIsWheelDown(t)) {
              i.onWheelDown.push(r);
              return;
            }
            if (this.customIsWheelUp(t)) {
              i.onWheelUp.push(r);
              return;
            }
            this.customIsMousePress(t) ? a._mouseDown ? i.onMousePress.push(r) : a._mouseIn ? i.onMouseMove.push(r) : (i.onMouseEnter.push(r), a._mouseIn = !0) : !a._mouseDown && this.customIsMouseDown(t) ? a._mouseDown || (i.onMouseDown.push(r), i.onClick.push(r), a._mouseDown = !0, a._mouseUp = !1, a._focus || (a._focus = !0, i.onFocus.push(r))) : this.customIsMouseUp(t) && (a._mouseUp || (i.onMouseUp.push(r), a._mouseDown = !1, a._mouseUp = !0, a._focus || (i.onFocus.push(r), a._focus = !0)));
          } else a._mouseIn && (i.onMouseLeave.push(r), a._mouseIn = !1);
        } else a._mouseIn && (i.onMouseLeave.push(r), a._mouseIn = !1), a._focus && (this.customIsMouseDown(t) || this.customIsMouseUp(t)) && (i.onBlur.push(r), a._focus = !1);
      }
    }]);
  }();
  var Yxe = {
    children: !0,
    ref: !0,
    key: !0,
    style: !0,
    forwardedRef: !0,
    unstable_applyCache: !0,
    unstable_applyDrawHitFromCache: !0,
    className: !0
  };
  function mb(e, r) {
    for (var t in r) Yxe[t] || A4(e, t, r[t]);
  }
  var Ma = function Ma(e) {
    var r = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [new hi({
      cache: !0
    }), new hi({
      cache: !0
    }), new hi({
      cache: !0
    })];
    return {
      attributes: {},
      childNodes: [],
      parentNode: void 0,
      layoutNode: new jm(),
      props: {
        nodeName: e,
        osdOverlays: r
      }
    };
  };
  function ka(e, r) {
    for (; e && _typeof(e.attributes[r]) > "u";) if (e.parentNode) e = e.parentNode;else return;
    return e.attributes[r];
  }
  function hb(e, r, t) {
    var _ka, _ka2, _ka3, _ka4, _ka5;
    var _e$attributes$text = e.attributes.text,
      i = _e$attributes$text === void 0 ? "" : _e$attributes$text,
      a = lc(),
      s = (_ka = ka(e, "font")) !== null && _ka !== void 0 ? _ka : "",
      l = (_ka2 = ka(e, "color")) !== null && _ka2 !== void 0 ? _ka2 : "FFFFFFFF",
      p = (_ka3 = ka(e, "fontSize")) !== null && _ka3 !== void 0 ? _ka3 : "5%",
      d = (_ka4 = ka(e, "fontBorderSize")) !== null && _ka4 !== void 0 ? _ka4 : 0,
      v = (_ka5 = ka(e, "fontBorderColor")) !== null && _ka5 !== void 0 ? _ka5 : "000000",
      g = "FF";
    return l.length === 6 && (g = "00"), l.length === 8 && (g = l.slice(6, 8), l = l.slice(0, 6)), new Ii().pos(r, t).font(s).fontSize(Pi(e, p, !1, 32) * a).fontBorderColor(v).fontBorderSize(Pi(e, d, !1, 0) * a).color(l).alpha(g).append(i).toString();
  }
  var Vm,
    Wm = {};
  function Gm(e) {
    var r = e.layoutNode,
      t = lc(),
      i = hb(e, 0, 0);
    if (Wm[i]) return Wm[i];
    Vm || (Vm = new hi({
      computeBounds: !0,
      hidden: !0
    })), Vm.data = i;
    var _Vm$update = Vm.update(1 / t),
      a = _Vm$update.width,
      s = _Vm$update.height;
    return r.textRect.width = a, r.textRect.height = s, Wm[i] = {
      width: a,
      height: s
    }, Wm[i];
  }
  var N4 = "@mpv-easy/root",
    Xxe = "@mpv-easy/box",
    Km,
    pt = function pt() {
      return Km || (Km = Ma(N4), Km);
    },
    qi = 30,
    gb = /*#__PURE__*/function (_$m) {
      function gb() {
        var _this7;
        _classCallCheck(this, gb);
        _this7 = _callSuper(this, gb), _this7.renderCount = 0, _this7.maxRenderCount = 1024, _this7.rootNode = pt();
        return _this7;
      }
      _inherits(gb, _$m);
      return _createClass(gb, [{
        key: "customCreateMouseEvent",
        value: function customCreateMouseEvent(r, t, i, a, s) {
          return new zm(r, t, i, a, s);
        }
      }, {
        key: "customIsWheelDown",
        value: function customIsWheelDown(r) {
          return r.event.key_name === "WHEEL_DOWN";
        }
      }, {
        key: "customIsWheelUp",
        value: function customIsWheelUp(r) {
          return r.event.key_name === "WHEEL_UP";
        }
      }, {
        key: "customIsMousePress",
        value: function customIsMousePress(r) {
          return r.event.event === "press";
        }
      }, {
        key: "customIsMouseDown",
        value: function customIsMouseDown(r) {
          return r.event.event === "down";
        }
      }, {
        key: "customIsMouseUp",
        value: function customIsMouseUp(r) {
          return r.event.event === "up";
        }
      }, {
        key: "renderToMpv",
        value: function renderToMpv() {
          this.rerender();
        }
      }, {
        key: "customCreateNode",
        value: function customCreateNode() {
          return Ma(Xxe);
        }
      }, {
        key: "customIsRootNode",
        value: function customIsRootNode(r) {
          return r.props.nodeName === N4;
        }
      }, {
        key: "customCreateRootNode",
        value: function customCreateRootNode() {
          return pt();
        }
      }, {
        key: "customRenderNode",
        value: function customRenderNode(r) {
          var _ka6;
          var t = (_ka6 = ka(r, "hide")) !== null && _ka6 !== void 0 ? _ka6 : !1,
            _r$props$osdOverlays = _slicedToArray(r.props.osdOverlays, 3),
            i = _r$props$osdOverlays[0],
            a = _r$props$osdOverlays[1],
            s = _r$props$osdOverlays[2],
            l = r.layoutNode,
            p = r.attributes;
          if (t) {
            var _r$props$imageOverlay;
            if (l._hideCache) return;
            l._hideCache = !0;
            var _iterator37 = _createForOfIteratorHelper(r.props.osdOverlays),
              _step37;
            try {
              for (_iterator37.s(); !(_step37 = _iterator37.n()).done;) {
                var d = _step37.value;
                d.hidden = !0, d.computeBounds = !1, d.update();
              }
            } catch (err) {
              _iterator37.e(err);
            } finally {
              _iterator37.f();
            }
            typeof p.backgroundImage == "string" && r.props.imageOverlay && ((_r$props$imageOverlay = r.props.imageOverlay) === null || _r$props$imageOverlay === void 0 ? void 0 : _r$props$imageOverlay.remove());
          } else if (r.props.nodeName === "@mpv-easy/box") {
            l._hideCache = !1;
            var _d2 = lc(),
              v = p.backgroundColor,
              g = p.borderSize,
              _p$borderColor = p.borderColor,
              x = _p$borderColor === void 0 ? "FFFFFFFF" : _p$borderColor,
              _p$padding = p.padding,
              S = _p$padding === void 0 ? 0 : _p$padding,
              _p$justifyContent = p.justifyContent,
              b = _p$justifyContent === void 0 ? "start" : _p$justifyContent,
              _p$alignItems = p.alignItems,
              q = _p$alignItems === void 0 ? "start" : _p$alignItems,
              _p$borderRadius = p.borderRadius,
              E = _p$borderRadius === void 0 ? 0 : _p$borderRadius,
              _p$flexDirection = p.flexDirection,
              C = _p$flexDirection === void 0 ? "column" : _p$flexDirection,
              _T6 = p.backgroundImage,
              _p$backgroundImageFor = p.backgroundImageFormat,
              _D4 = _p$backgroundImageFor === void 0 ? "bgra" : _p$backgroundImageFor,
              _M5 = typeof S == "string" ? sm(S) * l.width : S,
              k = typeof E == "string" ? sm(E) * l.width : E;
            x.length === 6 && (x += "00"), typeof g == "string" && (g = l.width * sm(g));
            var W = l.x,
              ee = l.y,
              N = l.width,
              B = l.height;
            _typeof(g) < "u" && (s.data = T4({
              x: W * _d2,
              y: ee * _d2,
              width: N * _d2,
              height: B * _d2,
              borderColor: x,
              borderSize: g * _d2
            }), s.hidden = !1, s.computeBounds = !1, s.hidden = !1, s.update()), g = g || 0;
            var U = _typeof(p.text) < "u";
            if (U) {
              var be = 0 + _M5 + l.x + g,
                re = 0 + _M5 + l.y + g,
                Ne = l.textRect;
              switch (C) {
                case "column":
                  {
                    switch (b) {
                      case "start":
                        break;
                      case "center":
                        {
                          be += (l.width - Ne.width - 2 * _M5 - 2 * g) / 2;
                          break;
                        }
                      case "end":
                        {
                          be += l.width - Ne.width - 2 * _M5 - 2 * g;
                          break;
                        }
                    }
                    switch (q) {
                      case "start":
                        break;
                      case "center":
                        {
                          re += (l.height - Ne.height - 2 * _M5 - 2 * g) / 2;
                          break;
                        }
                      case "end":
                        {
                          re += l.height - Ne.height - 2 * _M5 - 2 * g;
                          break;
                        }
                    }
                    break;
                  }
                case "row":
                  {
                    switch (b) {
                      case "start":
                        break;
                      case "center":
                        {
                          re += (l.height - Ne.height - 2 * _M5 - 2 * g) / 2;
                          break;
                        }
                      case "end":
                        {
                          re += l.height - Ne.height - 2 * _M5 - 2 * g;
                          break;
                        }
                    }
                    switch (q) {
                      case "start":
                        break;
                      case "center":
                        {
                          be += (l.width - Ne.width - 2 * _M5 - 2 * g) / 2;
                          break;
                        }
                      case "end":
                        {
                          be += l.width - Ne.width - 2 * _M5 - 2 * g;
                          break;
                        }
                    }
                  }
                default:
                  throw new Error("text layout not support: justifyContent ".concat(b, " alignItems ").concat(q));
              }
              i.data = hb(r, be * _d2, re * _d2), i.hidden = !1, i.computeBounds = !0;
            }
            var me = i.update(1 / _d2);
            if (_typeof(v) < "u") {
              var _r$parentNode;
              v.length === 6 && (v += "00");
              var _be10 = W,
                _re5 = ee,
                _Ne3 = N,
                se = B;
              U && ((_r$parentNode = r.parentNode) === null || _r$parentNode === void 0 ? void 0 : _r$parentNode.attributes.alignContent) !== "stretch" && (_be10 = me.x, _re5 = me.y, _Ne3 = me.width, se = me.height);
              var Qe = new ci(_be10 + g + _M5, _re5 + g + _M5, _Ne3 - 2 * g - 2 * _M5, se - 2 * g - 2 * _M5),
                Me = q4(_objectSpread(_objectSpread({}, Qe.scale(_d2)), {}, {
                  color: v,
                  borderRadius: k * _d2
                }));
              a.data = Me, a.hidden = !1, a.update();
            }
            if (typeof _T6 == "string") {
              var _be11 = p.height,
                _re6 = p.width,
                _Ne4 = p.id;
              if (typeof _Ne4 != "number" || _Ne4 < 0 || _Ne4 > 63) throw new Error("backgroundImage'id must be a number in [0, 63]");
              if (typeof _re6 != "number" || typeof _be11 != "number") throw new Error("backgroundImage's width and height must be number");
              r.props.imageOverlay || (r.props.imageOverlay = new lm(_Ne4));
              var _se2 = r.props.imageOverlay;
              _T6 = _T6.split("?")[0];
              var _Qe = hc(_T6);
              if (!_Qe) an("backgroundImage file not found: ".concat(_T6));else {
                var _Me = _Qe.size;
                _re6 * _be11 * 4 !== _Me ? an("backgroundImage size error: ".concat(_re6, "-").concat(_be11, "-").concat(_Me)) : (_se2.x = W | 0, _se2.y = ee | 0, _se2.file = _T6, _se2.fmt = _D4, _se2.w = _re6 | 0, _se2.h = _be11 | 0, _se2.offset = 0, _se2.stride = (_re6 | 0) << 2, _se2.update());
              }
            }
          }
        }
      }, {
        key: "customComputeZIndex",
        value: function customComputeZIndex(r, t) {
          var _r$props$osdOverlays2 = _slicedToArray(r.props.osdOverlays, 3),
            i = _r$props$osdOverlays2[0],
            a = _r$props$osdOverlays2[1],
            s = _r$props$osdOverlays2[2];
          i.z = t + 3, a.z = t + 2, s.z = t + 1;
        }
      }, {
        key: "customMeasureNode",
        value: function customMeasureNode(r) {
          return Gm(r);
        }
      }]);
    }($m),
    vb;
  function qc() {
    return vb || (vb = new gb());
  }
  var R4 = function R4(e, r, t) {
      var i = qc().customCreateMouseEvent(e, r.x, r.y, r.hover, t);
      qc().dispatchMouseEvent(e, i);
    },
    M4 = function M4() {
      qc().renderToMpv();
    };
  function yb(e, r, t, i) {
    var a = t / 2,
      s = i / 2;
    return e < a ? r < s ? "left-top" : "left-bottom" : r < s ? "right-top" : "right-bottom";
  }
  function xb(e, r, t, i) {
    var a = {
      x: 0,
      y: 0
    };
    if (!e) return a;
    var _e$layoutNode = e.layoutNode,
      s = _e$layoutNode.height,
      l = _e$layoutNode.width;
    switch (i) {
      case "left-bottom":
        {
          a.x = r, a.y = t - s;
          break;
        }
      case "left-top":
        {
          a.x = r, a.y = t;
          break;
        }
      case "right-bottom":
        {
          a.x = r - l, a.y = t - s;
          break;
        }
      case "right-top":
        {
          a.x = r - l, a.y = t;
          break;
        }
    }
    return a;
  }
  function D4(e, r, t) {
    var _e$attributes$title;
    var _iterator38 = _createForOfIteratorHelper(e.childNodes),
      _step38;
    try {
      for (_iterator38.s(); !(_step38 = _iterator38.n()).done;) {
        var i = _step38.value;
        var a = D4(i, r, t);
        if (a) return a;
      }
    } catch (err) {
      _iterator38.e(err);
    } finally {
      _iterator38.f();
    }
    if (e.layoutNode.hasPoint(r, t) && (_e$attributes$title = e.attributes.title) !== null && _e$attributes$title !== void 0 && _e$attributes$title.length) return e;
  }
  var k4 = new Ot("mouse-pos"),
    B4 = function B4(_ref9) {
      var _ref9$tooltipThrottle = _ref9.tooltipThrottle,
        e = _ref9$tooltipThrottle === void 0 ? 100 : _ref9$tooltipThrottle,
        r = _objectWithoutProperties(_ref9, _excluded2);
      var _ref10 = (0, ao.useState)(!0),
        _ref11 = _slicedToArray(_ref10, 2),
        t = _ref11[0],
        i = _ref11[1],
        _ref12 = (0, ao.useState)(""),
        _ref13 = _slicedToArray(_ref12, 2),
        a = _ref13[0],
        s = _ref13[1],
        l = k4.value,
        _ref14 = (0, ao.useState)(l),
        _ref15 = _slicedToArray(_ref14, 2),
        p = _ref15[0],
        d = _ref15[1],
        v = (0, ao.useRef)(null);
      return (0, ao.useEffect)(function () {
        var g = l,
          x = Rn(function (S) {
            g = S;
            var b = S.x,
              q = S.y,
              E = S.hover;
            if (!E) {
              i(!1);
              return;
            }
            var C = D4(pt(), b, q);
            if (!C) {
              i(!1);
              return;
            }
            var T = C === null || C === void 0 ? void 0 : C.attributes.title;
            if (T !== null && T !== void 0 && T.length) {
              var _D5 = yb(b, q, pt().layoutNode.width, pt().layoutNode.height),
                _M6 = xb(v.current, b, q, _D5);
              d(_M6), i(!0), s(T);
            }
          }, e);
        k4.observe(x, Cc);
      }, []), ao.default.createElement(K, _objectSpread(_objectSpread({
        id: "tooltip"
      }, r), {}, {
        hide: !v.current || r.hide || !t,
        ref: v,
        x: p.x,
        y: p.y,
        text: a,
        position: "absolute"
      }));
    };
  var zt = j(Z());
  function Qxe(e) {
    var r = {};
    var _loop5 = function _loop5(t) {
      Um.find(function (i) {
        return i === t;
      }) || ["width", "height", "x", "y", "left", "right", "top", "bottom", "title"].includes(t) || (r[t] = e[t]);
    };
    for (var t in e) {
      _loop5(t);
    }
    return r;
  }
  var fn = function fn(e) {
    var r = (0, zt.useRef)(null),
      _ref16 = (0, zt.useState)(!1),
      _ref17 = _slicedToArray(_ref16, 2),
      t = _ref17[0],
      i = _ref17[1],
      _e$items = e.items,
      a = _e$items === void 0 ? [] : _e$items,
      _e$direction = e.direction,
      s = _e$direction === void 0 ? "bottom" : _e$direction,
      l = Qxe(e),
      _e$dropdownStyle = e.dropdownStyle,
      p = _e$dropdownStyle === void 0 ? {} : _e$dropdownStyle,
      _e$dropdownListStyle = e.dropdownListStyle,
      d = _e$dropdownListStyle === void 0 ? {} : _e$dropdownListStyle,
      _e$maxItemCount = e.maxItemCount,
      v = _e$maxItemCount === void 0 ? 6 : _e$maxItemCount,
      g = e.pageDown,
      x = e.pageUp,
      S = s === "top" ? {
        bottom: "100%"
      } : {
        top: "100%"
      },
      b = a.length > v,
      _ref18 = (0, zt.useState)(0),
      _ref19 = _slicedToArray(_ref18, 2),
      q = _ref19[0],
      E = _ref19[1],
      C = Math.ceil(a.length / v),
      T = v * q,
      D = T + v,
      M = a.slice(T, D);
    return zt.default.createElement(zt.default.Fragment, null, zt.default.createElement(de, _objectSpread(_objectSpread(_objectSpread({}, e), p), {}, {
      ref: r,
      onMouseDown: function onMouseDown(k) {
        var _e$onMouseDown;
        i(function (W) {
          return !W;
        }), (_e$onMouseDown = e.onMouseDown) === null || _e$onMouseDown === void 0 ? void 0 : _e$onMouseDown.call(e, k);
      },
      onBlur: function onBlur(k) {
        setTimeout(function () {
          var _e$onBlur;
          i(!1), (_e$onBlur = e.onBlur) === null || _e$onBlur === void 0 ? void 0 : _e$onBlur.call(e, k);
        }, 16);
      }
    }), t && zt.default.createElement(K, _objectSpread(_objectSpread({
      id: "dropdown-list",
      display: "flex",
      flexDirection: "row",
      justifyContent: "start",
      alignItems: "start"
    }, S), {}, {
      alignContent: "stretch",
      color: e.color,
      backgroundColor: e.backgroundColor
    }, d), b && zt.default.createElement(de, _objectSpread(_objectSpread(_objectSpread(_objectSpread({
      position: "relative"
    }, l), p), {}, {
      width: void 0,
      key: "dropdown-up",
      text: x === null || x === void 0 ? void 0 : x.text
    }, x === null || x === void 0 ? void 0 : x.style), {}, {
      onMouseDown: function onMouseDown(k) {
        var W = (q - 1 + C) % C;
        E(W), k.stopPropagation();
      }
    })), M.map(function (k) {
      return zt.default.createElement(de, _objectSpread(_objectSpread(_objectSpread({
        position: "relative"
      }, l), p), {}, {
        width: void 0,
        id: k.key,
        key: k.key,
        text: k.label,
        onMouseDown: function onMouseDown(W) {
          var _k$onSelect;
          (_k$onSelect = k.onSelect) !== null && _k$onSelect !== void 0 && _k$onSelect.call(k, k, W), i(!1);
        }
      }, k.style));
    }), b && zt.default.createElement(de, _objectSpread(_objectSpread(_objectSpread(_objectSpread({
      position: "relative"
    }, l), p), {}, {
      width: void 0,
      key: "dropdown-down"
    }, g === null || g === void 0 ? void 0 : g.style), {}, {
      text: g === null || g === void 0 ? void 0 : g.text,
      onMouseDown: function onMouseDown(k) {
        var W = (q + 1) % C;
        E(W), k.stopPropagation();
      }
    })))));
  };
  var oj = j(Z4()),
    ij = j(tj());
  var nj = {};
  function aj(e) {
    var _e$props$imageOverlay, _e$props$imageOverlay2;
    var _iterator39 = _createForOfIteratorHelper(e.childNodes),
      _step39;
    try {
      for (_iterator39.s(); !(_step39 = _iterator39.n()).done;) {
        var t = _step39.value;
        aj(t);
      }
    } catch (err) {
      _iterator39.e(err);
    } finally {
      _iterator39.f();
    }
    var _iterator40 = _createForOfIteratorHelper(e.props.osdOverlays),
      _step40;
    try {
      for (_iterator40.s(); !(_step40 = _iterator40.n()).done;) {
        var _t5 = _step40.value;
        _t5.remove();
      }
    } catch (err) {
      _iterator40.e(err);
    } finally {
      _iterator40.f();
    }
    var r = e.attributes.backgroundImage;
    typeof r == "string" && ((_e$props$imageOverlay = e.props.imageOverlay) !== null && _e$props$imageOverlay !== void 0 && _e$props$imageOverlay.remove(), (_e$props$imageOverlay2 = e.props.imageOverlay) === null || _e$props$imageOverlay2 === void 0 ? void 0 : _e$props$imageOverlay2.destroy());
  }
  function Zxe(e) {
    return (0, oj.default)({
      supportsMutation: !0,
      supportsPersistence: !1,
      supportsMicrotasks: !1,
      appendChildToContainer: function appendChildToContainer(r, t) {
        Hm(r, t), e();
      },
      insertInContainerBefore: pb,
      commitUpdate: function commitUpdate(r, t) {
        mb(r, t), e();
      },
      commitTextUpdate: function commitTextUpdate(r, t, i) {
        throw new Error("not support Text Component update");
      },
      commitMount: function commitMount() {},
      removeChildFromContainer: function removeChildFromContainer(r, t) {
        Pc(r, t), e();
      },
      createInstance: function createInstance(r, t, i, a, s) {
        var l = Ma("@mpv-easy/box");
        return mb(l, t), l;
      },
      createTextInstance: function createTextInstance(r, t, i, a) {
        throw new Error("not support Text components");
      },
      hideTextInstance: function hideTextInstance(r) {},
      unhideTextInstance: function unhideTextInstance(r, t) {},
      hideInstance: function hideInstance(r) {},
      unhideInstance: function unhideInstance(r) {},
      appendInitialChild: function appendInitialChild(r, t) {
        Hm(r, t), e();
      },
      appendChild: function appendChild(r, t) {
        Hm(r, t), e();
      },
      insertBefore: function insertBefore(r, t, i) {
        pb(r, t, i), e();
      },
      finalizeInitialChildren: function finalizeInitialChildren(r, t, i, a, s) {
        return !1;
      },
      prepareUpdate: function prepareUpdate(r, t, i, a, s, l) {
        return a;
      },
      shouldSetTextContent: function shouldSetTextContent(r, t) {
        return !1;
      },
      getRootHostContext: function getRootHostContext(r) {
        return nj;
      },
      getChildHostContext: function getChildHostContext(r, t, i) {
        return nj;
      },
      getPublicInstance: function getPublicInstance(r) {
        return r;
      },
      prepareForCommit: function prepareForCommit(r) {
        return null;
      },
      resetTextContent: function resetTextContent(r) {},
      clearContainer: function clearContainer() {},
      resetAfterCommit: function resetAfterCommit(r) {},
      preparePortalMount: function preparePortalMount(r) {},
      scheduleTimeout: function scheduleTimeout(r, t) {
        return setTimeout(r, t);
      },
      cancelTimeout: function cancelTimeout(r) {
        return clearTimeout(r);
      },
      noTimeout: -1,
      isPrimaryRenderer: !0,
      getCurrentEventPriority: function getCurrentEventPriority() {
        return ij.DefaultEventPriority;
      },
      getInstanceFromNode: function getInstanceFromNode(r) {
        return null;
      },
      beforeActiveInstanceBlur: function beforeActiveInstanceBlur() {},
      afterActiveInstanceBlur: function afterActiveInstanceBlur() {},
      prepareScopeUpdate: function prepareScopeUpdate(r, t) {},
      getInstanceFromScope: function getInstanceFromScope(r) {
        return null;
      },
      detachDeletedInstance: function detachDeletedInstance(r) {
        aj(r);
      },
      removeChild: function removeChild(r, t) {
        Pc(r, t), e();
      },
      supportsHydration: !1
    });
  }
  var Ob = 0,
    _c = [];
  function sj() {
    var _ref20 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      _ref20$enableMouseMov = _ref20.enableMouseMoveEvent,
      e = _ref20$enableMouseMov === void 0 ? !0 : _ref20$enableMouseMov,
      _ref20$fps = _ref20.fps,
      r = _ref20$fps === void 0 ? qi : _ref20$fps,
      _ref20$flex = _ref20.flex,
      t = _ref20$flex === void 0 ? qc() : _ref20$flex,
      _ref20$showFps = _ref20.showFps,
      i = _ref20$showFps === void 0 ? !1 : _ref20$showFps,
      _ref20$customRender = _ref20.customRender,
      a = _ref20$customRender === void 0 ? Rn(function () {
        var l = +Date.now();
        M4();
        var p = +Date.now(),
          d = p - l;
        Ob = Math.max(Ob, d), _c.push(d), _c.length > 32 && _c.shift();
        var v = _c.reduce(function (g, x) {
          return g + x;
        }, 0) / _c.length;
        i && an("render time:", p, d, Ob, v);
      }, 1e3 / r) : _ref20$customRender,
      _ref20$customDispatch = _ref20.customDispatch,
      s = _ref20$customDispatch === void 0 ? R4 : _ref20$customDispatch;
    var l = Zxe(a);
    return function (p) {
      var d = l.createContainer(t.rootNode, 0, null, !1, null, "", function (q) {
          throw q;
        }, null),
        v = {
          x: 0,
          y: 0,
          hover: !1
        };
      Lt("mouse-pos", "native", function (q, E) {
        v = E, e && s(t.rootNode, v, {
          event: "press",
          is_mouse: !0,
          key: ""
        });
      }), lt("MOUSE_BTN0", "MPV_EASY_MOUSE_BTN0", function (q) {
        s(t.rootNode, v, q);
      }, {
        complex: !0,
        repeatable: !0,
        forced: !1
      }), lt("MOUSE_BTN3", "MPV_EASY_MOUSE_BTN3", function (q) {
        s(t.rootNode, v, q);
      }, {
        complex: !0,
        repeatable: !0,
        forced: !1
      }), lt("MOUSE_BTN4", "MPV_EASY_MOUSE_BTN4", function (q) {
        s(t.rootNode, v, q);
      }, {
        complex: !0,
        repeatable: !0,
        forced: !1
      });
      var g = 0,
        x = 0;
      function S(_ref21) {
        var q = _ref21.w,
          E = _ref21.h;
        if (!q || !E || g === q && x === E) return;
        g = q, x = E;
        var _t$rootNode = t.rootNode,
          C = _t$rootNode.attributes,
          T = _t$rootNode.layoutNode;
        C.id = "__root__", C.width = q, C.height = E, C.position = "relative", C.color = "FFFFFF", C.display = "flex", C.backgroundColor = "000000FF", C.padding = 0, C.borderSize = 0, C.x = 0, C.y = 0, C.zIndex = 0, C.alignContent = "stretch", T.x = 0, T.y = 0, T.width = q, T.height = E, T.padding = 0, T.border = 0, l.updateContainer(p, d, null, null);
      }
      var b = new Ot("osd-dimensions");
      S(b.value), b.observe(function (q) {
        S(q);
      });
    };
  }
  var $b = j(Z());
  var Le = j(Z());
  var qu = j(Z());
  var Ir = j(Z());
  var hj = j(Z(), 1),
    vj = j(fj(), 1),
    eh = j(Z(), 1),
    jt = "default" in eh ? eh.default : eh,
    pj = Symbol.for("react-redux-context"),
    dj = (typeof globalThis === "undefined" ? "undefined" : _typeof(globalThis)) < "u" ? globalThis : {};
  function s0e() {
    var _dj$pj;
    if (!jt.createContext) return {};
    var e = (_dj$pj = dj[pj]) !== null && _dj$pj !== void 0 ? _dj$pj : dj[pj] = new Map(),
      r = e.get(jt.createContext);
    return r || (r = jt.createContext(null), e.set(jt.createContext, r)), r;
  }
  var Oi = s0e(),
    gj = function gj() {
      throw new Error("uSES not initialized!");
    };
  function Ab() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : Oi;
    return function () {
      return jt.useContext(e);
    };
  }
  var yj = Ab(),
    xj = gj,
    u0e = function u0e(e) {
      xj = e;
    },
    l0e = function l0e(e, r) {
      return e === r;
    };
  function c0e() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : Oi;
    var r = e === Oi ? yj : Ab(e),
      t = function t(i) {
        var a = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
        var _ref22 = typeof a == "function" ? {
            equalityFn: a
          } : a,
          _ref22$equalityFn = _ref22.equalityFn,
          s = _ref22$equalityFn === void 0 ? l0e : _ref22$equalityFn,
          _ref22$devModeChecks = _ref22.devModeChecks,
          l = _ref22$devModeChecks === void 0 ? {} : _ref22$devModeChecks,
          _r3 = r(),
          p = _r3.store,
          d = _r3.subscription,
          v = _r3.getServerState,
          g = _r3.stabilityCheck,
          x = _r3.identityFunctionCheck,
          S = jt.useRef(!0),
          b = jt.useCallback(_defineProperty({}, i.name, function (E) {
            var C = i(E);
            if (0) {
              if ((D === "always" || D === "once" && S.current) && !s(C, M)) try {} catch (W) {}
              if ((T === "always" || T === "once" && S.current) && C === E) try {} catch (k) {}
            }
            return C;
          })[i.name], [i, g, l.stabilityCheck]),
          q = xj(d.addNestedSub, p.getState, v || p.getState, b, s);
        return jt.useDebugValue(q), q;
      };
    return Object.assign(t, {
      withTypes: function withTypes() {
        return t;
      }
    }), t;
  }
  var w = c0e(),
    JLe = Symbol.for("react.element"),
    ZLe = Symbol.for("react.portal"),
    eze = Symbol.for("react.fragment"),
    rze = Symbol.for("react.strict_mode"),
    tze = Symbol.for("react.profiler"),
    nze = Symbol.for("react.provider"),
    oze = Symbol.for("react.context"),
    ize = Symbol.for("react.server_context"),
    f0e = Symbol.for("react.forward_ref"),
    aze = Symbol.for("react.suspense"),
    sze = Symbol.for("react.suspense_list"),
    p0e = Symbol.for("react.memo"),
    uze = Symbol.for("react.lazy"),
    lze = Symbol.for("react.offscreen"),
    cze = Symbol.for("react.client.reference"),
    d0e = f0e,
    m0e = p0e;
  function h0e(e) {
    e();
  }
  function v0e() {
    var e = null,
      r = null;
    return {
      clear: function clear() {
        e = null, r = null;
      },
      notify: function notify() {
        h0e(function () {
          var t = e;
          for (; t;) t.callback(), t = t.next;
        });
      },
      get: function get() {
        var t = [],
          i = e;
        for (; i;) t.push(i), i = i.next;
        return t;
      },
      subscribe: function subscribe(t) {
        var i = !0,
          a = r = {
            callback: t,
            next: null,
            prev: r
          };
        return a.prev ? a.prev.next = a : e = a, function () {
          !i || e === null || (i = !1, a.next ? a.next.prev = a.prev : r = a.prev, a.prev ? a.prev.next = a.next : e = a.next);
        };
      }
    };
  }
  var mj = {
    notify: function notify() {},
    get: function get() {
      return [];
    }
  };
  function g0e(e, r) {
    var t,
      i = mj,
      a = 0,
      s = !1;
    function l(E) {
      g();
      var C = i.subscribe(E),
        T = !1;
      return function () {
        T || (T = !0, C(), x());
      };
    }
    function p() {
      i.notify();
    }
    function d() {
      q.onStateChange && q.onStateChange();
    }
    function v() {
      return s;
    }
    function g() {
      a++, t || (t = r ? r.addNestedSub(d) : e.subscribe(d), i = v0e());
    }
    function x() {
      a--, t && a === 0 && (t(), t = void 0, i.clear(), i = mj);
    }
    function S() {
      s || (s = !0, g());
    }
    function b() {
      s && (s = !1, x());
    }
    var q = {
      addNestedSub: l,
      notifyNestedSubs: p,
      handleChangeWrapper: d,
      isSubscribed: v,
      trySubscribe: S,
      tryUnsubscribe: b,
      getListeners: function getListeners() {
        return i;
      }
    };
    return q;
  }
  var y0e = (typeof window === "undefined" ? "undefined" : _typeof(window)) < "u" && _typeof(window.document) < "u" && _typeof(window.document.createElement) < "u",
    x0e = (typeof navigator === "undefined" ? "undefined" : _typeof(navigator)) < "u" && navigator.product === "ReactNative",
    S0e = y0e || x0e ? jt.useLayoutEffect : jt.useEffect;
  var b0e = {
      $$typeof: !0,
      render: !0,
      defaultProps: !0,
      displayName: !0,
      propTypes: !0
    },
    w0e = {
      $$typeof: !0,
      compare: !0,
      defaultProps: !0,
      displayName: !0,
      propTypes: !0,
      type: !0
    },
    fze = _defineProperty(_defineProperty({}, d0e, b0e), m0e, w0e);
  var pze = Object.prototype;
  var E0e = gj,
    C0e = function C0e(e) {
      E0e = e;
    };
  function I0e(_ref23) {
    var e = _ref23.store,
      r = _ref23.context,
      t = _ref23.children,
      i = _ref23.serverState,
      _ref23$stabilityCheck = _ref23.stabilityCheck,
      a = _ref23$stabilityCheck === void 0 ? "once" : _ref23$stabilityCheck,
      _ref23$identityFuncti = _ref23.identityFunctionCheck,
      s = _ref23$identityFuncti === void 0 ? "once" : _ref23$identityFuncti;
    var l = jt.useMemo(function () {
        var v = g0e(e);
        return {
          store: e,
          subscription: v,
          getServerState: i ? function () {
            return i;
          } : void 0,
          stabilityCheck: a,
          identityFunctionCheck: s
        };
      }, [e, i, a, s]),
      p = jt.useMemo(function () {
        return e.getState();
      }, [e]);
    S0e(function () {
      var v = l.subscription;
      return v.onStateChange = v.notifyNestedSubs, v.trySubscribe(), p !== e.getState() && v.notifyNestedSubs(), function () {
        v.tryUnsubscribe(), v.onStateChange = void 0;
      };
    }, [l, p]);
    var d = r || Oi;
    return jt.createElement(d.Provider, {
      value: l
    }, t);
  }
  var Sj = I0e;
  function bj() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : Oi;
    var r = e === Oi ? yj : Ab(e),
      t = function t() {
        var _r4 = r(),
          i = _r4.store;
        return i;
      };
    return Object.assign(t, {
      withTypes: function withTypes() {
        return t;
      }
    }), t;
  }
  var P0e = bj();
  function q0e() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : Oi;
    var r = e === Oi ? P0e : bj(e),
      t = function t() {
        return r().dispatch;
      };
    return Object.assign(t, {
      withTypes: function withTypes() {
        return t;
      }
    }), t;
  }
  var ne = q0e();
  u0e(vj.useSyncExternalStoreWithSelector);
  C0e(hj.useSyncExternalStore);
  var kb = {};
  Ju(kb, {
    __DO_NOT_USE__ActionTypes: function __DO_NOT_USE__ActionTypes() {
      return Rc;
    },
    applyMiddleware: function applyMiddleware() {
      return Mb;
    },
    bindActionCreators: function bindActionCreators() {
      return N0e;
    },
    combineReducers: function combineReducers() {
      return Rb;
    },
    compose: function compose() {
      return rh;
    },
    createStore: function createStore() {
      return Mc;
    },
    isAction: function isAction() {
      return R0e;
    },
    isPlainObject: function isPlainObject() {
      return Nb;
    },
    legacy_createStore: function legacy_createStore() {
      return A0e;
    }
  });
  function Mr(e) {
    return "Minified Redux error #".concat(e, "; visit https://redux.js.org/Errors?code=").concat(e, " for the full message or use the non-minified dev environment for full errors. ");
  }
  var T0e = typeof Symbol == "function" && Symbol.observable || "@@observable",
    wj = T0e,
    _b = function _b() {
      return Math.random().toString(36).substring(7).split("").join(".");
    },
    O0e = {
      INIT: "@@redux/INIT".concat(_b()),
      REPLACE: "@@redux/REPLACE".concat(_b()),
      PROBE_UNKNOWN_ACTION: function PROBE_UNKNOWN_ACTION() {
        return "@@redux/PROBE_UNKNOWN_ACTION".concat(_b());
      }
    },
    Rc = O0e;
  function Nb(e) {
    if (_typeof(e) != "object" || e === null) return !1;
    var r = e;
    for (; Object.getPrototypeOf(r) !== null;) r = Object.getPrototypeOf(r);
    return Object.getPrototypeOf(e) === r || Object.getPrototypeOf(e) === null;
  }
  function Mc(e, r, t) {
    if (typeof e != "function") throw new Error(Mr(2));
    if (typeof r == "function" && typeof t == "function" || typeof t == "function" && typeof arguments[3] == "function") throw new Error(Mr(0));
    if (typeof r == "function" && _typeof(t) > "u" && (t = r, r = void 0), _typeof(t) < "u") {
      if (typeof t != "function") throw new Error(Mr(1));
      return t(Mc)(e, r);
    }
    var i = e,
      a = r,
      s = new Map(),
      l = s,
      p = 0,
      d = !1;
    function v() {
      l === s && (l = new Map(), s.forEach(function (C, T) {
        l.set(T, C);
      }));
    }
    function g() {
      if (d) throw new Error(Mr(3));
      return a;
    }
    function x(C) {
      if (typeof C != "function") throw new Error(Mr(4));
      if (d) throw new Error(Mr(5));
      var T = !0;
      v();
      var D = p++;
      return l.set(D, C), function () {
        if (T) {
          if (d) throw new Error(Mr(6));
          T = !1, v(), l.delete(D), s = null;
        }
      };
    }
    function S(C) {
      if (!Nb(C)) throw new Error(Mr(7));
      if (_typeof(C.type) > "u") throw new Error(Mr(8));
      if (typeof C.type != "string") throw new Error(Mr(17));
      if (d) throw new Error(Mr(9));
      try {
        d = !0, a = i(a, C);
      } finally {
        d = !1;
      }
      return (s = l).forEach(function (D) {
        D();
      }), C;
    }
    function b(C) {
      if (typeof C != "function") throw new Error(Mr(10));
      i = C, S({
        type: Rc.REPLACE
      });
    }
    function q() {
      var C = x;
      return _defineProperty({
        subscribe: function subscribe(T) {
          if (_typeof(T) != "object" || T === null) throw new Error(Mr(11));
          function D() {
            var k = T;
            k.next && k.next(g());
          }
          return D(), {
            unsubscribe: C(D)
          };
        }
      }, wj, function () {
        return this;
      });
    }
    return S({
      type: Rc.INIT
    }), _defineProperty({
      dispatch: S,
      subscribe: x,
      getState: g,
      replaceReducer: b
    }, wj, q);
  }
  function A0e(e, r, t) {
    return Mc(e, r, t);
  }
  function _0e(e) {
    Object.keys(e).forEach(function (r) {
      var t = e[r];
      if (_typeof(t(void 0, {
        type: Rc.INIT
      })) > "u") throw new Error(Mr(12));
      if (_typeof(t(void 0, {
        type: Rc.PROBE_UNKNOWN_ACTION()
      })) > "u") throw new Error(Mr(13));
    });
  }
  function Rb(e) {
    var r = Object.keys(e),
      t = {};
    for (var l = 0; l < r.length; l++) {
      var p = r[l];
      typeof e[p] == "function" && (t[p] = e[p]);
    }
    var i = Object.keys(t),
      a,
      s;
    try {
      _0e(t);
    } catch (l) {
      s = l;
    }
    return function () {
      var p = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      var d = arguments.length > 1 ? arguments[1] : undefined;
      if (s) throw s;
      var v = !1,
        g = {};
      for (var x = 0; x < i.length; x++) {
        var S = i[x],
          b = t[S],
          q = p[S],
          E = b(q, d);
        if (_typeof(E) > "u") {
          var C = d && d.type;
          throw new Error(Mr(14));
        }
        g[S] = E, v = v || E !== q;
      }
      return v = v || i.length !== Object.keys(p).length, v ? g : p;
    };
  }
  function Ej(e, r) {
    return function () {
      for (var _len2 = arguments.length, t = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        t[_key2] = arguments[_key2];
      }
      return r(e.apply(this, t));
    };
  }
  function N0e(e, r) {
    if (typeof e == "function") return Ej(e, r);
    if (_typeof(e) != "object" || e === null) throw new Error(Mr(16));
    var t = {};
    for (var i in e) {
      var a = e[i];
      typeof a == "function" && (t[i] = Ej(a, r));
    }
    return t;
  }
  function rh() {
    for (var _len3 = arguments.length, e = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
      e[_key3] = arguments[_key3];
    }
    return e.length === 0 ? function (r) {
      return r;
    } : e.length === 1 ? e[0] : e.reduce(function (r, t) {
      return function () {
        return r(t.apply(void 0, arguments));
      };
    });
  }
  function Mb() {
    for (var _len4 = arguments.length, e = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
      e[_key4] = arguments[_key4];
    }
    return function (r) {
      return function (t, i) {
        var a = r(t, i),
          s = function s() {
            throw new Error(Mr(15));
          },
          l = {
            getState: a.getState,
            dispatch: function dispatch(d) {
              for (var _len5 = arguments.length, v = new Array(_len5 > 1 ? _len5 - 1 : 0), _key5 = 1; _key5 < _len5; _key5++) {
                v[_key5 - 1] = arguments[_key5];
              }
              return s.apply(void 0, [d].concat(v));
            }
          },
          p = e.map(function (d) {
            return d(l);
          });
        return s = rh.apply(void 0, _toConsumableArray(p))(a.dispatch), _objectSpread(_objectSpread({}, a), {}, {
          dispatch: s
        });
      };
    };
  }
  function R0e(e) {
    return Nb(e) && "type" in e && typeof e.type == "string";
  }
  function Fa() {
    return Fa = Object.assign || function (e) {
      for (var r = 1; r < arguments.length; r++) {
        var t = arguments[r];
        for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
      }
      return e;
    }, Fa.apply(this, arguments);
  }
  function M0e(e) {
    var r;
    e.models.forEach(function (d) {
      return Tj(e, d);
    });
    var t = Oj(e),
      i = Mb.apply(kb, e.reduxConfig.middlewares),
      a = e.reduxConfig.devtoolComposer ? (r = e.reduxConfig).devtoolComposer.apply(r, e.reduxConfig.enhancers.concat([i])) : D0e(e.reduxConfig.devtoolOptions).apply(void 0, e.reduxConfig.enhancers.concat([i])),
      s = e.reduxConfig.createStore || Mc,
      l = e.reduxConfig.initialState,
      p = l === void 0 ? {} : l;
    return s(t, p, a);
  }
  function Tj(e, r) {
    var t = {},
      i = Object.keys(r.reducers);
    i.forEach(function (p) {
      var d = B0e(p) ? p : r.name + "/" + p;
      t[d] = r.reducers[p];
    });
    var a = function a(d, v) {
        return d === void 0 && (d = r.state), v.type in t ? t[v.type](d, v.payload, v.meta) : d;
      },
      s = r.baseReducer,
      l = s ? function (p, d) {
        return p === void 0 && (p = r.state), a(s(p, d), d);
      } : a;
    e.forEachPlugin("onReducer", function (p) {
      l = p(l, r.name, e) || l;
    }), e.reduxConfig.reducers[r.name] = l;
  }
  function Oj(e) {
    var r = e.reduxConfig.rootReducers,
      t = k0e(e.reduxConfig),
      i = t;
    return r && Object.keys(r).length && (i = function i(s, l) {
      var p = r[l.type];
      return t(p ? p(s, l) : s, l);
    }), e.forEachPlugin("onRootReducer", function (a) {
      i = a(i, e) || i;
    }), i;
  }
  function k0e(e) {
    var r = e.combineReducers || Rb;
    return Object.keys(e.reducers).length ? r(e.reducers) : function (t) {
      return t;
    };
  }
  function D0e(e) {
    return e === void 0 && (e = {}), !e.disabled && (typeof window === "undefined" ? "undefined" : _typeof(window)) == "object" && window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ ? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__(e) : rh;
  }
  function B0e(e) {
    return e.indexOf("/") > -1;
  }
  var Cj = function Cj(r) {
      return _typeof(r) == "object" && r !== null && !Array.isArray(r);
    },
    Ai = function Ai(r) {
      return !r || typeof r == "function";
    },
    kc = function kc(r) {
      if (0) var t, i;
    },
    F0e = function F0e(r) {
      kc(function () {
        return [[!Array.isArray(r.plugins), "init config.plugins must be an array"], [!Cj(r.models), "init config.models must be an object"], [!Cj(r.redux.reducers), "init config.redux.reducers must be an object"], [!Array.isArray(r.redux.middlewares), "init config.redux.middlewares must be an array"], [!Array.isArray(r.redux.enhancers), "init config.redux.enhancers must be an array of functions"], [!Ai(r.redux.combineReducers), "init config.redux.combineReducers must be a function"], [!Ai(r.redux.createStore), "init config.redux.createStore must be a function"]];
      });
    },
    Aj = function Aj(r) {
      kc(function () {
        return [[!r, "model config is required"], [typeof r.name != "string", 'model "name" [string] is required'], [r.state === void 0 && r.baseReducer === void 0, 'model "state" is required'], [!Ai(r.baseReducer), 'model "baseReducer" must be a function']];
      });
    },
    L0e = function L0e(r) {
      kc(function () {
        return [[!Ai(r.onStoreCreated), "Plugin onStoreCreated must be a function"], [!Ai(r.onModel), "Plugin onModel must be a function"], [!Ai(r.onReducer), "Plugin onReducer must be a function"], [!Ai(r.onRootReducer), "Plugin onRootReducer must be a function"], [!Ai(r.createMiddleware), "Plugin createMiddleware must be a function"]];
      });
    },
    z0e = function z0e(r, t, i) {
      kc(function () {
        return [[!!i.match(/\/.+\//), "Invalid reducer name (" + r + "/" + i + ")"], [typeof t[i] != "function", "Invalid reducer (" + r + "/" + i + "). Must be a function"]];
      });
    },
    j0e = function j0e(r, t, i) {
      kc(function () {
        return [[!!i.match(/\//), "Invalid effect name (" + r + "/" + i + ")"], [typeof t[i] != "function", "Invalid effect (" + r + "/" + i + "). Must be a function"]];
      });
    },
    _j = function _j(r, t, i, a) {
      return Object.assign(function (s, l) {
        var p = {
          type: t + "/" + i
        };
        return _typeof(s) < "u" && (p.payload = s), _typeof(l) < "u" && (p.meta = l), r.dispatch(p);
      }, {
        isEffect: a
      });
    },
    U0e = function U0e(r, t) {
      var i = r.dispatch[t.name],
        a = Object.keys(t.reducers);
      a.forEach(function (s) {
        z0e(t.name, t.reducers, s), i[s] = _j(r, t.name, s, !1);
      });
    },
    H0e = function H0e(r, t, i) {
      var a = r.dispatch[i.name],
        s = {};
      i.effects && (s = typeof i.effects == "function" ? i.effects(r.dispatch) : i.effects);
      var l = Object.keys(s);
      l.forEach(function (p) {
        j0e(i.name, s, p), t.effects[i.name + "/" + p] = s[p].bind(a), a[p] = _j(r, i.name, p, !0);
      });
    };
  function $0e(e) {
    return {
      models: V0e(e.models),
      reduxConfig: e.redux,
      forEachPlugin: function forEachPlugin(t, i) {
        e.plugins.forEach(function (a) {
          a[t] && i(a[t]);
        });
      },
      effects: {}
    };
  }
  function V0e(e) {
    return Object.keys(e).map(function (r) {
      var t = W0e(r, e[r]);
      return Aj(t), t;
    });
  }
  function W0e(e, r) {
    return Fa({
      name: e,
      reducers: {}
    }, r);
  }
  function G0e(e) {
    var r = $0e(e);
    r.reduxConfig.middlewares.push(K0e(r)), r.forEachPlugin("createMiddleware", function (a) {
      r.reduxConfig.middlewares.push(a(r));
    });
    var t = M0e(r),
      i = Fa({}, t, {
        name: e.name,
        addModel: function addModel(s) {
          Aj(s), Tj(r, s), Ij(i, s), Pj(i, r, s), t.replaceReducer(Oj(r)), t.dispatch({
            type: "@@redux/REPLACE"
          });
        }
      });
    return Y0e(i, e.plugins), r.models.forEach(function (a) {
      return Ij(i, a);
    }), r.models.forEach(function (a) {
      return Pj(i, r, a);
    }), r.forEachPlugin("onStoreCreated", function (a) {
      i = a(i, r) || i;
    }), i;
  }
  function K0e(e) {
    return function (r) {
      return function (t) {
        return function (i) {
          return i.type in e.effects ? (t(i), e.effects[i.type](i.payload, r.getState(), i.meta)) : t(i);
        };
      };
    };
  }
  function Ij(e, r) {
    var t = {};
    e.dispatch["" + r.name] = t, U0e(e, r);
  }
  function Pj(e, r, t) {
    H0e(e, r, t), r.forEachPlugin("onModel", function (i) {
      i(t, e);
    });
  }
  function Y0e(e, r) {
    r.forEach(function (t) {
      if (t.exposed) {
        var i = Object.keys(t.exposed);
        i.forEach(function (a) {
          if (t.exposed) {
            var s = t.exposed[a],
              l = typeof s == "function";
            e[a] = l ? function () {
              for (var p = arguments.length, d = new Array(p), v = 0; v < p; v++) d[v] = arguments[v];
              return s.apply(void 0, [e].concat(d));
            } : Object.create(t.exposed[a]);
          }
        });
      }
    });
  }
  var qj = 0;
  function X0e(e) {
    var r,
      t,
      i,
      a = (r = e.name) != null ? r : "Rematch Store " + qj;
    qj += 1;
    var s = {
      name: a,
      models: e.models || {},
      plugins: e.plugins || [],
      redux: Fa({
        reducers: {},
        rootReducers: {},
        enhancers: [],
        middlewares: []
      }, e.redux, {
        devtoolOptions: Fa({
          name: a
        }, (t = (i = e.redux) == null ? void 0 : i.devtoolOptions) != null ? t : {})
      })
    };
    return F0e(s), s.plugins.forEach(function (l) {
      l.config && (s.models = th(s.models, l.config.models), l.config.redux && (s.redux.initialState = th(s.redux.initialState, l.config.redux.initialState), s.redux.reducers = th(s.redux.reducers, l.config.redux.reducers), s.redux.rootReducers = th(s.redux.rootReducers, l.config.redux.reducers), s.redux.enhancers = [].concat(s.redux.enhancers, l.config.redux.enhancers || []), s.redux.middlewares = [].concat(s.redux.middlewares, l.config.redux.middlewares || []), s.redux.combineReducers = s.redux.combineReducers || l.config.redux.combineReducers, s.redux.createStore = s.redux.createStore || l.config.redux.createStore)), L0e(l);
    }), s;
  }
  function th(e, r) {
    return r ? Fa({}, r, e) : e;
  }
  var Nj = function Nj(r) {
      var t = X0e(r || {});
      return G0e(t);
    },
    Rj = function Rj() {
      return function (r) {
        return r;
      };
    };
  var Q0e = j(Z());
  var Mj = {
    uosc: "uosc",
    osc: "osc",
    oscx: "oscx",
    dark: "深色",
    light: "浅色",
    cn: "中文",
    en: "英文",
    languageChinese: "中文",
    languageEnglish: "英文",
    next: "下一个",
    previous: "上一个",
    stop: "停止",
    pause: "暂停",
    play: "播放",
    playlist: "播放列表",
    screenshot: "截图",
    randomPlay: "随机播放",
    listPlay: "列表播放",
    maximize: "最大化",
    fullscreen: "全屏",
    minimize: "最小化",
    restore: "恢复",
    close: "关闭",
    exit: "退出",
    nextVideo: "下一集",
    previousVideo: "上一集",
    nextAudio: "下一首",
    previousAudio: "上一首",
    nextImage: "下一张",
    previousImage: "上一张",
    mute: "静音",
    unmute: "取消静音",
    theme: "主题",
    ui: "UI",
    language: "语言",
    skin: "皮肤",
    subtitle: "字幕",
    audioTrack: "音频轨",
    subtitleTrack: "字幕轨",
    builtinTrack: "内置",
    externalTrack: "外挂",
    playMode: "播放模式",
    loopOne: "单集循环",
    loopAll: "列表循环",
    shuffle: "随机播放",
    nextFrame: "下一帧",
    previousFrame: "上一帧",
    moreInfo: "更多信息",
    more: "更多",
    console: "控制台",
    stats: "统计信息",
    reset: "重置",
    resetConfig: "重置设置",
    open: "打开",
    videoSpeed: "播放速度",
    copyPath: "复制路径",
    style: "样式",
    enlargeFontSize: "+字体",
    reduceFontSize: "-字体",
    history: "历史"
  };
  var kj = {
    uosc: "uosc",
    osc: "osc",
    oscx: "oscx",
    dark: "dark",
    light: "light",
    cn: "Chinese",
    en: "English",
    languageChinese: "Chinese",
    languageEnglish: "English",
    next: "next",
    previous: "previous",
    stop: "stop",
    pause: "pause",
    play: "play",
    playlist: "playlist",
    screenshot: "screenshot",
    randomPlay: "random play",
    listPlay: "list play",
    maximize: "maximize",
    fullscreen: "fullscreen",
    minimize: "minimize",
    restore: "restore",
    close: "close",
    exit: "exit",
    nextVideo: "next video",
    previousVideo: "previous video",
    nextAudio: "next audio",
    previousAudio: "previous audio",
    nextImage: "next image",
    previousImage: "previous image",
    mute: "mute",
    unmute: "unmute",
    theme: "theme",
    ui: "UI",
    language: "language",
    skin: "skin",
    subtitle: "subtitle",
    audioTrack: "audio Track",
    subtitleTrack: "subtitle track",
    builtinTrack: "builtin",
    externalTrack: "external",
    playMode: "play mode",
    loopOne: "loop one",
    loopAll: "loop all",
    shuffle: "shuffle",
    nextFrame: "next frame",
    previousFrame: "previous frame",
    moreInfo: "more info",
    more: "more",
    console: "console",
    stats: "stats",
    reset: "reset",
    resetConfig: "reset config",
    open: "open",
    videoSpeed: "speed",
    copyPath: "copy path",
    style: "style",
    enlargeFontSize: "+font",
    reduceFontSize: "-font",
    history: "history"
  };
  var ko = "@mpv-easy/i18n",
    Dc = ["cn", "en"],
    Dj = {
      default: "en",
      lang: {
        en: kj,
        cn: Mj
      }
    };
  var Bj = function Bj() {
    return {
      name: ko
    };
  };
  var _t = "@mpv-easy/anime4k",
    Lj = {
      current: 0,
      osdDuration: 2,
      shaders: [{
        key: "CTRL+0",
        value: "",
        title: "Anime4K: Clear"
      }, {
        key: "CTRL+1",
        value: "~~/shaders/Anime4K_Clamp_Highlights.glsl;~~/shaders/Anime4K_Restore_CNN_VL.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_VL.glsl;~~/shaders/Anime4K_Restore_CNN_M.glsl;~~/shaders/Anime4K_AutoDownscalePre_x2.glsl;~~/shaders/Anime4K_AutoDownscalePre_x4.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_M.glsl",
        title: "Anime4K: Mode A+A (HQ)"
      }, {
        key: "CTRL+2",
        value: "~~/shaders/Anime4K_Clamp_Highlights.glsl;~~/shaders/Anime4K_Restore_CNN_Soft_VL.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_VL.glsl;~~/shaders/Anime4K_AutoDownscalePre_x2.glsl;~~/shaders/Anime4K_AutoDownscalePre_x4.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_M.glsl",
        title: "Anime4K: Mode B (HQ)"
      }, {
        key: "CTRL+3",
        value: "~~/shaders/Anime4K_Clamp_Highlights.glsl;~~/shaders/Anime4K_Upscale_Denoise_CNN_x2_VL.glsl;~~/shaders/Anime4K_AutoDownscalePre_x2.glsl;~~/shaders/Anime4K_AutoDownscalePre_x4.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_M.glsl",
        title: "Anime4K: Mode C (HQ)"
      }, {
        key: "CTRL+4",
        value: "~~/shaders/Anime4K_Clamp_Highlights.glsl;~~/shaders/Anime4K_Restore_CNN_VL.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_VL.glsl;~~/shaders/Anime4K_AutoDownscalePre_x2.glsl;~~/shaders/Anime4K_AutoDownscalePre_x4.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_M.glsl",
        title: "Anime4K: Mode A (HQ)"
      }, {
        key: "CTRL+5",
        value: "~~/shaders/Anime4K_Clamp_Highlights.glsl;~~/shaders/Anime4K_Restore_CNN_Soft_VL.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_VL.glsl;~~/shaders/Anime4K_AutoDownscalePre_x2.glsl;~~/shaders/Anime4K_AutoDownscalePre_x4.glsl;~~/shaders/Anime4K_Restore_CNN_Soft_M.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_M.glsl",
        title: "Anime4K: Mode B+B (HQ)"
      }, {
        key: "CTRL+6",
        value: "~~/shaders/Anime4K_Clamp_Highlights.glsl;~~/shaders/Anime4K_Upscale_Denoise_CNN_x2_VL.glsl;~~/shaders/Anime4K_AutoDownscalePre_x2.glsl;~~/shaders/Anime4K_AutoDownscalePre_x4.glsl;~~/shaders/Anime4K_Restore_CNN_M.glsl;~~/shaders/Anime4K_Upscale_CNN_x2_M.glsl",
        title: "Anime4K: Mode C+A (HQ)"
      }]
    };
  function Fj(e) {
    var r = e.split(";").map(function (t) {
      return "no-osd change-list glsl-shaders toggle \"".concat(t, "\"");
    }).join(";");
    pe(r);
  }
  var zj = function zj(e, r) {
    return {
      name: _t,
      create: function create() {
        var t = e[_t],
          i = t.shaders[t.current].value;
        t.current ? pe('no-osd change-list glsl-shaders clr "";') : Fj(i);
        var _loop6 = function _loop6(a) {
          var _t$shaders$a = t.shaders[a],
            s = _t$shaders$a.key,
            l = _t$shaders$a.value,
            p = _t$shaders$a.title;
          lt(s, "".concat(_t, "/").concat(s), function () {
            l.length ? Fj(l) : pe('no-osd change-list glsl-shaders clr "";'), t.osdDuration && Jr(p, t.osdDuration), t.current = a, r.saveConfig(e);
          });
        };
        for (var a = 0; a < t.shaders.length; a++) {
          _loop6(a);
        }
      },
      destroy: function destroy() {
        var _iterator41 = _createForOfIteratorHelper(e[_t].shaders),
          _step41;
        try {
          for (_iterator41.s(); !(_step41 = _iterator41.n()).done;) {
            var t = _step41.value.key;
            Zd("".concat(_t, "/").concat(t));
          }
        } catch (err) {
          _iterator41.e(err);
        } finally {
          _iterator41.f();
        }
      }
    };
  };
  function au(e, r) {
    var t = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "...";
    return e.length <= r ? e : e.slice(0, r - t.length) + t;
  }
  function J0e(e) {
    var r = ut("playlist-count") || 0;
    for (var t = 0; t < r; t++) {
      var _or2, _or3;
      var i = (_or2 = or("playlist/".concat(t, "/filename"))) !== null && _or2 !== void 0 ? _or2 : "",
        a = (_or3 = or("playlist/".concat(t, "/title"))) !== null && _or3 !== void 0 ? _or3 : "";
      if (e === i && a.length) return a;
    }
  }
  function su(e) {
    var r = J0e(e);
    if (r !== null && r !== void 0 && r.length) return r;
    var t = or("force-media-title");
    if (t !== null && t !== void 0 && t.length) return t;
    if (gi.isJellyfin(e)) {
      var i = gi.getNameFromUrl(e);
      if (i) return qn(i) || "";
    }
    return qn(e) || "";
  }
  function _i(e) {
    var r = 0;
    var _iterator42 = _createForOfIteratorHelper(e),
      _step42;
    try {
      for (_iterator42.s(); !(_step42 = _iterator42.n()).done;) {
        var t = _step42.value;
        r = Math.max(t.length, r);
      }
    } catch (err) {
      _iterator42.e(err);
    } finally {
      _iterator42.f();
    }
    return r;
  }
  var Z0e = new On("pause"),
    jj = new Vs("path"),
    eSe = new On("mute"),
    Uj = Rj()({
      state: {},
      reducers: {
        setMode: function setMode(e, r) {
          return e[L].mode = r, _objectSpread({}, e);
        },
        setOsdDimensions: function setOsdDimensions(e, r) {
          return e[L].player.osdDimensions = r, _objectSpread({}, e);
        },
        setTheme: function setTheme(e, r) {
          return e[L].uiName = r, _objectSpread({}, e);
        },
        setLanguage: function setLanguage(e, r) {
          return e[ko].default = r, _objectSpread({}, e);
        },
        setUI: function setUI(e, r) {
          return e[L].uiName = r, _objectSpread({}, e);
        },
        setPause: function setPause(e, r) {
          return e[L].player.pause = r, Z0e.value = r, _objectSpread({}, e);
        },
        setMute: function setMute(e, r) {
          return e[L].player.mute = r, eSe.value = r, _objectSpread({}, e);
        },
        setTimePos: function setTimePos(e, r) {
          return e[L].player.timePos = r, _objectSpread({}, e);
        },
        setWindowMaximized: function setWindowMaximized(e, r) {
          return e[L].player.windowMaximized = r, ir("window-maximized", r), _objectSpread({}, e);
        },
        setFullscreen: function setFullscreen(e, r) {
          return e[L].player.fullscreen = r, ir("fullscreen", r), _objectSpread({}, e);
        },
        setDuration: function setDuration(e, r) {
          return e[L].player.duration = r, _objectSpread({}, e);
        },
        setWindowMinimized: function setWindowMinimized(e, r) {
          return e[L].player.windowMinimized = r, ir("window-minimized", r), _objectSpread({}, e);
        },
        setPath: function setPath(e, r) {
          return e[L].player.path = r, r !== or("path") && Jd("path", r), _objectSpread({}, e);
        },
        playVideo: function playVideo(e, r) {
          return fi("loadfile", r, "replace"), e;
        },
        screenshot: function screenshot(e) {
          return pe("screenshot video"), _objectSpread({}, e);
        },
        setMousePos: function setMousePos(e, r) {
          return e[L].player.mousePos = r, _objectSpread({}, e);
        },
        setHide: function setHide(e, r) {
          return e[L].state = _objectSpread(_objectSpread({}, e[L].state), {}, {
            hide: r
          }), _objectSpread({}, e);
        },
        setPlaylistHide: function setPlaylistHide(e, r) {
          return e[L].state.playlistHide = r, _objectSpread({}, e);
        },
        setHistoryHide: function setHistoryHide(e, r) {
          return e[L].state.historyHide = r, _objectSpread({}, e);
        },
        setPlayMode: function setPlayMode(e, r) {
          return e[L].player.playMode = r, _objectSpread({}, e);
        },
        setSpeed: function setSpeed(e, r) {
          return e[L].player.speed = r, _objectSpread({}, e);
        },
        setPlaylist: function setPlaylist(e, r, t) {
          return e[L].player = _objectSpread(_objectSpread({}, e[L].player), {}, {
            playlist: r,
            path: r[t]
          }), xL(r, t), _objectSpread({}, e);
        },
        addHistory: function addHistory(e, r) {
          if (!tn(r) && !Tt(r)) return e;
          var t = e[L].history || [],
            i = t.findIndex(function (p) {
              return p.path === r;
            }),
            a = _toConsumableArray(t);
          i >= 0 && a.splice(i, 1), a.unshift({
            path: r,
            name: su(r)
          });
          var s = e[L].mode,
            l = e[L].style[s].history.stackSize;
          for (; a.length > l;) a.pop();
          return e[L].history = a, _objectSpread({}, e);
        },
        exit: function exit(e) {
          return pe("quit"), _objectSpread({}, e);
        },
        next: function next(e) {
          var r = e[L].player.playlist,
            t = e[L].player.path,
            i = r.length,
            a = r.indexOf(t),
            s = (a + 1) % i;
          return s === a ? e : (e[L].player.playlistPos = s, e[L].player.path = r[s], jj.value = r[s], pe("playlist-play-index ".concat(s)), _objectSpread({}, e));
        },
        previous: function previous(e) {
          var r = e[L].player.playlist,
            t = e[L].player.path,
            i = r.length,
            a = r.indexOf(t),
            s = (a + i - 1) % i;
          return s === a ? e : (e[L].player.playlistPos = s, e[L].player.path = r[s], jj.value = r[s], pe("playlist-play-index ".concat(s)), _objectSpread({}, e));
        },
        setVid: function setVid(e, r) {
          return e[L].player = _objectSpread(_objectSpread({}, e[L].player), {}, {
            vid: r
          }), _objectSpread({}, e);
        },
        setAid: function setAid(e, r) {
          return e[L].player = _objectSpread(_objectSpread({}, e[L].player), {}, {
            aid: r
          }), _objectSpread({}, e);
        },
        setSid: function setSid(e, r) {
          return e[L].player = _objectSpread(_objectSpread({}, e[L].player), {}, {
            sid: r
          }), _objectSpread({}, e);
        },
        setAnime4k: function setAnime4k(e, r) {
          return e[_t] = _objectSpread({}, r), _objectSpread({}, e);
        },
        setVideoParams: function setVideoParams(e, r) {
          return e[L].player = _objectSpread(_objectSpread({}, e[L].player), {}, {
            videoParams: r
          }), _objectSpread({}, e);
        },
        setVolume: function setVolume(e, r) {
          return e[L].player = _objectSpread(_objectSpread({}, e[L].player), {}, {
            volume: r
          }), _objectSpread({}, e);
        },
        setVolumeMax: function setVolumeMax(e, r) {
          return e[L].player = _objectSpread(_objectSpread({}, e[L].player), {}, {
            volumeMax: r
          }), _objectSpread({}, e);
        },
        resetConfig: function resetConfig(e) {
          return Db();
        },
        setProtocolHook: function setProtocolHook(e, r) {
          return e[L].config.protocolHook = r, _objectSpread({}, e);
        },
        setFontSize: function setFontSize(e, r) {
          var t = r + 16,
            i = r / 8;
          return e[L].style.dark.button.default.fontSize = r, e[L].style.dark.button.default.width = t, e[L].style.dark.button.default.height = t, e[L].style.dark.button.default.padding = i, e[L].style.light.button.default.fontSize = r, e[L].style.light.button.default.width = t, e[L].style.light.button.default.height = t, e[L].style.light.button.default.padding = i, _objectSpread({}, e);
        }
      },
      selectors: function selectors(e) {
        return {};
      }
    });
  var Hj = {
    context: Uj
  };
  var La = "@mpv-easy/thumbfast",
    $j = 360,
    Vj = 360,
    Wj = !0,
    Gj = "bgra",
    Kj = !0,
    Yj = _e(Hs(), "mpv-easy-thumbfast.tmp"),
    Xj = "mpv-easy-thumbfast",
    rSe = 0,
    Bb = {
      path: Yj,
      format: Gj,
      maxWidth: $j,
      maxHeight: Vj,
      ipcId: Xj,
      startTime: rSe,
      hrSeek: Wj,
      network: Kj
    };
  function tSe(e, r, t, i) {
    var a = e / t,
      s = r / i,
      l = Math.max(s, a),
      p = e / l,
      d = r / l;
    return [p | 0, d | 0];
  }
  var nh = /*#__PURE__*/function () {
      function nh() {
        var _ref26 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : _objectSpread(_objectSpread({}, Bb), {}, {
            videoHeight: 0,
            videoWidth: 0
          }),
          _ref26$path = _ref26.path,
          r = _ref26$path === void 0 ? Yj : _ref26$path,
          _ref26$format = _ref26.format,
          t = _ref26$format === void 0 ? Gj : _ref26$format,
          _ref26$maxWidth = _ref26.maxWidth,
          i = _ref26$maxWidth === void 0 ? $j : _ref26$maxWidth,
          _ref26$maxHeight = _ref26.maxHeight,
          a = _ref26$maxHeight === void 0 ? Vj : _ref26$maxHeight,
          _ref26$ipcId = _ref26.ipcId,
          s = _ref26$ipcId === void 0 ? Xj : _ref26$ipcId,
          _ref26$startTime = _ref26.startTime,
          l = _ref26$startTime === void 0 ? 0 : _ref26$startTime,
          _ref26$videoWidth = _ref26.videoWidth,
          p = _ref26$videoWidth === void 0 ? 0 : _ref26$videoWidth,
          _ref26$videoHeight = _ref26.videoHeight,
          d = _ref26$videoHeight === void 0 ? 0 : _ref26$videoHeight,
          _ref26$hrSeek = _ref26.hrSeek,
          v = _ref26$hrSeek === void 0 ? Wj : _ref26$hrSeek,
          _ref26$network = _ref26.network,
          g = _ref26$network === void 0 ? Kj : _ref26$network;
        _classCallCheck(this, nh);
        _defineProperty(this, "path", void 0);
        _defineProperty(this, "format", void 0);
        _defineProperty(this, "maxWidth", void 0);
        _defineProperty(this, "maxHeight", void 0);
        _defineProperty(this, "ipcId", void 0);
        _defineProperty(this, "startTime", void 0);
        _defineProperty(this, "thumbWidth", void 0);
        _defineProperty(this, "thumbHeight", void 0);
        _defineProperty(this, "network", void 0);
        var x = tm();
        Tt(r) && HL(r), this.path = r, this.format = t, this.maxWidth = i, this.maxHeight = a, this.ipcId = s, this.startTime = l;
        var S = Nr(or("path") || ""),
          b = p,
          q = d,
          _tSe = tSe(b, q, i, a),
          _tSe2 = _slicedToArray(_tSe, 2),
          E = _tSe2[0],
          C = _tSe2[1];
        this.thumbWidth = E & -4, this.thumbHeight = C & -4, this.network = g;
        var T = or("stream-open-filename");
        on("demuxer-via-network") && (T === null || T === void 0 ? void 0 : T.length) && g && T !== r && (S = T.replace(/,ytdl_description.*/, ""));
        var D = [x, "--no-config", "--msg-level=all=no", "--idle", "--keep-open=always", "--pause", "--really-quiet", "--terminal=no", "--ao=null", "--vo=null", "--load-auto-profiles=no", "--load-osd-console=no", "--load-scripts=no", "--load-stats-overlay=no", "--osc=no", "--vd-lavc-skiploopfilter=all", "--vd-lavc-skipidct=all", "--vd-lavc-software-fallback=1", "--vd-lavc-fast", "--vd-lavc-threads=2", "--hwdec=auto", "--edition=auto", "--vid=1", "--sub=no", "--hr-seek=".concat(v ? "yes" : "no"), "--no-sub", "--no-audio", "--audio=no", "--sub-auto=no", "--audio-file-auto=no", "--start=0", "--ytdl=no", "--ytdl-format=worst", "--demuxer-readahead-secs=0", "--gpu-dumb-mode=yes", "--tone-mapping=clip", "--hdr-compute-peak=no", "--sws-allow-zimg=no", "--sws-fast=yes", "--sws-scaler=fast-bilinear", "--audio-pitch-correction=no", "--ovc=rawvideo", "--of=image2", "--ofopts=update=1", "--ocopy-metadata=no", "--sws-allow-zimg=no", "--demuxer-max-bytes=512KiB", "--vf=scale=w=".concat(this.thumbWidth, ":h=").concat(this.thumbHeight, ":force_original_aspect_ratio=decrease,pad=w=").concat(this.thumbWidth, ":h=").concat(this.thumbHeight, ":x=-1:y=-1,format=").concat(this.format), "--o=".concat(this.path), "--input-ipc-server=".concat(this.ipcId), "--", S];
        Yd({
          name: "subprocess",
          args: D,
          playback_only: !0,
          capture_stdout: !0,
          capture_stderr: !0
        });
      }
      return _createClass(nh, [{
        key: "seek",
        value: function seek(r) {
          ya({
            name: "subprocess",
            args: [Be() === "windows" ? "cmd" : "sh", Be() === "windows" ? "/c" : "-c", "echo set time-pos ".concat(r, " > \\\\.\\pipe\\").concat(this.ipcId)],
            playback_only: !0,
            capture_stdout: !0,
            capture_stderr: !0
          });
        }
      }, {
        key: "exit",
        value: function exit() {
          ya({
            name: "subprocess",
            args: [Be() === "windows" ? "cmd" : "sh", Be() === "windows" ? "/c" : "-c", "echo quit > \\\\.\\pipe\\".concat(this.ipcId)],
            playback_only: !0,
            capture_stdout: !0,
            capture_stderr: !0
          });
        }
      }]);
    }(),
    Qj = function Qj(e, r) {
      return {
        name: La,
        create: function create() {
          var t = mi(e[La].path);
          t && !Tt(t) && cm(t);
        },
        destroy: function destroy() {}
      };
    };
  function Jj() {
    return Nj({
      models: Hj
    });
  }
  var cr = function cr(e) {
      return e.context[L].mode;
    },
    Hr = function Hr(e) {
      return e.context[L].style;
    },
    uu = function uu(e) {
      return e.context[L].uiName;
    },
    Zj = function Zj(e) {
      return e.context[io];
    },
    Bc = function Bc(e) {
      return e.context[ko].default;
    },
    le = function le(e) {
      return e.context[ko].lang[Bc(e)];
    },
    eU = function eU(e) {
      return e.context[_t];
    };
  var oh = function oh(e) {
      return e.context[L].player.pause;
    },
    Ni = function Ni(e) {
      return e.context[L].player.fullscreen;
    },
    rU = function rU(e) {
      return e.context[L].player.mute;
    },
    tU = function tU(e) {
      return e.context[L].player.mousePos;
    },
    Do = function Do(e) {
      var _e$context$L$player$p;
      return Nr((_e$context$L$player$p = e.context[L].player.path) !== null && _e$context$L$player$p !== void 0 ? _e$context$L$player$p : "");
    };
  var nU = function nU(e) {
      return e.context[L].player.duration;
    },
    oU = function oU(e) {
      return e.context[L].player.timePos;
    },
    iU = function iU(e) {
      return e.context[L].player.aid;
    };
  var aU = function aU(e) {
      return e.context[L].player.sid;
    },
    ih = function ih(e) {
      return e.context[L].player.volume;
    },
    ah = function ah(e) {
      return e.context[L].player.volumeMax;
    };
  var sU = function sU(e) {
      var _su;
      var r = Do(e);
      return (_su = su(r)) !== null && _su !== void 0 ? _su : "";
    },
    uU = function uU(e) {
      return e.context[L].config.fps;
    },
    Y = function Y(e) {
      return Hr(e)[cr(e)].button.default;
    },
    lU = function lU(e) {
      return Hr(e)[cr(e)].font;
    },
    Ri = function Ri(e) {
      var r = Hr(e)[cr(e)].button.default;
      return r.width + r.padding * 2;
    },
    Mi = function Mi(e) {
      return Hr(e)[cr(e)].button.default.fontSize;
    },
    lu = function lu(e) {
      return Hr(e)[cr(e)].button.default.fontSize * .75;
    };
  var cU = function cU(e) {
      return Hr(e)[cr(e)].scrollList;
    },
    fU = function fU(e) {
      return Hr(e)[cr(e)].volume;
    },
    dn = function dn(e) {
      return Hr(e)[cr(e)].dropdown;
    },
    sh = function sh(e) {
      return Hr(e)[cr(e)].clickMenu;
    },
    cu = function cu(e) {
      return Hr(e)[cr(e)].control;
    },
    pU = function pU(e) {
      return Hr(e)[cr(e)].progress;
    },
    fu = function fu(e) {
      return Hr(e)[cr(e)].toolbar;
    };
  var dU = function dU(e) {
      return Hr(e)[cr(e)].playlist;
    },
    mU = function mU(e) {
      return Hr(e)[cr(e)].history;
    },
    hU = function hU(e) {
      return Hr(e)[cr(e)].speed;
    },
    vU = function vU(e) {
      return e.context[L].player.playlist;
    },
    gU = function gU(e) {
      return e.context[L].player.osdDimensions;
    },
    uh = function uh(e) {
      return e.context[L].player.speed;
    },
    lh = function lh(e) {
      return e.context[L].player.speedList;
    },
    yU = function yU(e) {
      return e.context[L].history;
    },
    xU = function xU(e) {
      return e.context[L].player.playMode;
    },
    ch = function ch(e) {
      return e.context[L].state.playlistHide;
    },
    fh = function fh(e) {
      return e.context[L].state.historyHide;
    },
    ie = function ie(e) {
      return e.context.experimental.mouseHoverStyle;
    },
    SU = function SU(e) {
      return e.context.enablePlugins;
    },
    bU = function bU(e) {
      return e.context[L].config.protocolHook;
    },
    wU = function wU(e) {
      return e.context[La];
    };
  var pu = function pu(_ref27) {
    var _C$current, _E$current$layoutNode, _E$current, _b$current4, _b$current5, _b$current6, _b$current7;
    var e = _ref27.width,
      r = _ref27.height,
      t = _objectWithoutProperties(_ref27, _excluded3);
    var _ref28 = (0, Ir.useState)(0),
      _ref29 = _slicedToArray(_ref28, 2),
      i = _ref29[0],
      a = _ref29[1],
      _ref30 = (0, Ir.useState)(!0),
      _ref31 = _slicedToArray(_ref30, 2),
      s = _ref31[0],
      l = _ref31[1],
      p = w(pU),
      d = w(Y),
      v = w(oU),
      g = w(nU),
      x = ne(),
      S = kL(g),
      b = (0, Ir.useRef)(),
      q = (0, Ir.useRef)(null),
      E = (0, Ir.useRef)(null),
      C = (0, Ir.useRef)(null),
      T = (_C$current = C.current) === null || _C$current === void 0 ? void 0 : _C$current.layoutNode.width,
      D = T ? p.cursorSize / 2 / T : 0,
      M = v / g - D,
      k = on("seekable"),
      W = w(wU),
      ee = k && W.network;
    (0, Ir.useEffect)(function () {
      new Ot("video-params").observe(function (se) {
        if (!se || !ee) return;
        var _se$w = se.w,
          Qe = _se$w === void 0 ? 0 : _se$w,
          _se$h = se.h,
          Me = _se$h === void 0 ? 0 : _se$h;
        if (!Qe || !Me) return;
        b.current && b.current.exit();
        var ve = "ipc_".concat(PL());
        b.current = new nh(_objectSpread(_objectSpread({}, W), {}, {
          ipcId: ve,
          videoWidth: Qe,
          videoHeight: Me
        }));
      });
    }, []);
    var N = function N(se) {
        var _se$target, _b$current;
        var Qe = ((_se$target = se.target) === null || _se$target === void 0 ? void 0 : _se$target.layoutNode.width) || 0,
          Me = (se.offsetX - p.cursorSize / 2) / Qe;
        a(Me);
        var ve = g * (se.offsetX / Qe);
        return (_b$current = b.current) !== null && _b$current !== void 0 && _b$current.seek(ve), Me;
      },
      B = (0, Ir.useRef)(null),
      U = (_E$current$layoutNode = (_E$current = E.current) === null || _E$current === void 0 ? void 0 : _E$current.layoutNode.width) !== null && _E$current$layoutNode !== void 0 ? _E$current$layoutNode : 0,
      me = p.cursorSize - U >> 1,
      be = 0,
      re = 0;
    if (B.current) {
      var _b$current$thumbWidth, _b$current2, _b$current$thumbHeigh, _b$current3;
      var _B$current$layoutNode = B.current.layoutNode,
        se = _B$current$layoutNode.x,
        Qe = _B$current$layoutNode.y,
        Me = _B$current$layoutNode.height,
        ve = _B$current$layoutNode.width;
      be = se + ve / 2 - ((_b$current$thumbWidth = (_b$current2 = b.current) === null || _b$current2 === void 0 ? void 0 : _b$current2.thumbWidth) !== null && _b$current$thumbWidth !== void 0 ? _b$current$thumbWidth : 0) / 2, re = Qe - ((_b$current$thumbHeigh = (_b$current3 = b.current) === null || _b$current3 === void 0 ? void 0 : _b$current3.thumbHeight) !== null && _b$current$thumbHeigh !== void 0 ? _b$current$thumbHeigh : 0) - Me;
    }
    var Ne = w(lu);
    return Ir.default.createElement(K, _objectSpread({
      ref: C,
      display: "flex",
      id: "uosc-progress",
      position: "relative",
      width: e,
      height: r,
      color: p.backgroundColor,
      fontSize: Ne,
      font: p.font,
      backgroundColor: p.backgroundColor,
      onMouseDown: function onMouseDown(se) {
        var _se$target2;
        var Qe = ((_se$target2 = se.target) === null || _se$target2 === void 0 ? void 0 : _se$target2.layoutNode.width) || 0,
          ve = se.offsetX / Qe * g;
        x.context.setTimePos(ve), N(se), Ur("time-pos", ve), se.preventDefault();
      },
      onMouseMove: function onMouseMove(se) {
        l(!1), N(se);
      },
      onMouseEnter: function onMouseEnter(se) {
        N(se), l(!1);
      },
      onMouseLeave: function onMouseLeave(se) {
        N(se), l(!0);
      }
    }, t), Ir.default.createElement(K, {
      ref: q,
      id: "progress-text-start",
      position: "relative",
      left: 0,
      height: "100%",
      justifyContent: "center",
      alignItems: "center",
      backgroundColor: p.timeTextBackgroundColor,
      color: p.timeTextColor,
      text: am(v, S),
      padding: d.padding,
      pointerEvents: "none"
    }), Ir.default.createElement(K, {
      id: "progress-text-end",
      position: "relative",
      right: 0,
      height: "100%",
      justifyContent: "center",
      alignItems: "center",
      backgroundColor: p.timeTextBackgroundColor,
      color: p.timeTextColor,
      text: am(g, S),
      padding: d.padding,
      pointerEvents: "none"
    }), Ir.default.createElement(K, {
      id: "cursor",
      position: "relative",
      width: p.cursorSize,
      left: "".concat(M * 100, "%"),
      height: "100%",
      backgroundColor: p.cursorColor,
      color: p.cursorColor,
      pointerEvents: "none"
    }), !s && Ir.default.createElement(K, {
      ref: B,
      id: "preview-cursor",
      position: "relative",
      width: p.previewCursorSize,
      left: "".concat(i * 100, "%"),
      height: "100%",
      backgroundColor: p.previewCursorColor,
      color: p.previewCursorColor,
      pointerEvents: "none",
      zIndex: p.previewZIndex,
      display: "flex",
      alignContent: "stretch"
    }, !s && Ir.default.createElement(K, {
      id: "preview-cursor-time",
      position: "absolute",
      height: "100%",
      top: "-100%",
      left: me,
      backgroundColor: p.backgroundColor,
      color: p.color,
      text: am(i * g, S),
      pointerEvents: "none",
      display: "flex",
      ref: E,
      justifyContent: "center",
      alignItems: "center"
    }), b.current && !s && !!be && !!re && ee && Ir.default.createElement(K, {
      id: 42,
      position: "absolute",
      x: be,
      y: re,
      width: (_b$current4 = b.current) === null || _b$current4 === void 0 ? void 0 : _b$current4.thumbWidth,
      height: (_b$current5 = b.current) === null || _b$current5 === void 0 ? void 0 : _b$current5.thumbHeight,
      backgroundImage: (_b$current6 = b.current) === null || _b$current6 === void 0 ? void 0 : _b$current6.path,
      backgroundImageFormat: (_b$current7 = b.current) === null || _b$current7 === void 0 ? void 0 : _b$current7.format,
      pointerEvents: "none"
    })));
  };
  var Br = j(Z());
  var KU = j(Z());
  var ar = "";
  var EU = "";
  var CU = "";
  var IU = "",
    PU = "",
    qU = "",
    TU = "",
    OU = "";
  var AU = "",
    _U = "";
  var NU = "󰔎";
  var sr = "󰄰";
  var RU = "󰐑";
  var MU = "󰨖";
  var kU = "",
    DU = "",
    BU = "",
    FU = "";
  var LU = "",
    zU = "",
    jU = "󱑽",
    UU = "";
  var HU = "",
    $U = "󰑐",
    VU = "",
    WU = "󰋚";
  var GU = "";
  var mn = "",
    hn = "";
  var du = function du() {
    var e = w(Y),
      r = w(oh),
      t = w(le),
      i = ne(),
      a = w(ie);
    return KU.default.createElement(de, {
      id: "mpv-easy-button-play",
      title: r ? t.play : t.pause,
      width: e.width,
      height: e.height,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      enableMouseStyle: a,
      text: r ? IU : PU,
      padding: e.padding,
      backgroundColor: e.backgroundColor,
      font: e.font,
      fontSize: e.fontSize,
      color: e.color,
      onMouseDown: function onMouseDown(s) {
        i.context.setPause(!r);
      },
      colorHover: e.colorHover,
      backgroundColorHover: e.backgroundColorHover
    });
  };
  var YU = j(Z());
  var ph = function ph() {
    var e = w(Y),
      r = w(le),
      t = ne(),
      i = w(ie);
    return YU.default.createElement(de, {
      id: "mpv-easy-button-stop",
      title: r.stop,
      width: e.width,
      height: e.height,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      text: qU,
      enableMouseStyle: i,
      padding: e.padding,
      colorHover: e.colorHover,
      backgroundColorHover: e.backgroundColorHover,
      backgroundColor: e.backgroundColor,
      font: e.font,
      fontSize: e.fontSize,
      color: e.color,
      onMouseDown: function onMouseDown() {
        t.context.setPause(!0), t.context.setTimePos(0), Ur("time-pos", 0);
      }
    });
  };
  var XU = j(Z());
  var mu = function mu() {
    var e = w(Y),
      r = w(le),
      t = ne(),
      i = w(ie);
    return XU.default.createElement(de, {
      id: "mpv-easy-button-screenshot",
      title: r.screenshot,
      width: e.width,
      height: e.height,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      enableMouseStyle: i,
      text: EU,
      colorHover: e.colorHover,
      backgroundColorHover: e.backgroundColorHover,
      padding: e.padding,
      backgroundColor: e.backgroundColor,
      font: e.font,
      fontSize: e.fontSize,
      color: e.color,
      onMouseDown: function onMouseDown() {
        t.context.screenshot();
      }
    });
  };
  var QU = j(Z());
  var hu = function hu() {
    var e = w(Y),
      r = w(le),
      t = ne(),
      i = w(ie);
    return QU.default.createElement(de, {
      id: "mpv-easy-button-fullscreen",
      title: r.fullscreen,
      width: e.width,
      height: e.height,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      enableMouseStyle: i,
      colorHover: e.colorHover,
      backgroundColorHover: e.backgroundColorHover,
      text: DU,
      padding: e.padding,
      backgroundColor: e.backgroundColor,
      font: e.font,
      fontSize: e.fontSize,
      color: e.color,
      onMouseDown: function onMouseDown(a) {
        t.context.setFullscreen(!0);
      }
    });
  };
  var JU = j(Z());
  var vu = function vu() {
    var e = w(Y),
      r = w(le),
      t = ne(),
      i = w(ie);
    return JU.default.createElement(de, {
      id: "mpv-easy-button-next",
      title: r.next,
      width: e.width,
      height: e.height,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      enableMouseStyle: i,
      colorHover: e.colorHover,
      backgroundColorHover: e.backgroundColorHover,
      text: _U,
      padding: e.padding,
      backgroundColor: e.backgroundColor,
      font: e.font,
      fontSize: e.fontSize,
      color: e.color,
      onMouseDown: function onMouseDown(a) {
        t.context.next();
      }
    });
  };
  var ZU = j(Z());
  var gu = function gu() {
    var e = w(Y),
      r = w(le),
      t = ne(),
      i = w(ie);
    return ZU.default.createElement(de, {
      id: "mpv-easy-button-previous",
      title: r.previous,
      width: e.width,
      height: e.height,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      enableMouseStyle: i,
      colorHover: e.colorHover,
      backgroundColorHover: e.backgroundColorHover,
      text: AU,
      padding: e.padding,
      backgroundColor: e.backgroundColor,
      font: e.font,
      fontSize: e.fontSize,
      color: e.color,
      onMouseDown: function onMouseDown() {
        t.context.previous();
      }
    });
  };
  var eH = j(Z());
  var yu = function yu() {
    var e = w(Y),
      r = w(le),
      t = ne(),
      i = w(ie),
      a = w(ch);
    return eH.default.createElement(de, {
      text: RU,
      id: "mpv-easy-button-playlist",
      title: r.playlist,
      width: e.width,
      height: e.height,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      enableMouseStyle: i,
      colorHover: e.colorHover,
      backgroundColorHover: e.backgroundColorHover,
      padding: e.padding,
      backgroundColor: e.backgroundColor,
      font: e.font,
      fontSize: e.fontSize,
      color: e.color,
      onMouseDown: function onMouseDown(s) {
        t.context.setHistoryHide(!0), t.context.setPlaylistHide(!a), s.stopPropagation();
      }
    });
  };
  var rH = j(Z());
  function nSe() {
    var e = [],
      r = ut("track-list/count") || 0;
    for (var t = 0; t < r; t++) if (or("track-list/".concat(t, "/type")) === "sub") {
      var a = or("track-list/".concat(t, "/title")),
        s = or("track-list/".concat(t, "/lang")),
        l = on("track-list/".concat(t, "/selected")),
        p = on("track-list/".concat(t, "/external")),
        d = ut("track-list/".concat(t, "/id")) || 0;
      e.push({
        title: a,
        lang: s,
        selected: l,
        id: d,
        external: p
      });
    }
    return e;
  }
  var xu = function xu() {
    var e = w(Y),
      r = w(le),
      t = ne(),
      i = w(ie),
      a = w(dn),
      s = w(aU),
      p = nSe().map(function (_ref32, b) {
        var _ref33;
        var d = _ref32.title,
          v = _ref32.lang,
          g = _ref32.external,
          x = _ref32.selected,
          S = _ref32.id;
        var q = [d, v, g, b].join("-");
        return {
          label: "".concat(s === S ? ar : sr, " ").concat((_ref33 = d !== null && d !== void 0 ? d : v) !== null && _ref33 !== void 0 ? _ref33 : "default"),
          key: q,
          onSelect: function onSelect(T, D) {
            s === S ? (t.context.setSid(-1), ro("sid", "no")) : (t.context.setSid(S), ro("sid", "yes"), ro("sid", S)), D.stopPropagation();
          },
          style: _objectSpread(_objectSpread({}, a.item), {}, {
            justifyContent: "start"
          })
        };
      });
    return rH.default.createElement(fn, {
      id: "mpv-easy-button-subtitle-track",
      direction: "top",
      title: r.subtitleTrack,
      items: p,
      text: MU,
      dropdownStyle: a.button,
      width: e.width,
      height: e.height,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      enableMouseStyle: i,
      colorHover: a.button.colorHover,
      backgroundColorHover: a.button.backgroundColorHover,
      padding: a.button.padding,
      backgroundColor: a.button.backgroundColor,
      font: a.button.font,
      fontSize: e.fontSize,
      color: a.button.color,
      dropdownListStyle: a.list,
      pageDown: {
        style: a.item,
        text: mn
      },
      pageUp: {
        style: a.item,
        text: hn
      }
    });
  };
  var tH = j(Z());
  function oSe() {
    return (pi("track-list") || []).filter(function (r) {
      return r.type === "audio";
    });
  }
  var Su = function Su() {
    var e = w(dn),
      r = w(Y),
      t = w(le),
      i = w(ie),
      a = oSe(),
      s = w(iU),
      l = ne(),
      p = a.map(function (_ref34, b) {
        var _ref35;
        var d = _ref34.title,
          v = _ref34.lang,
          g = _ref34.external,
          x = _ref34.selected,
          S = _ref34.id;
        var q = [d, v, g, b].join("-");
        return {
          label: "".concat(x || s === S ? ar : sr, " ").concat((_ref35 = d !== null && d !== void 0 ? d : v) !== null && _ref35 !== void 0 ? _ref35 : "default"),
          key: q,
          onSelect: function onSelect(T, D) {
            ro("aid", S), l.context.setAid(S), D.stopPropagation();
          },
          style: _objectSpread(_objectSpread({}, e.item), {}, {
            justifyContent: "start"
          })
        };
      });
    return tH.default.createElement(fn, {
      id: "mpv-easy-button-audio-track",
      items: p,
      text: jU,
      title: t.audioTrack,
      width: r.width,
      height: r.height,
      direction: "top",
      dropdownStyle: e.button,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      enableMouseStyle: i,
      colorHover: e.button.colorHover,
      backgroundColorHover: e.button.backgroundColorHover,
      padding: e.button.padding,
      backgroundColor: e.button.backgroundColor,
      font: e.button.font,
      fontSize: r.fontSize,
      color: e.button.color,
      dropdownListStyle: e.list,
      pageDown: {
        style: e.item,
        text: mn
      },
      pageUp: {
        style: e.item,
        text: hn
      }
    });
  };
  var nH = j(Z());
  var ki = function ki() {
    var e = w(Y),
      r = w(le),
      t = ne(),
      i = w(ie);
    return nH.default.createElement(de, {
      id: "mpv-easy-button-restore",
      title: r.restore,
      width: e.width,
      height: e.height,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      enableMouseStyle: i,
      padding: e.padding,
      colorHover: e.colorHover,
      backgroundColorHover: e.backgroundColorHover,
      text: FU,
      backgroundColor: e.backgroundColor,
      font: e.font,
      fontSize: e.fontSize,
      color: e.color,
      onMouseDown: function onMouseDown() {
        t.context.setFullscreen(!1);
      }
    });
  };
  var dH = j(Z());
  var Ee = "FFFFFF",
    Ce = "000000";
  var Nt = "00FFFF",
    Di = "FF";
  var kr = "80",
    ur = "40",
    Ie = "00",
    pH = ["loopOne", "loopAll", "shuffle"],
    Bi = ["dark", "light"],
    Eu = ["osc", "uosc", "oscx"],
    iSe = "loopAll",
    oH = !0,
    iH = 1024,
    bu = 512;
  var aH = 256,
    sH = 256,
    uH = 128,
    dh = 512,
    Dr = "JetBrainsMono NFM Regular",
    Pr = 48,
    aSe = "uosc",
    vn = 6,
    et = Pr * 1.25,
    wu = 4,
    lH = 8,
    cH = 10,
    mh = 5e3,
    Fb = 2e3,
    fH = [{
      delay: 500,
      speed: 2
    }, {
      delay: 2e3,
      speed: 4
    }];
  function Lb() {
    return structuredClone({
      mode: "dark",
      uiName: aSe,
      history: [],
      style: {
        dark: {
          font: Dr,
          button: {
            default: {
              padding: vn,
              color: Ee + Ie,
              backgroundColor: Ce + Di,
              colorHover: Nt + Ie,
              backgroundColorHover: Ee + kr,
              fontSize: Pr,
              font: Dr,
              width: et,
              height: et
            },
            active: {
              padding: vn,
              color: Ee + Ie,
              backgroundColor: Ce + ur,
              colorHover: Nt + Ie,
              backgroundColorHover: Ee + kr,
              fontSize: Pr,
              font: Dr,
              width: et,
              height: et
            },
            hover: {
              padding: vn,
              color: Ee + Ie,
              backgroundColor: Ce + ur,
              colorHover: Nt + Ie,
              backgroundColorHover: Ee + kr,
              fontSize: Pr,
              font: Dr,
              width: et,
              height: et
            }
          },
          progress: {
            height: et,
            color: Ee + Ie,
            backgroundColor: Ce + ur,
            cursorColor: Ee + Ie,
            cursorSize: wu,
            previewCursorSize: wu,
            previewCursorColor: Ee + kr,
            timeTextBackgroundColor: Ee + Di,
            timeTextColor: Ee + Ie,
            font: Dr,
            previewZIndex: aH
          },
          control: {
            backgroundColor: Ce + ur,
            height: et
          },
          scrollList: {
            maxItemCount: lH
          },
          toolbar: {
            backgroundColor: Ce + ur,
            autoHideDelay: mh,
            maxTitleLength: 32
          },
          volume: {
            backgroundColor: Ce + ur,
            autoHideDelay: mh,
            fontSize: Pr * .75,
            zIndex: uH,
            step: cH,
            previewCursorSize: wu,
            previewCursorColor: Ee + kr
          },
          speed: {
            showText: !0,
            steps: fH
          },
          playlist: {
            backgroundColor: Ce + ur,
            zIndex: dh,
            maxTitleLength: 32
          },
          history: {
            backgroundColor: Ce + ur,
            zIndex: dh,
            maxTitleLength: 32,
            stackSize: 32
          },
          tooltip: {
            enable: !0,
            zIndex: iH,
            padding: vn,
            color: Ee + Ie,
            backgroundColor: Ce + ur,
            colorHover: Nt + Ie,
            backgroundColorHover: Ee + kr,
            fontSize: Pr * .75,
            font: Dr
          },
          dropdown: {
            list: {
              padding: 0,
              color: Ee + Ie,
              backgroundColor: Ce + ur,
              colorHover: Nt + Ie,
              backgroundColorHover: Ee + kr,
              fontSize: Pr,
              font: Dr,
              zIndex: bu + 1
            },
            button: {
              padding: vn,
              color: Ee + Ie,
              backgroundColor: Ce + Di,
              colorHover: Nt + Ie,
              backgroundColorHover: Ee + kr,
              fontSize: Pr,
              font: Dr,
              zIndex: bu
            },
            item: {
              padding: vn,
              color: Ee + Ie,
              backgroundColor: Ce + Di,
              colorHover: Nt + Ie,
              backgroundColorHover: Ee + kr,
              fontSize: Pr * .75,
              font: Dr,
              zIndex: bu + 2,
              height: Pr * .75
            }
          },
          clickMenu: {
            backgroundColor: Ce + ur,
            zIndex: sH,
            disable: oH
          }
        },
        light: {
          font: Dr,
          button: {
            default: {
              padding: vn,
              color: Ce + Ie,
              backgroundColor: Ee + Di,
              colorHover: Nt + Ie,
              backgroundColorHover: Ce + kr,
              fontSize: Pr,
              font: Dr,
              width: et,
              height: et
            },
            active: {
              padding: vn,
              color: Ce + Ie,
              backgroundColor: Ee + ur,
              colorHover: Nt + Ie,
              backgroundColorHover: Ce + kr,
              fontSize: Pr,
              font: Dr,
              width: et,
              height: et
            },
            hover: {
              padding: vn,
              color: Ce + Ie,
              backgroundColor: Ee + ur,
              colorHover: Nt + Ie,
              backgroundColorHover: Ce + kr,
              fontSize: Pr,
              font: Dr,
              width: et,
              height: et
            }
          },
          progress: {
            height: et,
            color: Ce + Ie,
            backgroundColor: Ee + ur,
            cursorColor: Ce + Ie,
            cursorSize: wu,
            previewCursorSize: wu,
            previewCursorColor: Ce + kr,
            timeTextBackgroundColor: Ce + Di,
            timeTextColor: Ce + Ie,
            font: Dr,
            previewZIndex: aH
          },
          control: {
            backgroundColor: Ee + ur,
            height: et
          },
          toolbar: {
            backgroundColor: Ee + ur,
            autoHideDelay: mh,
            maxTitleLength: 32
          },
          scrollList: {
            maxItemCount: lH
          },
          volume: {
            backgroundColor: Ee + ur,
            fontSize: Pr * .75,
            autoHideDelay: mh,
            step: cH,
            zIndex: uH,
            previewCursorSize: wu,
            previewCursorColor: Ce + kr
          },
          speed: {
            showText: !0,
            steps: fH
          },
          playlist: {
            backgroundColor: Ee + ur,
            zIndex: dh,
            maxTitleLength: 32
          },
          history: {
            backgroundColor: Ee + ur,
            zIndex: dh,
            maxTitleLength: 32,
            stackSize: 32
          },
          tooltip: {
            enable: !0,
            zIndex: iH,
            padding: vn,
            color: Ce + Ie,
            backgroundColor: Ee + ur,
            colorHover: Nt + Ie,
            backgroundColorHover: Ce + kr,
            fontSize: Pr * .75,
            font: Dr
          },
          dropdown: {
            list: {
              padding: 0,
              color: Ce + Ie,
              backgroundColor: Ee + ur,
              colorHover: Nt + Ie,
              backgroundColorHover: Ce + kr,
              fontSize: Pr,
              font: Dr,
              zIndex: bu + 1
            },
            button: {
              padding: vn,
              color: Ce + Ie,
              backgroundColor: Ee + Di,
              colorHover: Nt + Ie,
              backgroundColorHover: Ce + kr,
              fontSize: Pr,
              font: Dr,
              zIndex: bu
            },
            item: {
              padding: vn,
              color: Ce + Ie,
              backgroundColor: Ee + Di,
              colorHover: Nt + Ie,
              backgroundColorHover: Ce + kr,
              fontSize: Pr * .75,
              font: Dr,
              zIndex: bu + 2,
              height: Pr * .75
            }
          },
          clickMenu: {
            backgroundColor: Ee + ur,
            zIndex: sH,
            disable: oH
          }
        }
      },
      progress: {
        save: !0,
        time: 0
      },
      player: sSe,
      state: zb,
      config: {
        fps: qi,
        enableMouseMoveEvent: !0,
        saveConfigThrottle: Fb,
        protocolHook: ""
      }
    });
  }
  var zb = {
      hide: !1,
      playlistHide: !0,
      historyHide: !0
    },
    sSe = {
      pause: !1,
      timePos: 0,
      duration: 0,
      windowMaximized: !1,
      fullscreen: !1,
      windowMinimized: !1,
      path: "",
      mute: !1,
      playlistPos: 0,
      mousePos: {
        x: 0,
        y: 0,
        hover: !1
      },
      osdDimensions: {
        w: 0,
        h: 0
      },
      aid: 0,
      vid: 0,
      sid: 0,
      playlist: [],
      videoParams: {},
      volume: 100,
      volumeMax: 130,
      speed: 1,
      speedList: [.25, .5, .75, 1, 1.25, 1.5, 2, 4],
      playMode: iSe
    },
    jb = Lb();
  var Cu = function Cu() {
    var e = w(Y),
      r = w(le),
      t = w(ie),
      i = w(xU),
      a = w(dn),
      s = {
        loopOne: HU,
        loopAll: $U,
        shuffle: GU
      },
      l = ne(),
      p = pH.map(function (d) {
        return {
          label: "".concat(i === d ? ar : sr, " ").concat(r[d]),
          key: d,
          onSelect: function onSelect(v, g) {
            l.context.setPlayMode(d), d === r.loopOne ? (ir("loop-playlist", !1), ir("loop-file", !0), ir("shuffle", !1)) : d === r.loopAll ? (ir("loop-file", !1), ir("loop-playlist", !0), ir("shuffle", !1)) : d === r.shuffle && (ir("shuffle", !0), ir("loop-file", !1), ir("loop-playlist", !0)), g.stopPropagation();
          },
          style: _objectSpread(_objectSpread({}, a.item), {}, {
            justifyContent: "start"
          })
        };
      });
    return dH.default.createElement(fn, {
      id: "mpv-easy-button-play-mode",
      items: p,
      title: r.playMode,
      text: s[i],
      width: e.width,
      height: e.height,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      direction: "top",
      dropdownStyle: a.button,
      colorHover: a.button.colorHover,
      backgroundColorHover: a.button.backgroundColorHover,
      padding: a.button.padding,
      backgroundColor: a.button.backgroundColor,
      font: a.button.font,
      fontSize: e.fontSize,
      color: a.button.color,
      enableMouseStyle: t,
      dropdownListStyle: a.list,
      pageDown: {
        style: a.item,
        text: mn
      },
      pageUp: {
        style: a.item,
        text: hn
      }
    });
  };
  var mH = j(Z());
  var Iu = function Iu() {
    var e = w(Y),
      r = w(le),
      t = w(ie);
    return mH.default.createElement(de, {
      id: "mpv-easy-button-previous-frame",
      title: r.previousFrame,
      text: CU,
      width: e.width,
      height: e.height,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      enableMouseStyle: t,
      colorHover: e.colorHover,
      backgroundColorHover: e.backgroundColorHover,
      padding: e.padding,
      backgroundColor: e.backgroundColor,
      font: e.font,
      fontSize: e.fontSize,
      color: e.color,
      onMouseDown: function onMouseDown() {
        pe("no-osd frame-back-step");
      }
    });
  };
  var hH = j(Z());
  var Pu = function Pu() {
    var e = w(Y),
      r = w(le),
      t = w(ie);
    return hH.default.createElement(de, {
      id: "mpv-easy-button-next-frame",
      title: r.nextFrame,
      text: OU,
      width: e.width,
      height: e.height,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      enableMouseStyle: t,
      colorHover: e.colorHover,
      backgroundColorHover: e.backgroundColorHover,
      padding: e.padding,
      backgroundColor: e.backgroundColor,
      font: e.font,
      fontSize: e.fontSize,
      color: e.color,
      onMouseDown: function onMouseDown(i) {
        pe("no-osd frame-step");
      }
    });
  };
  var vH = j(Z());
  var za = function za() {
    var e = w(Y),
      r = w(le),
      t = ne(),
      i = w(ie),
      a = w(fh);
    return vH.default.createElement(de, {
      text: WU,
      id: "mpv-easy-button-history",
      title: r.history,
      width: e.width,
      height: e.height,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      enableMouseStyle: i,
      colorHover: e.colorHover,
      backgroundColorHover: e.backgroundColorHover,
      padding: e.padding,
      backgroundColor: e.backgroundColor,
      font: e.font,
      fontSize: e.fontSize,
      color: e.color,
      onMouseDown: function onMouseDown(s) {
        t.context.setPlaylistHide(!0), t.context.setHistoryHide(!a), s.stopPropagation();
      }
    });
  };
  var gH = function gH(e) {
    var r = e.width,
      t = e.height,
      i = w(function (p) {
        return p.context[L].mode;
      }),
      a = w(function (p) {
        return p.context[L].style[i].button.default;
      }),
      s = w(function (p) {
        return p.context[L].style[i].control;
      }),
      l = w(Ni);
    return Br.default.createElement(K, {
      id: "uosc-control",
      display: "flex",
      font: a.font,
      fontSize: a.fontSize,
      color: a.color,
      width: r,
      height: t,
      justifyContent: "space-between",
      alignItems: "center"
    }, Br.default.createElement(K, {
      display: "flex",
      justifyContent: "start",
      height: t,
      alignItems: "center",
      backgroundColor: s.backgroundColor
    }, Br.default.createElement(du, null), Br.default.createElement(ph, null), Br.default.createElement(xu, null), Br.default.createElement(Su, null), Br.default.createElement(mu, null), Br.default.createElement(za, null)), Br.default.createElement(K, {
      display: "flex",
      height: t,
      justifyContent: "end",
      alignItems: "center",
      backgroundColor: s.backgroundColor
    }, Br.default.createElement(Cu, null), Br.default.createElement(Iu, null), Br.default.createElement(gu, null), Br.default.createElement(yu, null), Br.default.createElement(vu, null), Br.default.createElement(Pu, null), l ? Br.default.createElement(ki, null) : Br.default.createElement(hu, null)));
  };
  var yH = (0, qu.forwardRef)(function (e, r) {
    var t = w(Ri);
    return qu.default.createElement(K, {
      width: "100%",
      height: t * 2,
      display: "flex",
      flexDirection: "row",
      hide: e.hide,
      ref: r,
      id: "uosc",
      justifyContent: "end",
      onMouseDown: function onMouseDown(i) {
        return i.stopPropagation;
      }
    }, qu.default.createElement(gH, _objectSpread(_objectSpread({}, e), {}, {
      width: "100%",
      height: t
    })), qu.default.createElement(pu, _objectSpread(_objectSpread({}, e), {}, {
      width: "100%",
      height: t
    })));
  });
  var Ou = j(Z());
  var rt = j(Z());
  var xH = function xH(_ref36) {
    var e = _ref36.height,
      r = _ref36.width;
    var t = w(Y),
      i = w(cu),
      a = w(Ni);
    return rt.default.createElement(K, {
      id: "osc-control",
      display: "flex",
      font: t.font,
      fontSize: t.fontSize,
      color: t.color,
      height: e,
      width: r,
      flexDirection: "column",
      justifyContent: "space-between",
      backgroundColor: i.backgroundColor,
      alignItems: "center"
    }, rt.default.createElement(K, {
      id: "osc-control-buttons1",
      display: "flex",
      justifyContent: "start",
      alignItems: "center",
      height: e
    }, rt.default.createElement(du, null), rt.default.createElement(ph, null), rt.default.createElement(za, null), rt.default.createElement(mu, null), rt.default.createElement(Cu, null), rt.default.createElement(za, null)), rt.default.createElement(pu, {
      width: "60%",
      height: e || 0
    }), rt.default.createElement(K, {
      id: "osc-control-buttons2",
      display: "flex",
      justifyContent: "end",
      alignItems: "center",
      height: e
    }, rt.default.createElement(Su, null), rt.default.createElement(xu, null), rt.default.createElement(yu, null), a ? rt.default.createElement(ki, null) : rt.default.createElement(hu, null)));
  };
  var Tu = j(Z());
  var SH = function SH(_ref37) {
    var e = _ref37.height;
    var r = w(Y),
      t = w(cu);
    return Tu.default.createElement(K, {
      id: "osc-info",
      display: "flex",
      font: r.font,
      fontSize: r.fontSize,
      color: r.color,
      height: e,
      width: "100%",
      flexDirection: "column",
      justifyContent: "start",
      alignItems: "center",
      backgroundColor: t.backgroundColor
    }, Tu.default.createElement(Iu, null), Tu.default.createElement(gu, null), Tu.default.createElement(vu, null), Tu.default.createElement(Pu, null));
  };
  var bH = (0, Ou.forwardRef)(function (e, r) {
    var t = w(Ri);
    return Ou.default.createElement(K, {
      width: "100%",
      height: t * 2,
      display: "flex",
      flexDirection: "row",
      hide: e.hide,
      ref: r,
      justifyContent: "end",
      alignItems: "end",
      id: "osc",
      onMouseDown: function onMouseDown(i) {
        return i.stopPropagation;
      }
    }, Ou.default.createElement(SH, _objectSpread(_objectSpread({}, e), {}, {
      width: "100%",
      height: t
    })), Ou.default.createElement(xH, _objectSpread(_objectSpread({}, e), {}, {
      width: "100%",
      height: t
    })));
  });
  var Au = j(Z());
  var qr = j(Z());
  var hh = j(Z());
  var wH = function wH() {
    var e = w(Y),
      r = w(le),
      _ref38 = (0, hh.useState)(!1),
      _ref39 = _slicedToArray(_ref38, 2),
      t = _ref39[0],
      i = _ref39[1],
      a = w(ie);
    return hh.default.createElement(de, {
      id: "mpv-easy-button-more-info",
      text: VU,
      title: r.moreInfo,
      width: e.width,
      height: e.height,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      enableMouseStyle: a,
      padding: e.padding,
      backgroundColor: e.backgroundColor,
      font: e.font,
      fontSize: e.fontSize,
      color: e.color,
      onMouseDown: function onMouseDown() {
        t ? pe("script-message-to console disable") : pe("script-message-to console enable"), i(function (s) {
          return !s;
        });
      },
      colorHover: e.colorHover,
      backgroundColorHover: e.backgroundColorHover
    });
  };
  var EH = function EH(_ref40) {
    var e = _ref40.height;
    var r = w(Y),
      t = w(cu),
      i = w(Ni);
    return qr.default.createElement(K, {
      id: "oscx-info",
      display: "flex",
      font: r.font,
      fontSize: r.fontSize,
      color: r.color,
      height: e,
      width: "100%",
      flexDirection: "column",
      justifyContent: "space-between",
      alignItems: "center",
      backgroundColor: t.backgroundColor
    }, qr.default.createElement(K, {
      display: "flex",
      justifyContent: "start",
      height: e,
      alignItems: "center"
    }, qr.default.createElement(mu, null), qr.default.createElement(xu, null), qr.default.createElement(Su, null)), qr.default.createElement(K, {
      display: "flex",
      height: e,
      justifyContent: "center",
      alignItems: "center"
    }, qr.default.createElement(za, null), qr.default.createElement(Iu, null), qr.default.createElement(gu, null), qr.default.createElement(du, null), qr.default.createElement(vu, null), qr.default.createElement(Pu, null), qr.default.createElement(yu, null)), qr.default.createElement(K, {
      display: "flex",
      height: e,
      justifyContent: "end",
      alignItems: "center"
    }, qr.default.createElement(Cu, null), qr.default.createElement(wH, null), i ? qr.default.createElement(ki, null) : qr.default.createElement(hu, null)));
  };
  var CH = (0, Au.forwardRef)(function (e, r) {
    var t = w(Ri);
    return Au.default.createElement(K, {
      width: "100%",
      height: t * 2,
      display: "flex",
      flexDirection: "row",
      hide: e.hide,
      ref: r,
      justifyContent: "end",
      alignItems: "end",
      id: "osc",
      onMouseDown: function onMouseDown(i) {
        return i.stopPropagation;
      }
    }, Au.default.createElement(pu, {
      width: "100%",
      height: t
    }), Au.default.createElement(EH, _objectSpread(_objectSpread({}, e), {}, {
      width: "100%",
      height: t
    })));
  });
  var Ut = j(Z());
  var IH = j(Z());
  var PH = function PH() {
    var e = w(Y),
      r = w(le),
      t = ne(),
      i = w(ie),
      a = w(dn),
      s = w(Bc),
      l = _i(Bi.map(function (d) {
        return r[d];
      })),
      p = Dc.map(function (d) {
        return {
          key: d,
          label: "".concat(s === d ? ar : sr, " ").concat(r[d].padEnd(l)),
          onSelect: function onSelect() {
            t.context.setLanguage(d);
          },
          style: a.item
        };
      });
    return IH.default.createElement(fn, {
      text: s === "cn" ? "中" : "A",
      id: "mpv-easy-button-language",
      title: r.language,
      direction: "bottom",
      items: p,
      height: e.height,
      width: e.width,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      dropdownStyle: a.button,
      enableMouseStyle: i,
      padding: a.button.padding,
      colorHover: a.button.colorHover,
      backgroundColorHover: a.button.backgroundColorHover,
      backgroundColor: a.button.backgroundColor,
      font: a.button.font,
      fontSize: e.fontSize,
      color: a.button.color,
      dropdownListStyle: a.list,
      pageDown: {
        style: a.item,
        text: mn
      },
      pageUp: {
        style: a.item,
        text: hn
      }
    });
  };
  var qH = j(Z());
  var TH = function TH() {
    var e = w(Y),
      r = w(le),
      t = ne(),
      i = w(ie),
      a = w(dn),
      s = w(cr),
      l = Bi.map(function (d) {
        return r[d].length;
      }).reduce(function (d, v) {
        return Math.max(d, v);
      }, 0),
      p = Bi.map(function (d) {
        var g = "".concat(s === d ? ar : sr, " ").concat(r[d].padEnd(l, " "));
        return {
          key: d,
          label: g,
          onSelect: function onSelect() {
            t.context.setMode(d);
          },
          style: _objectSpread(_objectSpread({}, a.item), {}, {
            justifyContent: "space-between",
            alignItems: "center"
          })
        };
      });
    return qH.default.createElement(fn, {
      id: "mpv-easy-button-theme",
      text: NU,
      title: r.theme,
      items: p,
      dropdownStyle: a.button,
      direction: "bottom",
      width: e.width,
      height: e.height,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      enableMouseStyle: i,
      padding: a.button.padding,
      colorHover: a.button.colorHover,
      backgroundColorHover: a.button.backgroundColorHover,
      backgroundColor: a.button.backgroundColor,
      font: a.button.font,
      fontSize: e.fontSize,
      color: a.button.color,
      dropdownListStyle: a.list,
      pageDown: {
        style: a.item,
        text: mn
      },
      pageUp: {
        style: a.item,
        text: hn
      }
    });
  };
  var OH = j(Z());
  var AH = function AH() {
    var e = w(Y),
      r = w(le),
      t = ne(),
      i = w(ie),
      a = w(dn),
      s = w(uu),
      l = _i(Eu),
      p = Eu.map(function (d) {
        return {
          key: d,
          label: "".concat(s === d ? ar : sr, " ").concat(r[d].padEnd(l, " ")),
          onSelect: function onSelect() {
            t.context.setUI(d);
          },
          style: _objectSpread(_objectSpread({}, a.item), {}, {
            justifyContent: "space-between"
          })
        };
      });
    return OH.default.createElement(fn, {
      id: "mpv-easy-button-ui",
      direction: "bottom",
      title: r.skin,
      items: p,
      text: UU,
      height: e.height,
      width: e.width,
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      alignItems: "center",
      enableMouseStyle: i,
      dropdownStyle: a.button,
      padding: a.button.padding,
      colorHover: a.button.colorHover,
      backgroundColorHover: a.button.backgroundColorHover,
      backgroundColor: a.button.backgroundColor,
      font: a.button.font,
      fontSize: e.fontSize,
      color: a.button.color,
      dropdownListStyle: a.list,
      onMouseDown: function onMouseDown() {},
      pageDown: {
        style: a.item,
        text: mn
      },
      pageUp: {
        style: a.item,
        text: hn
      }
    });
  };
  var _H = j(Z());
  var NH = function NH() {
    var e = w(Y),
      r = w(le),
      t = ne(),
      i = w(ie);
    return _H.default.createElement(de, {
      id: "mpv-easy-button-close",
      title: r.close,
      width: e.width,
      height: e.height,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      enableMouseStyle: i,
      padding: e.padding,
      colorHover: e.colorHover,
      backgroundColorHover: e.backgroundColorHover,
      text: kU,
      backgroundColor: e.backgroundColor,
      font: e.font,
      fontSize: e.fontSize,
      color: e.color,
      onMouseDown: function onMouseDown() {
        t.context.exit();
      }
    });
  };
  var RH = j(Z());
  var MH = function MH() {
    var e = w(Y),
      r = w(le),
      t = ne(),
      i = w(ie);
    return RH.default.createElement(de, {
      id: "mpv-easy-button-minimize",
      title: r.minimize,
      width: e.width,
      height: e.height,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      enableMouseStyle: i,
      padding: e.padding,
      colorHover: e.colorHover,
      backgroundColorHover: e.backgroundColorHover,
      text: BU,
      backgroundColor: e.backgroundColor,
      font: e.font,
      fontSize: e.fontSize,
      color: e.color,
      onMouseDown: function onMouseDown() {
        t.context.setWindowMinimized(!0);
      }
    });
  };
  var kH = j(Z());
  var DH = function DH() {
    var _r$length;
    var e = w(Y),
      r = w(sU),
      t = w(fu).maxTitleLength,
      i = au(r, t),
      a = w(Do);
    return ((_r$length = r === null || r === void 0 ? void 0 : r.length) !== null && _r$length !== void 0 ? _r$length : 0) > 0 && kH.default.createElement(de, {
      height: e.height,
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      alignItems: "center",
      text: i,
      padding: e.padding,
      backgroundColor: e.backgroundColor,
      font: e.font,
      fontSize: e.fontSize,
      color: e.color,
      colorHover: e.colorHover,
      onMouseUp: function onMouseUp() {
        if (Ea(a) || tn(a)) {
          kz(a);
          return;
        }
        if (Tt(a)) {
          Mz(a);
          return;
        }
      }
    });
  };
  var BH = (0, Ut.forwardRef)(function (_ref41, r) {
    var e = _ref41.hide;
    var t = w(Ni),
      i = w(Y),
      a = w(fu),
      s = w(Mi);
    return Ut.default.createElement(K, {
      id: "toolbar",
      ref: r,
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      font: i.font,
      fontSize: s,
      color: i.color,
      width: "100%",
      hide: e
    }, Ut.default.createElement(K, {
      position: "relative",
      display: "flex",
      justifyContent: "start",
      alignItems: "center",
      backgroundColor: a.backgroundColor,
      color: i.color,
      id: "toolbar-left"
    }, Ut.default.createElement(TH, null), Ut.default.createElement(PH, null), Ut.default.createElement(AH, null), Ut.default.createElement(DH, null)), t && Ut.default.createElement(K, {
      display: "flex",
      font: i.font,
      justifyContent: "end",
      alignItems: "center",
      backgroundColor: a.backgroundColor
    }, Ut.default.createElement(MH, null), Ut.default.createElement(ki, null), Ut.default.createElement(NH, null)));
  });
  function uSe(e, r, t) {
    return e === e && (t !== void 0 && (e = e <= t ? e : t), r !== void 0 && (e = e >= r ? e : r)), e;
  }
  var FH = uSe;
  function lSe(e, r, t) {
    return t === void 0 && (t = r, r = void 0), t !== void 0 && (t = qa(t), t = t === t ? t : 0), r !== void 0 && (r = qa(r), r = r === r ? r : 0), FH(qa(e), r, t);
  }
  var vh = lSe;
  var vr = j(Z());
  var cSe = new Ot("mouse-pos"),
    LH = vr.default.forwardRef(function (e, r) {
      var _B$children;
      var _ref42 = (0, vr.useState)({
          x: 0,
          y: 0
        }),
        _ref43 = _slicedToArray(_ref42, 2),
        t = _ref43[0],
        i = _ref43[1],
        _ref44 = (0, vr.useState)({
          x: 0,
          y: 0
        }),
        _ref45 = _slicedToArray(_ref44, 2),
        a = _ref45[0],
        s = _ref45[1],
        _ref46 = (0, vr.useState)(!0),
        _ref47 = _slicedToArray(_ref46, 2),
        l = _ref47[0],
        p = _ref47[1],
        d = ne(),
        v = w(oh),
        g = w(le),
        x = w(eU),
        S = w(uh),
        b = w(lh),
        q = w(Bc),
        E = w(cr),
        C = w(uu),
        T = w(SU),
        D = 12,
        M = 120,
        k = 12,
        W = w(Mi);
      function ee() {
        var ve = Be(),
          Ht = [];
        ve === "windows" && Ht.push({
          key: g.open,
          label: g.open,
          onSelect: function onSelect() {
            var ue = nm()[0];
            ue && d.context.playVideo(ue);
          }
        });
        var Dn = [];
        T[_t] && Dn.push({
          key: "anime4k",
          label: "anime4k",
          children: x.shaders.map(function (ue, $r) {
            var X = $r === x.current ? ar : sr;
            return {
              key: ue.key,
              label: "".concat(X, " ").concat(ue.title),
              onSelect: function onSelect() {
                var tr = ue.value,
                  Ge = ue.title;
                tr.length ? (pe("no-osd change-list glsl-shaders set \"".concat(tr, "\";")), x.osdDuration && Jr(Ge, x.osdDuration)) : (pe('no-osd change-list glsl-shaders clr "";'), x.osdDuration && Jr(Ge, x.osdDuration)), x.current = $r, d.context.setAnime4k(x);
              }
            };
          })
        });
        var ji = [{
            key: g.style,
            label: g.style,
            children: [{
              key: g.enlargeFontSize,
              label: g.enlargeFontSize,
              onSelect: function onSelect() {
                var ue = di(W + k, D, M);
                d.context.setFontSize(ue);
              }
            }, {
              key: g.reduceFontSize,
              label: g.reduceFontSize,
              onSelect: function onSelect() {
                var ue = di(W - k, D, M);
                d.context.setFontSize(ue);
              }
            }]
          }, {
            key: g.language,
            label: g.language,
            children: Dc.map(function (ue) {
              var $r = q === ue ? ar : sr,
                X = _i(Dc);
              return {
                key: g.languageChinese,
                label: "".concat($r, " ").concat(g[ue].padEnd(X)),
                onSelect: function onSelect() {
                  d.context.setLanguage(ue);
                }
              };
            })
          }, {
            key: g.more,
            label: g.more,
            children: [{
              key: g.console,
              label: g.console,
              onSelect: function onSelect() {
                pe("script-message-to console type");
              }
            }, {
              key: g.copyPath,
              label: g.copyPath,
              onSelect: function onSelect() {
                var ue = or("path");
                ue && mm(ue) && Jr("copy path to clipboard", 5);
              }
            }, {
              key: g.resetConfig,
              label: g.resetConfig,
              onSelect: function onSelect() {
                d.context.resetConfig();
              }
            }]
          }, {
            key: g.exit,
            label: g.exit,
            onSelect: function onSelect() {
              d.context.exit();
            }
          }],
          tt = [{
            key: v ? g.play : g.pause,
            label: v ? g.play : g.pause,
            onSelect: function onSelect() {
              d.context.setPause(!v);
            }
          }, {
            key: g.playlist,
            label: g.playlist,
            onSelect: function onSelect() {
              d.context.setPlaylistHide(!1);
            }
          }, {
            key: g.theme,
            label: g.theme,
            children: Bi.map(function (ue) {
              var $r = E === ue ? ar : sr,
                X = _i(Bi.map(function (Ge) {
                  return g[Ge];
                })),
                tr = "".concat($r, " ").concat(g[ue].padStart(X, " "));
              return {
                key: ue,
                label: tr,
                onSelect: function onSelect() {
                  d.context.setMode(ue);
                },
                style: {
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center"
                }
              };
            })
          }, {
            key: g.skin,
            label: g.skin,
            children: Eu.map(function (ue) {
              var $r = _i(Eu),
                tr = "".concat(C === ue ? ar : sr, " ").concat(g[ue].padEnd($r, " "));
              return {
                key: ue,
                label: tr,
                onSelect: function onSelect() {
                  d.context.setUI(ue);
                },
                style: {
                  justifyContent: "space-between",
                  alignItems: "center"
                }
              };
            })
          }, {
            key: g.videoSpeed,
            label: g.videoSpeed,
            children: b.map(function (ue) {
              var $r = ue === S ? ar : sr;
              return {
                key: "".concat(g.videoSpeed, "-").concat(ue),
                label: "".concat($r, " ").concat(ue.toString()),
                onSelect: function onSelect() {
                  S !== ue && (d.context.setSpeed(ue), Ur("speed", ue));
                }
              };
            })
          }];
        return [].concat(Ht, tt, Dn, ji);
      }
      var N = ee(),
        _ref48 = (0, vr.useState)(void 0),
        _ref49 = _slicedToArray(_ref48, 2),
        B = _ref49[0],
        U = _ref49[1],
        me = (0, vr.useRef)(null),
        be = (0, vr.useRef)(null),
        re = w(Y),
        Ne = w(ie),
        se = w(sh),
        _ref50 = (0, vr.useState)(!0),
        _ref51 = _slicedToArray(_ref50, 2),
        Qe = _ref51[0],
        Me = _ref51[1];
      return vr.default.useImperativeHandle(r, function () {
        return {
          setHide: function setHide() {
            p(!0), Me(!0);
          }
        };
      }), (0, vr.useEffect)(function () {
        lt("MOUSE_BTN2", "MOUSE_BTN2_CLICK_MENU", function () {
          if (!me.current) {
            p(!0);
            return;
          }
          var ve = cSe.value,
            Ht = yb(ve.x, ve.y, pt().layoutNode.width, pt().layoutNode.height),
            Dn = xb(me.current, ve.x, ve.y, Ht);
          i(Dn), p(!1), Me(!0);
        }, {
          forced: !0
        });
      }, []), vr.default.createElement(vr.default.Fragment, null, vr.default.createElement(K, {
        id: "click-menu-main",
        hide: l,
        ref: me,
        position: "relative",
        x: t.x,
        y: t.y,
        display: "flex",
        flexDirection: "row",
        alignContent: "stretch",
        justifyContent: "start",
        alignItems: "start",
        backgroundColor: se.backgroundColor,
        zIndex: se.zIndex
      }, N.map(function (ve, Ht) {
        var _ve$children2;
        return vr.default.createElement(de, {
          id: "click-menu-".concat(ve.key),
          key: ve.key,
          text: ve.label,
          enableMouseStyle: Ne,
          padding: re.padding,
          colorHover: re.colorHover,
          backgroundColorHover: re.backgroundColorHover,
          backgroundColor: re.backgroundColor,
          font: re.font,
          fontSize: re.fontSize,
          color: re.color,
          height: re.fontSize,
          onMouseDown: function onMouseDown(Dn) {
            var _ve$onSelect, _ve$children;
            if (Dn.stopPropagation(), (_ve$onSelect = ve.onSelect) !== null && _ve$onSelect !== void 0 && _ve$onSelect.call(ve, ve), Me(!1), (_ve$children = ve.children) !== null && _ve$children !== void 0 && _ve$children.length) {
              var _Dn$target;
              U(ve);
              var _ref52 = ((_Dn$target = Dn.target) === null || _Dn$target === void 0 ? void 0 : _Dn$target.layoutNode) || {},
                _ref52$x = _ref52.x,
                ji = _ref52$x === void 0 ? 0 : _ref52$x,
                _ref52$y = _ref52.y,
                tt = _ref52$y === void 0 ? 0 : _ref52$y,
                _ref52$width = _ref52.width,
                ue = _ref52$width === void 0 ? 0 : _ref52$width,
                _ref52$height = _ref52.height,
                $r = _ref52$height === void 0 ? 0 : _ref52$height;
              s({
                x: ji + ue,
                y: tt
              });
            } else setTimeout(function () {
              p(!0), U(void 0);
            }, 16);
          },
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          alignItems: "start",
          postfix: (_ve$children2 = ve.children) !== null && _ve$children2 !== void 0 && _ve$children2.length ? ">" : void 0
        });
      })), vr.default.createElement(K, {
        id: "click-child-menu-main",
        hide: l || Qe,
        ref: be,
        position: "relative",
        x: a.x,
        y: a.y,
        font: re.font,
        fontSize: re.fontSize,
        color: re.color,
        display: "flex",
        flexDirection: "row",
        justifyContent: "start",
        alignItems: "start",
        alignContent: "stretch",
        backgroundColor: se.backgroundColor,
        onMouseDown: function onMouseDown(ve) {
          ve.stopPropagation();
        }
      }, ((_B$children = B === null || B === void 0 ? void 0 : B.children) !== null && _B$children !== void 0 ? _B$children : []).map(function (ve) {
        return vr.default.createElement(de, _objectSpread({
          id: "click-child-menu-".concat(ve.key),
          key: ve.key,
          text: ve.label,
          enableMouseStyle: Ne,
          padding: re.padding,
          colorHover: re.colorHover,
          backgroundColorHover: re.backgroundColorHover,
          backgroundColor: re.backgroundColor,
          font: re.font,
          fontSize: re.fontSize,
          color: re.color,
          height: re.fontSize,
          onMouseDown: function onMouseDown(Ht) {
            var _ve$onSelect2;
            Ht.stopPropagation(), (_ve$onSelect2 = ve.onSelect) !== null && _ve$onSelect2 !== void 0 && _ve$onSelect2.call(ve, ve), Me(!0), p(!0);
          },
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          alignItems: "start"
        }, ve.style));
      })));
    });
  var Fc = j(Z());
  var Fi = j(Z());
  var Ub = {},
    Hb = [];
  function fSe(e, r, t) {
    var i = CL(),
      a = "".concat(JSON.stringify(i), "\n").concat(e.join("\n"));
    if (Ub[a]) return Ub[a];
    for (; Hb.length < e.length;) Hb.push(Ma("@mpv-easy/box"));
    var s = 0;
    for (var l = 0; l < e.length; l++) {
      var p = e[l],
        d = Hb[l];
      d.attributes = r, d.attributes.text = p, s = Math.max(s, Gm(d).width), t && (d.parentNode = t);
    }
    return Ub[a] = s, s;
  }
  var gh = function gh(_ref53) {
    var e = _ref53.items,
      r = _objectWithoutProperties(_ref53, _excluded4);
    var t = w(Y),
      a = w(cU).maxItemCount,
      _ref54 = (0, Fi.useState)(0),
      _ref55 = _slicedToArray(_ref54, 2),
      s = _ref55[0],
      l = _ref55[1],
      p = w(ie),
      d = a < e.length,
      v = a * (t.height + t.padding * 2),
      g = d ? a / e.length * v : 0,
      x = v - g,
      S = t.padding * 2 + s / (e.length - a) * x,
      b = e.slice(s, s + a),
      q = (0, Fi.useRef)(null),
      E = fSe(e.map(function (T) {
        return T.label;
      }), t, q.current),
      C = w(Mi);
    return Fi.default.createElement(K, {
      id: "scroll-list",
      display: "flex",
      justifyContent: "center",
      position: "relative",
      flexDirection: "row",
      alignItems: "start",
      padding: t.padding,
      borderSize: t.padding,
      borderColor: t.backgroundColorHover,
      onWheelDown: function onWheelDown(T) {
        s + a < e.length && l(s + 1);
      },
      onWheelUp: function onWheelUp(T) {
        s > 0 && l(s - 1);
      },
      zIndex: r.zIndex,
      ref: q
    }, d && Fi.default.createElement(K, {
      position: "absolute",
      id: "scroll-bar",
      top: S,
      right: 0,
      width: t.padding,
      height: g,
      backgroundColor: t.color
    }), b.map(function (_ref56, k) {
      var T = _ref56.key,
        D = _ref56.label,
        M = _ref56.onClick;
      return Fi.default.createElement(de, {
        id: "scroll-list-".concat(T),
        key: T,
        text: D,
        width: E + t.padding * 2,
        height: t.height,
        enableMouseStyle: p,
        padding: t.padding,
        colorHover: t.colorHover,
        backgroundColorHover: t.backgroundColorHover,
        backgroundColor: t.backgroundColor,
        font: t.font,
        fontSize: C,
        color: t.color,
        onClick: M
      });
    }));
  };
  var zH = function zH() {
    var e = w(dU),
      r = ne(),
      t = w(vU),
      i = (0, Fc.useRef)(null),
      a = w(ch),
      s = w(Y),
      l = 0,
      p = 0;
    if (i.current) {
      var v = pt().layoutNode.width,
        g = pt().layoutNode.height,
        x = i.current.layoutNode.width,
        S = i.current.layoutNode.height;
      l = (v - x) / 2, p = (g - S) / 2;
    }
    var d = w(Do);
    return Fc.default.createElement(K, {
      id: "playlist-main",
      ref: i,
      x: l,
      y: p,
      hide: a,
      display: "flex",
      position: "relative",
      flexDirection: "row",
      justifyContent: "start",
      alignContent: "stretch",
      alignItems: "start",
      backgroundColor: e.backgroundColor
    }, !!t.length && Fc.default.createElement(gh, {
      zIndex: e.zIndex,
      items: t.map(function (v) {
        var g = v === d ? ar : sr,
          x = au(su(v) || "", e.maxTitleLength),
          S = "".concat(g, " ").concat(x);
        return {
          key: v,
          label: S,
          onClick: function onClick(b) {
            var q = t.indexOf(v);
            q >= 0 && (pe("playlist-play-index ".concat(q)), r.context.setPath(t[q])), r.context.setPlaylistHide(!0), b.stopPropagation();
          }
        };
      })
    }));
  };
  var kn = j(Z());
  var jH = j(Z());
  var UH = function UH() {
    var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var r = w(Y),
      t = w(rU),
      i = ne(),
      a = w(ie),
      s = w(le);
    return jH.default.createElement(de, _objectSpread({
      id: "mpv-easy-button-mute",
      title: t ? s.unmute : s.mute,
      text: t ? zU : LU,
      width: r.width,
      height: r.height,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      enableMouseStyle: a,
      padding: r.padding,
      colorHover: r.colorHover,
      backgroundColorHover: r.backgroundColorHover,
      backgroundColor: r.backgroundColor,
      font: r.font,
      fontSize: r.fontSize,
      color: r.color,
      onMouseDown: function onMouseDown(l) {
        i.context.setMute(!t);
      }
    }, e));
  };
  var HH = kn.default.forwardRef(function (e, r) {
    var t = w(ih),
      i = w(ah),
      a = ne(),
      s = w(Y),
      l = w(fU),
      p = t / i,
      d = w(gU).h,
      v = w(Ri),
      x = s.height * 5,
      S = x + 2 * v + 2 * s.padding,
      b = (d - S) / 2,
      _ref57 = (0, kn.useState)(!0),
      _ref58 = _slicedToArray(_ref57, 2),
      q = _ref58[0],
      E = _ref58[1],
      _ref59 = (0, kn.useState)(0),
      _ref60 = _slicedToArray(_ref59, 2),
      C = _ref60[0],
      T = _ref60[1],
      D = w(lu),
      M = C + l.previewCursorSize / 2 / x > p ? s.color : l.backgroundColor;
    return d > S && kn.default.createElement(K, _objectSpread(_objectSpread({
      id: "voice-control",
      top: b,
      right: 0,
      width: v + 2 * s.padding,
      height: S,
      onWheelDown: function onWheelDown() {
        var k = di(t - l.step, 0, i);
        a.context.setVolume(k), Ur("volume", k);
      },
      onWheelUp: function onWheelUp() {
        var k = di(t + l.step, 0, i);
        a.context.setVolume(k), Ur("volume", k);
      },
      position: "relative",
      display: "flex",
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      padding: s.padding,
      backgroundColor: l.backgroundColor
    }, e), {}, {
      ref: r,
      hide: e.hide,
      zIndex: l.zIndex
    }), kn.default.createElement(K, {
      id: "voice-control-volume",
      fontSize: D,
      text: t.toFixed(0).toString(),
      width: s.width,
      height: s.height,
      color: s.color,
      padding: s.padding,
      display: "flex",
      justifyContent: "center",
      alignItems: "center"
    }), kn.default.createElement(K, {
      id: "voice-control-box",
      height: x,
      width: s.width - 2 * s.padding,
      display: "flex",
      position: "relative",
      flexDirection: "row",
      justifyContent: "center",
      alignItems: "center",
      borderSize: s.padding,
      borderColor: s.color,
      zIndex: l.zIndex + 2,
      onMouseDown: function onMouseDown(k) {
        var _k$target;
        E(!1);
        var W = (1 - k.offsetY / (((_k$target = k.target) === null || _k$target === void 0 ? void 0 : _k$target.layoutNode.height) || 0)) * i | 0,
          ee = di(W, 0, i);
        a.context.setVolume(ee), Ur("volume", ee);
      },
      onMouseEnter: function onMouseEnter() {
        E(!1);
      },
      onMouseMove: function onMouseMove(k) {
        var _k$target2;
        var W = ((_k$target2 = k.target) === null || _k$target2 === void 0 ? void 0 : _k$target2.layoutNode.height) || 0,
          ee = (1 - k.offsetY / W) * i | 0,
          N = di(ee, 0, i);
        E(!1), T(N / i - l.previewCursorSize / 2 / W);
      },
      onMouseLeave: function onMouseLeave(k) {
        E(!0);
      }
    }, kn.default.createElement(K, {
      id: "voice-control-box-inner",
      pointerEvents: "none",
      height: "".concat(p * 100, "%"),
      bottom: 0,
      left: 0,
      width: s.width,
      backgroundColor: s.color,
      position: "absolute",
      zIndex: l.zIndex + 1
    }), q || kn.default.createElement(K, {
      id: "voice-control-cursor",
      pointerEvents: "none",
      height: l.previewCursorSize,
      left: 0,
      bottom: "".concat(C * 100, "%"),
      width: s.width,
      position: "absolute",
      backgroundColor: M,
      zIndex: l.zIndex + 16
    })), kn.default.createElement(UH, null));
  });
  var Lc = j(Z());
  var $H = function $H() {
    var e = w(mU),
      r = ne(),
      t = w(yU),
      i = (0, Lc.useRef)(null),
      a = w(fh),
      s = w(Y),
      l = 0,
      p = 0;
    if (i.current) {
      var v = pt().layoutNode.width,
        g = pt().layoutNode.height,
        x = i.current.layoutNode.width,
        S = i.current.layoutNode.height;
      l = (v - x) / 2, p = (g - S) / 2;
    }
    var d = w(Do);
    return Lc.default.createElement(K, {
      id: "history-main",
      ref: i,
      x: l,
      y: p,
      hide: a,
      display: "flex",
      position: "relative",
      flexDirection: "row",
      justifyContent: "start",
      alignContent: "stretch",
      alignItems: "start",
      backgroundColor: e.backgroundColor
    }, !!t.length && Lc.default.createElement(gh, {
      zIndex: e.zIndex,
      items: t.map(function (v) {
        var g = v.path === d ? ar : sr,
          x = au(v.name, e.maxTitleLength),
          S = "".concat(g, " ").concat(x);
        return {
          key: v.path,
          label: S,
          onClick: function onClick(b) {
            var q = t.indexOf(v);
            q >= 0 && (r.context.setPath(t[q].path), SL(t[q].path)), r.context.setHistoryHide(!0), b.stopPropagation();
          }
        };
      })
    }));
  };
  var Li = j(Z());
  var pSe = j(Z());
  var dSe = j(Z()),
    YHe = [].concat(mL, xS, SS, dL);
  var mSe = j(Z());
  var VH = j(Z()),
    hSe = function hSe(e, r, t) {
      switch (r) {
        case "bool":
          {
            ir(e, t);
            break;
          }
        case "string":
          {
            wL(e, t);
            break;
          }
        case "number":
          {
            Ur(e, t);
            break;
          }
        case "native":
          {
            ro(e, t);
            break;
          }
        default:
          throw new Error("prop type error: ".concat(e, " ").concat(r));
      }
    };
  function vSe(e, r, t) {
    var _ref61 = (0, VH.useState)(t),
      _ref62 = _slicedToArray(_ref61, 2),
      i = _ref62[0],
      a = _ref62[1];
    return Lt(e, r, function (s, l) {
      t !== l && a(l);
    }), [i, function (s) {
      var l = typeof s == "function" ? s(i) : s;
      a(l), hSe(e, r, l);
    }];
  }
  function WH(e, r) {
    return vSe(e, "number", r);
  }
  var gSe = j(Z());
  function GH() {
    var e = w(hU),
      _WH = WH("speed", 1),
      _WH2 = _slicedToArray(_WH, 2),
      r = _WH2[0],
      t = _WH2[1],
      _ref63 = (0, Li.useState)(!1),
      _ref64 = _slicedToArray(_ref63, 2),
      i = _ref64[0],
      a = _ref64[1],
      s = w(lU),
      l = (0, Li.useRef)([]),
      p = (0, Li.useRef)(1);
    return Li.default.createElement(K, {
      id: "mpv-easy-speed",
      position: "absolute",
      display: "flex",
      width: "100%",
      height: "100%",
      justifyContent: "center",
      alignItems: "center",
      font: s,
      onMouseDown: function onMouseDown() {
        i || (p.current = r, l.current = e.steps.map(function (d) {
          return +setTimeout(function () {
            a(!0), t(d.speed);
          }, d.delay);
        }));
      },
      onMouseUp: function onMouseUp() {
        var _iterator43 = _createForOfIteratorHelper(l.current),
          _step43;
        try {
          for (_iterator43.s(); !(_step43 = _iterator43.n()).done;) {
            var d = _step43.value;
            clearTimeout(d);
          }
        } catch (err) {
          _iterator43.e(err);
        } finally {
          _iterator43.f();
        }
        a(!1), t(p.current);
      }
    }, e.showText && i && Li.default.createElement(K, {
      position: "relative",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      text: "".concat(TU, "x").concat(r)
    }));
  }
  var ySe = new On("window-maximized"),
    xSe = new On("fullscreen"),
    SSe = new sn("time-pos"),
    bSe = new sn("duration"),
    wSe = new On("pause"),
    KH = new Vs("path"),
    ESe = new Ot("mouse-pos"),
    CSe = new Ot("video-params"),
    ISe = new On("mute"),
    PSe = new sn("aid"),
    qSe = new sn("vid"),
    TSe = new sn("sid"),
    OSe = new sn("volume"),
    ASe = new sn("volume-max"),
    _Se = new sn("speed"),
    NSe = new sn("playlist/count"),
    RSe = new Ot("osd-dimensions"),
    MSe = 12,
    kSe = 120;
  function YH(e, r, t) {
    if (!e) return !1;
    if (e.layoutNode.hasPoint(r, t)) return !0;
    var _iterator44 = _createForOfIteratorHelper(e.childNodes),
      _step44;
    try {
      for (_iterator44.s(); !(_step44 = _iterator44.n()).done;) {
        var i = _step44.value;
        if (YH(i, r, t)) return !0;
      }
    } catch (err) {
      _iterator44.e(err);
    } finally {
      _iterator44.f();
    }
    return !1;
  }
  var XH = function XH(e) {
    var _M$autoHideDelay;
    var r = ne(),
      t = w(uU),
      i = w(Do),
      a = w(Zj),
      s = w(bU),
      l = w(Mi),
      p = (0, Le.useRef)(l);
    p.current = l;
    var d = w(ih),
      v = (0, Le.useRef)(d);
    v.current = d;
    var g = w(ah),
      x = w(uh),
      S = (0, Le.useRef)(x);
    S.current = x;
    var b = w(lh),
      q = Math.max.apply(Math, _toConsumableArray(b)),
      E = Math.min.apply(Math, _toConsumableArray(b));
    (0, Le.useEffect)(function () {
      var tt = tm();
      if (s !== tt) {
        var X = Rz();
        Nz(tt, X) && r.context.setProtocolHook(tt);
      }
      e.fontSize && r.context.setFontSize(e.fontSize), r.context.addHistory(i), _z(i), NSe.observe(function (X) {
        var tr = KH.value;
        if (i !== tr) {
          var Ge = cc(),
            Bo = Ge.indexOf(tr);
          r.context.setPlaylist(Ge, Bo === -1 ? 0 : Bo);
        }
      }), PSe.observe(function (X) {
        r.context.setAid(X);
      }), qSe.observe(function (X) {
        r.context.setVid(X);
      }), TSe.observe(function (X) {
        r.context.setSid(X);
      }), _Se.observe(function (X) {
        r.context.setSpeed(X);
      }), OSe.observe(function (X) {
        r.context.setVolume(X);
      }), ASe.observe(function (X) {
        r.context.setVolumeMax(X);
      }), CSe.observe(function (X) {
        r.context.setVideoParams(X !== null && X !== void 0 ? X : {});
      }), ySe.observe(function (X) {
        r.context.setWindowMaximized(X);
      }), xSe.observe(function (X) {
        r.context.setFullscreen(X);
      });
      var ue = Rn(function (X) {
        r.context.setTimePos(X !== null && X !== void 0 ? X : 0);
      }, 1e3 / t);
      SSe.observe(Rn(ue, 1e3 / t)), bSe.observe(function (X) {
        r.context.setDuration(X || 0);
      }), KH.observe(function (X) {
        var _X2, _X3;
        if (X = Nr((_X2 = X) !== null && _X2 !== void 0 ? _X2 : ""), (_X3 = X) !== null && _X3 !== void 0 && _X3.length && X !== i) {
          r.context.addHistory(X), Az(X), r.context.setPath(X);
          var tr = mi(X);
          if (!tr) return;
          var Ge = Qs(a, X, tr, js(X) || ""),
            Bo = Ge.indexOf(X);
          r.context.setPlaylist(Ge, Bo === -1 ? 0 : Bo);
        }
      });
      var $r = Rn(function (X) {
        r.context.setMousePos(X);
      }, 1e3 / t);
      ISe.observe(function (X) {
        r.context.setMute(X);
      }), wSe.observe(function (X) {
        r.context.setPause(X);
      }), ESe.observe($r, Cc), RSe.observe(Rn(function (X) {
        r.context.setOsdDimensions(X);
      }, 1e3 / t), Cc), pc("open-dialog", function () {
        var X = nm()[0];
        X && r.context.playVideo(X);
      }), pc("volume-change", function (X) {
        var tr = Number.parseFloat("".concat(X)),
          Ge = vh(v.current + tr, 0, g);
        r.context.setVolume(Ge), Ur("volume", Ge), Tn("volume: ".concat(Ge), 2);
      }), pc("fontsize-change", function (X) {
        var tr = Number.parseFloat("".concat(X)),
          Ge = vh(p.current + tr, MSe, kSe);
        r.context.setFontSize(Ge), Tn("fontsize: ".concat(Ge), 2);
      }), pc("speed-change", function (X) {
        var tr = Number.parseFloat("".concat(X)),
          Ge = vh(S.current + tr, E, q);
        r.context.setSpeed(Ge), Ur("speed", Ge), Tn("speed: ".concat(Ge), 2);
      });
    }, []);
    var C = w(lu),
      T = w(Hr),
      D = w(cr),
      M = w(fu),
      k = w(uu),
      W = w(tU),
      ee = {
        osc: bH,
        uosc: yH,
        oscx: CH
      }[k],
      N = T[D].tooltip,
      B = (0, Le.useRef)(null),
      U = (0, Le.useRef)(null),
      me = (0, Le.useRef)(null),
      be = (0, Le.useRef)(null),
      _ref65 = (0, Le.useState)(!0),
      _ref66 = _slicedToArray(_ref65, 2),
      re = _ref66[0],
      Ne = _ref66[1],
      se = W.x,
      Qe = W.y,
      _ref67 = (0, Le.useState)(!!e.initHide),
      _ref68 = _slicedToArray(_ref67, 2),
      Me = _ref68[0],
      ve = _ref68[1],
      Ht = (0, Le.useRef)(-1);
    [B.current, U.current, be.current].some(function (tt) {
      return YH(tt, se, Qe);
    }) ? (clearTimeout(Ht.current), Me && ve(!1)) : Ht.current = +setTimeout(function () {
      ve(!0);
    }, (_M$autoHideDelay = M.autoHideDelay) !== null && _M$autoHideDelay !== void 0 ? _M$autoHideDelay : 5e3);
    var ji = w(sh);
    return Le.default.createElement(Le.default.Fragment, null, Le.default.createElement(B4, {
      backgroundColor: N.backgroundColor,
      font: N.font,
      fontSize: C,
      color: N.color,
      padding: N.padding,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      zIndex: T[D].tooltip.zIndex
    }), Le.default.createElement(K, {
      id: "mpv-easy-main",
      display: "flex",
      width: "100%",
      height: "100%",
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "start",
      position: "relative",
      onMouseDown: function onMouseDown(tt) {
        var _tt$target, _tt$target2, _tt$target3;
        var ue = ((_tt$target = tt.target) === null || _tt$target === void 0 ? void 0 : _tt$target.attributes.id) === "mpv-easy-main" || ((_tt$target2 = tt.target) === null || _tt$target2 === void 0 ? void 0 : _tt$target2.attributes.id) === "mpv-easy-speed" || ((_tt$target3 = tt.target) === null || _tt$target3 === void 0 ? void 0 : _tt$target3.attributes.id) === void 0;
        setTimeout(function () {
          var _me$current;
          (_me$current = me.current) === null || _me$current === void 0 || _me$current.setHide(!0);
        }, 1 / qi), ue && (r.context.setPlaylistHide(!0), r.context.setHistoryHide(!0));
      }
    }, Le.default.createElement(BH, {
      ref: B,
      hide: Me
    }), Le.default.createElement(ee, {
      ref: U,
      hide: Me
    }), Le.default.createElement(HH, {
      ref: be,
      hide: Me
    }), !ji.disable && Le.default.createElement(LH, {
      ref: me,
      hide: re
    }), Le.default.createElement(zH, null), Le.default.createElement($H, null), Le.default.createElement(GH, null)));
  };
  var L = "@mpv-easy/easy-ui",
    QH = function QH(e, r) {
      return {
        name: L,
        create: function create() {
          var _e$L$config$enableMou;
          var t = r.store;
          t.getState().context = e, e[L].state = zb, t.subscribe(Rn(function () {
            var s = t.getState().context;
            r.saveConfig(s);
          }, Fb));
          var i = e[L].config.fps || qi;
          sj({
            fps: i,
            enableMouseMoveEvent: (_e$L$config$enableMou = e[L].config.enableMouseMoveEvent) !== null && _e$L$config$enableMou !== void 0 ? _e$L$config$enableMou : !0
          })($b.default.createElement(Sj, {
            store: t
          }, $b.default.createElement(XH, null)));
        }
      };
    };
  var ja = "@mpv-easy/copy-time",
    yh = {
      key: "ctrl+c"
    };
  function JH(e, r) {
    return [e / r, e % r];
  }
  function DSe() {
    var e = ut("time-pos") || 0,
      _JH = JH(e, 60),
      _JH2 = _slicedToArray(_JH, 2),
      r = _JH2[0],
      t = _JH2[1],
      _JH3 = JH(r, 60),
      _JH4 = _slicedToArray(_JH3, 2),
      i = _JH4[0],
      a = _JH4[1],
      s = Math.floor(t),
      l = Math.floor((t - s) * 1e3),
      p = "".concat(i.toString().padStart(2, "0"), ":").concat(a.toString().padStart(2, "0"), ":").concat(s.toString().padStart(2, "0"), ".").concat(l.toString().padStart(3, "0"));
    mm(p) ? Jr("Copied to Clipboard: ".concat(p)) : Jr("Failed to copy time to clipboard");
  }
  var ZH = function ZH(e) {
    return {
      name: ja,
      defaultConfig: yh,
      create: function create() {
        var _e$ja$key, _e$ja;
        var r = (_e$ja$key = (_e$ja = e[ja]) === null || _e$ja === void 0 ? void 0 : _e$ja.key) !== null && _e$ja$key !== void 0 ? _e$ja$key : yh.key;
        lt(r, ja, DSe);
      },
      destroy: function destroy() {
        Zd(ja);
      }
    };
  };
  var zi = "@mpv-easy/copy-screen",
    zc = {
      key: "ctrl+c",
      path: _e(Hs(), "copy_screen.tmp")
    };
  function BSe(e) {
    pe("no-osd screenshot-to-file ".concat(e)), dz(e) ? Jr("Copied to Clipboard", 5) : Jr("Failed to copy screen to clipboard", 5);
  }
  var e3 = function e3(e) {
    return {
      name: zi,
      defaultConfig: zc,
      create: function create() {
        var _e$zi$key, _e$zi, _e$zi$path, _e$zi2;
        if (!ML("pwsh")) {
          Jr("".concat(zi, " need pwsh"), 10);
          return;
        }
        var r = (_e$zi$key = (_e$zi = e[zi]) === null || _e$zi === void 0 ? void 0 : _e$zi.key) !== null && _e$zi$key !== void 0 ? _e$zi$key : zc.key,
          t = (_e$zi$path = (_e$zi2 = e[zi]) === null || _e$zi2 === void 0 ? void 0 : _e$zi2.path) !== null && _e$zi$path !== void 0 ? _e$zi$path : zc.path;
        lt(r, zi, function () {
          BSe(t);
        });
      },
      destroy: function destroy() {}
    };
  };
  var r3 = "0.1.9",
    t3 = [Lz, zj, ZH, Bj, QH, Bz, Qj, e3, Fz],
    FSe = "mpv-easy.config.json",
    xh = _e(dc(), zs),
    Uc = _e(xh, FSe),
    LSe = {
      mouseHoverStyle: !1,
      toolbar: !0
    };
  function Db() {
    var _structuredClone;
    return structuredClone((_structuredClone = {}, _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_structuredClone, Ca, XS), _t, Lj), ja, yh), ko, Dj), L, jb), io, Dz), La, Bb), zi, zc), Js, YS), "enablePlugins", _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty({}, ko, !0), L, !0), Ca, Be() === "windows"), _t, !0), ja, !1), io, !0), La, !0), zi, !1), Js, !0)), _defineProperty(_defineProperty(_structuredClone, "version", r3), "experimental", LSe)));
  }
  var jc = Db();
  function Sh(e) {
    if (!Tt(xh)) try {
      cm(xh);
    } catch (_unused70) {
      an("mkdir config dir error: ".concat(xh));
    }
    try {
      to(Uc, JSON.stringify(e, null, 2));
    } catch (_unused71) {
      an("write config file error: ".concat(Uc));
    }
  }
  function zSe() {
    try {
      return JSON.parse(rm(Uc));
    } catch (_unused72) {
      an("parse or read config file error: ".concat(Uc));
    }
    return jc;
  }
  function n3() {
    var e;
    return Tt(Uc) ? (e = zSe(), e.version !== r3 && (e = jc, Sh(jc), an("config version error: fallback to default config"))) : (Sh(jc), e = jc), e;
  }
  function jSe() {
    var e = Jj(),
      r = n3(),
      _Lb = Lb(),
      t = _Lb.state,
      i = _Lb.player;
    r[L].player = i, r[L].state = t;
    var a = {
      saveConfig: Sh,
      updatePlaylist: function updatePlaylist(s, l) {
        return e.dispatch.context.setPlaylist(s, l);
      },
      getPlaylist: function getPlaylist() {
        return e.getState().context[L].player.playlist;
      },
      setPath: function setPath(s) {
        return e.dispatch.context.setPath(s);
      },
      setPause: function setPause(s) {
        return e.dispatch.context.setPause(s);
      },
      getPath: function getPath() {
        return e.getState().context[L].player.path;
      },
      store: e
    };
    for (var _i10 = 0, _t6 = t3; _i10 < _t6.length; _i10++) {
      var s = _t6[_i10];
      var l = s(r, a);
      r.enablePlugins[l.name] && l.create && (l.create(), an("add plugin ".concat(l.name)));
    }
  }
  jSe();
})();
/*! Bundled license information:

ieee754/index.js:
  (*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> *)

buffer/index.js:
  (*!
   * The buffer module from node.js, for the browser.
   *
   * @author   Feross Aboukhadijeh <https://feross.org>
   * @license  MIT
   *)

react/cjs/react.production.min.js:
  (**
   * @license React
   * react.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

scheduler/cjs/scheduler.production.min.js:
  (**
   * @license React
   * scheduler.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react-reconciler/cjs/react-reconciler.production.min.js:
  (**
   * @license React
   * react-reconciler.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react-reconciler/cjs/react-reconciler-constants.production.min.js:
  (**
   * @license React
   * react-reconciler-constants.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

use-sync-external-store/cjs/use-sync-external-store-with-selector.production.min.js:
  (**
   * @license React
   * use-sync-external-store-with-selector.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)
*/